Notes for installing PnP drivers without signature on Windows XP

Hardlock PCI CPC, Hardlock internal PCI:

attach Hardlock device;
please make sure Windows XP dialog "Driver Signing Options" is set to Ignore or Warn
point to INF files at the FoundNewHardwareWizard;
press "Contiue Anyway" button at the "Hardware Installation" dialog box;




