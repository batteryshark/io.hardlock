

                        INSTALLING HARDLOCK DRIVERS
        Windows XP, 2000, NT4, ME, 98, 95 & Windows 3.x


In order to use Hardlock under Windows XP, 2000, NT4, ME, 98, 95 & Windows 3.x, 
the support drivers in this directory must be installed first.


Quick installation:
===================

Windows 3.x:

    Start HLDRV16.EXE to install Hardlock support from your Hardlock CD.
    or get it from ftp://ftp.aladdin.de/pub/hardlock/hldrv16.exe


Windows XP, 2000, NT4, ME, 98, 95:

    Start HLDRV32.EXE to install Hardlock support from your Hardlock CD,
    or get it from ftp://ftp.aladdin.de/pub/hardlock/hldrv32.exe


a, Installing Windows 3.x driver HARDLOCK.VXD
---------------------------------------------

   For a GUI install program, use HLDRV16.EXE !

   INSTVXD.EXE is a command line utility that can be used to install and
   deinstall the Hardlock driver.

   If you wish to do it manually, please add the following line to 386enh
   section in your Windows 3.x SYSTEM.INI file:

   [386Enh]
   device=[path\]hardlock.vxd

   Where [path\] is the directory which contains Hardlock.VxD

   If you have installed the driver while Windows 3.x is running, you will
   need to restart Windows.


b, Installing Windows Windows XP, 2000, NT4, ME, 98, 95 drivers:
---------------------------------------------------

   For a GUI install program, use HLDRV32.EXE !

   HLDINST.EXE is a command shell utility that can be used to install and
   deinstall the Hardlock driver. The installation updates the driver
   files only if they have an older version.

   The driver files are included in the install program itself, so there
   is no need to ship the driver files separately!

   Use:

     HLDINST -install

   to install Hardlock drivers. HLDINST takes the driver files from
   it's image and copies the driver to the appropriate system
   directories and starts the Hardlock service (driver). When HLDINST is
   finished, the driver is running and you can execute programs which
   access the Hardlock.

   If you want to remove the Hardlock service from the system, enter

     HLDINST -remove

   at the shell prompt. No application using the Hardlock driver should be
   running at this time. Please note, that the HLDINST stops the Hardlock
   service and removes the registry entries belonging to the Hardlock driver.


