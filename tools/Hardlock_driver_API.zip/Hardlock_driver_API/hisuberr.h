/* $Id: hisuberr.h,v 1.5 2007/02/13 15:11:14 horatiu Exp $
**
** Aladdin Device Driver Install API sub-status codes
** Copyright (c) 1996-2007 Aladdin Knowledge Systems, Ltd.
*/

#ifndef __HISUBERR_H__
#define __HISUBERR_H__

#define NO_SUB_ERROR 0

/*
 * Library errors.
 */
#define ERROR_LOAD_LIB                      0x00000001
#define ERROR_GET_PROC_ADDR                 0x00000002
#define ERROR_FREE_LIB                      0x00000003
#define ERROR_GET_VER_EX                    0x00000004
#define CANNOT_ALLOC_MEM                    0x00000005
#define ERROR_GET_DATE_FORMAT               0x00000006

/*
 * Database registry errors.
 */
#define ERROR_OPENING_REGISTRY              0x00010001
#define ERROR_CLOSING_REGISTRY              0x00010002
#define ERROR_SETTING_VALUE_REGISTRY        0x00010003
#define ERROR_DELETING_VALUE_REGISTRY       0x00010004
#define ERROR_DELETING_REGISTRY             0x00010005
#define ERROR_QUERY_REGISTRY                0x00010006
#define ERROR_CREATING_REGISTRY             0x00010007
#define ERROR_CANNOT_ADD_PCMCIA_ENTRIES     0x00010008
#define ERROR_MISSING_REG_DATA              0x00010009
#define ERROR_INVALID_REG_DATA              0x0001000a

/*
 * Services database errors.
 */
#define OPEN_SERVICE_MANAGER_ERROR          0x00020001
#define CLOSE_SERVICE_REGISTRY_ERROR        0x00020002
#define CREATE_SERVICE_ERROR                0x00020003
#define CLOSING_SERVICE_ERROR               0x00020004
#define OPEN_SERVICE_ERROR                  0x00020005
#define STOP_SERVICE_ERROR                  0x00020006
#define START_SERVICE_ERROR                 0x00020007
#define DELETING_SERVICE_ERROR              0x00020008
#define CLOSING_SERVICE_MANAGER_ERROR       0x00020009
#define LM_NOT_EXISTS                       0x00020010

/*
 * File errors.
 */
#define CANNOT_DELETE_FILE                  0x00040001
#define CANNOT_MOVE_FILE                    0x00040002
#define ERROR_CREATE_FILE                   0x00040003
#define ERROR_WRITE_FILE                    0x00040004
#define ERROR_CLOSE_FILE                    0x00040005
#define ERROR_OPEN_FILE                     0x00040006
#define COPY_FILE_ERROR                     0x00040007
#define ERROR_GET_FILE_SIZE                 0x00040008
#define CANNOT_SET_FILE_POINTER             0x00040009
#define ERROR_READ_FILE                     0x0004000a
#define ERROR_ACCESS_FILE                   0x0004000b
#define ERROR_COPY_FILE                     0x0004000c
#define ERROR_CREATE_DIRECTORY              0x0004000d

/*
 * Miscellaneous errors.
 */
#define FATAL_ERROR                         0x00080001
#define CANNOT_FIND_SECTION                 0x00080002
#define CANNOT_FIND_HASP36_SIG              0x00080003
#define ERROR_EXECUTE_GETFILEATTRIBUTE      0x00080004
#define HI_FILE_ATTRIBUTE_READONLY          0x00080005
#define SYSTEM_INI_NOT_FOUND                0x00080006

/*
 * Hardlock installation errors.
 */
#define ERROR_NOT_RUNNING_UNDER_NT          0x00090001
#define ERROR_NOTENOUGH_MEMORY              0x00090003
#define ERROR_INTERNAL_PROCESS_OVERFLOW     0x00090004
#define ERROR_CANNOT_OPEN_HARDLOCKSYS       0x00090005
#define ERROR_HARDLOCKSYS_TOO_OLD           0x00090006
#define ERROR_BUFFER_TOO_SMALL              0x00090007

/*
 * SetupApi errors.
 */
#define GET_CLASS_DEVS_ERROR                0x00000008
#define GET_DEVICE_PROPERTY_ERROR           0x00000009
#define CALL_CLASS_INSTALLER_ERROR          0x00000009
#define INSTALL_ALREADY_IN_PROGRESS         0x0000000a
#define UPDATE_DRV_FOR_PNP_ERROR            0x0000000b
#define NO_MORE_ITEMS                       0x0000000c
#define INSTALL_ROOT_ERROR                  0x0000000d

/*
 * haspds_windows & hinstd_windows dll sub error codes
 * they are in fact a mask between haspds.h error codes and 
 * 0x00100000
 */

#define     HASPDS_SUBERR_OK 			0x00100000
#define     HASPDS_SUBERR_NO_ADMIN 		0x00100001           /* not admin context */
#define     HASPDS_SUBERR_INVALID_PARAM 	0x00100002           /* invalid parameter */
#define     HASPDS_SUBERR_OS_NOT_SUPPORTED 	0x00100003 	     /* OS not supported */
#define     HASPDS_SUBERR_CAB_PCD 		0x00100004           /* cab is inconsistent with the PCD */
#define     HASPDS_SUBERR_LOAD_LIB 		0x00100005           /* error loading library */
#define     HASPDS_SUBERR_FCT_PTR 		0x00100006           /* error getprocaddress */
#define     HASPDS_SUBERR_WIN_ERR		0x00100007           /* handle the error base on GetLastError() */
#define     HASPDS_SUBERR_NO_MEM		0x00100008           /* allocation failure */
#define     HASPDS_SUBERR_MAX_PATH		0x00100009           /* Path > 256 */
#define     HASPDS_SUBERR_EOF			0x0010000A           /* end of file reached */
#define     HASPDS_SUBERR_INVALID_CFGFILE	0x0010000B           /* config file is invalid */
#define     HASPDS_SUBERR_FILE_ERROR		0x0010000C           /* file processing error */
#define     HASPDS_SUBERR_DISK_SPACE		0x0010000D           /* insufficient disk space */
#define     HASPDS_SUBERR_SETUPAPI 		0x0010000E           /* setupapi function failed */
#define     HASPDS_SUBERR_UNKNOWN 		0x0010000F           /* unknown error */
#define     HASPDS_SUBERR_REGISTRY_ACCESS 	0x00100010           /* error acessing registry */
#define     HASPDS_SUBERR_NEED_REINSERT 	0x00100011           /* devices need to be reinserted to load new drivers */
#define     HASPDS_SUBERR_HLSERVER_RUNNING 	0x00100012           /* Hardlock server is running */
#define     HASPDS_SUBERR_HSSERVER_RUNNING 	0x00100013           /* LM Server Running */
#define     HASPDS_SUBERR_STILL_DRV_PROC   	0x00100014           /* still processes accessing the hardlock driver */
#define     HASPDS_SUBERR_ALREADY_RUNNING 	0x00100015           /* another installer is already running */
#define     HASPDS_SUBERR_WIN_SETUP_RUNNING 	0x00100016           /* a windows setup is already running */
#define     HASPDS_SUBERR_INSERT_REQUIRED  	0x00100017           /* on win2k ask for a insert to finish the installation */
#define     HASPDS_SUBERR_USEFR_REQUIRED   	0x00100018           /* older installation present to uninstall the -fr option is required */
#define     HASPDS_SUBERR_USEHINST_REQUIRED  	0x00100019           /* old installer present, need to be used to complete uninstall */
#define     HASPDS_SUBERR_REBOOT_REQUIRED       0x0010001A           /* error to be used to providealso a message for that */
#define     HASPDS_SUBERR_SERVICE_NOT_INSTALLED 0x0010001B           /* drivers are not installed */
#define     HASPDS_SUBERR_UNKNOWN_PARAM     	0x0010001C           /* unknown driver parameter */
#define     HASPDS_SUBERR_INSTALL_OLD 		0x0010001D           /* current driver is older than installed on */
#define     HASPDS_SUBERR_SERVICE_NOT_STARTED 	0x0010001E           /* could not start hardlock service */
#define     HASPDS_SUBERR_SERVICE_NOT_STOPED 	0x0010001F           /* could not stop hardlock service */
#define     HASPDS_SUBERR_REMOVE_REBOOT_REQ 	0x00100020           /* reboot needed after remove */
#define     HASPDS_SUBERR_START_PROCESS 	0x00100021           /* start hasplm9x failed */  
#define     HASPDS_SUBERR_INSTALL_CAT 		0x00100022           /* problems installing a cat file */
#define     HASPDS_SUBERR_ALREADY_INSTALLED 	0x00100023	     /* drivers already installed */
#define     HASPDS_SUBERR_DRV_NEWER		0x00100024           /* installed drivers are newer */
#define     HASPDS_SUBERR_V2C 			0x00100025           /* error in V@C processing */
#define     HASPDS_SUBERR_OPEN_SCMANAGER 	0x00100026           /* could not open service manager */
#define     HASPDS_SUBERR_OPEN_SERVICE 		0x00100027           /* could not open service */
#define     HASPDS_SUBERR_QUERY_STATUS 		0x00100028           /* error querying service status */
#define     HASPDS_SUBERR_DEL_SRV 		0x00100029           /* could not uninstall service */
#define     HASPDS_SUBERR_INSTALL_PNP		0x0010002A           /* installing an inf file failed */
#define     HASPDS_SUBERR_SET_FW 		0x0010002B           /* error open ports 1947 */



#endif /* #ifndef __HISUBERR_H__ */
