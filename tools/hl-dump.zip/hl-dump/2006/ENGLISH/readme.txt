Introduction
============

Having  got  hold  of  that  archive, you have become the happy owner of memory
dumper  and algorithm  data for  emulation HL_CODE(), HL_CRYPT() functions  for
HardLock  dongles (LPT, USB and ISA/PCI-boards) producing  by  Aladdin  Company
(http://www.aladdin.co.il).

Dumper posesses the following functions:
(o) Works with any types of HardLock dongles:
    [*] by the plug method:
        - local device;
        - network device.
    [*] by the interface type:
        - LPT-dongle;
        - USB-dongle;
        - ISA/PCI-board-dongle.
    [*] by chip type:
        - Luna ASIC;
        - Flora ASIC.
(o) Dongle  access  password (Module Adress or MODAD) bruteforcing  by the user
    defined  range  (this  function  works  with local HardLock dongles only as
    dongle access password bruteforcing through the network demands *plenty* of
    time, that it comes nothing);
(o) Dongle's memory dumping by known MODAD (finded or received from the user);
(o) Full dumping of algorithm's data, need fo emulation HardLock secret
    functions HL_CODE(), HL_CRYPT().

Main features of this dumper:
- Works under almost any version of windows (95/98/NT/2004/XP/2003);
- Ability to work with the original program simultaneously, without any harm to
  the program;
- It dumps *all* information  from the dongle. After  making the  dump, you may
  throw the dongle away (if you can emulate it, of course);
- It flawlessly  works  with  modern USB-dongles, as  far  as  with  old  style
  LPT-dongles. ISA- and PCI-board dongles are also supported.

I  examined  functioning  of  the  dumper  with three HardLock dongles attached
together  with  three  different MODADs. All passed successfully. Of course, if
you  have  HardLock  dongles  simultaneously attached to your computer with the
same  MODADs, I can't give you guarantee successful dongles dumping. I suppose,
that  dongle  which is plugged first to the computer (which is located as close
as possible to the computer port), will be dumped only.

Searching in the  whole MODAD range takes about 9 hours. Usually MODAD could be
found  faster, you should be a very unlucky person if your MODAD key is located
near the end of MODAD range (0x7FFF).

The  dumper  instantly  dumps  dongles's memory, acquiring  data  for HL_CODE()
emulation takes about 12-15 min.

For  decreasing  time  of  dongle access password bruteforcing I suggest to add
hl-brut.reg  to  the registry. You may edit hl-brut.reg that it sould meet your
requirements.  If  you  use  HardLock  dongle  at the LPT1, you should keep its
adress  only,  and  if  you  use  dongle  at  the USB port, you should keep its
configuration only. After all dumper manipulation, you can undo all changes you
have made, by adding hl-orig.reg to the registry.

In  some  cases  you may  check  my webpage for  known MODAD  keys, instead  of
guessing  it yourself. URL  could be  changed, but  actually  the  document  is
located here: [6].

If  dumper  is  not  started, demanding HLVDD.DLL, then HardLock drivers is not
most likely installed or installed old version of drivers on your computer. You
should upgrade your HardLock drivers using http://www.aladdin.co.il or download
HLVDD.DLL  directly  from  my site at http://www.sporaw.ru/work/files/hlvdd.rar
(287kb) for property-sheet mode.

List of arguments for dumper starting are able to read by having started dumper
with "/?" switch in command line. To make sure, I cite help without any changes
and comments as an example. (HL-DUMP.EXE /? > HELP).

Aladdin's HardLock E-Y-E Memory/Algorithm Data Dumper (HL-DUMP) v2.1
(c) 2003-05, Sp0Raw // RDW, nikita@work [ sp0raw@mail.ru ] http://www.sporaw.ru

Syntax: HL-DUMP.EXE <Command> [MODAD] [Last MODAD]

Commands are:
<nothing> - dump HardLock data with known MODAD (asking user)
/DUMP     - dump HardLock data with specified MODAD
/BF       - bruteforce MODAD (from MODAD to Last MODAD, default 0-7FFFh)
/?        - this pseudo-help screen

Examples:
HL-DUMP.EXE                 -> you will need input MODAD to dump dongle data
HL-DUMP.EXE /DUMP           -> see above
HL-DUMP.EXE /DUMP 0x409     -> dumper will use MODAD = 1033 (0409h)
HL-DUMP.EXE /BF             -> dumper will bruteforce MODAD (0000h-7FFFh)
HL-DUMP.EXE /BF 256         -> dumper will bruteforce MODAD (0100h-7FFFh)
HL-DUMP.EXE /BF 0x420 25000 -> dumper will bruteforce MODAD (0420h-61A8h)


Structure of .REG-dumpfile format
=================================

Name   - [String] Application description or dongle function.
SN     - [Double word] Dongle  identifier  (HardLock ID)  which   is   returned
         HardLock dongle API demand (in case of USB HardLock dongles only).
Type   - [Double word] Key  type, which  is  returned  on HardLock  dongle  API
         demand. Possible values:
            1 - Local device;
            2 - Network device.
Memory - [Double word] Flag  of presence/absence  dongle memory, value  of this
         argument is returned on HardLock dongle API demand. Possible values:
            0 - 0 bytes (without memory);
            1 - 128 bytes of the dongle memory.
AC1    - [Data array] \ The byte array (8 bytes) to checkout collisions
AC2    - [Data array] / of HL_CODE() and HL_CRYPT() algorithms.
Data   - [Data array] The byte array (128 bytes) of the dongle  memory (only in
         case if dongle have memory).
Code   - [Data array] The byte array (8192 bytes) of  the  data  for  HL_CODE()
         emulation.


Structure of .DAT-dumpfile format
=================================

8192 bytes - Data  for  HL_CODE() emulation  algorithm  of  HardLock dongle (if
             dumper got it, in other case this data isn't exist in file);
128 bytes  - HardLock dongle memory data;
4 bytes    - \  
4 bytes    -  > Data  to  checkout  collisions   of  HL_CODE()  and  HL_CRYPT()
8 bytes    - /  algorithms;
4 bytes    - Dongle's ID.


Sources compiling
=================

You  need HardLock SDK (HardLock CD) for dumper sources compiling. If you don't
have it, so, some files, which I have speccially been placed for you at my site
will  be enough. You should unpack archive [1] into \INCLUDE\ directory. If you
are  going to compile .dll-version of dumper, then you need [2] too, if you are
going to compile .lib-version of dumper, then you need [3]. It is possible also
that HLVDD.DLL will be neccassary for your work (if you want to know more about
it, look above in the using topic).

If  this  links are down (for whatever reasons), please, go to the main page of
my site, perhaps, links have been changed.

[1] http://www.sporaw.ru/work/files/hl_incs.rar
[2] http://www.sporaw.ru/work/files/lib_hlvdd.rar
[3] http://www.sporaw.ru/work/files/lib_hlw32_mc.rar


Frequently asked questions (FAQ)
================================

Q: The  program  has worked  for a very  long time, going  over  something, but
   there's nothing in the end! What's the problem?
A: Please, make  sure that your  dongle is HardLock. It's a  common  mistake to
   call other  dongles (HASP, Sentinel, etc.) this name. You can  determine the
   type  of  your dongle  by verifying its look  against photos. Use the  types
   database at [4]. If  it is HardLock indeed and you can't get a dump from it,
   please contact me.

Q: I've made a dump and got .dat/.reg files. What do I do with them?
A: You  should contact  me at sp0raw@mail.ru, send me these files. You can also
   order  your  dongle's  emulation  then. Please  pack  dump  files  with  any
   archivator, for   example, RAR  or  ZIP. This   is  need   because  of  some
   antiviruses  on intermediated  nodes (mail servers) deleting attached  files
   with ".reg" extension.

Q: The  program  prints that HLVDD.DLL  is  not found when started. What's that
   file and where do I get it?
A: It means  that you  don't have the  original HardLock drivers installed. You
   can get  them from Aladdin  website or from me at [5]. You must install them
   by typing "hinstall.exe -i". You should reboot your computer then.

Q: How can I know MODAD for my program without bruteforcing it?
A: Try looking for your  program in  the up-to-date  list of MODAD's at [6]. If
   you find a MODAD which is not in the list, please contact  me and send it to
   me.

Q: My dongle  is found  by two MODADs, one of which is invalid - 4799h (18329).
   What's the problem?
A: It's absolutely normal. It happens  with reprogrammed dongles. A dongle with
   4799h MODAD is a  service Aladdin dongle. If your  dongle is found with this
   MODAD, skip it and continue the search for a real MODAD.

Q: Tried to  make a dump of dongle  using Windows XP SP2 (here may be described
   any  type of OS based on NT - author's note), but  dumper fail  with  error:
   "Cannot open HardLock driver '\\.\HARDLOCK.VXD'!". What to do?
�: This error appears because of  on your system MS ACT ("Microsoft Application
   Compatibility Toolkit") is installed, and  its settings  for console windows
   (CMD.EXE, "DOS Prompt", "Command Prompt") are initialized  for compatibility
   with Windows 9x OS. So, dumper "thinking", that  its started  on Windows 9x,
   and  it tries  to open driver  using  invalid (on that system)  name. Please
   disable "compatibility" options for dumper, and use it again.

If  this  links are down (for whatever reasons), please, go to the main page of
my site, perhaps, links have been changed.

[4] http://www.sporaw.com/work/dongles/identity.htm
[5] http://www.sporaw.ru/work/files/hinstall.exe
[6] http://www.sporaw.com/work/dongles/hl/dumps.htm


Bugs and feedback
=================

If  you  have  discovered  and perhaps corrected some annoying bugs or you have
some words to tell me (may be you have some ideas or wishes) please, contact me
and let me know all information you want to share with me.


Future plans
============

Dongle dumper update plans for the near future:
- Operation  with  HardLock  dongle directly without  usage API and drivers, it
  will  allow  to  increase speed dongle access password bruteforcing almost in
  160  times  (!!!),  that will reduce full dongle access password bruteforcing
  about several minutes.


Project changes
===============

I would like to thank man with nickname "Super" for authorized translation.

02-Feb-2006 2.1 High Level data is stored anyway, even if HL_CODE()'s low level
                dumping fault. Printing correct information about version of HL
                API.
16-Nov-2005 2.0 Dumping of Anti-Collision data is changed to some other. Binary
                dump  format is  changed  finaly. Now dumper write Dongle ID to
                binary dump too (-1 value for LPT dongles).
14-Nov-2005 1.9 Year  is not passed (who  knows me, will  understand about what
                I'm talking ;), and I come to fix some. Now detecting chip type
                (Luna ASIC, Flora ASIC). Changed  dumping  algorithm. Added FAQ
                to documentation. Added  some  additional checks. Changed  dump
                file format.
02-Feb-2005 1.8 Fixed bug: if  MODAD  was not  found in full bruteforce  range,
                dumper makes infinite loop and tries to use negatives MODADs.
12-Jul-2004 1.7 Argument /? shows filename without  the full  path. Saving dump
13-Jul-2004     to a binary file added. HL_CODE() emulation data dumping added.
                So, I changed description of the dumper. :)
25-Sep-2003 1.6 Timestamps (month part) in dumpfiles were incorrect. Fixed.
07-May-2003 1.5 Internal changes.
08-Feb-2003 1.4 Thought  that  MODAD  is  a  Signed Word, assumption  was  just
                appeared  from  it,  that  the  highest  MODAD  is  only 0x7FFF
                (32767). My small observations on dongles had confirmed it fact
                (the  highest key is 7xxxh). Thus bruteforcing range reduced in
                2  times.  (Maximum  bruteforcing time is only 9.1 hours - full
                working  day  ;). But if you will need to bruteforce to 0xFFFF,
                so  in  this  case,  you  are able to start program with "/BF 0
                0xFFFF" switch.
07-Feb-2003 1.3 (Early night) The documetation had been written.
06-Feb-2003 1.3 (Late evening) Support of HL-DUMP.INI had released.
                (Early  night)  That's  all. Full-range xxxx.REG is created. :)
                Tested with several dongles. HL-DUMP.INI was devised.
05-Feb-2003 1.3 (Late evening) I forgot  to call HL_LOGOUT() in the bruteforcer
                kernel.  Corrected  some string messages. Added the memory read
                function, now you need just to save all data to the file.
03-Feb-2003 1.2 Forgot to make  displaiyng of the help about command  line mode
                in  case  of  using  wrong  options. Now function HL_AVAIL() is
                called  before  bruteforcing  to  be sure that the computer has
                generally plugged dongle in. Dumper was able to work in no-load
                operation mode without plugged dongle before.
02-Feb-2003 1.1 (Early night) Wrote  command line options recognition, now user
                can  specify range of dongle bruteforcing (thus user can divide
                password bruteforcing into some phases).
28-Jan-2003 1.0 (Evening)  I  rewrote the  bruteforcer "kernel" ;). Now  dumper
                checks error type and continued working only if dongle does not
                found, but not Port Busy or Driver not found. :-) Removed first
                useless  check, and cycle was enlarged (but actually it was not
                clear  for  me why), and now it begins from 0 but not from 1. I
                made  console  version of the bruteforcer. Removed this useless
                GUI.
                (Early  night) Banal bruteforcer by cycle with range from 0001h
                to FFFFh was written.


Contact me
==========

You sholud contact me at the following adresses:

WWW     : http://www.sporaw.com (you are also able to download the latest
                                version of HardLock dumper here)
E-Mail  : sp0raw@mail.ru or mail@sporaw.ru
          (please, don't mail to both addresses together)
ICQ     : 667169 (or 38890179, see Contacts page at site, what is actual at
          this time)
FidoNet : 2:5030/2731.409

                                                  -- "fucking paranoiac" (c) R.
