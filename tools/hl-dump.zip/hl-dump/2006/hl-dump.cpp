/* ======================================================================= */
/* Project: Aladdin's HardLock E-Y-E Universal Dumper (HL-DUMP)            */
/* Title  : HL-DUMP.EXE (HardLock Memory/Algo Dumper Project)              */
/* Comment: Bruteforcing MODAD of HardLock and dumping memory, algo data   */
/* Version: 2.1                                                            */
/* Created: 28-Jan-2003          Update: 25-May-2006                       */
/* ----------------------------------------------------------------------- */
/* (c) 2003-06, Sp0Raw, Remote Access Network, Inc. <sp0raw@mail.ru>       */
/*                                                    http://www.sporaw.ru */
/*                                                                         */
/* This is Remote Access Network, Inc. internal source, not for publishing */
/* ----------------------------------------------------------------------- */
/* History:                                                                */
/*    < Described at README.TXT chapter "What's new" >                     */
/*                                                                         */
/* Compile:                                                                */
/*    (Any C++ compiler)     use included .cmd files                       */
/*                                                                         */
/* WARNING:                                                                */
/*    We assumes no responsibility on any side-effect in using this code   */
/* ======================================================================= */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "include/hlapi_c.h"

#define _VERSION "2.1"
#define _INIFILE "HL-DUMP.INI"
//               argv[0]
#define _DUMPER  "HL-DUMP.EXE"

// DO NOT CHANGE THIS CONSTANTS! THEY ARE USED IN ALGORITHM.
#define _FLORA_ASIC 1
#define _LUNA_ASIC  2

unsigned char RefKey[8] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
unsigned char VerKey[8] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

unsigned short int MODAD   = 0;
unsigned short int BF_Low  = 0;
unsigned short int BF_High = 0x7FFF;
unsigned short int Port    = 0;
unsigned char ChipShift = 0; // Shift (demand on chip type)
bool iniStopIfFound = true; // Stop bruteforcing if first MODAD is found
bool iniAskDesc     = true; // Ask description for every dumping dongle
bool iniWriteBinary = true; // Write binary copy of the dump
short int Status;
char timestr[20];
char Copyright[128]; // Copyright string
char DumpPath[128];  // Path to store dump in registry

int HL_ID = -1;              // ID not detected
short int HL_Type;           // Dongle type
short int HL_IsMemo = 0;     // Dongle without memory
bool HL_IsCodeDumped = false; // HL_CODE() data dumped or not?
unsigned char HL_Mem[128];   // HardLock's Memory
unsigned char HL_Code[8192]; // HardLock's Algorithm Data
unsigned char HL_AC[8 + 8];  // HardLock's Anti-Collision Data

char* GetTimeStamp(char* timestr)
{
 time_t t1;
 time(&t1);
 tm *t = localtime(&t1);
 sprintf(timestr, "%02d.%02d.%04d %02d:%02d:%02d", t->tm_mday, t->tm_mon + 1, 1900 + t->tm_year, t->tm_hour, t->tm_min, t->tm_sec);
 return timestr;
}

void PrintHelp(char* name)
{
 printf("Syntax: %s <Command> [MODAD] [Last MODAD]\n\n", name);
 printf("Commands are:\n");
 printf("<nothing> - dump HardLock data with known MODAD (asking user)\n");
 printf("/DUMP     - dump HardLock data with specified MODAD\n");
 printf("/BF       - bruteforce MODAD (from MODAD to Last MODAD, default 0-7FFFh)\n");
 printf("/?        - this pseudo-help screen\n\n");
 printf("Examples:\n");
 printf("%s                 -> you will need input MODAD to dump dongle data\n", name);
 printf("%s /DUMP           -> see above\n", name);
 printf("%s /DUMP 0x409     -> dumper will use MODAD = 1033 (0409h)\n", name);
 printf("%s /BF             -> dumper will bruteforce MODAD (0000h-7FFFh)\n", name);
 printf("%s /BF 256         -> dumper will bruteforce MODAD (0100h-7FFFh)\n", name);
 printf("%s /BF 0x420 25000 -> dumper will bruteforce MODAD (0420h-61A8h)\n\n", name);
}

void AskMODAD()
{
 printf("\nDecimal or hexadecimal numbers supported only (for example: 23166 or 0x5A7E).\n");
 printf("MODAD \"????h\" must be provided as \"0x????\" format (i.e. 2492h -> 0x2492).\n\n");
 printf("Enter MODAD to access your dongle (or press <ENTER> to exit): ");
 char MODAD_Str[7];
 fflush(stdin);
 fgets(MODAD_Str, sizeof(MODAD_Str), stdin);
 sscanf(MODAD_Str, "%i", &MODAD);
 printf("\n");
}

void ReadBoolean(FILE* INI, bool &Value)
{
 char Str[128];
 fgets(Str, sizeof(Str), INI);
 sscanf(strupr(Str), "%3s", &Str);
 if (!strcmp(Str, "YES")) Value = true;
 else if (!strcmp(Str, "NO")) Value = false;
 else
    {
     printf("Invalid data in " _INIFILE "! (\"%s\")\n", Str);
     fclose(INI);
     exit(-2);
    }
}

void ReadINI()
{
 if (FILE* INI = fopen(_INIFILE, "rt"))
    {
     ReadBoolean(INI, iniStopIfFound);
     ReadBoolean(INI, iniAskDesc);
     ReadBoolean(INI, iniWriteBinary);
     fgets(DumpPath, sizeof(DumpPath), INI);
     if (DumpPath[0] != 0x00)
        {
         DumpPath[strlen(DumpPath) - 1] = 0x00;
         if (DumpPath[strlen(DumpPath) - 1] != '\\') strcat(DumpPath, "\\");
        }
     fgets(Copyright, sizeof(Copyright), INI);
     if (Copyright[0] != 0x00) Copyright[strlen(Copyright) - 1] = 0x00;
     else strcpy(Copyright, "(c) Sp0Raw // RDW (sp0raw@mail.ru), http://www.sporaw.ru");
     strcat(Copyright, " / dumped with HL-DUMP v" _VERSION);
     fclose(INI);
    }
 else
    {
     printf("Cannot open " _INIFILE "!\n\n");
     exit(-1);
    }
}

bool DumpMemory()
{
 if (MODAD == 0) return false;
 printf("Dumping key using MODAD = %04Xh (%d).\n", MODAD, MODAD);
 HL_ID = -1; // Initializing HL ID to "ID not detected" state
 memset(HL_Mem, 0x00, sizeof(HL_Mem)); // Initializing HL Memory block

 Status = HL_LOGIN(MODAD, DONT_CARE, RefKey, VerKey);
 if (Status == STATUS_OK) // Dongle is opened, ready to dumping it
    {
     if (HL_AVAIL() != STATUS_OK) // Is dongle removed?
        {
         printf("%s (Error: %d)\n", HL_ERRMSG(Status, 0, NULL, NULL), Status);
         return false;
        }
     printf("HardLock API version: %i\n", (Word)HL_VERSION());

     HL_Type = HL_ACCINF();
     switch (HL_Type)
        {
         case LOCAL_DEVICE: printf("Local device connected.\n"); break;
         case NET_DEVICE: printf("Network device connected.\n"); break;
         default: printf("Cannot detect type of dongle! We got %d.\n", HL_Type);
        }

     Port = HL_PORTINF();
     if (Port == 0) // USB device
        {
         printf("USB device detected.\n");
         unsigned short int ID_Low, ID_High;
         if (HL_READID(&ID_Low, &ID_High) == STATUS_OK) 
            {
             HL_ID = (ID_High << 16) | ID_Low;
             printf("Dongle ID: %08Xh (%d).\n", HL_ID, HL_ID);
            }
         else printf("Cannot get dongle ID!\n");
        }
     else printf("[Remote] port: %03Xh\n", Port);

     printf("Chip type: ");
     if ((MODAD & 0x1F) == 0x1F)
        {
         ChipShift = _FLORA_ASIC;
         printf("Flora ASIC (old revision)\n");
        }
     else
        {
         ChipShift = _LUNA_ASIC;
         printf("Luna ASIC (new revision)\n");
        }

     if (HL_MEMINF() == STATUS_OK)
        {
         HL_IsMemo = 1;
         printf("Memory detected... ");
         if (HL_READBL(HL_Mem) == STATUS_OK) printf("Memory dumped.\n");
         else printf("Cannot read dongle memory!\n");
        }
     else printf("Dongle without memory.\n");

     memset(HL_AC, 0x00, sizeof(HL_AC)); // Initializing HL AC block (size: full)
     printf("Dumping Anti-Collision data (high level)... ");
     if (HL_CODE(&HL_AC[8], 1) == STATUS_OK) printf("Done.\n");
     else printf("Failed.\n");

     HL_LOGOUT();
    }
 else // We got error when tried to open dongle
    {
     printf("%s (Error: %d)\n", HL_ERRMSG(Status, 0, NULL, NULL), Status);
     return false;
    }
 return true;
}

#ifdef PUBLIC_DUMPER // Defines public version of dumper
bool DumpAlgo()
{
 // Dumping algorithm data (HL_CODE) is stripped in public sources,
 // if you have any questions, you can try to mail sp0raw@mail.ru
 printf("\nYou compiled public sources. Dumping Algorithm Data function is stripped here!\n");
 printf("Use original binaries. Sorry!\n\n");
 memset(HL_Code, 0x00, sizeof(HL_Code)); // Initializing HL Algorithm Data block
 memset(HL_AC, 0x00, sizeof(HL_AC)); // Initializing HL AC block
 return false; // HL_CODE() data is NOT dumped, don't try save it
}
#else
extern bool DumpAlgo();
#endif

void SaveDump()
{
 char filename[(4 + 1 + 3) + 1];
 char HL_Desc[128];

 HL_Desc[0] = 0x00;

 printf("Writing dump to registry file... ");
 sprintf(filename, "%04X.REG", MODAD);
 if (FILE* Dump = fopen(filename, "wt"))
    {
     fprintf(Dump, "REGEDIT4\n\n");
     fprintf(Dump, "[%s%04X]\n", DumpPath, MODAD);
     if (iniAskDesc)
        {
         printf("\nInput your description for this dump (or press <ENTER> to skip):\n");
         fflush(stdin);
         fgets(HL_Desc, sizeof(HL_Desc), stdin);
         HL_Desc[strlen(HL_Desc) - 1] = 0x00;
        }
     if (HL_Desc[0] == 0x00) sprintf(HL_Desc, "Dump for %04Xh (%d) dongle", MODAD, MODAD);
     fprintf(Dump, "\"Name\"=\"%s\"\n", HL_Desc);
     if ((HL_Type == LOCAL_DEVICE) || (HL_Type = NET_DEVICE)) fprintf(Dump, "\"Type\"=dword:%08X\n", HL_Type);
     if (HL_ID != -1) fprintf(Dump, "\"ID\"=dword:%08X\n", HL_ID);
     fprintf(Dump, "\"Memory\"=dword:%08X\n", HL_IsMemo);
     fprintf(Dump, "\"Created\"=\"%s\"\n", GetTimeStamp(timestr));
     fprintf(Dump, "\"Copyright\"=\"%s\"\n", Copyright);
     // If HardLock's Anti-Collision Data is dumped, we must save it
     if (HL_IsCodeDumped)
        {
         fprintf(Dump, "\"ACL\"=hex:"); // Anti-Collision data (low level)
         for (int i_byte = 0; i_byte < 7; i_byte++) fprintf(Dump, "%02X,", HL_AC[i_byte]);
         fprintf(Dump, "%02X\n", HL_AC[7]);
        }
     // High level data is always dumped
     fprintf(Dump, "\"HCH\"=hex:"); // HL_CODE() Anti-Collision data (high level)
     for (int i_byte = 8; i_byte < 15; i_byte++) fprintf(Dump, "%02X,", HL_AC[i_byte]);
     fprintf(Dump, "%02X\n", HL_AC[15]);
     if (HL_IsMemo == 1)
        {
         fprintf(Dump, "\"Data\"=hex:");
         for (int i_str = 0; i_str < 8; i_str++)
            {
             for (int i_byte = 0; i_byte < 15; i_byte++) fprintf(Dump, "%02X,", HL_Mem[i_str * 16 + i_byte]);
             if (i_str != 8 - 1) fprintf(Dump, "%02X,\\\n           ", HL_Mem[i_str * 16 + (16 - 1)]);
            }
         fprintf(Dump, "%02X\n", HL_Mem[128 - 1]);
        }
     // If HardLock's Algorithm Data is dumped, we must save it
     if (HL_IsCodeDumped)
        {
         fprintf(Dump, "\"Code\"=hex:");
         for (int i_str = 0; i_str < 512; i_str++)
            {
             for (int i_byte = 0; i_byte < 15; i_byte++) fprintf(Dump, "%02X,", HL_Code[i_str * 16 + i_byte]);
             if (i_str != 512 - 1) fprintf(Dump, "%02X,\\\n           ", HL_Code[i_str * 16 + (16 - 1)]);
            }
         fprintf(Dump, "%02X\n", HL_Code[8192 - 1]);
        }
     fclose(Dump);
     printf("Done.\n");
    }
 else printf("Cannot create %s file!\n", filename);

 // Writing binary copy of the dump
 if (iniWriteBinary)
    {
     printf("Writing dump to binary file... ");
     sprintf(filename, "%04X.DAT", MODAD);
     if (FILE* Dump = fopen(filename, "wb"))
        {
         fwrite(&HL_Code, sizeof(HL_Code), 1, Dump);
         fwrite(&HL_Mem, sizeof(HL_Mem), 1, Dump);
         fwrite(&HL_AC, sizeof(HL_AC), 1, Dump);
         fwrite(&HL_ID, sizeof(HL_ID), 1, Dump);
         fclose(Dump);
         printf("Done.\n\n");
        }
     else printf("Cannot create %s file!\n\n", filename);
    }
 else printf("\n");
}

void DumpDongle()
{
 if (DumpMemory())
    {
     HL_IsCodeDumped = DumpAlgo(); // Don't checking errors, because of
     SaveDump();                   // we must write memory to dump in any case
    }
}

int Bruteforce()
{
 printf("Speed of bruteforcing: 1 password for 0.9-1.1 second. So, please wait!\n\n");
 printf("%s Starting to bruteforce Module Address (MODAD)...\n", GetTimeStamp(timestr));
 printf("%s Ranges: (%04Xh-%04Xh) [%d-%d]\n", GetTimeStamp(timestr), BF_Low, BF_High, BF_Low, BF_High);
 // Must be dword, not a word. Incremenatition of loop variable placed before
 // checking range of loop, so variable will be overflowed to zero and loop
 // will be looped. ;)
 for (unsigned int BF = BF_Low; BF <= BF_High; BF++)
    {
     Status = HL_LOGIN(BF, LOCAL_DEVICE, RefKey, VerKey);
     if (Status != NO_DONGLE)
        {
         if (Status == STATUS_OK) // Dongle is opened, saving MODAD and going down
            {
             HL_LOGOUT();
             MODAD = BF;
             printf("%s Hardlock E-Y-E with Module Address: %04Xh (%d).\n\n", GetTimeStamp(timestr), MODAD, MODAD);
             if (MODAD == 0x4799)
                {
                 printf("\nAladdin's service dongle found! Probably this is collision and this dongle have\n");
                 printf("another MODAD. I will continue to bruteforce other MODADs after dumping.\n\n");
                }
             DumpDongle();
             if (MODAD != 0x4799) if (iniStopIfFound) break;
            }
         else // Driver error, port busy or something other
            {
             printf("%s %s (Error: %d), current MODAD = %04Xh (%d)\n", GetTimeStamp(timestr), HL_ERRMSG(Status, 0, NULL, NULL), Status, BF, BF);
             return -1;
            }
        }
     // Print status every ~60 seconds
     if (BF % 60 == 0) printf("%s Current MODAD = %04Xh (%d).\n", GetTimeStamp(timestr), BF, BF);
    }
 printf("%s Bruteforcing is done.", GetTimeStamp(timestr));
 if (MODAD == 0) printf(" But we did not found MODAD to open your dongle!");
 printf("\n\n");
 return 0;
}

int main(int argc, char *argv[])
{
 #ifdef PUBLIC_DUMPER
 #define ALGO_LOGO ""
 #else
 #define ALGO_LOGO "/Algorithm Data"
 #endif

 printf("Aladdin's HardLock E-Y-E Memory" ALGO_LOGO " Dumper (HL-DUMP) v" _VERSION "\n");
 printf("(c) 2003-06, Sp0Raw // RDW, nikita@work [ sp0raw@mail.ru ] http://www.sporaw.ru\n\n");

 switch (argc)
    {
     case 4:
     case 3:
     case 2:
        {
         if (!strcmp(argv[1], "/?"))
            {
             PrintHelp(_DUMPER);
             return 0;
            }
         if (!strcmp(strupr(argv[1]), "/DUMP"))
            {
             ReadINI();
             if (argc == 3) sscanf(argv[2], "%i", &MODAD);
             else AskMODAD();
             DumpDongle();
             return 0;
            }
         if (!strcmp(strupr(argv[1]), "/BF"))
            {
             switch (argc)
                {
                 case 4: sscanf(argv[3], "%i", &BF_High);
                 case 3: sscanf(argv[2], "%i", &BF_Low);
                }
             if (BF_Low > BF_High)
                {
                 printf("Sorry, but specified bruteforcing ranges are wrong! (%04Xh-%04Xh) [%d-%d]\n", BF_Low, BF_High, BF_Low, BF_High);
                 return -1;
                }
             ReadINI();
             Bruteforce();
             return 0;
            }
         PrintHelp(_DUMPER);
         break;
        }
     case 1:
        {
         printf("No arguments were given. Use \"/?\" command if you want to see help screen.\n");
         ReadINI();
         AskMODAD();
         DumpDongle();
         break;
        }
     default: PrintHelp(_DUMPER);
    }
 return 0;
}
