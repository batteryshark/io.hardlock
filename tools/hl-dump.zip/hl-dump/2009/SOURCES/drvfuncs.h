#ifndef __DRVFUNCS_H__
#define __DRVFUNCS_H__

#include "include/fastapi.h"

// [#] - not original names

// Driver level functions (low-level API)

#define df_API_INIT            0  /* 0x00 */
#define df_API_DOWN            1  /* 0x01 */
#define df_API_MULTI_SHELL_ON  2  /* 0x02 */
#define df_API_MULTI_SHELL_OFF 3  /* 0x03 */
#define df_API_MULTI_ON        4  /* 0x04 */
#define df_API_MULTI_OFF       5  /* 0x05 */
#define df_API_AVAIL           6  /* 0x06 */
#define df_API_LOGIN           7  /* 0x07 */
#define df_API_LOGOUT          8  /* 0x08 */
#define df_API_INFO            9  /* 0x09 */
#define df_API_KEYE_1_BLOCK    14 /* 0x0E HL_CRYPT()    */
#define df_API_HL_CALC         16 /* 0x10 [#] HL_CALC() */
#define df_API_KEYE            17 /* 0x11 HL_CODE()     */
#define df_API_READ            20 /* 0x14 */
#define df_API_WRITE           21 /* 0x15 */
#define df_API_SET_KEY         22 /* 0x16 [#] */
#define df_API_READBLOCK       23 /* 0x17 HL_READBL()   */
#define df_API_WRITEBLOCK      24 /* 0x18 HL_WRITEBL()  */
#define df_API_READ_ID         29 /* 0x1D HL_READID()   */
#define df_API_GET_ID_KEY      30 /* 0x1E [#] */
#define df_API_FORCE_DOWN      31 /* 0x1F */
#define df_API_NETDOWN         50 /* 0x32 */
#define df_API_ABORT           51 /* 0x33 */

// Application level functions (high-level API)
// Main part of this functions are declared in original "fastapi.h"

#define af_API_INIT              API_INIT            /* 0x00 Init API structure      */
#define af_API_DOWN              API_DOWN            /* 0x01 Free API structure      */
#define af_API_MULTI_SHELL_ON    API_MULTI_SHELL_ON  /* 0x02 MTS is enabled          */
#define af_API_MULTI_SHELL_OFF   API_MULTI_SHELL_OFF /* 0x03 MTS is disabled         */
#define af_API_MULTI_ON          API_MULTI_ON        /* 0x04 Enable MTS              */
#define af_API_MULTI_OFF         API_MULTI_OFF       /* 0x05 Disable MTS             */
#define af_API_AVAIL             API_AVAIL           /* 0x06 Dongle available?       */
#define af_API_LOGIN             API_LOGIN           /* 0x07 Login dongle server     */
#define af_API_LOGOUT            API_LOGOUT          /* 0x08 Logout dongle server    */
#define af_API_INFO              API_INFO            /* 0x09 Get API informations    */
#define af_API_KEYE              API_KEYE            /* 0x0B Use KEYE for encryption */
                                                     /*      HL_CODE()               */
#define af_API_NOTDEFINED_10     16                  /* 0x10                         */
#define af_API_READ              API_READ            /* 0x14 Read one word of dongle EEPROM  */
                                                     /*      HL_READ()                       */
#define af_API_WRITE             API_WRITE           /* 0x15 Write one word of dongle EEPROM */
                                                     /*      HL_WRITE()                      */
#define af_API_READ_BLOCK        API_READ_BLOCK      /* 0x17 Read EEPROM in one block   */
                                                     /*      HL_READBL()                */
#define af_API_WRITE_BLOCK       API_WRITE_BLOCK     /* 0x18 Write EEPROM in one block  */
                                                     /*      HL_WRITEBL()               */
#define af_API_READ_ID           API_READ_ID         /* 0x1D Read USB ID memory         */
                                                     /*      HL_READID()                */
#define af_API_FORCE_DOWN        API_FORCE_DOWN      /* 0x1F Force deinintialization    */
#define af_API_GET_TASKID        API_GET_TASKID      /* 0x20 Get TaskID from API        */
#define af_API_LOGIN_INFO        API_LOGIN_INFO      /* 0x22 Get API Login informations */
#define af_API_LMINIT            API_LMINIT          /* 0x28 LM compatible API_INIT replacement        */
#define af_API_LMPING            API_LMPING          /* 0x29 checks if LM dongle and slot is available */
#define af_API_LMINFO            API_LMINFO          /* 0x2A info about currently used LIMA            */
#define af_API_ABORT             API_ABORT           /* 0x33 Critical Error Abort       */

#define af_API_FFS_INIT           API_FFS_INIT           /* 0x0100 RUS init function, downed with API_DOWN */
#define af_API_FFS_ISRUSHL        API_FFS_ISRUSHL        /* 0x0101 Is RUS HL ?                             */
                                                         /*        HLM_ISRUSHL()                           */
#define af_API_FFS_LOGIN          API_FFS_LOGIN          /* 0x0102 RUS Login to Hardlock server            */
#define af_API_FFS_CHECK_LIC      API_FFS_CHECK_LIC      /* 0x0103 RUS Create LIS                          */
                                                         /*        HLM_CHECKALLSLOTS()                     */
#define af_API_FFS_READ_LICBLOCK  API_FFS_READ_LICBLOCK  /* 0x0104 RUS Read LIC Block                      */
#define af_API_FFS_QUERY_SLOT     API_FFS_QUERY_SLOT     /* 0x0105 RUS query slot function                 */
                                                         /*        HLM_CHECKSLOT()                         */
#define af_API_FFS_FREE_SLOT      API_FFS_FREE_SLOT      /* 0x0106 RUS free slot                           */
                                                         /*        HLM_FREESLOT()                          */
#define af_API_FFS_OCCUPY_SLOT    API_FFS_OCCUPY_SLOT    /* 0x0107 RUS occupies a slot                     */
                                                         /*        HLM_OCCUPYSLOT()                        */
#define af_API_FFS_INC_CNTR       API_FFS_INC_CNTR       /* 0x0108 RUS counter increment                   */
                                                         /*        HLM_CHECKCOUNTER()                      */
#define af_API_FFS_PARSERTB       API_FFS_PARSERTB       /* 0x0109 RUS Parse RTB                           */
#define af_API_FFS_GET_HWDEP_INFO API_FFS_GET_HWDEP_INFO /* 0x010A RUS get hardware dependent information  */
#define af_API_FFS_WRITE_LIC      API_FFS_WRITE_LIC      /* 0x010B RUS write updated license information   */
                                                         /*        HLM_WRITELICENSE()                      */
#define af_API_FSS_CHECKEXPDATE   268                    /* 0x010C [#]                                     */
                                                         /*        HLM_CHECKEXPDATE()                      */
#define af_API_FFS_GETRUSINFO     API_FFS_GETRUSINFO     /* 0x010D get RUS info                            */
                                                         /*        HLM_GETRUSINFO()                        */

#endif // __DRVFUNCS_H__
