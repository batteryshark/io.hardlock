HASP HL / SRM Q/A Table Extractor v.2.0  (public) 
build on (11:31:44 Oct 72013)

SUPPORTED QA TABLES:
Binary 4096 bytes HASP HL / HASP SRM QA Tables.

FEATURES:
Automatic scanner and extraction of supported QA tables.
Automatic append multiple table data.
Reverse table creating (QA to AQ).
					
OUTPUT:
Plain registry tables (public emulator compatible).
Crypted registry tables (useless for public).
Binary QA tables.
C/Cpp QA tables.
RAW QA tables.

COPYRIGHT:
(c) RENGTEAM 2009 - 2013

CONTACT:
Web:    http://rengteam.blogspot.com
E-Mail: rceguru@gmail.com

USAGE:
Download, unpack and run tool to any empty folder (i.e. c:\QAExtractor).

MINI FAQ:
Q: I use "Process PE file dump ..." and get message "Processed 'n' QA blocks"
   What next?
A: Tool saves recognised QA to scanned exe directory.
   So check directory for created .hvc files.
   Ignore naming scheme of .bin files.

Q: Tool not find any AQ tables. Why???
A: Make sure you scan:
   Memory dump of hasp envelope protected file (exe or dll).
   Dump enveloped file with dongle attached.
   This tool not works with new API envelope (known PE sections AKS0, AKS1, ...).

Q: I want to use it for create tables for emulator.
A: Create and install emulator.
   Run protected program. You get "Envelope unknown error".
   Dump enveloped file.
   Use QA Extractor tool.
   Return to beginning until envelope error gone. Max enveloped sections is 5.

Q: What is 'Reverse table creating (QA to AQ)?
A: Envelope table is decryption table with size 4096 bytes.
   Is 2048 (128 x 16) answers followed by 2048 (128 x 16) querys.
   Reverse table is for create correct encryption table to match decrypt table.

Q: What to make with data tool create?
A: Whatever you want :)

TODO LIST:
(very possible never will happen)
Add recursive directory scanner.
Improve search precision parameters.


DISCLAIMER OF LIABILITY:
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND!!!

RENGTEAM
