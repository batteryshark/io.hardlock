/* $Id: hierr.h,v 1.5 2002/04/11 12:57:49 chris Exp $
**
** Aladdin Device Driver Install API status codes
** Copyright (c) 1996-2002 Aladdin Knowledge Systems, Ltd.
**
** $Revision: 1.5 $
** $Author: chris $
** $Date: 2002/04/11 12:57:49 $
**
** $Log: hierr.h,v $
** Revision 1.5  2002/04/11 12:57:49  chris
** added copyright message
**
** Revision 1.4  2002/02/18 10:57:15  horatiu
** add akspccard.sys 1.01 to installer
**
** Revision 1.3  2002/02/08 16:23:42  chris
** replaced with r1.26 from dll/hinst
**
*/

#ifndef __HIERR_H__
#define __HIERR_H__

#include "hisuberr.h"

/*
 * Invalid parameter errors.
 */
#define INVALID_PARAM                           0x02000001
#define SERVICE_IS_NOT_SUPPORTED                0x02000004

/*
 * Library errors.
 */
#define CANNOT_GET_OS_TYPE                      0x02001000
#define PLATFORM_DETECTION_FAIL                 0x02001001
#define PLATFORM_UNKNOWN                        0x02001002

/*
 * Database registry errors.
 */
#define CANNOT_READ_PARAM_FROM_DBR              0x02002000
#define ERROR_UPDATE_PARAM_IN_DBR               0x02002001
#define CANNOT_WRITE_DD_VMM_TO_DBR              0x02002002
#define CANNOT_WRITE_DD_VXD_TO_DBR              0x02002003
#define CANNOT_WRITE_PARAMETERS_PARAM_IN_DBR    0x02002004
#define CANNOT_DELETE_VMM_KEY                   0x02002005
#define CANNOT_DELETE_VXD_KEY                   0x02002006
#define CANNOT_WRITE_PARAM_TO_DBR               0x02002007

#define CANNOT_WRITE_PARAM_TO_EVENTLOG          0x02002008
#define CANNOT_WRITE_HASPNT_PARAM_IN_DBR        0x02002009
#define CANNOT_WRITE_HASP_PARAM_IN_DBR          0x0200200a
#define CANNOT_DELETE_HASP_PARAM_FROM_DBR       0x0200200b
#define CANNOT_DELETE_HASPNT_KEY                0x0200200c
#define CANNOT_DELETE_EVENTLOG_KEY              0x0200200d
#define CANNOT_INSTALL_HASP386_IN_INI           0x0200200e
#define CANNOT_REMOVE_HASP386_FROM_INI          0x0200200f
#define CANNOT_INSTALL_VDD                      0x02002011
#define CANNOT_REMOVE_VDD                       0x02002012
#define CANNOT_WRITE_PCMCIA_PARAM_IN_DBR        0x02002013
#define CANNOT_DELETE_PCMCIA_KEY                0x02002014

#define CANNOT_WRITE_HARDLOCK_PARAM_IN_DBR      0x02002015
#define CANNOT_DELETE_HARDLOCK_KEY              0x02002016
#define CANNOT_INSTALL_HARDLOCKVXD_IN_INI       0x02002017
#define CANNOT_REMOVE_HARDLOCKVXD_FROM_INI      0x02002018
#define CANNOT_READ_PARAM_FROM_INI              0x02002019
#define CANNOT_DELETE_PARAM_FROM_INI            0x0200201a
#define CANNOT_WRITE_PARAM_TO_INI               0x0200201b

/*
 * File errors.
 */
#define CANNOT_WRITE_VXD_TO_DISK                0x02004001
#define CANNOT_WRITE_HASPNT_TO_DISK             0x02004002
#define CANNOT_WRITE_VDD_TO_DISK                0x02004003
#define CANNOT_WRITE_HASPUT_TO_DISK             0x02004004
#define CANNOT_WRITE_HASP386_TO_DISK            0x02004005
#define CANNOT_WRITE_LOADER_TO_DISK             0x02004006
#define CANNOT_REMOVE_VXD_FROM_DISK             0x02004007
#define CANNOT_REMOVE_HASPNT_FROM_DISK          0x02004008
#define CANNOT_REMOVE_VDD_FROM_DISK             0x02004009
#define CANNOT_REMOVE_HASPUT_FROM_DISK          0x0200400a
#define CANNOT_REMOVE_HASP386_FROM_DISK         0x0200400b
#define CANNOT_REMOVE_LOADER_FROM_DISK          0x0200400c
#define DRIVER_NOT_INSTALLED                    0x0200400d
#define CANNOT_WRITE_DYNAMIC_VXD_TO_DISK        0x0200400e
#define CANNOT_REMOVE_DYNAMIC_VXD_FROM_DISK     0x0200400f
#define CANNOT_REMOVE_USB_DRIVER_FROM_DISK      0x02004010
#define CANNOT_REMOVE_USB_INF_FILE_FROM_DISK    0x02004011
#define CANNOT_REMOVE_PCCARD_INF_FILE_FROM_DISK 0x0200401d

#define CANNOT_WRITE_USB_DRIVER_TO_DISK         0x02004012
#define CANNOT_WRITE_USB_INF_FILE_TO_DISK       0x02004013
#define CANNOT_WRITE_HARDLOCKUT_TO_DISK         0x02004014
#define CANNOT_REMOVE_HARDLOCKUT_FROM_DISK      0x02004015
#define CANNOT_WRITE_HARDLOCKVXD_TO_DISK        0x02004016
#define CANNOT_REMOVE_HARDLOCKVXD_FROM_DISK     0x02004017
#define CANNOT_WRITE_HARDLOCK_VDD_TO_DISK       0x02004018
#define CANNOT_REMOVE_HARDLOCK_VDD_FROM_DISK    0x02004019
#define CANNOT_WRITE_HARDLOCKNT_TO_DISK         0x0200401a
#define CANNOT_REMOVE_HARDLOCKNT_FROM_DISK      0x0200401b
#define CANNOT_WRITE_PCCARD_INF_FILE_TO_DISK    0x0200401c
#define CANNOT_WRITE_USB_CAT_FILE_TO_DISK       0x0200401e
#define CANNOT_WRITE_PCCARD_CAT_FILE_TO_DISK    0x0200401f
#define CANNOT_WRITE_PCCARD_SYS_FILE_TO_DISK    0x02004020

/*
 * Services database error.
 */
#define CANNOT_HANDLE_SC_MANAGER                0x02008001
#define CANNOT_ADD_LM_LOADER_IN_SERVICES        0x02008002
#define CANNOT_REMOVE_LM_LOADER_FROM_SERVICES   0x02008003
#define CANNOT_STOP_DRIVER                      0x02008004
#define CANNOT_REMOVE_DRIVER_FROM_SERVICES      0x02008005
#define CANNOT_INSTALL_DRIVER_IN_SERVICES       0x02008006
#define CANNOT_START_DRIVER                     0x02008007

/*
 * Miscellaneous errors.
 */
#define USER_HAVE_NO_ACCESS                     0x02010000
#define HASP_DD_NOT_INSTALLED_YET               0x02010001
#define INSTALLED_DEVICE_IS_NEWER               0x02010002
#define CANNOT_ACCESS_SYSTEM_INI                0x02010003
#define CANNOT_ACCESS_INSTALLED_DRIVER          0x02010004
#define PROCESSES_OPEN                          0x02010006
#define CANNOT_TERMINATE_PROCESS                0x02010007
#define DD_NOT_INSTALLED_YET                    0x02010008
#define HL_NT_SERVER_RUNNING                    0x02010009
#define CANNOT_QUERY_PROCESS                    0x0201000a

/*
 * SetupApi errors.
 */
#define CANNOT_REMOVE_VIA_SETUPAPI              0x02020000
#define CANNOT_INSTALL_VIA_SETUPAPI             0x02020001

/*
 * Successful operations.
 */
#define OPERATION_SUCCEED                       0x0210001e
#define WIN95_INSTALL_SUCCESSFUL_REBOOT         0x0210001f
#define WIN95_REMOVED_SUCCESSFUL_REBOOT         0x02100020
#define WINNT_INSTALL_SUCCESSFUL_REBOOT         0x02100021
#define INSTALL_SUCCESSFUL_REBOOT               0x02100022
#define REMOVE_SUCCESSFUL_REBOOT                0x02100023

#define WRN_HDD_NOT_INSTALLED                   0x02100101
#define WRN_LOADER_STILL_INSTALLED              0x02100102

#endif /* #ifndef __HIERR_H__ */
