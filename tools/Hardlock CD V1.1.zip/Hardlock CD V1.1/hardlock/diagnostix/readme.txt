List of Aladdin DiagnostiX Versions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This list includes improvements, bug fixes, and other relevant information.
It is arranged in descending chronological order.

-------------
November 2002
-------------

New Aladdin DiagnostiX tool

The Aladdin DiagnostiX utility is new, replacing the Aladdin Diagnostic tool.
The Aladdin DiagnostiX tool lets you check all the information in your system
relating to both HASP and Hardlock keys. 
New features
- if any HASP key is checked, will find all keys connected to different ports ( but not daisy-chained )
- provide your customer with a customized dll, allowing to check HASP without knowing passwords
- save HASP memory encrypted to report file and vendor can unpack to HASPEdit file with memory beamer
- guided creation of a nethasp.ini including server names from network scan
- create a report in xml, html or text
- run additional reporting tools and zip all the created output files
- change the environment settings for hardlock
- change the HL_SEARCH setting when testing the hardlock
- save Hardlock memory to report file and vendor can unpack to EEP-file

Known bugs and limitations on Windows 95
- msvcirt.dll required: This dll will be required by DiagnostiX. Usually this dll is not provided by Windows 95, but
  gets installed with newer applications like Internet Explorer. So please, if you encounter this problem, update your
  system or simply copy the required dll from any other system to the DiagnostiX directory.

For details about usage refer to the DiagnostiX help file.




