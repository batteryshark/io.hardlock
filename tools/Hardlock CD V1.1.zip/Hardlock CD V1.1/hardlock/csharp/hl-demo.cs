/****************************************************************************/
/**                                                                        **/
/**                      Hardlock API Demo Program                         **/
/**                                                                        **/
/**   This demo program is based on the Hardlock application interface,    **/
/**   called API, to access a Hardlock via a local or a remote port.       **/
/**   To access the Hardlock remote, HL-Server must be installed first.    **/
/**                                                                        **/
/**                     Aladdin Knowledge Systems			               **/
/**                                                                        **/
/**                               Note                                     **/
/**                               ----                                     **/
/**  The following demo program is not meant to represent a real good      **/
/**  implementation of software protection into your application. It       **/
/**  demonstrates the basic use of the Hardlock API functions and is       **/
/**  thus as short and simple as possible. Please read the manual          **/
/**  carefully to get an insight in the strategy of the implementation.    **/
/**  Please keep in mind that there is no general solution for a good      **/
/**  protection. We provide you with the necessary functions, the          **/
/**  implementation itself is up to you and your imagination.              **/
/**                                                                        **/
/** $Id: hl-demo.cs,v 1.3 2002/01/25 13:31:58 alex Exp $
/** $Date: 2002/01/25 13:31:58 $
/** $Name:  $
/** $Author: alex $
***
*******************************************************************************
** Revision history:
** $Log: hl-demo.cs,v $
** Revision 1.3  2002/01/25 13:31:58  alex
** Removed some comments for release
**
** Revision 1.2  2002/01/16 15:56:45  alex
** first beta version
**
** Revision 1.1  2002/01/04 08:49:45  alex
** Initial check-in
**
** 
/****************************************************************************/


namespace hl_demo
{
    using System;
	using System.Runtime.InteropServices;	/* Required namespace for the DllImport method */
	
	using AKS.HardlockEnums;				/* Use the Hardlock enumerations	*/

    public class HL_DEMO
    {			
		public static int Main(string[] args)
		{	
			ushort result, modad;
			byte[] RefKey = { 72,  65,  82,  68,  76,  79,  67,  75};	// RefKey 'Hardlock'
			byte[] VerKey = { 24,  76, 151, 240, 192, 122,   8, 136};	// corresponding VerKey
					
			Console.WriteLine("\nHardlock C#-Demo - Aladdin Knowledge Systems 2002");
			Console.WriteLine("--------------------------------------------------\n");

			if (args.Length != 0)
			{
				Console.WriteLine("Usage: hl-demo - no parameters required");
				return 0;
			}
		
			// Sample is using module address 29809, change here if you require different modad
			modad = 29809;

			/* Login to the hardlock */
			try 
			{										
				result = AKS.Hardlock.HL_LOGIN(modad, (ushort)AKS.HardlockEnums.HL_ACCESS.DONT_CARE, RefKey, VerKey);												
			}
			catch (DllNotFoundException loaderror)
			{
				Console.WriteLine(loaderror.Message + " Please make sure that the drivers are installed!", "Load HLVDD.DLL");
				return 0;
			}
											
			if (result != (ushort)AKS.HardlockEnums.HL_STATUS.STATUS_OK)
			{
				switch (result)
				{
					case (ushort)HL_STATUS.NETWORK_ERROR:
						Console.WriteLine("Sorry, a network error occured, maybe protocol (IPX/Netbios) not loaded!!\n");
						break;
					case (ushort)HL_STATUS.NO_DONGLE:
						Console.WriteLine("Sorry, no Hardlock with this ID found!!\n");
						break;
					case (ushort)HL_STATUS.VERSION_MISMATCH:
						Console.WriteLine("Sorry, version mismatch between API and HL-Server or device driver!!\n");
						break;
					case (ushort)HL_STATUS.TOO_MANY_USERS:
						Console.WriteLine("Sorry, too many logins to HL-Server. Login table full!!\n");
						break;
					case (ushort)HL_STATUS.INVALID_ENV:
						Console.WriteLine("Sorry, invalid environment search string!! (HL_SEARCH)\n");
						break;
					case (ushort)HL_STATUS.CANNOT_OPEN_DRIVER:
						Console.WriteLine("Sorry, cannot open driver, maybe Hardlock driver not installed!!\n");
						break;
					case (ushort)HL_STATUS.INVALID_LIC:
						Console.WriteLine("Sorry, no valid licence memory image found!! (LM)\n");
						break;
					case (ushort)HL_STATUS.NO_LICENSE:
						Console.WriteLine("Sorry, no licence information for the requested slot!! (LM)\n");
						break;
					default:
						Console.WriteLine("Sorry, an unexpected error occured!! ERROR: {0}\n", result);
						break;
				}
				return (result);
			}
			Console.WriteLine("Hardlock with module address\t\t: {0}", modad);
		
			/* ------------------------------------------------------- */
			/* Now we get some information about the  connected module */
			/* ------------------------------------------------------- */

			/* Get the API version number */
			Console.WriteLine("The API version is\t\t\t: {0}", AKS.Hardlock.HL_VERSION());
		
			/* Looking for the Hardlock with the expected coding */
			if ( AKS.Hardlock.HL_AVAIL() == (ushort) HL_STATUS.STATUS_OK)
				Console.WriteLine("The connected Hardlock is the \t\t: Test device");		
			else Console.WriteLine("The connected Hardlock is the \t\t: Not the test device");
		
			/* Now we can get some information about the connected module */
			result = AKS.Hardlock.HL_ACCINF();
			if ( (ushort) result != (ushort) HL_STATUS.STATUS_OK)
			{	
				switch (result)
				{
					case (ushort) HL_ACCESS.LOCAL_DEVICE:
						Console.WriteLine("Hardlock access is \t\t\t: Local");
						Console.WriteLine("Connected to the local port address\t: 0x{0:X4}", AKS.Hardlock.HL_PORTINF());															
						break;
					case (ushort) HL_ACCESS.NET_DEVICE:
						Console.WriteLine("Hardlock access is \t\t\t: Remote");
						Console.WriteLine("The HL-Server version is\t\t: {0}", AKS.Hardlock.HL_HLSVERS());															
						Console.WriteLine("Connected to the remote port address\t: 0x{0:X4}", AKS.Hardlock.HL_PORTINF());															
						Console.WriteLine("Number of users logged in HL-Server is\t: {0}", AKS.Hardlock.HL_USERINF());															
						Console.WriteLine("The max. number of HL-Server logins is\t: {0}", AKS.Hardlock.HL_MAXUSER());															
						break;
					default:
						Console.WriteLine("Hardlock access is \t\t\t: no access");
						break;
				}
			}

			/* Read the internal serial number of Hardlock USB Module */
			ushort IDHigh, IDLow; 
			result = AKS.Hardlock.HL_READID(out IDLow, out IDHigh);
			switch (result)
			{
					case (ushort) HL_STATUS.STATUS_OK: 
					Console.WriteLine("The serial number ID is\t\t\t: {0} (0x{1:X4})", IDHigh * 65536 + IDLow, IDHigh * 65536 + IDLow);
					break;
				case (ushort) HL_STATUS.NO_SERIALID:
					Console.WriteLine("The serial number is \t\t\t: not available for this key");
					break;
				default:
					Console.WriteLine("Cannot determine the serial ID, API error\t: {0}", result);
					break;
			}

			/* Now we encrypt the message Cryptstring[] and decrypt it again */			
			byte[] Cryptstring = {	0x2D, 0xD4, 0x16, 0xA3, 0x19, 0x5C, 0xC2, 0x18,
									0xAB, 0xA3, 0x8C, 0xDC, 0x8E, 0x66, 0xD4, 0xAB,
									0x8F, 0xC0, 0x2F, 0x19, 0x39, 0xBA, 0x76, 0x5C,
									0xE2, 0x06, 0x7C, 0x98, 0xC8, 0xA3, 0x55, 0x24,
									0x00};
						
			Console.Write("\nThe encrypted message is\t\t: ");
			for (int i=0; i<32; i++)
			{
				if ( Cryptstring[i] < 32 ) Console.Write("{0}", ".");			
				else Console.Write("{0}", Convert.ToChar(Cryptstring[i]));			
			}
			
			if ( AKS.Hardlock.HL_AVAIL() == (ushort)HL_STATUS.STATUS_OK ) 
			{
				result = AKS.Hardlock.HL_CODE( Cryptstring, 4 );
				if (result == (ushort)HL_STATUS.STATUS_OK)
				{		
					/* HL_CODE returned STATUS_OK, the message should be decrypted */
					Console.Write("\nThe decrypted message is\t\t: ");
					for (int i=0; i<32; i++)
					{
						if ( Cryptstring[i] < 32 ) Console.Write("{0}", ".");			
						else Console.Write("{0}", Convert.ToChar(Cryptstring[i]));			
					}
					/* Encode the string again */
					AKS.Hardlock.HL_CODE( Cryptstring, 4);
					Console.Write("\nEncrypted again is\t\t\t: ");
					for ( int i=0; i<32; i++)
					{
						if ( Cryptstring[i] < 32 ) Console.Write("{0}", ".");			
						else Console.Write("{0}", Convert.ToChar(Cryptstring[i]));			
					}
						Console.Write("\n");
				}	// end of HL_CODE successful
				else Console.WriteLine("\nSorry, the decryption failed!");				
							

			}	// end of if for HL_AVAIL
		
			/* We are looking for the memory option of the hardlock */ 
			result = AKS.Hardlock.HL_MEMINF();
			if ( result == (ushort) HL_STATUS.STATUS_OK)
			{
				Console.WriteLine("\nHardlock with memory\t\t\t: Yes");
				/* Now we can work with the memory. Read the string written in the */
				/* register 48 to 63 ( The RAM area ) */ 
				Console.Write("Read all registers of RAM area (Intel)\t: [");
				ushort outvalue = 0;
				for ( ushort i = 48; i < 64; i++ ) 
				{
					result = AKS.Hardlock.HL_READ( i, out outvalue);
					Console.Write("{0}{1}", Convert.ToChar((Convert.ToByte(outvalue & 255))), 
						Convert.ToChar((Convert.ToByte(outvalue >> 8)))  );
				}
				Console.WriteLine("]");
				
				/* Read the RAM & ROM memory in one block */
				
				byte[] memoryOld = new Byte[128];
				byte[] memoryNew = new Byte[128];

				Console.Write("\nRead the whole memory in one block\t: [");
				result = AKS.Hardlock.HL_READBL( memoryOld);		
				
				for (int j = 0; j < 4  ; j++ )
				{					
					for (int i = 0; i < 32; i++ )
					{					
						if ( memoryOld[i+j*32] < 32 ) Console.Write("{0}", ".");			
						else Console.Write("{0}", Convert.ToChar(memoryOld[i+j*32]));						
					}
					if ( j != 3 ) Console.Write("]ROM\n\t\t\t\t\t  [");
					else Console.Write("]RAM\n");
				}
				Console.Write("\n");		
						
				/* Write new RAM area */
				string newmemory = "This is the new RAM contents !!!";
				Console.WriteLine("Write new Hardlock RAM data (old saved)\t:  {0}", newmemory);
				
				byte[] writebuffer = new Byte[32];
				for (int i = 0; i < 32; i++)
				{	
					writebuffer[i] = Convert.ToByte(newmemory[i]);
				}
				AKS.Hardlock.HL_WRITEBL(writebuffer);

				/* Read back again */		
				Console.Write("Read contents of RAM area\t\t: [");
				result = AKS.Hardlock.HL_READBL( memoryNew);
				
				for ( int i = 96; i < 128; i++ )
				{					
					if ( memoryNew[i] < 32 ) Console.Write("{0}", ".");			
					else Console.Write("{0}", Convert.ToChar(memoryNew[i]));						
				}
				Console.Write("]\n");

				/* Now write back the old RAM contents */
				for (int i = 0; i < 32; i++)
				{	
					writebuffer[i] = Convert.ToByte(memoryOld[i+96]);
				}
				AKS.Hardlock.HL_WRITEBL(writebuffer);
					
			} // end of HL_MEMINF successful
			else
			{
				Console.WriteLine("\nHardlock with memory\t\t\t: No");
			}
			
			/* Logout from the hardlock and release the API structure */	
			result = AKS.Hardlock.HL_LOGOUT();			

			ushort language = 0;	// use English output
						
			byte[] message = new Byte[64];					
			int errresult;
			errresult = AKS.Hardlock.HL_ERRMSGB((ushort)result, language, message, 64);
			Console.WriteLine("\nNow logging out from the API returns\t: {0}",	errresult); 	
			/* We know that the returned string does not contain escape characters -> System.Text.Encoding.ASCII.GetString */
			Console.WriteLine("The error message for this status is\t: {0}", System.Text.Encoding.ASCII.GetString(message));			 
			
		return 0;
		} // end of main

    }	// end of class
} // end of namespace
