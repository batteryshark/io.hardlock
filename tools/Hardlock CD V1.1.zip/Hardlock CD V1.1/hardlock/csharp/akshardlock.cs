/****************************************************************************
/**                                                                        **
/**                              Hardlock                                  **
/**                    API-Structures and definitions                      **
/**                                                                        **
/**   This file contains some helpful defines to access a Hardlock using   **
/**   the application programing interface (API) for Hardlock.             **
/**                                                                        **
/**                       Aladdin Knowledge Systems                        **
/**                                                                        **/
/** $Id: AKSHardlock.cs,v 1.2 2002/01/25 13:31:58 alex Exp $
/** $Date: 2002/01/25 13:31:58 $
/** $Name:  $
/** $Author: alex $
***
*******************************************************************************
** Revision history:
** $Log: AKSHardlock.cs,v $
** Revision 1.2  2002/01/25 13:31:58  alex
** Removed some comments for release
**
** Revision 1.1  2002/01/16 15:56:45  alex
** first beta version
**
** Revision 1.1  2002/01/04 08:51:27  alex
** Initial check-in
**
** 
/****************************************************************************/

namespace AKS
{
    using System;
	using System.Runtime.InteropServices;	/* Required namespace for the DllImport method */

    public class Hardlock
    {
		/* This c#-class will import all the required Hardlock classes */	
		/* The functions will be used as a static function only	       */
		
		/* ------------------------------ */
		/*     Classic Hardlock API       */
		/* ------------------------------ */
		
		/* Login functions */
		
		/* HL_LOGIN */
		[DllImport("HLVDD.DLL", EntryPoint="HL_LOGIN", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_LOGIN(ushort modad, ushort access, byte[] refkey, byte[] verkey);
		/* HL_LOGOUT */
		[DllImport("HLVDD.DLL", EntryPoint="HL_LOGOUT", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_LOGOUT();
		
		/* Information about attached Hardlock */
		
		/* HL_AVAIL */
		[DllImport("HLVDD.DLL", EntryPoint="HL_AVAIL", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_AVAIL();
		/* HL_VERSION */
		[DllImport("HLVDD.DLL", EntryPoint="HL_VERSION", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_VERSION();
		/* HL_HLSVERS */
		[DllImport("HLVDD.DLL", EntryPoint="HL_HLSVERS", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_HLSVERS();
		/* HL_ACCINF */
		[DllImport("HLVDD.DLL", EntryPoint="HL_ACCINF", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_ACCINF();
		/* HL_PORTINF */
		[DllImport("HLVDD.DLL", EntryPoint="HL_PORTINF", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_PORTINF();
		/* HL_USERINF */
		[DllImport("HLVDD.DLL", EntryPoint="HL_USERINF", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_USERINF();
		/* HL_MAXUSER */
		[DllImport("HLVDD.DLL", EntryPoint="HL_MAXUSER", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_MAXUSER();
		/* HL_READID */
		[DllImport("HLVDD.DLL", EntryPoint="HL_READID", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_READID(out ushort IDLow, out ushort IDHigh);

		/* Encode/Decode function */
				
		/* HL_CODE */
		[DllImport("HLVDD.DLL", EntryPoint="HL_CODE", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_CODE(byte[] data, ushort count);	
		
		/* Memory access functions */

		/* HL_MEMINF */
		[DllImport("HLVDD.DLL", EntryPoint="HL_MEMINF", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_MEMINF();		
		/* HL_READ */
		[DllImport("HLVDD.DLL", EntryPoint="HL_READ", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_READ( ushort reg, out ushort regvalue);
				
		/* HL_READBL */
		[DllImport("HLVDD.DLL", EntryPoint="HL_READBL", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_READBL( byte[] memory);
		
		/* HL_WRITE */
		[DllImport("HLVDD.DLL", EntryPoint="HL_WRITE", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_WRITE( ushort reg, ushort regvalue);

		/* HL_WRITEBL */
		[DllImport("HLVDD.DLL", EntryPoint="HL_WRITEBL", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_WRITEBL( byte[] memory);

		/* Additional functions */
		/* HL_ABORT */
		[DllImport("HLVDD.DLL", EntryPoint="HL_ABORT", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_ABORT();
		
		/* Hardlock error routine */
		
		/* HL_ERRMSGB */
		[DllImport("HLVDD.DLL", EntryPoint="HL_ERRMSGB", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HL_ERRMSGB(ushort num, ushort options,[MarshalAs(UnmanagedType.LPArray)] byte[] errmsg, int buflen);
				
		/* ------------------------------ */
		/*     Hardlock RUS API       */
		/* ------------------------------ */
		
		/* Login functions for RUS */

		/* HLM_LOGIN */
		/*	As long as we are logged in to the API we have to lock the VKey */
		/*  from access of the GC, because the API remembers the reference! */
		/*  Otherwise you will get RUS_INVALID_VK when using HLM-functions  */
		/*  For pinning the VKey use code like								*/	
		/*	GCHandle VKeyHandle = GCHandle.Alloc(VKey, GCHandleType.Pinned);*/
		[DllImport("HLVDD.DLL", EntryPoint="HLM_LOGIN", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HLM_LOGIN(ushort modad, ushort access, byte[] refkey, byte[] verkey, byte[] vkey, int RUSOptions, byte[] SearchStr);
		/* HLM_LOGOUT */
		[DllImport("HLVDD.DLL", EntryPoint="HLM_LOGOUT", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HLM_LOGOUT();

		/* Query the RUS information of the RUS Hardlock */

		/* HLM_ISRUSHL */
		[DllImport("HLVDD.DLL", EntryPoint="HLM_ISRUSHL", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HLM_ISRUSHL(out int rusid);
		/* HLM_CHECKEXPDATE */
		[DllImport("HLVDD.DLL", EntryPoint="HLM_CHECKEXPDATE", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HLM_CHECKEXPDATE(int slot, out ushort year, out ushort month, out ushort day);
		/* HLM_CHECKCOUNTER */
		[DllImport("HLVDD.DLL", EntryPoint="HLM_CHECKCOUNTER", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HLM_CHECKCOUNTER(ushort incvalue, out int maxcounter, out int currentcounter);
		/* HLM_OCCUPYSLOT */
		[DllImport("HLVDD.DLL", EntryPoint="HLM_OCCUPYSLOT", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HLM_OCCUPYSLOT(int slot);
		/* HLM_FREESLOT */
		[DllImport("HLVDD.DLL", EntryPoint="HLM_FREESLOT", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HLM_FREESLOT(int slot);
		/* HLM_CHECKSLOT */
		[DllImport("HLVDD.DLL", EntryPoint="HLM_CHECKSLOT", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HLM_CHECKSLOT(int slot, out int maxuser, out int curruser);
		/* HLM_GETRUSINFO */
		[DllImport("HLVDD.DLL", EntryPoint="HLM_GETRUSINFO", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HLM_GETRUSINFO (ref int BufLen, byte[] Buffer, ushort Base64);
		/* HLM_WRITELICENSE */
		[DllImport("HLVDD.DLL", EntryPoint="HLM_WRITELICENSE", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HLM_WRITELICENSE (int BufLen, byte[] Buffer, ushort Access, byte[] SearchStr, ushort Options);		
		/* HLM_CHECKALLSLOTS */
		[DllImport("HLVDD.DLL", EntryPoint="HLM_CHECKALLSLOTS", CallingConvention = CallingConvention.StdCall)]
		public static extern ushort HLM_CHECKALLSLOTS (ref int BufLen, byte[] licstruct);		
		
		/* Static function to convert the byte array to a license struct */
		public static void ByteArrayToHL_LIS( ref byte[] array, out AKS.HardlockStructs.HL_LIS structure )
		{
			uint length = (uint)array.Length;
			//uint numslots = (uint)(length-16)/12;	
			/* Initializing the HL_LIS structure */
			structure.current_date = (ushort)(array[0] + (array[1]<<8));
			structure.res = (ushort) 0;		/* array[2] and array[3] */
			structure.num_slots = (ushort)(array[4] + (array[5]<<8) + (array[6]<<16) + (array[7]<<24));
			structure.glob_exp_date = (ushort)(array[8] + (array[9]<<8));
			structure.res2 = (ushort) 0;	/* array[10] and array[11] */
			structure.slots = new AKS.HardlockStructs.HL_SIS[structure.num_slots];
			
			for (int i = 0; i < structure.num_slots; i++)
			{			
			structure.slots[i].max_user = (uint)(array[12+i*12] + (array[13+i*12]<<8) + (array[14+i*12]<<16) + (array[15+i*12]<<24));
			structure.slots[i].cur_user = (uint)(array[16+i*12] + (array[17+i*12]<<8) + (array[18+i*12]<<16) + (array[19+i*12]<<24));
			structure.slots[i].exp_date = (ushort)(array[20+i*12] + (array[21+i*12]<<8));
			structure.slots[i].flag = (byte)(array[22+i*12]);
			structure.slots[i].res = (byte)(array[23+i*12]);			
			}
		}
		
		/* Static function to convert the API days to Day/Month/Year */
		public static void ConvertAPIDaysToDate( ushort days, out ushort Day, out ushort Month, out ushort Year )
		{
			uint scalar, temp;		
			scalar = (uint) (days + 730120 - 365);

			for (temp = (uint)((scalar * 400L) / 146097); yearstodays(temp) < scalar; temp++);

			Year = (ushort) temp;
			temp = (scalar - yearstodays(temp-1));
			if (temp > 59)
			{
				temp += 2;
				if ((bool)(leap(Year)))
					temp -= (uint)(temp > 62 ? 1 : 2);
			}
			Month = (ushort) ((temp * 100 + 3007) / 3057);
			Day = (ushort) (temp - monthstodays(Month));

			return;
		}
		
		/* Date helper functions:										*/
		private static bool leap (uint yr)
		{return ((bool)(yr % 400 == 0)) || ((bool)(yr % 4 == 0) && (bool)(yr % 100 != 0));}

		private static uint monthstodays (uint month)
		{return (month * 3057 - 3007) / 100;}

		private static uint yearstodays (uint yr)
		{return yr * 365 + yr / 4 - yr / 100 + yr / 400;}
    }
    
    namespace HardlockStructs
    {
		/* ------------------------------------------ */
		/* The required structs for HLM_CHECKALLSLOTS */
		/* ------------------------------------------ */
		[StructLayout(LayoutKind.Explicit)] // not required anymore
		public struct HL_SIS
		{
			[FieldOffset(0)] public uint max_user;
			[FieldOffset(4)] public uint cur_user;
			[FieldOffset(8)] public ushort	exp_date;
			[FieldOffset(10)] public byte flag;
			[FieldOffset(11)] public byte res;		/* filler to make structure size multiple of 4 bytes */	
			/* size of HL_SIS is 12 Bytes -> use to calculate the maximum size of slots  */	
		}
		
		[StructLayout(LayoutKind.Explicit)]
		public struct HL_LIS
		{
			[FieldOffset(0)] public ushort current_date;
			[FieldOffset(2)] public ushort res;		/* filler to make size multiple of 4 bytes */
			[FieldOffset(4)] public uint num_slots;
			[FieldOffset(8)] public ushort glob_exp_date;
			[FieldOffset(10)] public ushort res2;	/* filler to make size multiple of 4 bytes */
			[FieldOffset(12)] public HL_SIS[] slots;	
		}		
	}
    
	namespace HardlockEnums
	{
		/* ------------------------------ */
		/* Some useful enums for Hardlock */
		/* ------------------------------ */
	
		/* Access modes for login */
		enum HL_ACCESS: ushort 
		{
		LOCAL_DEVICE =   1,               /* Query local HL only         */
		NET_DEVICE   =   2,               /* Query remote HL only        */
		DONT_CARE    =   3				  /* Try local then remote		 */
		}

		/* Return codes for API calls */
		enum HL_STATUS: ushort
		{
			STATUS_OK				=    0,		/* API call was succesfull                */
			NOT_INIT				=    1,		/* DONGLE not initialized                 */
			ALREADY_INIT			=    2,		/* Already initialized                    */
			UNKNOWN_DONGLE			=    3,		/* Device not supported                   */
			UNKNOWN_FUNCTION		=    4,		/* Function not supported                 */
			HLS_FULL				=    6,		/* HL-Server login table full             */
			NO_DONGLE				=    7,		/* No device available                    */
			NETWORK_ERROR			=	 8,		/* A network error occured                */
			NO_ACCESS				=	 9,		/* No device available                    */
			INVALID_PARAM			=	10,     /* A wrong parameter occured              */
			VERSION_MISMATCH		=   11,     /* HL-Server not API version              */
			DOS_ALLOC_ERROR			=   12,     /* Error on memory allocation             */
			CANNOT_OPEN_DRIVER		=   14,     /* Can not open Hardlock driver           */
			INVALID_ENV				=   15,     /* Invalid environment string             */
			DYNALINK_FAILED			=   16,     /* Unable to get a function entry         */
			INVALID_LIC				=   17,     /* No valid licence info (LM)             */
			NO_LICENSE				=   18,     /* Slot/licence not enabled (LM)          */
			PORT_BUSY				=   19,     /* Cannot acquire port                    */
			RUS_NO_DEVICE			=   20,     /* Key is no Hardlock RUS key             */
			RUS_INVALID_LIC			=   21,     /* Invalid RUS license                    */
			RUS_SYNC_ERR			=   22,     /* FIB in key and api struc mismatch      */
			NOT_IMPLEMENTED			=   23,     /* not (yet) implemented                  */
			BUFFER_TOO_SMALL		=	24,     /* Buffer for function too small          */
			UNKNOWN_HW_TYPE			=	25,     /* unknown hardware descriptor            */
			RUS_INV_FBPOS			=	26,     /* unknown fixed block position           */
			RUS_INVALID_SLOT		=	27,     /* Non-existing slot number given         */
			RUS_DATE_FAKE			=	28,     /* RUS Date fake detected                 */
			RUS_COUNT_DOWN			=	29,     /* RUS dead counter limit reached         */
			RUS_INVALID_VK			=	30,     /* RUS Vendor key is invalid              */
			RUS_NO_LIC_FILE			=	31,     /* RUS License file not found             */
			RUS_INV_VBLOCK			=	32,     /* RUS invalid variable block             */
			RUS_LIC_FILE_WRITE_ERR	=	33,     /* error writing (updated) license file   */
			RUS_NO_INFO_AVAILABLE	=	34,     /* GET_HWDEP_INFO: no info there          */
			RUS_INFO_PACK_ERR		=	35,     /*    "  "  "  " : cannot TLV encode data */
			RUS_LIC_WRITE_ERR		=	36,     /* write license failed                   */
			RUS_DATE_EXPIRED		=	37,     /* RUS Expiration Date reached.           */
			TS_DETECTED				=	38,     /* Term. Server / Citrix Winframe detected*/
			RUS_INVALID_RTB			=	39,     /* Invalid updated data (RTB)             */
			RUS_RTB_EXPIRED			=	40,     /* Update data (RTB) has expired.         */
			RUS_SERIAL_MISMATCH		=	41,     /* Update data serial does not match      */
			TOO_MANY_USERS			=	256,    /* Login table full (remote)              */
			SELECT_DOWN				=	257,    /* Printer not On-line                    */
			NO_SERIALID				=	258     /* Serial ID not readable or n/a          */

		}
	}

}
