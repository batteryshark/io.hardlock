/****************************************************************************/
/**                                                                        **/
/**                        Hardlock Demo Program                           **/
/**                                                                        **/
/**   This demo program is based on the Hardlock application interface,    **/
/**   called API, to access a Hardlock via a local or a remote port.       **/
/**   To access the Hardlock remote, HL-Server must be installed first.    **/
/**                                                                        **/
/**                   Aladdin Knowledge Systems, Germany                   **/
/**                                                                        **/
/**              Computer: IBM PC or compatible                            **/
/**              OS      : MS-PC/DOS 2.0 or higher                         **/
/**              Language: 32 bit C                                        **/
/**                                                                        **/
/**                               Note                                     **/
/**                               ----                                     **/
/**  The following demo program is not meant to represent a real good      **/
/**  implementation of software protection into your application. It       **/
/**  demonstrates the basic use of the Hardlock API functions and is       **/
/**  thus as short and simple as possible. Please read the manual          **/
/**  carefully to get an insight in the strategy of the implementation.    **/
/**  Please keep in mind that there is no general solution for a good      **/
/**  protection. We provide you with the necessary functions, the          **/
/**  implementation itself is up to you and your imagination.              **/
/**                                                                        **/
/**  Revision history                                                      **/
/**  ----------------
***  $Log: hardlock.c $
***  Revision 1.5  1998/06/17 16:37:20  Henri
***  Added HL_READID().
***  
***  Revision 1.4  1997/02/10 09:12:00  henri
***  Added messages for LM.
***
***  Revision 1.3  1996/08/12 13:54:20  henri
***  Added VCS log.
***
***
**/
/***************************************************************************/

#include <stdio.h>
#include <adslib.h>
#include "HLAPI_C.H"

void HardlockDemo (void);

/* ------------------------------------------------------------------------ */
/* Module address of Hardlock test device and RefKey/VerKey. We generated   */
/* the VerifyKey with TESTAPI.EXE. The API use the keys to identify the     */
/* Hardlock with the correct encoding.                                      */
/* The keys defined here are only valid for the demo module.                */
/* You have to change module address AND VerKey for your specific Hardlock! */
/* ------------------------------------------------------------------------ */
#define MODAD  29809
Byte RefKey[8] = {"HARDLOCK"};
Byte VerKey[8] = {0x18,0x4C,0x97,0xF0,0xC0,0x7A,0x08,0x88};

/* ----------------------------------------- */
/* CryptStr contains the encrypted message : */
/* "The Answer to the Great Question"        */
/* (only valid for the demo module).         */
/* ----------------------------------------- */
char CryptStr[33] =
   {0x2D, 0xD4, 0x16, 0xA3, 0x19, 0x5C, 0xC2, 0x18,
    0xAB, 0xA3, 0x8C, 0xDC, 0x8E, 0x66, 0xD4, 0xAB,
    0x8F, 0xC0, 0x2F, 0x19, 0x39, 0xBA, 0x76, 0x5C,
    0xE2, 0x06, 0x7C, 0x98, 0xC8, 0xA3, 0x55, 0x24,
    0x00};

/***************************************************************************/
/*  MAIN  --   Main ADS transaction processor.                             */
/***************************************************************************/

void main(argc, argv)
  int argc;
  char *argv[];
{
    int stat, scode = RSRSLT;

    ads_init(argc, argv);             /* Initialise the application */

    while (1) {    /* Main dispatch loop. */
        if ((stat = ads_link(scode)) < 0) {
            printf("Bad status from ads_link() = %d\n", stat);
            exit(1);
        }

        scode = RSRSLT;               /* Default return code */

        switch (stat) {

        case RQXLOAD:                 /* Load functions. */
            scode = -(funcload() ? RSRSLT : RSERR);
            break;

        case RQSUBR:                  /* Evaluate external lisp function */
            acad_dofunc();
            break;

        default:
            break;
}   }   }

/***************************************************************************/
/*  Command request dispatcher.                                            */
/***************************************************************************/

acad_dofunc()
{
  int func_no;             /*  function number to execute  */

    /*  Get Function Number from ADS, and Process Function */
    if ((func_no = ads_getfuncode()) >= 0)
      {
      switch (func_no)
        {
        case 1:
            HardlockDemo();
            break;
        default:
            break;
        }
      }
    return ads_retvoid();     /* Return no Arguments to LISP */
}

/***************************************************************************/
/* FUNCLOAD  --  Load external functions into AutoLISP                     */
/***************************************************************************/

funcload()
{
    ads_defun("C:HARDLOCK", 1);
    ads_printf("\nHardlock Demo loaded. New Command is: HARDLOCK\n");
    return 1;
}


/***************************************************************************/
/* Hardlock Demo Main Proc                                                 */
/***************************************************************************/

void HardlockDemo (void)
{
    char   tbuf[80];
    char   datbuf[80];
    char   Text[33];       /* Temp. Var.                    */
    Word   n, Reg, Val;    /* Counter, Register & Value     */
    Word   TestOK = 0;     /* Return value from subroutines */
    char   Memory[128];    /* Save old Hardlock RAM & ROM   */
    char   OldMem[128];    /*                     "         */
    char   NewRAM[33];     /* New Hardlock RAM              */
    Long   SerialID = 0;   /* Module internal serial ID     */

    ads_printf("\n+---------------+");
    ads_printf("\n| Hardlock Demo |");
    ads_printf("\n+---------------+\n");

    /* ------------------------------------- */
    /* First we need to initialize the API : */
    /* ------------------------------------- */
    TestOK = HL_LOGIN(MODAD, DONT_CARE, RefKey, VerKey);

    if(TestOK != STATUS_OK)
      {
      switch (TestOK)
        {
        case NETWORK_ERROR:
          ads_printf(" Sorry, a network error occured, maybe IPX not loaded!!\n");
          break;
        case NO_DONGLE:
          ads_printf(" Sorry, no Hardlock with this ID found!!\n");
          break;
        case VERSION_MISMATCH:
          ads_printf(" Sorry, version mismatch between API and HL-Server or device driver!!\n");
          break;
        case TOO_MANY_USERS:
          ads_printf(" Sorry, too many logins to HL-Server. Login table full!!\n");
          break;
        case INVALID_ENV:
          ads_printf(" Sorry, invalid environment search string!! (HL_SEARCH)\n");
          break;
        case INVALID_LIC:
          ads_printf(" Sorry, no valid license information found!! (LM)\n");
          break;
        case NO_LICENSE:
          ads_printf(" Sorry, no license information for the requested slot!! (LM)\n");
          break;
        default:
          ads_printf(" Sorry, an unexpected error occured!! ERROR: %i\n", TestOK);
          break;
        }
      return;
      }
    sprintf(tbuf,"\n Hardlock with Module Address\t\t: %d\n", MODAD);
    ads_printf(tbuf);

    /* ---------------------------- */
    /* Get the API version number : */
    /* ---------------------------- */
    sprintf(tbuf," The API version is\t\t\t: %d\n", HL_VERSION());
    ads_printf(tbuf);

    /* ----------------------------------------------------- */
    /* Looking for the Hardlock with the expected coding.    */
    /* ----------------------------------------------------- */
    if(HL_AVAIL() == STATUS_OK)
      ads_printf(" The connected Hardlock E-Y-E is\t: Test device.\n");
     else
      ads_printf(" The connected Hardlock E-Y-E is\t: Not the test device.\n");

    /* ------------------------------------------------------------ */
    /* Now we can get some informations about the connected module. */
    /* ------------------------------------------------------------ */
    TestOK = HL_ACCINF();
    switch (TestOK)
      {
      case LOCAL_DEVICE:
        ads_printf(" The Hardlock E-Y-E access is\t\t: Local\n");
        sprintf(tbuf," Connected to the local port address\t: 0x%03X.\n", HL_PORTINF());
        ads_printf(tbuf);
        break;
      case NET_DEVICE:
        ads_printf(" The Hardlock E-Y-E access is\t\t: Remote\n");
        sprintf(tbuf," The HL-Server version is\t\t: %d.\n", HL_HLSVERS());
        ads_printf(tbuf);
        sprintf(tbuf," Connected to the remote port address\t: 0x%03X.\n", HL_PORTINF());
        ads_printf(tbuf);
        sprintf(tbuf," Number of users logged in HL-Server is\t: %d\n", HL_USERINF());
        ads_printf(tbuf);
        sprintf(tbuf," The max. number of HL-Server logins is\t: %d\n", HL_MAXUSER());
        ads_printf(tbuf);
        break;
      default:
        ads_printf(" The Hardlock E-Y-E access is\t\t: No access\n");
        break;
      }

    /* ------------------------------------------------------ */
    /* Read the internal serial number of Hardlock USB Module */
    /* ------------------------------------------------------ */
    TestOK = HL_READID((Word *)&SerialID, ((Word *)&SerialID)+1);
    switch (TestOK)
      {
      case STATUS_OK:
        sprintf(tbuf, " The serial number ID is\t\t: %lu (0x%08lX)\n", SerialID, SerialID);
        ads_printf(tbuf);
        break;
      case NO_SERIALID:
        ads_printf(" The serial number ID is\t\t: not available for this Key\n");
        break;
      default:
        ads_printf(" Cannot determine serial ID, API error:\t: %i\n", TestOK);
      }


    /* ------------------------------------------------------ */
    /* Now we decrypt the message from CryptStr. Maybe we use */
    /* the message in our application.                        */
    /* ------------------------------------------------------ */
    sprintf(tbuf,"\n The encrypted message is\t\t: %s\n", CryptStr);
    ads_printf(tbuf);
    TestOK = HL_AVAIL();
    if (TestOK == STATUS_OK)
      TestOK = HL_CODE(CryptStr, 4);
    if(TestOK == STATUS_OK)
      {
      /* ------------------------------------------------- */
      /* HL_CODE returned 0, CryptStr should be decrypted. */
      /* ------------------------------------------------- */
      sprintf(tbuf," The decrypted message is\t\t: %s\n", CryptStr);
      ads_printf(tbuf);
      HL_CODE(CryptStr, 4);
      sprintf(tbuf," Encrypted again\t\t\t: %s\n", CryptStr);
      ads_printf(tbuf);
      }
     else
      {
      /* ----------------------------------------------------------------------*/
      /* HL_CODE returned an other value, maybe someone removed the Hardlock ? */
      /* ----------------------------------------------------------------------*/
      ads_printf(" Sorry, the decryption has failed!\n");
      }

    /* ---------------------------------------------------- */
    /* We're looking for the memory option of the Hardlock. */
    /* ---------------------------------------------------- */
    TestOK = HL_MEMINF();
    if(TestOK == STATUS_OK)
      {
      ads_printf("\n Hardlock E-Y-E with memory\t\t: Yes\n");

    /* ------------------------------------------------------- */
    /* Now we can work with the memory. Let's read the string  */
    /* written in register 48 to 63.                           */
    /* ------------------------------------------------------- */
      for(n = 0, Reg = 48; Reg < 64; Reg++)
        {
        /* -------------------------------------------------------- */
        /* The memory is organized as 16 bit registers, so we have  */
        /* to perform a typecasting.                                */
        /* -------------------------------------------------------- */
        HL_READ(Reg, &Val);
        Text[n++] = (char) (Val >> 8);
        Text[n++] = (char) (Val & 255);
        }
      /* ---------------------------------- */
      /* We terminate the string with 0 ... */
      /* ---------------------------------- */
      Text[n] = '\0';

      /* ----------------- */
      /* ... and print it. */
      /* ----------------- */
      ads_printf(" Read all registers of RAM area (Intel)\t: [");
      for (n = 0; n < 32; n++) {
        sprintf(tbuf,"%c", ((unsigned char) Text[n] < 32) ? '.' : Text[n]);
        ads_printf(tbuf);
      }
      ads_printf("]\n\n");

      /* ------------------------------------*/
      /* Read RAM & ROM memory in one block. */
      /* ------------------------------------*/
      TestOK = HL_READBL(Memory);
      if (TestOK == STATUS_OK)
        {
        ads_printf(" Read whole memory in one block\t\t: [");
        for (n = 0; n < 4; n++)
          {
          if (n > 0)
            ads_printf(" \t\t\t\t\t  [");
          for (Reg = 32 * n; Reg < (32 + 32 * n); Reg++) {
            sprintf(tbuf,"%c",((unsigned char) Memory[Reg] < 32) ? '.' : Memory[Reg]);
            ads_printf(tbuf);
          }
          if (n < 3)
            ads_printf("]ROM\n");
           else
            ads_printf("]RAM\n");
          }
        }
       else
        ads_printf(" Read whole memory in one block\t\t: Failed\n");

      /* ---------------------------------------- */
      /* Write new RAM area (no error handling) : */
      /* ---------------------------------------- */
      strncpy(NewRAM,"This is the new RAM contents !!!",32);
      ads_printf(" Write new Hardlock RAM data (save old) :  ");
      for (n = 0; n < 32; n++) {
        sprintf(tbuf,"%c", NewRAM[n]);
        ads_printf(tbuf);
      }
      ads_printf("\n");
      HL_READBL(OldMem);
      HL_WRITEBL(NewRAM);
      ads_printf(" Read contents of RAM area  \t\t: [");
      HL_READBL(Memory);
      for (n = 0; n <= 32; n++)
        NewRAM[n] = Memory[96 + n];
      for (n = 0; n < 32; n++) {
        sprintf(tbuf,"%c", NewRAM[n]);
        ads_printf(tbuf);
      }
      ads_printf("]\n");
      for (n = 0; n <= 32; n++)
            NewRAM[n] = OldMem[96 + n];
      HL_WRITEBL(NewRAM);
      }
     else
      ads_printf("\n Hardlock E-Y-E with memory\t\t: No\n");

    HL_LOGOUT();
}

/***************************************************************************/
/* end of file */
