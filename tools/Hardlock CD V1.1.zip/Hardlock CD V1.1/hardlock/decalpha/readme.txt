
Differences between Alpha and i386 version of NT Hardlock software
------------------------------------------------------------------

 - No HLCWin32 or dataloader available.
 - Remote access to HL-Server not implemented.
 - Hardlock support for DOS/Win16 applications (HLVDD.DLL) isn't
   available.

