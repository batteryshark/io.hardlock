// hlprgDlg.cpp : implementation file
//

// 06.07.98: new error messages $3,$5
// 07.07.98: new function HLPROGGetVersion in HLPROG.DLL used
// 13.07.98: new error message $6

#include "stdafx.h"
#include "hlprg.h"
#include "hlprgDlg.h"

#include <string.h>

#include "hlprog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// call HLPROGGetVersion in HLPROG.DLL to get version of DLL
static unsigned short get_hlprogver(void)
{
  HMODULE m;
  FARPROC f;

  m=GetModuleHandle("hlprog.dll");
  if (!m) return(0);
  f=GetProcAddress(m,"HLPROGGetVersion");
  if (!f) return(0);
  return(f());
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHlprgDlg dialog

CHlprgDlg::CHlprgDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHlprgDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHlprgDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CHlprgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHlprgDlg)
	DDX_Control(pDX, IDC_SIGPORT, m_cSigPort);
	DDX_Control(pDX, IDC_PROGPORT, m_cProgPort);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CHlprgDlg, CDialog)
	//{{AFX_MSG_MAP(CHlprgDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHlprgDlg message handlers

BOOL CHlprgDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	// Initialize the GUI
	SetDlgItemText(IDC_EDIT1, "0");
	SetDlgItemText(IDC_EDIT2, "0");
	SetDlgItemText(IDC_EDIT3, "test.eep");

	// show HLPROG.DLL version
	int w;
	char s[200],s1[200];
	w=get_hlprogver();	
	strcpy(s, "HLPROG.DLL Version = ");
	strcat(s, itoa((w & 0xFF00)>>8, s1, 10));
	strcat(s, ".");
	char* temp = new char[3];
	sprintf(temp, "%02d",(w & 0x00FF) );		
	strcat(s, temp);
	delete temp;
	SetDlgItemText(IDC_EDIT4, s);

	// Get the port and cards list
	unsigned int		retvalue, i;
	char*				tempstring;
	tempstring = (char*) malloc(21);
	
	memset(&m_CPCardList, 0, sizeof(TCPCardList));
	retvalue = GetListOfCPCards( &m_CPCardList );
	if (retvalue) 
	{
		MessageBox( "Unable to get the CP Cards list", "Get list of CP Cards", MB_OK);
		GetDlgItem(IDC_BUTTON1)->EnableWindow(FALSE);
	}
	
	for (i=0; i < m_CPCardList.Size; i++)
	{
		memset(tempstring, 0, 21);
		switch (m_CPCardList.CPCard[i].Flags)
		{			
		case CPC_IS_ISA:
			sprintf(tempstring, "0x%04x (ISA-CPC)", m_CPCardList.CPCard[i].BaseAdr);
			m_cProgPort.AddString(tempstring);			
			break;
		case CPC_IS_OX12PCI840:
			sprintf(tempstring, "0x%04x (PCI-CPC)", m_CPCardList.CPCard[i].BaseAdr);
			m_cProgPort.AddString(tempstring);			
			break;
		case CPC_IS_NOTUSED:
			sprintf(tempstring, "0x%04x (CPC ??)", m_CPCardList.CPCard[i].BaseAdr);
			m_cProgPort.AddString(tempstring);			
			break;
		default:
			sprintf(tempstring, "0x%04x (Unknown flag)", m_CPCardList.CPCard[i].BaseAdr);
			m_cProgPort.AddString(tempstring);			
			break;
			break;
		}	
	}
	m_cProgPort.AddString("USB");
	m_cProgPort.SetCurSel(0);
	
	retvalue = GetListOfParPorts( &m_ParPortList );
	if (retvalue) 
	{
		MessageBox( "Unable to get the list parallel ports", "Get list of Parallel ports", MB_OK);
		GetDlgItem(IDC_BUTTON1)->EnableWindow(FALSE);
	}	
	for (i=0; i < m_ParPortList.Size; i++)
	{
		memset(tempstring, 0, 21);
		switch (m_ParPortList.ParPort[i].Flags)
		{		
		case CPC_IS_NOTUSED:
			sprintf(tempstring, "0x%04x (ParPort)", m_ParPortList.ParPort[i].BaseAdr);
			m_cSigPort.AddString(tempstring);
			break;
		case CPC_IS_ISA:
			sprintf(tempstring, "0x%04x (ISA-CPC)", m_ParPortList.ParPort[i].BaseAdr);
			m_cSigPort.AddString(tempstring);
			break;
		case CPC_IS_OX12PCI840:
			sprintf(tempstring, "0x%04x (PCI-CPC)", m_ParPortList.ParPort[i].BaseAdr);
			m_cSigPort.AddString(tempstring);
			break;
		default:
			sprintf(tempstring, "0x%04x (Unknown Flag)", m_ParPortList.ParPort[i].BaseAdr);
			m_cSigPort.AddString(tempstring);
		}		
	}
	m_cSigPort.SetCurSel(0);

	UpdateData(FALSE);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CHlprgDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHlprgDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CHlprgDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CHlprgDlg::OnButton1() 
{
PROG_PARAM p;
char lpsz[128];
char dummy[128];	
unsigned int retcode;

SetDlgItemText(IDC_EDIT4, "wait...");
GetDlgItem(IDC_EDIT4)->UpdateWindow();
// initialization of PROG_PARAM structure
memset(&p,0,sizeof(PROG_PARAM)); // initialize I/O structure 
// UserModAddr
GetDlgItem(IDC_EDIT1)->GetWindowText(lpsz, 5);
p.iMAUser = atoi(lpsz);
// SubCode
GetDlgItem(IDC_EDIT2)->GetWindowText(lpsz, 5);
p.uiSubCode = atoi(lpsz);

// port-addr of CP-card
// (or PROG_USB_HARDLOCK if we want to burn a USB-Hardlock)

unsigned int selection;
selection = m_cProgPort.GetCurSel();
if (selection == m_CPCardList.Size) p.usProgPort = PROG_USB_HARDLOCK;
else p.usProgPort = m_CPCardList.CPCard[selection].BaseAdr;

// port-addr of signature (normally CP-card)
// if you want to use a (USB-)Master-Hardlock you have to
// specify the port-addr where the Master-Hardlock is connected to
selection = m_cSigPort.GetCurSel();
p.usSigPort = m_ParPortList.ParPort[selection].BaseAdr;

// do we want to burn memory contents into the Hardlock?
if(((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck()==1) 
	{
	GetDlgItem(IDC_EDIT3)->GetWindowText(lpsz, 20);
	strcpy(p.szMemFile, lpsz);
	}
else
	p.szMemFile[0]=0;
// call the HLPROG.DLL
retcode = StdCHLProg(&p);
// error handling
switch(p.ErrorCode)
	{
	case PROG_NO_ERROR:						SetDlgItemText(IDC_EDIT4, "burning successful"); break;
	case PROG_UNABLE_TO_ADJUST:				SetDlgItemText(IDC_EDIT4, "unable to adjust"); break;
	case PROG_HL_NOT_RESPONDING:			if(p.usProgPort==PROG_USB_HARDLOCK)
												SetDlgItemText(IDC_EDIT4, "There must be exactly one Hardlock USB connected.");
											else
												SetDlgItemText(IDC_EDIT4, "Hardlock not responding");
											break;
	case PROG_CANNOT_OPEN_USB:				SetDlgItemText(IDC_EDIT4, "cannot open USB"); break;
	case PROG_UNABLE_TO_LOAD_SIGNATURE:		SetDlgItemText(IDC_EDIT4, "Unable to load signature"); break;
	case PROG_CANNOT_OPEN_DRIVER:			SetDlgItemText(IDC_EDIT4, "cannot open driver"); break;
	case PROG_BURN_PROHIBITED:				SetDlgItemText(IDC_EDIT4, "reprogramming not allowed"); break;
	case PROG_ILLEGAL_SIGNATURE:			SetDlgItemText(IDC_EDIT4, "invalid signature"); break;
	case PROG_MEMORY_VERIFY_FAILED:			SetDlgItemText(IDC_EDIT4, "verification of memory failed"); break;
	case PROG_NO_CPC_FOUND:					if(p.usProgPort==PROG_USB_HARDLOCK)
												SetDlgItemText(IDC_EDIT4, "no USB master hardlock found");
											else
												SetDlgItemText(IDC_EDIT4, "no CP-CARD found");
											break;
	case PROG_WRONG_HL_DRIVER:				SetDlgItemText(IDC_EDIT4, "HL driver does not support CP functions"); break;
	case PROG_NO_EE_IMAGE:					SetDlgItemText(IDC_EDIT4, "unable to load memory image file"); break;
	case PROG_NO_CDB:						SetDlgItemText(IDC_EDIT4, "no CDB"); break;
	case PROG_INVALID_SRN:					SetDlgItemText(IDC_EDIT4, "invalid serial number"); break;
	case PROG_INVALID_ARGUMENT:				SetDlgItemText(IDC_EDIT4, "invalid argument"); break;
	case PROG_WRONG_SIGNATURE:				SetDlgItemText(IDC_EDIT4, "wrong signature"); break;
	case PROG_USB_ERROR:					SetDlgItemText(IDC_EDIT4, "USB error"); break;
	case PROG_NOHL:							SetDlgItemText(IDC_EDIT4, "Connected device is no Hardlock(tm)"); break;
	default:								SetDlgItemText(IDC_EDIT4, "error"); break;
	};
// if burn was succesful show resulting ModAddr
GetDlgItem(IDC_EDIT4)->GetWindowText(lpsz, 100);
if(retcode==0)
	{
	itoa(p.ModAdr, dummy, 10);
	strcat(dummy, ", ");
	}
else dummy[0]=0;

strcat(dummy, lpsz);
SetDlgItemText(IDC_EDIT4, dummy);
}

