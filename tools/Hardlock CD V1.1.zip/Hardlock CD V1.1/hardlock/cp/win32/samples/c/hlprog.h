/*
** $Id: hlprog.h,v 1.3 2001/08/23 13:51:24 alex Exp $
**
** hlprog.h
** --------
**
** public definitions for HLProg DLL
**
** $Revision: 1.3 $
** $Date: 2001/08/23 13:51:24 $
** $Author: alex $
**
** $Log: hlprog.h,v $
** Revision 1.3  2001/08/23 13:51:24  alex
** updated to latest version for sample
**
** Revision 1.24  2001/06/15 08:34:10  Martin
** Definitions for max. Subcode & User module address added.
** String representations for all error codes added.
** 
** Revision 1.23  2001/05/03 11:54:46  Martin
** Pragma's for byte-alignment of structures added (Used insted of compiler switch).
** 
** Revision 1.22  2001/05/02 14:18:05  Martin
** Type for CPCardList and ParPortList renamed to "TCPCardList" in orde to avoid name conflicts.
** 
** Revision 1.21  2001/04/27 13:15:11  Seidl
** Revision 1.20  2001/04/27 12:54:27  Martin
** File beautified (Comments added, unused statements removed, etc..).
** Code2 is removed from the new hlprog-structure.
** New hlprog-structure renamed to "HLProgExParams".
** All "typedef struct {....} bla" statments removed, since the caused problems with C++ compilers.
** New function "GetListOfParPorts" added.
** standard keytypes are now defined with fixed values.
** 
** Revision 1.19  2001/04/26 07:37:28  Martin
** Field "Operation" finally removed from the structure.
** Flag "HLP_NO_CPC_CHECK" removed.
** New error code "PROG_WRONG_CPCARD" added.
** 
** Revision 1.18  2001/04/19 11:24:26  Martin
** Document revised. Special key type definitions moved to "hlprogi.h".
** 
** Revision 1.17  2001/04/02 11:59:33  Horatiu
** add Michael Schmidl changes
** 
** Revision 1.16  2001/02/26 10:26:03  Martin
** New hlprog additions #ifdef-ed.
** 
** Revision 1.15  2001/02/06 14:47:31  Martin
** New Entry point "HlProgEx" added.
** New parameter structure defined for this entry point.
** 
** 
** Revision 1.14  1998/07/09 16:19:03  chris
** PROG_BURN_PROHIBITED: new error code
** 
** Revision 1.13  1998/07/08 14:56:14  chris
** removed uiASEPort and Vpp24 entries from PROG_PARAM;
** added reserved and flags entries to PROG_PARAM
**
** Revision 1.12  1998/07/07 14:57:28  chris
** PROG_NO_MEMORY_FOUND: removed unused error code
**
** Revision 1.11  1998/07/06 12:04:58  chris
** added definition of HLPROGGetVersion() function
**
** Revision 1.10  1998/06/26 12:42:36  chris
** new error codes: PROG_CANNOT_OPEN_USB and
** PROG_CANNOT_OPEN_DRIVER; made include file C++
** compatible
**
** Revision 1.9  1998/06/08 14:38:15  chris
** added PROG_NOHL error code
**
** Revision 1.8  1998/02/13 13:46:55  chris
** move including of hlprogi.h to end of file, because hlprogi.h
** uses things defined herein
**
** Revision 1.7  1998/01/23 11:35:13  chris
** defined PROG_USB_HARDLOCK
**
** Revision 1.6  1997/12/09 11:48:56  chris
** defined PROG_USB_ERROR
**
** Revision 1.5  1997/12/04 12:13:03  chris
** cleaned up a little bit & rcs headers added
**
*/

#ifndef HLPROG_H
#define HLPROG_H

#ifdef _MSC_VER
#if _MSC_VER >= 900
  #pragma pack(push,_hlprog_h_,1)
#else
  #pragma pack(1)
#endif
#endif

// general definitions

#define MAXSUBCODE 43680
#define MAXUSERMA  29


// ---------------------------------------
// Definitions for old HLProg function
// ---------------------------------------

// Old Parameter Structure for StdCHLProg(..)
// ===========================================

typedef struct prog_param  {
   unsigned int   uiSubCode;              // Sub-Code
   int            iMAUser;                // User Module-Address
   unsigned short usProgPort;             // ProgPort: Address of CP-Card
   unsigned short usSigPort;              // SigPort:  Address of Master-HL or CPC which contains the signature
   char           szMemFile[128];         // File name of memory file
   char           szExecFile[128];        // (not supported)
   unsigned int   uiIntEE;                // 16-bit of HL internal memory
   unsigned int   uiSRN;                  // (for Internal use)
   char           szCDB[128];             // (for Internal use)
   unsigned int   reserved;
   unsigned int   flags;                  // Flags (see flag definition below)

   // Return parameters:
   int            Luna;                   // Indicates, that HL-ASIC is a Luna chip
   int            ErrorCode;              // Error code
   int            ModAdr;                 // Resulting ModuleAddress of coded HL
} PROG_PARAM;

// prog_param.flags definitions:

#define PPF_VPP24    1     // (internal use)
#define PPF_BURNALL  2     // ignore "not" table

//  special USB id in prog_param.usProgPort

#define PROG_USB_HARDLOCK 0xfafa



// ---------------------------------------
// Definitions for new HLProgEx functions
// ---------------------------------------

// New Parameter Structure for HLProgEx(..)
// ===========================================

struct _HlProgExParams {
   unsigned int   ParStructRev;        // Revision of this parameter structure (currently 1)

   unsigned int   SubCode;             // Sub-Code
   unsigned int   MAUser;              // User Module-Address
   unsigned int   ProgPort;            // ProgPort: Address of CP-Card
   unsigned int   SigPort;             // SigPort:  Address of Master-HL or CPC which contains the signature

   unsigned char* MemBuffer;           // Pointer to memory buffer (either buffer or file name: see Flags)
   unsigned int   MemBufferSize;       // Size of MemBuffer (only relevant, if Memory image is passed as buffer, otherw. N/A)

   unsigned char* CDBBuffer;           // (for Internal use)
   unsigned int   CDBBufferSize;       // (for Internal use)
                  
   unsigned int   IntEE;               // 16-bit of HL internal memory
   unsigned int   SRN;                 // (for Internal use)

   unsigned int   KeyType;             // Definition of KeyType. 
   unsigned int   Flags;               // Flags (see flag definition below)

   unsigned int   NumOfRetries;        // Number of Retries (N/A for USB keys) / max. 5 retries

   unsigned int   Reserved1;
   unsigned int   Reserved2;
   unsigned int   Reserved3;
   void*          ReservedPnt;         // Reserved void pointer

   // Return parameters : set by HLPROG.DLL 

   unsigned int    RetFlags;           // Return flags
   unsigned short  ModAdr;             // Resulting ModuleAddress of coded HL
  
};

typedef struct _HlProgExParams HlProgExParams;

//  Definition of Flags
//  ===========================
enum
{
   HLP_BURNALL       = 0x0002,		// Burn all connected hardlocks (ignore "NOT"-Table)

   HLP_MEM_FROM_FILE = 0x0000,      // Memory file is passed as file ("MemBuffer" contains file name of EE)
   HLP_MEM_AS_BUFF   = 0x0004       // Memory file is passed as buffer ("MemBuffer" contains EE contens)
};

//  Definition of Return Flags
//  ===========================
enum
{
   HLP_IS_LUNA       = 0x0001        // Indicates, that HL-ASIC is a Luna chip       
};

//  standard key types
//  ===========================

enum
{
   HLP_HL_STD        = 0x1100,
   HLP_HL_MEM        = 0x1110,

   HLP_HL_USB_STD    = 0x1500,
   HLP_HL_USB_MEM    = 0x1510 
};

// Definitions for the CPCard- and ParallelPort-List
// =================================================

// General definitions
#define CPC_IS_NOTUSED      0        // unused entry
#define CPC_IS_ISA          0x10     // old ISA CPCard
#define CPC_IS_OX12PCI840   0x20     // PCI version with OX12PCI840 chipset

// Definitions for CPCardList
// --------------------------

#define MAX_NUM_CPCARDS 8

// Definition of a CP-Card list element
struct _CPCard
{
   unsigned int   BaseAdr;
   unsigned int   Flags;
   unsigned short RevID[2];      // Revision ID: 0 = first word, 1 = second word (only applies for CPC-PCI)
   unsigned int  SerialID;      // Serial number of the CP-Card (only applies for CPC-PCI)
};

// Definition of complete CP-Card list
struct _CPCardList
{
   unsigned int Size;
   struct _CPCard  CPCard[MAX_NUM_CPCARDS];
};

typedef struct _CPCardList TCPCardList;

// Definitions for Parallel Port List
// ----------------------------------

#define MAX_NUM_PARPORTS 16

// Definition of a Parallel port list element
struct _ParPort
{
   unsigned int BaseAdr;
   unsigned int   Flags;
};

// Definition of complete Parallel port list
struct _ParPortList
{
   unsigned int Size;
   struct _ParPort  ParPort[MAX_NUM_PARPORTS];
};

typedef struct _ParPortList TParPortList;




#ifdef __cplusplus
extern "C" {
#endif

// exported functions of HLPROG.DLL
// ================================

extern int __cdecl   HLProg(PROG_PARAM *);         // depreciated
extern int __stdcall StdCHLProg(PROG_PARAM *);
extern int __stdcall HLPROGGetVersion(void);
extern int __stdcall HLProgEx(HlProgExParams *);     // Advanced HL Prog entry point

extern unsigned int __stdcall GetListOfCPCards(TCPCardList* );
extern unsigned int __stdcall GetListOfParPorts(TParPortList* );

#ifdef __cplusplus
};
#endif


// error codes
// ===========

#define PROG_NO_ERROR                 0x0000
#define PROG_UNABLE_TO_ADJUST         0x0001
#define PROG_HL_NOT_RESPONDING        0x0002
#define PROG_CANNOT_OPEN_USB          0x0003
#define PROG_UNABLE_TO_LOAD_SIGNATURE 0x0004
#define PROG_CANNOT_OPEN_DRIVER       0x0005
#define PROG_BURN_PROHIBITED          0x0006
#define PROG_ILLEGAL_SIGNATURE        0x0008
#define PROG_NO_VPP24_RELAIS          0x0009
#define PROG_NO_VPP18_RELAIS          0x000A
#define PROG_BAD_VPP                  0x000B
#define PROG_BAD_ADC                  0x000C
#define PROG_MEMORY_VERIFY_FAILED     0x0020
#define PROG_NO_CPC_FOUND             0x0040
#define PROG_WRONG_HL_DRIVER          0x0080
#define PROG_NO_EE_IMAGE              0x0100
#define PROG_NO_CDB                   0x0200
#define PROG_INVALID_SRN              0x0400
#define PROG_INVALID_ARGUMENT         0x0800
#define PROG_WRONG_SIGNATURE          0x1000
#define PROG_USB_ERROR                0x2000
#define PROG_NOHL                     0x4000
#define PROG_WRONG_CPCARD             0x8000


// strings to translate the return values of HLPROG
// ================================================

#define tPROG_NO_ERROR                  "OKAY\n"
#define tPROG_UNABLE_TO_ADJUST          "unable to adjust\n"
#define tPROG_HL_NOT_RESPONDING         "Hardlock not responding\n"
#define tPROG_CANNOT_OPEN_USB           "cannot open USB driver\n"
#define tPROG_UNABLE_TO_LOAD_SIGNATURE  "unable to load signature\n"
#define tPROG_ILLEGAL_SIGNATURE         "invalid signature\n"
#define tPROG_NO_VPP24_RELAIS           "VPP24 relais is not working\n"
#define tPROG_NO_VPP18_RELAIS           "VPP18 relais is not working\n"
#define tPROG_BAD_VPP                   "VPP voltage problem\n"
#define tPROG_BAD_ADC                   "A/D-converter is not working\n"
#define tPROG_MEMORY_VERIFY_FAILED      "verification of memory failed\n"
#define tPROG_NO_CPC_FOUND              "no CP-CARD found\n"
#define tPROG_WRONG_HL_DRIVER           "HL driver does not support CP functions\n"
#define tPROG_NO_EE_IMAGE               "unable to load memory image file\n"
#define tPROG_NO_CDB                    "cannont find CDB database\n"
#define tPROG_INVALID_SRN               "invalid SRN\n"
#define tPROG_INVALID_ARGUMENT          "invalid argument\n"
#define tPROG_WRONG_SIGNATURE           "wrong signature\n"
#define tPROG_USB_ERROR                 "general USB error\n"
#define tPROG_NOHL                      "connected key is not a Hardlock\n"
#define tPROG_WRONG_CPCARD              "wrong CP-Card\n"

// obsolete definition
#define tPROG_NO_MEMORY_FOUND           "no optional memory found\n"



// include things only needed for internal version
// ================================================

#ifdef HLPROG_INTERNAL
#include "hlprogi.h"
#endif

#ifdef _MSC_VER
#if _MSC_VER >= 900
  #pragma pack(pop,_hlprog_h_)
#else
  #pragma pack()
#endif
#endif


#endif // HLPROG_H

//*************************************************************** end of file **
