/****************************************************************************/
/**                                                                        **/
/**                              Hardlock                                  **/
/**                         Error Message Module                           **/
/**                           Aladdin Germany                              **/
/**                                                                        **/
/**  Revision history                                                      **/
/**  ----------------
***  $Log: hlerrmsg.c $
***  Revision 1.7  2000/09/14 12:13:13  Henri
***  Corrected some spelling errors.
***  
***  Revision 1.6  2000/09/06 08:21:37  Henri
***  Rephrased version mismatch error.
***  
***  Revision 1.5  1999/12/17 14:36:21  Henri
***  Also copy zero in new function.
***  
***  Revision 1.4  1999/12/17 12:07:22  Henri
***  Some spelling errors.
***  
***  Revision 1.3  1999/12/17 11:57:30  Henri
***  Added HL_ERRMSGB for use with buffer.
***  
***  Revision 1.2  1999/11/17 10:43:33  Henri
***  Added new HL error module.
***
***  Revision 1.1  1999/11/17 10:23:20  Henri
***  Initial revision
***
**/
/****************************************************************************/

#include "fastapi.h"

struct _err_msg
{
unsigned short errnum;
char *errmsg;
char *errdefine;
char *errextmsg;
};

#define MAX_LANG 2
#define US 0
#define DE 1

#ifndef NULL
#define NULL 0
#endif

static struct _err_msg us_table [] =
        {
        {STATUS_OK,             "API call was succesfull.",                 "STATUS_OK",                "n/a"},
        {NOT_INIT,              "API structure not initialized.",           "NOT_INIT",                 "n/a"},
        {ALREADY_INIT,          "API structure already initialized.",       "ALREADY_INIT",             "n/a"},
        {UNKNOWN_DONGLE,        "Device not supported.",                    "UNKNOWN_DONGLE",           "n/a"},
        {UNKNOWN_FUNCTION,      "Function not supported.",                  "UNKNOWN_FUNCTION",         "n/a"},
        {HLS_FULL,              "HL-Server login table full.",              "HLS_FULL",                 "n/a"},
        {NO_DONGLE,             "Hardlock module not found.",               "NO_DONGLE",                "n/a"},
        {NETWORK_ERROR,         "A network error occured.",                 "NETWORK_ERROR",            "n/a"},
        {NO_ACCESS,             "No device available.",                     "NO_ACCESS",                "n/a"},
        {INVALID_PARAM,         "A wrong parameter occured.",               "INVALID_PARAM",            "n/a"},
        {VERSION_MISMATCH,      "HL-Server/Driver version mismatch.",       "VERSION_MISMATCH",         "n/a"},
        {DOS_ALLOC_ERROR,       "Error on memory allocation.",              "DOS_ALLOC_ERROR",          "n/a"},
        {CANNOT_OPEN_DRIVER,    "Can not open Hardlock driver.",            "CANNOT_OPEN_DRIVER",       "n/a"},
        {INVALID_ENV,           "Invalid environment string.",              "INVALID_ENV",              "n/a"},
        {DYNALINK_FAILED,       "Unable to get a function entry.",          "DYNALINK_FAILED",          "n/a"},
        {INVALID_LIC,           "No valid licence information.",            "INVALID_LIC",              "n/a"},
        {NO_LICENSE,            "Slot/licence not enabled.",                "NO_LICENSE",               "n/a"},
        {PORT_BUSY,             "Cannot acquire port.",                     "PORT_BUSY",                "n/a"},
        {RUS_NO_DEVICE,         "Device is no Hardlock LiMaS module.",      "RUS_NO_DEVICE",            "n/a"},
        {RUS_INVALID_LIC,       "Invalid license.",                         "RUS_INVALID_LIC",          "n/a"},
        {RUS_SYNC_ERR,          "FIB in key and api struc mismatch.",       "RUS_SYNC_ERR",             "n/a"},
        {NOT_IMPLEMENTED,       "Not (yet) implemented.",                   "NOT_IMPLEMENTED",          "n/a"},
        {BUFFER_TOO_SMALL,      "Buffer for function too small.",           "BUFFER_TOO_SMALL",         "n/a"},
        {UNKNOWN_HW_TYPE,       "Unknown hardware descriptor.",             "UNKNOWN_HW_TYPE",          "n/a"},
        {RUS_INV_FBPOS,         "Unknown fixed block position.",            "RUS_INV_FBPOS",            "n/a"},
        {RUS_INVALID_SLOT,      "Non-existing slot number given.",          "RUS_INVALID_SLOT",         "n/a"},
        {RUS_DATE_FAKE,         "Date fake detected.",                      "RUS_DATE_FAKE",            "n/a"},
        {RUS_COUNT_DOWN,        "Dead counter limit reached.",              "RUS_COUNT_DOWN",           "n/a"},
        {RUS_INVALID_VK,        "Vendor key is invalid.",                   "RUS_INVALID_VK",           "n/a"},
        {RUS_NO_LIC_FILE,       "License file not found.",                  "RUS_NO_LIC_FILE",          "n/a"},
        {RUS_INV_VBLOCK,        "Invalid variable block.",                  "RUS_INV_VBLOCK",           "n/a"},
        {RUS_LIC_FILE_WRITE_ERR,"Error writing (updated)license file.",     "RUS_LIC_FILE_WRITE_ERR",   "n/a"},
        {RUS_NO_INFO_AVAILABLE, "Cannot get HW dependent info.",            "RUS_NO_INFO_AVAILABLE",    "n/a"},
        {RUS_INFO_PACK_ERR,     "Cannot TLV encode data.",                  "RUS_INFO_PACK_ERR",        "n/a"},
        {RUS_LIC_WRITE_ERR,     "Write license failed.",                    "RUS_LIC_WRITE_ERR",        "n/a"},
        {RUS_DATE_EXPIRED,      "Expiration date reached.",                 "RUS_DATE_EXPIRED",         "n/a"},
        {TS_DETECTED,           "Term. Server/Citrix Winframe detected.",   "TS_DETECTED",              "n/a"},
        {RUS_INVALID_RTB,       "Invalid updated data (RTB).",              "RUS_INVALID_RTB",          "n/a"},
        {RUS_RTB_EXPIRED,       "Update data (RTB) has expired.",           "RUS_RTB_EXPIRED",          "n/a"},
        {RUS_SERIAL_MISMATCH,   "Update data serial no. does not match.",   "RUS_SERIAL_MISMATCH",      "n/a"},
        {TOO_MANY_USERS,        "Login table full (remote).",               "TOO_MANY_USERS",           "n/a"},
        {SELECT_DOWN,           "Printer not on-line.",                     "SELECT_DOWN",              "n/a"},
        {NO_SERIALID,           "Serial ID not readable or n/a.",           "NO_SERIALID",              "n/a"},
        {0xffff, NULL, NULL, NULL}
        };

static struct _err_msg de_table [] =
        {
        {STATUS_OK,             "API-Aufruf war erfolgreich.",              "STATUS_OK",                "n/a"},
        {NOT_INIT,              "API-Struktur ist nicht initialisiert.",    "NOT_INIT",                 "n/a"},
        {ALREADY_INIT,          "API-Struktur ist bereits initialisiert.",  "ALREADY_INIT",             "n/a"},
        {UNKNOWN_DONGLE,        "Hardware-Modul wird nicht unterstuetzt.",  "UNKNOWN_DONGLE",           "n/a"},
        {UNKNOWN_FUNCTION,      "Funktion wird nicht unterstuetzt.",        "UNKNOWN_FUNCTION",         "n/a"},
        {HLS_FULL,              "HL-Server Login-Tabelle voll.",            "HLS_FULL",                 "n/a"},
        {NO_DONGLE,             "Hardlock-Modul nicht gefunden.",           "NO_DONGLE",                "n/a"},
        {NETWORK_ERROR,         "Ein Netzwerkfehler ist aufgetreten.",      "NETWORK_ERROR",            "n/a"},
        {NO_ACCESS,             "Falscher Zugriffsmodus.",                  "NO_ACCESS",                "n/a"},
        {INVALID_PARAM,         "Ein falscher Parameter wurde angegeben.",  "INVALID_PARAM",            "n/a"},
        {VERSION_MISMATCH,      "HL-Server/Treiber-Versionen passen nicht.","VERSION_MISMATCH",         "n/a"},
        {DOS_ALLOC_ERROR,       "Fehler bei Speicherallokierung.",          "DOS_ALLOC_ERROR",          "n/a"},
        {CANNOT_OPEN_DRIVER,    "HL-Treiber kann nicht geoeffnet werden.",  "CANNOT_OPEN_DRIVER",       "n/a"},
        {INVALID_ENV,           "Ungueltige Umgebungsvariable.",            "INVALID_ENV",              "n/a"},
        {DYNALINK_FAILED,       "Funktion in DLL nicht gefunden.",          "DYNALINK_FAILED",          "n/a"},
        {INVALID_LIC,           "Keine gueltige Lizenzinformation.",        "INVALID_LIC",              "n/a"},
        {NO_LICENSE,            "Slot/Lizenz nicht freigeschaltet.",        "NO_LICENSE",               "n/a"},
        {PORT_BUSY,             "Port kann nicht angefordert werden.",      "PORT_BUSY",                "n/a"},
        {RUS_NO_DEVICE,         "Modul ist kein Hardlock-LiMas-Modul.",     "RUS_NO_DEVICE",            "n/a"},
        {RUS_INVALID_LIC,       "Ungueltige RUS-Lizenz.",                   "RUS_INVALID_LIC",          "n/a"},
        {RUS_SYNC_ERR,          "FIB in Modul/API-Struktur passt nicht.",   "RUS_SYNC_ERR",             "n/a"},
        {NOT_IMPLEMENTED,       "(Noch) Nicht implementiert.",              "NOT_IMPLEMENTED",          "n/a"},
        {BUFFER_TOO_SMALL,      "Puffer fuer Funktion zu klein.",           "BUFFER_TOO_SMALL",         "n/a"},
        {UNKNOWN_HW_TYPE,       "Unbekannter Hardware-Deskriptor.",         "UNKNOWN_HW_TYPE",          "n/a"},
        {RUS_INV_FBPOS,         "Unbekannte Position des FIXED-Blocks.",    "RUS_INV_FBPOS",            "n/a"},
        {RUS_INVALID_SLOT,      "Slot existiert nicht.",                    "RUS_INVALID_SLOT",         "n/a"},
        {RUS_DATE_FAKE,         "Datum wurde manipuliert.",                 "RUS_DATE_FAKE",            "n/a"},
        {RUS_COUNT_DOWN,        "Zaehlerlimit erreicht.",                   "RUS_COUNT_DOWN",           "n/a"},
        {RUS_INVALID_VK,        "Vendor-Key ist ungueltig.",                "RUS_INVALID_VK",           "n/a"},
        {RUS_NO_LIC_FILE,       "Lizenzdatei nicht gefunden.",              "RUS_NO_LIC_FILE",          "n/a"},
        {RUS_INV_VBLOCK,        "Ungueltiger VAR-Block.",                   "RUS_INV_VBLOCK",           "n/a"},
        {RUS_LIC_FILE_WRITE_ERR,"Fehler bei Schreiben der Lizenzdatei.",    "RUS_LIC_FILE_WRITE_ERR",   "n/a"},
        {RUS_NO_INFO_AVAILABLE, "Fehler bei Ermittlung der HW-Info.",       "RUS_NO_INFO_AVAILABLE",    "n/a"},
        {RUS_INFO_PACK_ERR,     "Daten koennen nicht TLV kodiert werden.",  "RUS_INFO_PACK_ERR",        "n/a"},
        {RUS_LIC_WRITE_ERR,     "Fehler bei Schreiben der Lizenz.",         "RUS_LIC_WRITE_ERR",        "n/a"},
        {RUS_DATE_EXPIRED,      "RUS-Ablaufdatum erreicht.",                "RUS_DATE_EXPIRED",         "n/a"},
        {TS_DETECTED,           "Term. Server/Citrix Winframe erkannt.",    "TS_DETECTED",              "n/a"},
        {RUS_INVALID_RTB,       "Ungueltige Update-Daten (RTB).",           "RUS_INVALID_RTB",          "n/a"},
        {RUS_RTB_EXPIRED,       "Datum fuer Update-Daten abgelaufen.",      "RUS_RTB_EXPIRED",          "n/a"},
        {RUS_SERIAL_MISMATCH,   "Seriennr. der Update-Daten passt nicht.",  "RUS_SERIAL_MISMATCH",      "n/a"},
        {TOO_MANY_USERS,        "Login-Tabelle ist voll (Netzwerk).",       "TOO_MANY_USERS",           "n/a"},
        {SELECT_DOWN,           "Drucker nicht online.",                    "SELECT_DOWN",              "n/a"},
        {NO_SERIALID,           "Seriennummer nicht lesbar/vorhanden.",     "NO_SERIALID",              "n/a"},
        {0xffff, NULL, NULL, NULL}
        };

static char _undefined [] = "Undefined return code";

struct _err_msg * _err_msgs [] = {us_table, de_table};

/*****************************************************************************************************/
const char * FAR_ CALL_ HL_ERRMSG (Word num, Long options, Byte ** errdefine, Byte ** errextmsg)
/*****************************************************************************************************/
{
struct _err_msg * currtable;

if (errdefine) *errdefine = NULL;
if (errextmsg) *errextmsg = NULL;

if (options >= MAX_LANG)
  return 0;

currtable = _err_msgs[options];
while (currtable->errnum != 0xffff)
  {
  if (currtable->errnum == num)
    {
    if (errdefine) *errdefine = currtable->errdefine;
    if (errextmsg) *errextmsg = currtable->errextmsg;
    return currtable->errmsg;
    }
  currtable++;
  }

return _undefined;
}

/*****************************************************************************************************/
Word FAR_ CALL_ HL_ERRMSGB (Word num, Long options, Byte * buf, Word bufsize)
/*****************************************************************************************************/
{
struct _err_msg * currtable;
Word   errlength, i;

if ((buf == NULL) || (bufsize == NULL))
  return BUFFER_TOO_SMALL;

if (options >= MAX_LANG)
  return INVALID_PARAM;

currtable = _err_msgs[options];
while (currtable->errnum != 0xffff)
  {
  if (currtable->errnum == num)
    {
    for (errlength = 0;; errlength++)
      if (currtable->errmsg[errlength] == 0x0)
        break;

    if (errlength > bufsize)
        return BUFFER_TOO_SMALL;

    for (i = 0; i < errlength; i++)
       *(buf+i) = currtable->errmsg[i];

    *(buf+i) = 0x0;

    return 0;
    }
  currtable++;
  }

return INVALID_PARAM;
}

