/****************************************************************************/
/**                                                                        **/
/**                          Hardlock Demo Program                         **/
/**                                                                        **/
/**   This demo program is based on the Hardlock application interface,    **/
/**   called API, to access a Hardlock via a local or a remote port.       **/
/**   To access the Hardlock remote, HL-Server must be installed first.    **/
/**                                                                        **/
/**                ///FAST Software Security - Group Aladdin		   **/
/**                                                                        **/
/**              Computer: IBM PC or compatible                            **/
/**              OS      : Novell Netware 386                              **/
/**              Language: 32 bit Watcom C                                 **/
/**                                                                        **/
/**                               Note                                     **/
/**                               ----                                     **/
/**  The following demo program is not meant to represent a real good      **/
/**  implementation of software protection into your application. It       **/
/**  demonstrates the basic use of the Hardlock API functions and is       **/
/**  thus as short and simple as possible. Please read the manual          **/
/**  carefully to get an insight in the strategy of the implementation.    **/
/**  Please keep in mind that there is no general solution for a good      **/
/**  protection. We provide you with the necessary functions, the          **/
/**  implementation itself is up to you and your imagination.              **/
/**                                                                        **/
/**  Revision history                                                      **/
/**  ----------------
***  $Log: hl-demo.c $
***  Revision 1.4  1997/02/10 10:25:50  henri
***  Added messages for LM.
***  
***  Revision 1.3  1996/08/08 18:49:42  henri
***  Added VCS log.
***
**/
/****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include "hlapi_c.h"

/* ------------------------------------------------------------------------ */
/* Module address of Hardlock test device and RefKey/VerKey. We generated   */
/* the VerifyKey with TESTAPI.EXE. The API use the keys to identify the     */
/* Hardlock with the correct encoding.                                      */
/* The keys defined here are only valid for the demo module.                */
/* You have to change module address AND VerKey for your specific Hardlock! */
/* ------------------------------------------------------------------------ */
#define MODAD  29809
Byte RefKey[8] = {"HARDLOCK"};
Byte VerKey[8] = {0x18,0x4C,0x97,0xF0,0xC0,0x7A,0x08,0x88};

/* ----------------------------------------- */
/* CryptStr contains the encrypted message : */
/* "The Answer to the Great Question"	     */
/* (only valid for the demo module).         */
/* ----------------------------------------- */
Byte CryptStr[33] =
   {0x2D, 0xD4, 0x16, 0xA3, 0x19, 0x5C, 0xC2, 0x18,
    0xAB, 0xA3, 0x8C, 0xDC, 0x8E, 0x66, 0xD4, 0xAB,
    0x8F, 0xC0, 0x2F, 0x19, 0x39, 0xBA, 0x76, 0x5C,
    0xE2, 0x06, 0x7C, 0x98, 0xC8, 0xA3, 0x55, 0x24,
    0x00};

/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
int main(void)
{
char   Text[33];          /* Temp. Var.                    */
Word   n, Reg, Val;       /* Counter, Register & Value     */
Word   TestOK = 0;        /* Return value from subroutines */
char   Memory[128];       /* Save old Hardlock RAM & ROM   */
char   OldMem[128];       /*                     "         */
char   NewRAM[33];        /* New Hardlock RAM              */

cprintf("\n\r���������������Ŀ");
cprintf("\n\r� Hardlock Demo �");
cprintf("\n\r�����������������\n\r");

/* ------------------------------------- */
/* First we need to initialize the API : */
/* ------------------------------------- */
TestOK = HL_LOGIN(MODAD, DONT_CARE, RefKey, VerKey);
if(TestOK != STATUS_OK)
  {
  switch (TestOK)
    {
    case NETWORK_ERROR:
      cprintf(" Sorry, a network error occured, maybe IPX not loaded!!\n\r");
      break;
    case NO_DONGLE:
      cprintf(" Sorry, no Hardlock E-Y-E with this ID found!!\n\r");
      break;
    case VERSION_MISMATCH:
      cprintf(" Sorry, version mismatch between API and HL-Server or device driver!!\n\r");
      break;
    case TOO_MANY_USERS:
      cprintf(" Sorry, too many logins to HL-Server. Login table full!!\n\r");
      break;
    case CANNOT_OPEN_DRIVER:
      cprintf(" Sorry, cannot open driver, maybe Hardlock driver not installed!!\n\r");
      break;
    case INVALID_LIC:
      cprintf(" Sorry, no valid licence memory image found!! (LM)\n\r");
      break;
    case NO_LICENSE:
      cprintf(" Sorry, no licence information for the requested slot!! (LM)\n\r");
      break;
    default:
      cprintf(" Sorry, an unexpected error occured!! ERROR: %d\n\r", TestOK);
      break;
    }
    return (TestOK);
}
cprintf("\n\r Hardlock E-Y-E with Module address\t: %d\n\r", MODAD);

/* ---------------------------- */
/* Get the API version number : */
/* ---------------------------- */
cprintf(" The API version is\t\t\t: %d\n\r",HL_VERSION());

/* ----------------------------------------------------- */
/* Looking for the Hardlock with the expected coding.    */
/* ----------------------------------------------------- */
if(HL_AVAIL() == STATUS_OK)
  cprintf(" The connected Hardlock E-Y-E is\t: Test device.\n\r");
 else
  cprintf(" The connected Hardlock E-Y-E is\t: Not the test device.\n\r");

/* ------------------------------------------------------------ */
/* Now we can get some informations about the connected module. */
/* ------------------------------------------------------------ */
TestOK = HL_ACCINF();
switch (TestOK)
  {
  case LOCAL_DEVICE:
    cprintf(" The Hardlock E-Y-E access is\t\t: Local\n\r");
    cprintf(" Connected to the local port address\t: 0x%03X.\n\r", HL_PORTINF());
    break;
  case NET_DEVICE:
    cprintf(" The Hardlock E-Y-E access is\t\t: Remote\n\r");
    cprintf(" The HL-Server version is\t\t: %d\n\r", HL_HLSVERS());
    cprintf(" Connected to the remote port address\t: 0x%03X.\n\r", HL_PORTINF());
    cprintf(" Number of users logged in HL-Server is\t: %d\n\r", HL_USERINF());
    cprintf(" The max. number of HL-Server logins is\t: %d\n\r", HL_MAXUSER());
    break;
  default:
    cprintf(" The Hardlock E-Y-E access is\t\t: No access\n\r");
    break;
  }

/* ------------------------------------------------------ */
/* Now we decrypt the message from CryptStr. Maybe we use */
/* the message in our application.                        */
/* ------------------------------------------------------ */
cprintf("\n\r The encrypted message is\t\t: ");
for (n = 0; n < 32; n++)
  cprintf("%c",((unsigned char) CryptStr[n] < 32) ? '.' : CryptStr[n]);

TestOK = HL_AVAIL();
if (TestOK == STATUS_OK)
  TestOK = HL_CODE(CryptStr, 4);
if(TestOK == STATUS_OK)
  {
  /* ------------------------------------------------- */
  /* HL_CODE returned 0, CryptStr should be decrypted. */
  /* ------------------------------------------------- */
  cprintf("\n\r The decrypted message is\t\t: ");
  for (n = 0; n < 32; n++)
    cprintf("%c",((unsigned char) CryptStr[n] < 32) ? '.' : CryptStr[n]);

  HL_CODE(CryptStr, 4);
  cprintf("\n\r Encrypted again\t\t\t: ");
  for (n = 0; n < 32; n++)
    cprintf("%c",((unsigned char) CryptStr[n] < 32) ? '.' : CryptStr[n]);
  }
 else
  /* ----------------------------------------------------------------------*/
  /* HL_CODE returned an other value, maybe someone removed the Hardlock ? */
  /* ----------------------------------------------------------------------*/
  cprintf("\n\r Sorry, the decryption has failed!");

/* ---------------------------------------------------- */
/* We're looking for the memory option of the Hardlock. */
/* ---------------------------------------------------- */
TestOK = HL_MEMINF();
if(TestOK == STATUS_OK)
  {
  cprintf("\n\r\n\r Hardlock E-Y-E with memory\t\t: Yes\n\r");

/* ------------------------------------------------------- */
/* Now we can work with the memory. Let's read the string  */
/* written in register 48 to 63.                           */
/* ------------------------------------------------------- */
  for(n = 0, Reg = 48; Reg < 64; Reg++)
    {
    /* -------------------------------------------------------- */
    /* The memory is organized as 16 bit registers, so we have  */
    /* to perform a typecasting.                                */
    /* -------------------------------------------------------- */
    HL_READ(Reg, &Val);
    Text[n++] = (char) (Val >> 8);
    Text[n++] = (char) (Val & 255);
    }
  /* ---------------------------------- */
  /* We terminate the string with 0 ... */
  /* ---------------------------------- */
  Text[n] = '\0';

  /* ----------------- */
  /* ... and print it. */
  /* ----------------- */
  cprintf(" Read all registers of RAM area (Intel)\t: [");
  for (n = 0; n < 32; n++)
    cprintf("%c", ((unsigned char) Text[n] < 32) ? '.' : Text[n]);
  cprintf("]\n\r\n\r");

  /* ------------------------------------*/
  /* Read RAM & ROM memory in one block. */
  /* ------------------------------------*/
  TestOK = HL_READBL(Memory);
  if (TestOK == STATUS_OK)
    {
    cprintf(" Read whole memory in one block\t\t: [");
    for (n = 0; n < 4; n++)
      {
      if (n > 0)
        cprintf(" \t\t\t\t\t  [");
      for (Reg = 32 * n; Reg < (32 + 32 * n); Reg++)
        cprintf("%c",((unsigned char) Memory[Reg] < 32) ? '.' : Memory[Reg]);
      if (n < 3)
        cprintf("]ROM\n\r");
       else
        cprintf("]RAM\n\r");
      }
    }
   else
    cprintf(" Read whole memory in one block\t\t: Failed\n\r");

  /* ---------------------------------------- */
  /* Write new RAM area (no error handling) : */
  /* ---------------------------------------- */
  strncpy(NewRAM,"This is the new RAM contents !!!",32);
  cprintf(" Write new Hardlock RAM data (save old) :  ");
  for (n = 0; n < 32; n++)
    cprintf("%c", NewRAM[n]);
  cprintf("\n\r");
  HL_READBL(OldMem);
  HL_WRITEBL(NewRAM);
  cprintf(" Read contents of RAM area  \t\t: [");
  HL_READBL(Memory);
  for (n = 0; n <= 32; n++)
    NewRAM[n] = Memory[96 + n];
  for (n = 0; n < 32; n++)
    cprintf("%c", NewRAM[n]);
  cprintf("]\n\r");
  for (n = 0; n <= 32; n++)
       NewRAM[n] = OldMem[96 + n];
  HL_WRITEBL(NewRAM);
  }
 else
  cprintf("\n\r\n\r Hardlock E-Y-E with memory\t\t: No\n\r");

/* ---------------------------------------------- */
/* At last we have to release the API structure.  */
/* ---------------------------------------------- */
return (HL_LOGOUT());
}
