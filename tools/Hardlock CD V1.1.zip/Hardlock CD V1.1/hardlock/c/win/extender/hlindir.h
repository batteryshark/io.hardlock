/* --------------------------------------------------------------*/
/* Indirect Handles for calling the 16 bit Hardlock Windows DLL: */
/* ------------------------------------------------------------- */
HINDIR HL_LOGINHandle;
HINDIR HL_LOGOUTHandle;
HINDIR HL_VERSIONHandle;
HINDIR HL_PORTINFHandle;
HINDIR HL_ACCINFHandle;
HINDIR HL_USERINFHandle;
HINDIR HL_MAXUSERHandle;
HINDIR HL_AVAILHandle;
HINDIR HL_CALCHandle;
HINDIR HL_CODEHandle;
HINDIR HL_MEMINFHandle;
HINDIR HL_READHandle;
HINDIR HL_HLSVERSHandle;
HINDIR HL_SELECTHandle;
HINDIR HL_LMLOGINHandle;
HINDIR HL_READIDHandle;

#define HL_LOGIN(ModAd, Access, RefKey, VerKey) \
       InvokeIndirectFunction (HL_LOGINHandle, (WORD) ModAd, (WORD) Access, (char *) RefKey, (char *) VerKey)
#define HL_LOGOUT() \
       InvokeIndirectFunction (HL_LOGOUTHandle)
#define HL_VERSION() \
       InvokeIndirectFunction (HL_VERSIONHandle)
#define HL_AVAIL() \
       InvokeIndirectFunction (HL_AVAILHandle)
#define HL_PORTINF() \
       InvokeIndirectFunction (HL_PORTINFHandle)
#define HL_CALC(i1, i2, i3, i4) \
       InvokeIndirectFunction (HL_CALCHandle, (WORD) i1, (WORD) i2, (WORD) i3, (WORD) i4)
#define HL_ACCINF() \
       InvokeIndirectFunction (HL_ACCINFHandle)
#define HL_USERINF() \
       InvokeIndirectFunction (HL_USERINFHandle)
#define HL_MAXUSER() \
       InvokeIndirectFunction (HL_MAXUSERHandle)
#define HL_MEMINF() \
       InvokeIndirectFunction (HL_MEMINFHandle)
#define HL_HLSVERS() \
       InvokeIndirectFunction (HL_HLSVERSHandle)
#define HL_CODE(DataPtr, Bcnt) \
       InvokeIndirectFunction (HL_CODEHandle, (char *) DataPtr, (WORD) Bcnt)
#define HL_READ(Reg, Val) \
       InvokeIndirectFunction (HL_READHandle, (WORD) Reg, (char far *) Val)
#define HL_SELECT(DataPtr) \
       InvokeIndirectFunction (HL_SELECTHandle, (char *) DataPtr)
#define HL_LMLOGIN(ModAd, Access, RefKey, VerKey, SlotID, SearchStr) \
       InvokeIndirectFunction (HL_LMLOGINHandle, (WORD) ModAd, (WORD) Access, (char *) RefKey, (char *) VerKey, Word SlotID, (char *) SearchStr)
#define HL_READID(IDLow, IDHigh) \
       InvokeIndirectFunction (HL_READIDHandle, (char far *) IDLow, (char far *) IDHigh)

WORD LoadHLDLL(void);
/*****************************************************************************/
WORD LoadHLDLL(void)
/*****************************************************************************/
{
HANDLE  dll;
FARPROC addr;

dll = LoadLibrary("api_1lnm.dll");
if (dll < 32)
  return (0);

addr = GetProcAddress(dll, "HL_LOGIN");
HL_LOGINHandle = GetIndirectFunctionHandle(addr, INDIR_WORD, INDIR_WORD, INDIR_PTR, INDIR_PTR, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_LOGOUT");
HL_LOGOUTHandle = GetIndirectFunctionHandle(addr, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_VERSION");
HL_VERSIONHandle = GetIndirectFunctionHandle(addr, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_AVAIL");
HL_AVAILHandle = GetIndirectFunctionHandle(addr, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_PORTINF");
HL_PORTINFHandle = GetIndirectFunctionHandle(addr, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_USERINF");
HL_USERINFHandle = GetIndirectFunctionHandle(addr, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_ACCINF");
HL_ACCINFHandle = GetIndirectFunctionHandle(addr, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_CALC");
HL_CALCHandle = GetIndirectFunctionHandle(addr, INDIR_WORD, INDIR_WORD, INDIR_WORD, INDIR_WORD, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_MEMINF");
HL_MEMINFHandle = GetIndirectFunctionHandle(addr, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_HLSVERS");
HL_HLSVERSHandle = GetIndirectFunctionHandle(addr, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_MAXUSER");
HL_MAXUSERHandle = GetIndirectFunctionHandle(addr, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_CODE");
HL_CODEHandle = GetIndirectFunctionHandle(addr, INDIR_PTR, INDIR_WORD, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_READ");
HL_READHandle = GetIndirectFunctionHandle(addr, INDIR_WORD, INDIR_PTR, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_SELECT");
HL_SELECTHandle = GetIndirectFunctionHandle(addr, INDIR_PTR, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_LMLOGIN");
HL_LMLOGINHandle = GetIndirectFunctionHandle(addr, INDIR_WORD, INDIR_WORD, INDIR_PTR, INDIR_PTR, INDIR_WORD, INDIR_PTR, INDIR_ENDLIST);
addr = GetProcAddress(dll, "HL_READID");
HL_READIDHandle = GetIndirectFunctionHandle(addr, INDIR_PTR, INDIR_PTR, INDIR_ENDLIST);

return (1);
}
