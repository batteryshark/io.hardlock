/****************************************************************************/
/**                                                                        **/
/**                         Hardlock Demo Program                          **/
/**                                                                        **/
/**   This demo program is based on the hardlock application interface,    **/
/**   called API, to access a hardlock via a local or an remote port.      **/
/**   To access the hardlock remote, HL-Server must be installed first.    **/
/**                                                                        **/
/**                   Aladdin Knowledge Systems, Germany                   **/
/**                                                                        **/
/**              Computer: IBM PC or compatible                            **/
/**              OS      : MS Windows 3.x                                  **/
/**              Language: C (TURBO C, MSC, WATCOM)                        **/
/**                                                                        **/
/**                               Note                                     **/
/**                               ----                                     **/
/**  The following demo program is not meant to represent a real good      **/
/**  implementation of software protection into your application. It       **/
/**  demonstrates the basic use of the Hardlock API functions and is       **/
/**  thus as short and simple as possible. Please read the manual          **/
/**  carefully to get an insight in the strategy of the implementation.    **/
/**  Please keep in mind that there is no general solution for a good      **/
/**  protection. We provide you with the necessary functions, the          **/
/**  implementation itself is up to you and your imagination.              **/
/**                                                                        **/
/**  Revision history                                                      **/
/**  ----------------
***  $Log: hl-demo.c $
***  Revision 1.4  1998/06/12 09:13:50  Henri
***  Added HL_READID.
***  
***  Revision 1.3  1997/02/09 15:20:22  henri
***  Added messages for LM.
***
***  Revision 1.2  1996/08/08 15:57:05  henri
***  Added VCS log.
***
**/
/****************************************************************************/

/* Includes : */
/* ---------- */
#include <windows.h>
#include <string.h>
#include <stdio.h>
#include <conio.h>

#include "HLAPI_C.H"

#ifdef WINNT
  #define _export
  #undef  FAR
  #define FAR
  #define PASCAL __stdcall
#endif

/* ------------------------------------------------------------------------ */
/* Module address of Hardlock test device and RefKey/VerKey. We generated   */
/* the VerifyKey with TESTAPI.EXE. The API use the keys to identify the     */
/* Hardlock with the correct encoding.                                      */
/* The keys defined here are only valid for the demo module.                */
/* You have to change module address AND VerKey for your specific Hardlock! */
/* ------------------------------------------------------------------------ */
#define MODAD  29809
Byte RefKey[8] = {"HARDLOCK"};
Byte VerKey[8] = {0x18,0x4C,0x97,0xF0,0xC0,0x7A,0x08,0x88};

/* ----------------------------------------- */
/* CryptStr contains the encrypted message : */
/* "The Answer to the Great Question"        */
/* (only valid for the demo module)          */
/* ----------------------------------------- */
unsigned char CryptStr[33] =
   {0x2D, 0xD4, 0x16, 0xA3, 0x19, 0x5C, 0xC2, 0x18,
    0xAB, 0xA3, 0x8C, 0xDC, 0x8E, 0x66, 0xD4, 0xAB,
    0x8F, 0xC0, 0x2F, 0x19, 0x39, 0xBA, 0x76, 0x5C,
    0xE2, 0x06, 0x7C, 0x98, 0xC8, 0xA3, 0x55, 0x24,
    0x00};

char   Text[33];           /* Temp. Var.                    */
Word   n, Reg, Val;        /* Counter, Register & Value     */
Word   TestOK = 0;         /* Return value from subroutines */
Word   LoginStatus;        /* Return from HL_LOGIN          */
char   buffer[500];        /* Buffer to display messages    */
Long   SerialID = 0;       /* Module internal serial ID     */

long FAR PASCAL _export WndProc          (HWND, WORD, WORD, LONG);
void                    Say              (HDC hdc, short y, char *text);
void                    HardlockFunction (HDC hdc);

#ifdef __386__
 #ifdef HLHIGH_DLL
   #include "HLINDIR.H"
 #endif
#endif

/****************************************************************************/
/****************************************************************************/
int PASCAL WinMain (HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
static char szAppName[] = "HL-DEMO";
HWND        hwnd;
MSG         msg;
WNDCLASS    wndclass;

lpszCmdParam = lpszCmdParam;

if (!hPrevInstance)
  {
  wndclass.style         = CS_HREDRAW | CS_VREDRAW;
  wndclass.lpfnWndProc   = (LPVOID) WndProc;
  wndclass.cbClsExtra    = 0;
  wndclass.cbWndExtra    = 0;
  wndclass.hInstance     = hInstance;
  wndclass.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
  wndclass.hCursor       = LoadCursor(NULL, IDC_ARROW);
  wndclass.hbrBackground = GetStockObject( WHITE_BRUSH);
  wndclass.lpszMenuName  = NULL;
  wndclass.lpszClassName = szAppName;
  RegisterClass (&wndclass);
  }
#ifdef __386__
 else
  return (0);
#endif

#ifdef __386__
  hwnd = CreateWindow(szAppName, "Hardlock - 32 bit HL-DEMO",
  WS_OVERLAPPEDWINDOW, 20, 20, 600, 320, NULL, NULL, hInstance, NULL);
 #else
  hwnd = CreateWindow(szAppName, "Hardlock - 16 bit HL-DEMO",
  WS_OVERLAPPEDWINDOW, 20, 20, 600, 320, NULL, NULL, hInstance, NULL);
#endif

/* ------------------------------------- */
/* First we need to initialize the API : */
/* ------------------------------------- */
#ifdef __386__
 #ifdef HLHIGH_DLL
   if (!LoadHLDLL())
    {
    MessageBox(NULL, "Could not load API_1LNM.DLL", "Error", MB_OK);
    return (0);
    }
 #endif
#endif
LoginStatus = HL_LOGIN(MODAD, DONT_CARE, RefKey, VerKey);

ShowWindow (hwnd, nCmdShow);
UpdateWindow (hwnd);
while (GetMessage (&msg, NULL, 0, 0))
  {
  TranslateMessage (&msg);
  DispatchMessage  (&msg);
  }

/* ---------------------------------------------- */
/* At last we have to release the API structure.  */
/* ---------------------------------------------- */
HL_LOGOUT();
return msg.wParam;
}

/****************************************************************************/
long FAR PASCAL _export WndProc( HWND hwnd, WORD message, WORD wParam, LONG lParam )
/****************************************************************************/
{
HDC          hdc;
PAINTSTRUCT  ps;

switch (message)
  {
  case WM_PAINT:
     hdc = BeginPaint (hwnd, &ps);
     HardlockFunction(hdc);
     EndPaint (hwnd, &ps);
     return 0;

  case WM_DESTROY:
     PostQuitMessage (0);
     return 0;

  }
return DefWindowProc (hwnd, message, wParam, lParam);
}

/*****************************************************************************/
void HardlockFunction(HDC hdc)
/*****************************************************************************/
{
short nLineCnt = 1;

if(LoginStatus != STATUS_OK)
  {
  switch (LoginStatus)
    {
    case NETWORK_ERROR:
      sprintf(buffer, " Sorry, a network error occured, maybe IPX not loaded!!");
      break;
    case NO_DONGLE:
      sprintf(buffer, " Sorry, no Hardlock with this ID found!!");
      break;
    case VERSION_MISMATCH:
      sprintf(buffer, " Sorry, version mismatch between API and HL-Server or device driver!!");
      break;
    case INVALID_ENV:
      sprintf(buffer, " Sorry, invalid environment search string!! (HL_SEARCH)");
      break;
    case CANNOT_OPEN_DRIVER:
      sprintf(buffer, " Sorry, cannot open driver, maybe Hardlock driver not installed!!");
      break;
    case TOO_MANY_USERS:
      sprintf(buffer, " Sorry, too many logins to HL-Server. Login table full!!");
      break;
    case INVALID_LIC:
      sprintf(buffer, " Sorry, no valid licence information found!! (LM)");
      break;
    case NO_LICENSE:
      sprintf(buffer, " Sorry, no licence information for the requested slot!! (LM)");
      break;
    default:
      sprintf(buffer, " Sorry, an unexpected error occured!! (Status: %d)", LoginStatus);
    }
  Say (hdc, nLineCnt++, buffer);
  return;
  }

sprintf(buffer, " Hardlock E-Y-E with Module Address\t\t: %d ", MODAD);
Say (hdc, nLineCnt++, buffer );

/* ---------------------------- */
/* Get the API version number : */
/* ---------------------------- */
sprintf(buffer, " The API version is\t\t\t: %i", (Word) HL_VERSION());
Say (hdc, nLineCnt++, buffer );

/* ----------------------------------------------------- */
/* Looking for the Hardlock with the expected coding.    */
/* ----------------------------------------------------- */
if((Word) HL_AVAIL() == STATUS_OK)
  Say(hdc, nLineCnt++, " The connected Hardlock E-Y-E is\t\t: Test device");
 else
  Say(hdc, nLineCnt++, " The connected Hardlock E-Y-E is\t\t: Not the test device");

/* ------------------------------------------------------------ */
/* Now we can get some informations about the connected module. */
/* ------------------------------------------------------------ */
TestOK = HL_ACCINF();
switch (TestOK)
  {
  case LOCAL_DEVICE:
    Say(hdc,nLineCnt++, " The Hardlock E-Y-E access is\t\t: Local");
    sprintf(buffer, " Connected to the local port address\t\t: 0x%03X", (Word) HL_PORTINF());
    Say (hdc, nLineCnt++, buffer);
    break;
  case NET_DEVICE:
    Say(hdc, nLineCnt++, " The Hardlock E-Y-E access is\t\t: Remote");
    sprintf(buffer, " The HL-Server version is\t\t\t: %d", (Word) HL_HLSVERS());
    Say(hdc, nLineCnt++, buffer);
    sprintf(buffer, " Connected to the remote port address\t: 0x%03X", (Word) HL_PORTINF());
    Say(hdc, nLineCnt++, buffer);
    sprintf(buffer, " Number of users logged in HL-Server\t\t: %d", (Word) HL_USERINF());
    Say(hdc, nLineCnt++, buffer);
    sprintf(buffer, " The max. number of HL-Server logins is\t: %d", (Word) HL_MAXUSER());
    Say(hdc, nLineCnt++, buffer);
    break;
  default:
    Say(hdc, nLineCnt++, " The Hardlock E-Y-E access is\t\t: No Access");
    break;
  }

/* ------------------------------------------------------ */
/* Read the internal serial number of Hardlock USB Module :
/* ------------------------------------------------------ */
TestOK = HL_READID((Word *)&SerialID, ((Word *)&SerialID)+1);
switch (TestOK)
  {
  case STATUS_OK:
    sprintf(buffer, " The serial number ID is\t\t\t: %lu (0x%08lX)", SerialID, SerialID);
    Say (hdc, nLineCnt++, buffer);
    break;
  case NO_SERIALID:
    Say(hdc,nLineCnt++, " The serial number ID is\t\t\t: not available for this Key");
    break;
  default:
    sprintf(buffer, " Cannot determine serial ID, API error\t: %i", TestOK);
    Say (hdc, nLineCnt++, buffer);
  }

/* ------------------------------------------------------ */
/* Now we decrypt the message from CryptStr. Maybe we use */
/* the message in our application.                        */
/* ------------------------------------------------------ */
nLineCnt++;
sprintf(buffer, " The encrypted message is\t\t\t: %s", CryptStr);
Say (hdc, nLineCnt++, buffer);
TestOK = HL_AVAIL();
if (TestOK == STATUS_OK)
  TestOK = HL_CODE(CryptStr, 4);
if(TestOK == STATUS_OK)
  {
  /* ------------------------------------------------- */
  /* HL_CODE returned 0, CryptStr should be decrypted. */
  /* ------------------------------------------------- */
  sprintf(buffer, " The decrypted message is\t\t\t: %s", CryptStr);
  Say (hdc, nLineCnt++, buffer);
  HL_CODE(CryptStr, 4);
  sprintf(buffer, " Encrypted again\t\t\t\t: %s", CryptStr);
  Say (hdc, nLineCnt++, buffer);
  }
 else
  {
  /* ----------------------------------------------------------------------*/
  /* HL_CODE returned an other value, maybe someone removed the Hardlock ? */
  /* ----------------------------------------------------------------------*/
  Say(hdc, nLineCnt++, " Sorry, the decryption has failed!");
  }

/* ---------------------------------------------------- */
/* We're looking for the memory option of the Hardlock. */
/* ---------------------------------------------------- */
nLineCnt++;
TestOK = HL_MEMINF();
if(TestOK == STATUS_OK)
  {
  Say (hdc, nLineCnt++, " Hardlock E-Y-E with memory\t\t: Yes");

/* ------------------------------------------------------- */
/* Now we can work with the memory. Let's read the string  */
/* written in register 48 to 63.                           */
/* ------------------------------------------------------- */
  for(n = 0, Reg = 48; Reg < 64; Reg++)
    {
/* -------------------------------------------------------- */
/* The memory is organized as 16 bit registers, so we have  */
/* to perform a typecasting.                                */
/* -------------------------------------------------------- */
    HL_READ(Reg, &Val);
    Text[n++] = (char) (Val >> 8);
    Text[n++] = (char) (Val & 255);
    }
/* ---------------------------------- */
/* We terminate the string with 0 ... */
/* ---------------------------------- */
  Text[n] = '\0';

/* ----------------- */
/* ... and print it. */
/* ----------------- */
  sprintf(buffer, " The memory contents string is\t\t: [%s]", Text);
  Say (hdc, nLineCnt++, buffer);
  }
 else
  Say (hdc, nLineCnt++, " Hardlock E-Y-E with memory\t\t: No");
}

/*****************************************************************************/
void Say(HDC hdc, short y, char *text)
/*****************************************************************************/
{
TabbedTextOut (hdc, 10, 20*y, text, strlen(text), 0, NULL, 0);
}
