
#include "stdafx.h"
#include "hlapi_c.h"

#include "stdlib.h"

#include "eep.h"


BOOL APIENTRY DllMain
( 
	HANDLE hModule, 
  DWORD  ul_reason_for_call, 
  LPVOID lpReserved
)
{
    return TRUE;
}



void __stdcall GetEEP
(
	char *					desc,				// dongle description			[max. 60]							IN
	char *					res1,				// reserved1							[max. 80]							IN
	char *					res2,				// reserved2							[max. 80]							IN
	char *					tmpl,				// template description		[max. 40]							IN
	unsigned short	uma,				// user module address		16 bit								IN
	unsigned short	sc,					// subcode								16 bit								IN
	char *					vk,					// vendor key							[max. 120]						IN
	unsigned short	is_rus,			// RUS										16 bit								IN
	unsigned long		sid,				// serial number					32 bit								IN
	unsigned long		buflen,			// length of HL_LIS				32 bit								IN
	HL_LIS *				buffer,			// HL_LIS = Glob.Exp, CounterLimit, Slots...		IN
	char *					company,		// company								[max. 80]							IN
	char *					name,				// name										[max. 80]							IN
	char *					cust_id,		// customer id						[max. 10]							IN
	char *					cres1,			// customer reserved1			[max. 80]							IN
	char *					cres2,			// customer reserved1			[max. 80]							IN
	unsigned char * result			// result buffer					[128]									OUT
)
{
	//
	// for debugging: show a message box with parameters
	//
	
	char buf[100000], tmp[100];
	memset(buf,0,100000);
	strcat(buf, "\nDescription = "); strcat(buf, desc);
	strcat(buf, "\nHL Reserved1 = "); strcat(buf, res1);
	strcat(buf, "\nHL Reserved2 = "); strcat(buf, res2);
	strcat(buf, "\nTemplate = ");	strcat(buf,tmpl);
	strcat(buf, "\nUserModAddr = "); itoa(uma, tmp, 10); strcat(buf, tmp);
	strcat(buf, "\nSubcode = "); itoa(sc, tmp, 10); strcat(buf, tmp);
	strcat(buf, "\nVendor Key = "); strcat(buf, vk);
	strcat(buf, "\nIsRUS = "); itoa(is_rus, tmp, 10); strcat(buf, tmp);
	strcat(buf, "\nSerialnumber = "); itoa(sid, tmp, 10); strcat(buf, tmp);
	if(company)
		{ strcat(buf, "\nCustomer company = "); strcat(buf, company); }
	if(name)
		{ strcat(buf, "\nCustomer name = "); strcat(buf, name); }
	if(cust_id)
		{ strcat(buf, "\nCustomer id = "); strcat(buf, cust_id); }
	if(cres1)
		{ strcat(buf, "\nCustomer Res1 = "); strcat(buf, cres1); }
	if(cres2)
		{ strcat(buf, "\nCustomer Res2 = "); strcat(buf, cres2); }
	::MessageBox(NULL, buf, "Parameters passed to EEP.DLL", MB_OK);

	//
	// sample code for writing Reserved1 and Reserved2 fields into memory
	// make sure not to write more than 128 bytes into buffer (non-LiMaS case)
	// make sure not to write more than 82 bytes into buffer (LiMaS case)
	//

	int i,j;

	j = 0;

	if(res1 && result)
		for(i=0; (res1[i]!=0) && (i+j<82); i++)
			result[i+j]=res1[i];

	j = i;

	if(res2 && result)
		for(i=0; (res2[i]!=0) && (i+j<82); i++)
			result[i+j]=res2[i];
}