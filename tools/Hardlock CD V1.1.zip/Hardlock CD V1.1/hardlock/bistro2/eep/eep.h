#pragma once


void __stdcall GetEEP
(
	char *					desc,				// dongle description			[max. 60]
	char *					res1,				// reserved1							[max. 80]
	char *					res2,				// reserved2							[max. 80]
	char *					tmpl,				// template description		[max. 40]
	unsigned short	uma,				// user module address
	unsigned short	sc,					// subcode
	char *					vk,					// vendor key							[max. 120]
	unsigned short	is_rus,			// RUS flag
	unsigned long		sid,				// serial number
	unsigned long		buflen,			// length of HL_LIS
	HL_LIS *				buffer,			// HL_LIS = Glob.Exp, CounterLimit, Slots...
	char *					company,		// company
	char *					name,				// name
	char *					cust_id,		// customer id
	char *					cres1,			// customer reserved1			[80]													
	char *					cres2,			// customer reserved1			[80]										
	unsigned char * result			// result buffer					[128]
);


