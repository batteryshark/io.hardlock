'****************************************************************************
'**                                                                        **
'**                              Hardlock                                  **
'**                    API-Structures and definitions                      **
'**                                                                        **
'**   This file contains some helpful defines to access a Hardlock using   **
'**   the application programing interface (API) for Hardlock.             **
'**                                                                        **
'**                       Aladdin Knowledge Systems                        **
'**                                                                        **
'**  Revision history                                                      **
'**  ----------------                                                      **
'** $Id: AKSHardlock.vb,v 1.2 2002/11/25 09:34:39 alex Exp $
'** $Date: 2002/11/25 09:34:39 $
'** $Name:  $
'** $Author: alex $
'**
'***************************************************************************
'* Revision history:
'* $Log: AKSHardlock.vb,v $
'* Revision 1.2  2002/11/25 09:34:39  alex
'* changed the return value for HL_LOGUT to short
'*
'* Revision 1.1  2002/11/13 08:08:51  alex
'* initial version and check-in
'*
'**
'***************************************************************************

Imports System.Runtime.InteropServices
Imports System.Text

Namespace Hardlock

    Module AKSHardlock
        '* -------------------- *'
        '* Dongle access mode : *'
        '* -------------------- *'

        Enum AccessMode As Short
            LOCAL_DEVICE = 1                 '* Query local HL only         *'
            NET_DEVICE = 2                   '* Query remote HL only        *'
            DONT_CARE = 3                    '* Query local or remote HL    *'
        End Enum

        '* -------------------- *'
        '* RUS flags:           *'
        '* -------------------- *'
        Enum RusFlags As Short
            FORCE_RUS = 1                    '* Enable RUS init without VK   *'
            FORCE_ALF_CREATE = 1             '* Force creation of ALF file in HLM_WRITELICENSE *'
        End Enum

        '* -------------------- *'
        '* API Status Codes :   *'
        '* -------------------- *'
        Enum APIStatus As Short
            STATUS_OK = 0                    '* API call was succesfull                *'
            NOT_INIT = 1                     '* DONGLE not initialized                 *'
            ALREADY_INIT = 2                 '* Already initialized                    *'
            UNKNOWN_DONGLE = 3               '* Device not supported                   *'
            UNKNOWN_FUNCTION = 4             '* Function not supported                 *'
            HLS_FULL = 6                     '* HL-Server login table full             *'
            NO_DONGLE = 7                    '* No device available                    *'
            NETWORK_ERROR = 8                '* A network error occured                *'
            NO_ACCESS = 9                    '* No device available                    *'
            INVALID_PARAM = 10               '* A wrong parameter occured              *'
            VERSION_MISMATCH = 11            '* HL-Server not API version              *'
            DOS_ALLOC_ERROR = 12             '* Error on memory allocation             *'
            CANNOT_OPEN_DRIVER = 14          '* Can not open Hardlock driver           *'
            INVALID_ENV = 15                 '* Invalid environment string             *'
            DYNALINK_FAILED = 16             '* Unable to get a function entry         *'
            INVALID_LIC = 17                 '* No valid licence info (LM)             *'
            NO_LICENSE = 18                  '* Slot'licence not enabled (LM)          *'
            PORT_BUSY = 19                   '* Cannot acquire port                    *'
            RUS_NO_DEVICE = 20               '* Key is no Hardlock RUS key             *'
            RUS_INVALID_LIC = 21             '* Invalid RUS license                    *'
            RUS_SYNC_ERR = 22                '* FIB in key and api struc mismatch      *'
            NOT_IMPLEMENTED = 23             '* not (yet) implemented                  *'
            BUFFER_TOO_SMALL = 24            '* Buffer for function too small          *'
            UNKNOWN_HW_TYPE = 25             '* unknown hardware descriptor            *'
            RUS_INV_FBPOS = 26               '* unknown fixed block position           *'
            RUS_INVALID_SLOT = 27            '* Non-existing slot number given         *'
            RUS_DATE_FAKE = 28               '* RUS Date fake detected                 *'
            RUS_COUNT_DOWN = 29              '* RUS dead counter limit reached         *'
            RUS_INVALID_VK = 30              '* RUS Vendor key is invalid              *'
            RUS_NO_LIC_FILE = 31             '* RUS License file not found             *'
            RUS_INV_VBLOCK = 32              '* RUS invalid variable block             *'
            RUS_LIC_FILE_WRITE_ERR = 33      '* error writing (updated) license file   *'
            RUS_NO_INFO_AVAILABLE = 34       '* GET_HWDEP_INFO: no info there          *'
            RUS_INFO_PACK_ERR = 35           '* GET_HWDEP_INFO: cannot TLV encode data *'
            RUS_LIC_WRITE_ERR = 36           '* write license failed                   *'
            RUS_DATE_EXPIRED = 37            '* RUS Expiration Date reached.           *'
            TS_DETECTED = 38                 '* Term. Server/Citrix Winframe detected  *'
            RUS_INVALID_RTB = 39             '* Invalid updated data (RTB)             *'
            RUS_RTB_EXPIRED = 40             '* Update data (RTB) has expired.         *'
            RUS_SERIAL_MISMATCH = 41         '* Update data serial does not match      *'
            TOO_MANY_USERS = 256             '* Login table full (remote)              *'
            SELECT_DOWN = 257                '* Printer not On-line                    *'
            NO_SERIALID = 258                '* Serial ID not readable or n'a          *'
        End Enum

        <StructLayout(LayoutKind.Explicit)> _
        Structure HL_SIS
            <FieldOffset(0)> Dim max_user As Integer
            <FieldOffset(4)> Public cur_user As Integer
            <FieldOffset(8)> Public exp_date As Short
            <FieldOffset(10)> Public flag As Byte
            <FieldOffset(11)> Public res As Byte
        End Structure

        <StructLayout(LayoutKind.Explicit)> _
        Structure HL_LIS
            <FieldOffset(0)> Public current_date As Short
            <FieldOffset(2)> Public res As Short
            <FieldOffset(4)> Public num_slots As Integer
            <FieldOffset(8)> Public glob_exp_date As Short
            <FieldOffset(10)> Public res2 As Short
            <FieldOffset(12), MarshalAs(UnmanagedType.Struct)> _
             Public slots() As HL_SIS
        End Structure

        Public Sub BufferToStruct(ByVal buf As Byte(), ByRef lic As Hardlock.HL_LIS)
            Dim buflen As Integer
            buflen = buf.Length

            ' Initializing the HL_LIS structure
            lic.current_date = buf(0) + buf(1) * 256    'use the suppplied date function to convert to a valid date
            lic.res = 0
            lic.num_slots = buf(4) + buf(5) * 256 + buf(6) * 65536 + buf(7) * 16777216
            lic.glob_exp_date = buf(8) + buf(9) * 256
            lic.res2 = 0
            ReDim lic.slots(lic.num_slots - 1)
            Dim i As Integer
            For i = 0 To lic.num_slots - 1
                lic.slots(i).max_user = buf(12 + i * 12) + buf(13 + i * 12) * 256 + buf(14 + i * 12) * 65536 + buf(15 + i * 12) * 16777216
                lic.slots(i).cur_user = buf(16 + i * 12) + buf(17 + i * 12) * 256 + buf(18 + i * 12) * 65536 + buf(19 + i * 12) * 16777216
                lic.slots(i).exp_date = buf(20 + i * 12) + buf(21 + i * 12) * 256
                lic.slots(i).flag = buf(22 + i * 12)
                lic.slots(i).res = buf(23 + i * 12)
            Next i
        End Sub

        ' Static function to convert the API days from license structure to Day/Month/Year
        Public Sub ConvertAPIDaysToDate(ByVal apidays As Short, ByRef myday As Short, ByRef mymonth As Short, ByRef myyear As Short)

            Dim scalar, temp As Integer
            scalar = (apidays + 730120 - 365)
            temp = ((scalar * 400) \ 146097)
            While yearstodays(temp) < scalar
                temp += 1                
            End While

            myyear = temp
            temp = (scalar - yearstodays(temp - 1))
            If temp > 59 Then
                temp += 2
                If leap(myyear) = True Then
                    If temp > 62 Then
                        temp = temp - 1
                    Else
                        temp = temp - 2
                    End If
                End If
            End If
            mymonth = ((temp * 100 + 3007) \ 3057)
            myday = (temp - monthstodays(mymonth))
        End Sub

        'Date helper functions
        Public Function leap(ByVal yr As Integer) As Boolean
            'leap = 
            If (yr Mod 400) = 0 Then
                leap = True
                Exit Function
            End If
            If (yr Mod 4) = 0 Then
                If (yr Mod 100) <> 0 Then
                    leap = True
                    Exit Function
                End If
            End If
            leap = False
            'c-code ;-)
            'return ((bool)(yr  400 == 0)) || ((bool)(yr % 4 == 0) && (bool)(yr % 100 != 0))
        End Function

        Public Function monthstodays(ByVal month As Integer) As Integer
            monthstodays = (month * 3057 - 3007) \ 100
        End Function

        Public Function yearstodays(ByVal yr As Integer) As Integer
            yearstodays = yr * 365 + yr \ 4 - yr \ 100 + yr \ 400
        End Function

        ' DLL contains the API-HighLevel routines :
        ' -----------------------------------------

        Declare Function HL_LOGIN Lib "HLVDD.DLL" (ByVal Modad As Short, ByVal remote As Short, ByVal id1 As Byte(), ByVal id2 As Byte()) As Short

        Declare Function HL_LOGOUT Lib "HLVDD.DLL" () As Short
        ' An additional possiblity is to declare the imported functions via DllImport:
        '-----------------------------------------------------------------------------
        ' Example for DllImport
        '----------------------
        '<DllImport("HLVDD.DLL", EntryPoint:="HL_LOGOUT",   SetLastError:=True, _
        '                                                   CharSet:=CharSet.Ansi, _
        '                                                   ExactSpelling:=True, _
        '                                                   CallingConvention:=CallingConvention.StdCall)> _
        'Public Function _
        '    HL_LOGOUT() As Short
        'End Function

        Declare Function HL_ABORT Lib "HLVDD.DLL" () As Short
        Declare Function HL_ACCINF Lib "HLVDD.DLL" () As Short
        Declare Function HL_PORTINF Lib "HLVDD.DLL" () As Short
        Declare Function HL_AVAIL Lib "HLVDD.DLL" () As Short
        Declare Function HL_READ Lib "HLVDD.DLL" (ByVal reg As Short, ByRef value As Short) As Short
        Declare Function HL_READBL Lib "HLVDD.DLL" (ByVal EEprom As Byte()) As Short
        Declare Function HL_WRITE Lib "HLVDD.DLL" (ByVal reg As Short, ByVal value As Short) As Short
        Declare Function HL_WRITEBL Lib "HLVDD.DLL" (ByVal EEprom As Byte()) As Short
        Declare Function HL_CODE Lib "HLVDD.DLL" (ByVal codedata As Byte(), ByVal blcnt As Integer) As Short
        Declare Function HL_MAXUSER Lib "HLVDD.DLL" () As Short
        Declare Function HL_MEMINF Lib "HLVDD.DLL" () As Short
        Declare Function HL_USERINF Lib "HLVDD.DLL" () As Short
        Declare Function HL_VERSION Lib "HLVDD.DLL" () As Short
        Declare Function HL_HLSVERS Lib "HLVDD.DLL" () As Short
        Declare Function HL_READID Lib "HLVDD.DLL" (ByRef IDLow As Short, ByRef IDHigh As Short) As Short
        Declare Function HL_ERRMSGB Lib "HLVDD.DLL" (ByVal num As Short, ByVal options As Integer, ByVal Buf As Byte(), ByVal BufLen As Short) As Short
        'Rus Functions
        '=============
        Declare Function HLM_LOGIN Lib "HLVDD.DLL" (ByVal Modad As Short, ByVal Access As Short, ByVal id1 As Byte(), ByVal id2 As Byte(), ByVal VKey As Byte(), ByVal RUSOptions As Integer, ByVal SearchStr As Byte()) As Short
        Declare Function HLM_OCCUPYSLOT Lib "HLVDD.DLL" (ByVal Slot As Integer) As Short
        Declare Function HLM_FREESLOT Lib "HLVDD.DLL" (ByVal Slot As Integer) As Short
        Declare Function HLM_CHECKSLOT Lib "HLVDD.DLL" (ByVal Slot As Integer, ByRef MaxUser As Integer, ByRef CurrentUser As Integer) As Short
        Declare Function HLM_CHECKCOUNTER Lib "HLVDD.DLL" (ByVal IncVal As Short, ByRef MaxCounter As Integer, ByRef CurrentCounter As Integer) As Short
        Declare Function HLM_CHECKEXPDATE Lib "HLVDD.DLL" (ByVal Slot As Integer, ByRef Year As Short, ByRef Month As Short, ByRef Day As Short) As Short
        Declare Function HLM_GETRUSINFO Lib "HLVDD.DLL" (ByRef BufLen As Integer, ByVal RTBBuffer As Byte(), ByVal Base64 As Short) As Short
        Declare Function HLM_WRITELICENSE Lib "HLVDD.DLL" (ByVal BufLen As Integer, ByVal RTBBuffer As Byte(), ByVal Access As Short, ByVal SearchStr As Byte(), ByVal options As Short) As Short
        Declare Function HLM_ISRUSHL Lib "HLVDD.DLL" (ByRef ID As Integer) As Short
        Declare Function HLM_CHECKALLSLOTS Lib "HLVDD.DLL" (ByRef BufLen As Integer, ByVal Buffer As Byte()) As Short
        Declare Function HLM_LOGOUT Lib "HLVDD.DLL" () As Short

    End Module
End Namespace

