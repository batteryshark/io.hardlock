'****************************************************************************
'**                                                                        **
'**                              Hardlock                                  **
'**                             API-Sampel                                 **
'**                                                                        **
'**                       Aladdin Knowledge Systems                        **
'**                                                                        **
'**  Revision history                                                      **
'**  ----------------                                                      **
'** $Id: hl-demo.vb,v 1.2 2002/11/25 09:38:11 alex Exp $
'** $Date: 2002/11/25 09:38:11 $
'** $Name:  $
'** $Author: alex $
'**
'******************************************************************************
'* Revision history:
'* $Log: hl-demo.vb,v $
'* Revision 1.2  2002/11/25 09:38:11  alex
'* changed default value to 29809 and changed history size
'*
'* Revision 1.1  2002/11/13 08:08:53  alex
'* initial version and check-in
'*
'**
'***************************************************************************'

Imports System.IO
Imports System.Text
Imports System.Runtime.InteropServices

Public Class hldemo
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents gbHistory As System.Windows.Forms.GroupBox
    Friend WithEvents gbSettings As System.Windows.Forms.GroupBox
    Friend WithEvents nudModad As System.Windows.Forms.NumericUpDown
    Friend WithEvents lModad As System.Windows.Forms.Label
    Friend WithEvents rbLocal As System.Windows.Forms.RadioButton
    Friend WithEvents rbNetwork As System.Windows.Forms.RadioButton
    Friend WithEvents rbBoth As System.Windows.Forms.RadioButton
    Friend WithEvents gbRUS As System.Windows.Forms.GroupBox
    Friend WithEvents cbRUS As System.Windows.Forms.CheckBox
    Friend WithEvents rbReadFile As System.Windows.Forms.RadioButton
    Friend WithEvents rbWriteFile As System.Windows.Forms.RadioButton
    Friend WithEvents btnAPIDemo As System.Windows.Forms.Button
    Friend WithEvents btnRUSUpdate As System.Windows.Forms.Button
    Friend WithEvents gbAccessMode As System.Windows.Forms.GroupBox
    Friend WithEvents rtbHistory As System.Windows.Forms.RichTextBox
    Friend WithEvents ofdWriteRUS As System.Windows.Forms.OpenFileDialog
    Friend WithEvents sfdReadRUS As System.Windows.Forms.SaveFileDialog
    Friend WithEvents btnRUSReadFile As System.Windows.Forms.Button
    Friend WithEvents tbRUSReadFile As System.Windows.Forms.TextBox
    Friend WithEvents tbRUSWriteFile As System.Windows.Forms.TextBox
    Friend WithEvents btnRUSWriteFile As System.Windows.Forms.Button
    Friend WithEvents tbReturnText As System.Windows.Forms.TextBox
    Friend WithEvents tbReturnValue As System.Windows.Forms.TextBox
    Friend WithEvents lReturnText As System.Windows.Forms.Label
    Friend WithEvents lReturnValue As System.Windows.Forms.Label
    Friend WithEvents lActiveOperation As System.Windows.Forms.Label
    Friend WithEvents tbActiveOperation As System.Windows.Forms.TextBox
    Friend WithEvents gbActive As System.Windows.Forms.GroupBox
    Friend WithEvents btnClearHistory As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(hldemo))
        Me.gbHistory = New System.Windows.Forms.GroupBox()
        Me.rtbHistory = New System.Windows.Forms.RichTextBox()
        Me.btnClearHistory = New System.Windows.Forms.Button()
        Me.gbSettings = New System.Windows.Forms.GroupBox()
        Me.btnAPIDemo = New System.Windows.Forms.Button()
        Me.gbRUS = New System.Windows.Forms.GroupBox()
        Me.btnRUSWriteFile = New System.Windows.Forms.Button()
        Me.tbRUSWriteFile = New System.Windows.Forms.TextBox()
        Me.btnRUSReadFile = New System.Windows.Forms.Button()
        Me.tbRUSReadFile = New System.Windows.Forms.TextBox()
        Me.rbWriteFile = New System.Windows.Forms.RadioButton()
        Me.rbReadFile = New System.Windows.Forms.RadioButton()
        Me.btnRUSUpdate = New System.Windows.Forms.Button()
        Me.gbAccessMode = New System.Windows.Forms.GroupBox()
        Me.rbBoth = New System.Windows.Forms.RadioButton()
        Me.rbNetwork = New System.Windows.Forms.RadioButton()
        Me.rbLocal = New System.Windows.Forms.RadioButton()
        Me.lModad = New System.Windows.Forms.Label()
        Me.nudModad = New System.Windows.Forms.NumericUpDown()
        Me.cbRUS = New System.Windows.Forms.CheckBox()
        Me.ofdWriteRUS = New System.Windows.Forms.OpenFileDialog()
        Me.sfdReadRUS = New System.Windows.Forms.SaveFileDialog()
        Me.tbReturnText = New System.Windows.Forms.TextBox()
        Me.tbReturnValue = New System.Windows.Forms.TextBox()
        Me.lReturnText = New System.Windows.Forms.Label()
        Me.lReturnValue = New System.Windows.Forms.Label()
        Me.lActiveOperation = New System.Windows.Forms.Label()
        Me.tbActiveOperation = New System.Windows.Forms.TextBox()
        Me.gbActive = New System.Windows.Forms.GroupBox()
        Me.gbHistory.SuspendLayout()
        Me.gbSettings.SuspendLayout()
        Me.gbRUS.SuspendLayout()
        Me.gbAccessMode.SuspendLayout()
        CType(Me.nudModad, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbActive.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbHistory
        '
        Me.gbHistory.Controls.AddRange(New System.Windows.Forms.Control() {Me.rtbHistory, Me.btnClearHistory})
        Me.gbHistory.Location = New System.Drawing.Point(344, 8)
        Me.gbHistory.Name = "gbHistory"
        Me.gbHistory.Size = New System.Drawing.Size(376, 456)
        Me.gbHistory.TabIndex = 2
        Me.gbHistory.TabStop = False
        Me.gbHistory.Text = "History"
        '
        'rtbHistory
        '
        Me.rtbHistory.Location = New System.Drawing.Point(8, 16)
        Me.rtbHistory.Name = "rtbHistory"
        Me.rtbHistory.Size = New System.Drawing.Size(360, 400)
        Me.rtbHistory.TabIndex = 1
        Me.rtbHistory.Text = ""
        '
        'btnClearHistory
        '
        Me.btnClearHistory.Location = New System.Drawing.Point(248, 424)
        Me.btnClearHistory.Name = "btnClearHistory"
        Me.btnClearHistory.Size = New System.Drawing.Size(120, 24)
        Me.btnClearHistory.TabIndex = 2
        Me.btnClearHistory.Text = "Clear History"
        '
        'gbSettings
        '
        Me.gbSettings.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnAPIDemo, Me.gbRUS, Me.gbAccessMode, Me.lModad, Me.nudModad, Me.cbRUS})
        Me.gbSettings.Location = New System.Drawing.Point(8, 8)
        Me.gbSettings.Name = "gbSettings"
        Me.gbSettings.Size = New System.Drawing.Size(328, 328)
        Me.gbSettings.TabIndex = 0
        Me.gbSettings.TabStop = False
        Me.gbSettings.Text = "Settings"
        '
        'btnAPIDemo
        '
        Me.btnAPIDemo.Location = New System.Drawing.Point(184, 120)
        Me.btnAPIDemo.Name = "btnAPIDemo"
        Me.btnAPIDemo.Size = New System.Drawing.Size(120, 24)
        Me.btnAPIDemo.TabIndex = 6
        Me.btnAPIDemo.Text = "Query API-Demo"
        '
        'gbRUS
        '
        Me.gbRUS.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnRUSWriteFile, Me.tbRUSWriteFile, Me.btnRUSReadFile, Me.tbRUSReadFile, Me.rbWriteFile, Me.rbReadFile, Me.btnRUSUpdate})
        Me.gbRUS.Location = New System.Drawing.Point(8, 152)
        Me.gbRUS.Name = "gbRUS"
        Me.gbRUS.Size = New System.Drawing.Size(312, 168)
        Me.gbRUS.TabIndex = 7
        Me.gbRUS.TabStop = False
        Me.gbRUS.Text = "RUS Update Demo"
        '
        'btnRUSWriteFile
        '
        Me.btnRUSWriteFile.Location = New System.Drawing.Point(264, 104)
        Me.btnRUSWriteFile.Name = "btnRUSWriteFile"
        Me.btnRUSWriteFile.Size = New System.Drawing.Size(32, 20)
        Me.btnRUSWriteFile.TabIndex = 6
        Me.btnRUSWriteFile.Text = "..."
        '
        'tbRUSWriteFile
        '
        Me.tbRUSWriteFile.Enabled = False
        Me.tbRUSWriteFile.Location = New System.Drawing.Point(8, 104)
        Me.tbRUSWriteFile.Name = "tbRUSWriteFile"
        Me.tbRUSWriteFile.Size = New System.Drawing.Size(248, 20)
        Me.tbRUSWriteFile.TabIndex = 5
        Me.tbRUSWriteFile.Text = ""
        '
        'btnRUSReadFile
        '
        Me.btnRUSReadFile.Location = New System.Drawing.Point(264, 48)
        Me.btnRUSReadFile.Name = "btnRUSReadFile"
        Me.btnRUSReadFile.Size = New System.Drawing.Size(32, 20)
        Me.btnRUSReadFile.TabIndex = 4
        Me.btnRUSReadFile.Text = "..."
        '
        'tbRUSReadFile
        '
        Me.tbRUSReadFile.Enabled = False
        Me.tbRUSReadFile.Location = New System.Drawing.Point(8, 48)
        Me.tbRUSReadFile.Name = "tbRUSReadFile"
        Me.tbRUSReadFile.Size = New System.Drawing.Size(248, 20)
        Me.tbRUSReadFile.TabIndex = 3
        Me.tbRUSReadFile.Text = ""
        '
        'rbWriteFile
        '
        Me.rbWriteFile.Location = New System.Drawing.Point(8, 80)
        Me.rbWriteFile.Name = "rbWriteFile"
        Me.rbWriteFile.Size = New System.Drawing.Size(120, 16)
        Me.rbWriteFile.TabIndex = 1
        Me.rbWriteFile.Text = "&Write to File"
        '
        'rbReadFile
        '
        Me.rbReadFile.Checked = True
        Me.rbReadFile.Location = New System.Drawing.Point(8, 24)
        Me.rbReadFile.Name = "rbReadFile"
        Me.rbReadFile.Size = New System.Drawing.Size(96, 16)
        Me.rbReadFile.TabIndex = 0
        Me.rbReadFile.TabStop = True
        Me.rbReadFile.Text = "&Read from File"
        '
        'btnRUSUpdate
        '
        Me.btnRUSUpdate.Location = New System.Drawing.Point(176, 136)
        Me.btnRUSUpdate.Name = "btnRUSUpdate"
        Me.btnRUSUpdate.Size = New System.Drawing.Size(120, 24)
        Me.btnRUSUpdate.TabIndex = 2
        Me.btnRUSUpdate.Text = "Update-API-Demo"
        '
        'gbAccessMode
        '
        Me.gbAccessMode.Controls.AddRange(New System.Windows.Forms.Control() {Me.rbBoth, Me.rbNetwork, Me.rbLocal})
        Me.gbAccessMode.Location = New System.Drawing.Point(8, 24)
        Me.gbAccessMode.Name = "gbAccessMode"
        Me.gbAccessMode.Size = New System.Drawing.Size(312, 40)
        Me.gbAccessMode.TabIndex = 0
        Me.gbAccessMode.TabStop = False
        Me.gbAccessMode.Text = "Acess Mode"
        '
        'rbBoth
        '
        Me.rbBoth.Location = New System.Drawing.Point(184, 16)
        Me.rbBoth.Name = "rbBoth"
        Me.rbBoth.Size = New System.Drawing.Size(112, 16)
        Me.rbBoth.TabIndex = 2
        Me.rbBoth.Text = "Both (local first)"
        '
        'rbNetwork
        '
        Me.rbNetwork.Location = New System.Drawing.Point(96, 16)
        Me.rbNetwork.Name = "rbNetwork"
        Me.rbNetwork.Size = New System.Drawing.Size(128, 16)
        Me.rbNetwork.TabIndex = 1
        Me.rbNetwork.Text = "&Network"
        '
        'rbLocal
        '
        Me.rbLocal.Checked = True
        Me.rbLocal.Location = New System.Drawing.Point(8, 16)
        Me.rbLocal.Name = "rbLocal"
        Me.rbLocal.Size = New System.Drawing.Size(72, 16)
        Me.rbLocal.TabIndex = 0
        Me.rbLocal.TabStop = True
        Me.rbLocal.Text = "&Local"
        '
        'lModad
        '
        Me.lModad.Location = New System.Drawing.Point(8, 72)
        Me.lModad.Name = "lModad"
        Me.lModad.Size = New System.Drawing.Size(88, 16)
        Me.lModad.TabIndex = 1
        Me.lModad.Text = "Module Address"
        '
        'nudModad
        '
        Me.nudModad.Location = New System.Drawing.Point(8, 88)
        Me.nudModad.Maximum = New Decimal(New Integer() {32767, 0, 0, 0})
        Me.nudModad.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudModad.Name = "nudModad"
        Me.nudModad.Size = New System.Drawing.Size(88, 20)
        Me.nudModad.TabIndex = 2
        Me.nudModad.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudModad.Value = New Decimal(New Integer() {29809, 0, 0, 0})
        '
        'cbRUS
        '
        Me.cbRUS.Location = New System.Drawing.Point(120, 90)
        Me.cbRUS.Name = "cbRUS"
        Me.cbRUS.Size = New System.Drawing.Size(176, 16)
        Me.cbRUS.TabIndex = 3
        Me.cbRUS.Text = "&Use Remote Update System"
        '
        'ofdWriteRUS
        '
        Me.ofdWriteRUS.DefaultExt = "vtc"
        Me.ofdWriteRUS.Filter = "Vendor to Customer (*.VTC)|*.VTC"
        '
        'sfdReadRUS
        '
        Me.sfdReadRUS.Filter = "Customer to Vendor (*.CTV)|*.CTV"
        '
        'tbReturnText
        '
        Me.tbReturnText.Location = New System.Drawing.Point(112, 88)
        Me.tbReturnText.Name = "tbReturnText"
        Me.tbReturnText.Size = New System.Drawing.Size(208, 20)
        Me.tbReturnText.TabIndex = 5
        Me.tbReturnText.Text = ""
        '
        'tbReturnValue
        '
        Me.tbReturnValue.Location = New System.Drawing.Point(8, 88)
        Me.tbReturnValue.Name = "tbReturnValue"
        Me.tbReturnValue.Size = New System.Drawing.Size(96, 20)
        Me.tbReturnValue.TabIndex = 3
        Me.tbReturnValue.Text = ""
        '
        'lReturnText
        '
        Me.lReturnText.Location = New System.Drawing.Point(112, 72)
        Me.lReturnText.Name = "lReturnText"
        Me.lReturnText.Size = New System.Drawing.Size(168, 16)
        Me.lReturnText.TabIndex = 4
        Me.lReturnText.Text = "Return Text"
        '
        'lReturnValue
        '
        Me.lReturnValue.Location = New System.Drawing.Point(8, 72)
        Me.lReturnValue.Name = "lReturnValue"
        Me.lReturnValue.Size = New System.Drawing.Size(96, 16)
        Me.lReturnValue.TabIndex = 2
        Me.lReturnValue.Text = "Return Value"
        '
        'lActiveOperation
        '
        Me.lActiveOperation.Location = New System.Drawing.Point(8, 24)
        Me.lActiveOperation.Name = "lActiveOperation"
        Me.lActiveOperation.Size = New System.Drawing.Size(160, 16)
        Me.lActiveOperation.TabIndex = 0
        Me.lActiveOperation.Text = "Active Operation"
        '
        'tbActiveOperation
        '
        Me.tbActiveOperation.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.tbActiveOperation.Location = New System.Drawing.Point(8, 40)
        Me.tbActiveOperation.Name = "tbActiveOperation"
        Me.tbActiveOperation.Size = New System.Drawing.Size(312, 20)
        Me.tbActiveOperation.TabIndex = 1
        Me.tbActiveOperation.Text = ""
        '
        'gbActive
        '
        Me.gbActive.Controls.AddRange(New System.Windows.Forms.Control() {Me.tbReturnText, Me.tbReturnValue, Me.lReturnText, Me.lReturnValue, Me.lActiveOperation, Me.tbActiveOperation})
        Me.gbActive.Location = New System.Drawing.Point(8, 344)
        Me.gbActive.Name = "gbActive"
        Me.gbActive.Size = New System.Drawing.Size(328, 120)
        Me.gbActive.TabIndex = 1
        Me.gbActive.TabStop = False
        Me.gbActive.Text = "Active"
        '
        'hldemo
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(732, 469)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.gbSettings, Me.gbActive, Me.gbHistory})
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(740, 496)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(740, 496)
        Me.Name = "hldemo"
        Me.Text = "Hardlock Sample for VB.NET"
        Me.gbHistory.ResumeLayout(False)
        Me.gbSettings.ResumeLayout(False)
        Me.gbRUS.ResumeLayout(False)
        Me.gbAccessMode.ResumeLayout(False)
        CType(Me.nudModad, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbActive.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    'Global variables for the login
    'Dim vendorkey As Hardlock.RUSVendorKey
    'Dim refkey As Hardlock.RefVerKey
    'Dim verkey As Hardlock.RefVerKey
    Dim refkey As Byte()
    Dim verkey As Byte()
    Dim vendorkey As Byte()
    Dim access As Short
    Dim result As Short
    Dim modad As Short
    Dim search As Byte()
    Dim file As FileStream
    Dim errstr(127) As Byte
    Dim vkHandle As GCHandle

    Private Sub hldemo_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' Set Reference and Verify Key to zero
        ReDim refkey(7)
        refkey(0) = 0
        refkey(1) = 0
        refkey(2) = 0
        refkey(3) = 0
        refkey(4) = 0
        refkey(5) = 0
        refkey(6) = 0
        refkey(7) = 0
        ReDim verkey(7)
        verkey(0) = 0
        verkey(1) = 0
        verkey(2) = 0
        verkey(3) = 0
        verkey(4) = 0
        verkey(5) = 0
        verkey(6) = 0
        verkey(7) = 0

        ' Set the RUS Vendor Key
        ReDim vendorkey(46)
        vendorkey(0) = &H6E
        vendorkey(1) = &H17
        vendorkey(2) = &H55
        vendorkey(3) = &HF
        vendorkey(4) = &HB9
        vendorkey(5) = &HB4
        vendorkey(6) = &HB7
        vendorkey(7) = &HB2

        vendorkey(8) = &HE8
        vendorkey(9) = &H7C
        vendorkey(10) = &H91
        vendorkey(11) = &H58
        vendorkey(12) = &HE2
        vendorkey(13) = &HE6
        vendorkey(14) = &H12
        vendorkey(15) = &HA1

        vendorkey(16) = &HF0
        vendorkey(17) = &HE
        vendorkey(18) = &HCC
        vendorkey(19) = &H16
        vendorkey(20) = &H17
        vendorkey(21) = &HE8
        vendorkey(22) = &HA6
        vendorkey(23) = &H34

        vendorkey(24) = &HAE
        vendorkey(25) = &H38
        vendorkey(26) = &H69
        vendorkey(27) = &HD3
        vendorkey(28) = &H60
        vendorkey(29) = &HE6
        vendorkey(30) = &H87
        vendorkey(31) = &HD1

        vendorkey(32) = &H9C
        vendorkey(33) = &HCE
        vendorkey(34) = &HA7
        vendorkey(35) = &HBA
        vendorkey(36) = &H7D
        vendorkey(37) = &H75
        vendorkey(38) = &HE
        vendorkey(39) = &H19

        vendorkey(40) = &HE3
        vendorkey(41) = &H6C
        vendorkey(42) = &H3D
        vendorkey(43) = &H83
        vendorkey(44) = &HB2
        vendorkey(45) = &HD8
        vendorkey(46) = &HD3

    End Sub

    Private Sub InitData()
        ' Set module address and access mode
        If rbLocal.Checked Then
            access = Hardlock.AccessMode.LOCAL_DEVICE
        ElseIf rbNetwork.Checked Then
            access = Hardlock.AccessMode.NET_DEVICE
        Else
            access = Hardlock.AccessMode.DONT_CARE
        End If
        modad = nudModad.Value
    End Sub

    Private Function DoLogin()
        InitData()
        ' Use try catch block to detect a not available DLL
        Try
            If cbRUS.Checked Then
                'Pin vendor key in memory to avoid moving by GC
                vkHandle = GCHandle.Alloc(vendorkey, GCHandleType.Pinned)

                result = Hardlock.HLM_LOGIN(modad, access, refkey, verkey, vendorkey, 0, search)
                UpdateActive("HLM_LOGIN", result)
                DoLogin = CheckApiReturn("HLM_LOGIN", result)
            Else
                result = Hardlock.HL_LOGIN(modad, access, refkey, verkey)
                UpdateActive("HL_LOGIN", result)
                DoLogin = CheckApiReturn("HL_LOGIN", result)
            End If
        Catch e As Exception
            rtbHistory.AppendText("Error accessing HLVDD.DLL" + ControlChars.CrLf)
            rtbHistory.AppendText(e.Message + ControlChars.CrLf)
            DoLogin = 0
        End Try
    End Function

    Private Function DoLoginForce()
        Try
            result = Hardlock.HLM_LOGIN(modad, access, refkey, verkey, vendorkey, Hardlock.RusFlags.FORCE_RUS, search)
            UpdateActive("HLM_LOGIN", result)
            DoLoginForce = CheckApiReturn("HLM_LOGIN", result)
        Catch e As Exception
            rtbHistory.AppendText("Error accessing HLVDD.DLL" + ControlChars.CrLf)
            rtbHistory.AppendText(e.Message() + ControlChars.CrLf)
            DoLoginForce = 0
        End Try
    End Function

    Private Sub UpdateActive(ByVal context As String, ByVal retvalue As Short)
        tbActiveOperation.Text = context
        tbReturnValue.Text = retvalue.ToString
        Hardlock.HL_ERRMSGB(retvalue, 0, errstr, 128)
        tbReturnText.Text = Encoding.Default.GetString(errstr)
        Refresh()
    End Sub

    Private Function CheckApiReturn(ByVal context As String, ByVal retvalue As Short)
        If retvalue = Hardlock.APIStatus.STATUS_OK Then
            rtbHistory.AppendText(context)
            Refresh()
            CheckApiReturn = 1
        Else
            rtbHistory.AppendText(context + ControlChars.Tab + "failed with error: " + result.ToString + ControlChars.CrLf)
            Refresh()
            CheckApiReturn = 0
        End If
    End Function

    Private Sub btnRUSFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRUSReadFile.Click
        'Open the OpenFileDialog, we write to RUS-Hardlock from file
        If ofdWriteRUS.ShowDialog() = DialogResult.OK Then
            tbRUSReadFile.Text = ofdWriteRUS.FileName
        End If
    End Sub

    Private Sub btnRUSWriteFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRUSWriteFile.Click
        'Open the SaveFileDialog, we read from Hardlock and save to file
        If sfdReadRUS.ShowDialog() = DialogResult.OK Then
            tbRUSWriteFile.Text = sfdReadRUS.FileName
        End If
    End Sub

    Private Sub btnRUSUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRUSUpdate.Click
        rtbHistory.AppendText(ControlChars.CrLf + "RUS Update Demo:" + ControlChars.CrLf)
        rtbHistory.AppendText("--------------------------------" + ControlChars.CrLf)

        'Check if a filename has been specified
        If rbReadFile.Checked Then
            If tbRUSReadFile.Text.Length = 0 Then
                rtbHistory.AppendText("Error: you have so specify a file name first!" + ControlChars.CrLf)
                Exit Sub
            End If
        Else
            If tbRUSWriteFile.Text.Length = 0 Then
                rtbHistory.AppendText("Error: you have so specify a file name first!" + ControlChars.CrLf)
                Exit Sub
            End If
        End If

        'Read the variables from the ui
        InitData()

        'Write Data to Hardlock or Read Data from Hardlock
        If rbReadFile.Checked Then
            '-------------------------------------------------------------------------
            'Open the specified file, read to buffer and use HLM_WRITELICENSE to write
            'to the Hardlock, a login in this case is not required, HLM_WRITELICESNE
            'does this on his own.
            '-------------------------------------------------------------------------

            'Read the file first to a buffer
            Dim filesize As Integer
            file = ofdWriteRUS.OpenFile
            filesize = file.Length
            Dim buffer(filesize) As Byte
            file.Read(buffer, 0, filesize)
            file.Close()

            'Use HLM_WRITELICENSE to write the update information to the Hardlock
            Try
                'Note: the last parameter could also be zero, but if the old alf-file is not found a new one is not created
                result = Hardlock.HLM_WRITELICENSE(filesize, buffer, access, search, Hardlock.RusFlags.FORCE_ALF_CREATE)
                UpdateActive("HLM_WRITELICENSE", result)
                Refresh()
            Catch ex As Exception
                'Probably DLL not found
                rtbHistory.AppendText("Error accessing HLVDD.DLL" + ControlChars.CrLf)
                rtbHistory.AppendText(ex.Message() + ControlChars.CrLf)
                Exit Sub
            End Try

            If CheckApiReturn("HLM_WRITELICENSE", result) = 1 Then
                rtbHistory.AppendText(" was successful" + ControlChars.CrLf)
                rtbHistory.AppendText("Bytes written to the Hardlock: " + filesize.ToString)
            End If

        Else
            'Login to the Hardlock
            If DoLoginForce() = 0 Then Exit Sub
            rtbHistory.AppendText(" was successful" + ControlChars.CrLf)
            Refresh()

            'Use HLM_GETRUSINFO to read the update information from the Hardlock
            'no try/catch here because DLL check already in DoLoginForce
            Dim ruslength As Integer
            Dim rusbuffer() As Byte

            Try
                result = Hardlock.HLM_GETRUSINFO(ruslength, rusbuffer, 1)
                UpdateActive("HLM_GETRUSINFO", result)
                Refresh()
            Catch e3 As Exception
                'Probably DLL not found
                rtbHistory.AppendText("Error accessing HLVDD.DLL" + ControlChars.CrLf)
                rtbHistory.AppendText(e3.Message() + ControlChars.CrLf)
                Exit Sub
            End Try

            'we determine the minimum required buffer size and expect BUFFER_TOO_SMALL as return
            If result = Hardlock.APIStatus.BUFFER_TOO_SMALL Then
                'set capacity to minimum length
                ReDim rusbuffer(ruslength)
                result = Hardlock.HLM_GETRUSINFO(ruslength, rusbuffer, 1)
                UpdateActive("HLM_GETRUSINFO", result)
                Refresh()
            Else
                CheckApiReturn("HLM_GETRUSINFO", result)
                Exit Sub
            End If
            'HLM_WRITELICENSE was successful - write to file            
            'very important: write only the real obtained length, not the allocated length
            file = sfdReadRUS.OpenFile
            file.Write(rusbuffer, 0, ruslength)
            file.Flush()
            file.Close()
            If CheckApiReturn("HLM_GETRUSINFO", result) = 1 Then
                rtbHistory.AppendText(" was successful" + ControlChars.CrLf)
                rtbHistory.AppendText(ruslength.ToString + " byte read and saved to: " + file.Name)
                Refresh()
            End If

            'Finally logout from the Hardlock
            Hardlock.HL_LOGOUT()

        End If
        rtbHistory.AppendText(ControlChars.CrLf)
    End Sub

    Private Sub btnAPIDemo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAPIDemo.Click

        rtbHistory.AppendText(ControlChars.CrLf + "Hardlock API Demo:" + ControlChars.CrLf)
        rtbHistory.AppendText("--------------------------------" + ControlChars.CrLf)

        InitData()

        If DoLogin() = 0 Then Exit Sub
        rtbHistory.AppendText(ControlChars.Tab + "successful" + ControlChars.CrLf)

        'Now do the different checks for Hardlock

        'Check versions, port info, access info etc...
        DoBasicCheck()

        'Do memory checks, reduced if a RUS Hardlock is used
        DoMemoryCheck()

        'If RUS is required do the RUS Checks
        If cbRUS.Checked Then DoRUSChecks()

        'Finally logout from the Hardlock
        If cbRUS.Checked Then
            result = Hardlock.HLM_LOGOUT()
            If CheckApiReturn("HLM_LOGOUT" + ControlChars.Tab, result) = 1 Then
                rtbHistory.AppendText(ControlChars.Tab + "successful")
                UpdateActive("HLM_LOGOUT", result)
            End If
        Else            
            result = Hardlock.HL_LOGOUT()            
            If CheckApiReturn("HL_LOGOUT", result) = 1 Then
                rtbHistory.AppendText(ControlChars.Tab + "successful")
                UpdateActive("HL_LOGOUT", result)
            End If

        End If
        'If we pinned the vendor key
        If vkHandle.IsAllocated Then
            vkHandle.Free()
        End If
        rtbHistory.AppendText(ControlChars.CrLf)

    End Sub

    Private Sub DoBasicCheck()
        'Do the basic checks for attached Hardlock

        'Check the Hardlock is available        
        result = Hardlock.HL_AVAIL()
        UpdateActive("HL_AVAIL", result)
        If CheckApiReturn("HL_AVAIL", result) = 1 Then
            rtbHistory.AppendText(ControlChars.Tab + "successful" + ControlChars.CrLf)
            Refresh()
        End If

        'Check the API Version -> returned in result
        rtbHistory.AppendText("HL_VERSION")
        Refresh()
        result = Hardlock.HL_VERSION()
        'No UpdateActive/CheckApiReturn, because result value is used for information
        If result <> 0 Then
            Dim temp As Integer
            temp = result \ 100
            rtbHistory.AppendText(ControlChars.Tab + "API Version: " + temp.ToString + "." + (result - (temp * 100)).ToString)
        Else
            rtbHistory.AppendText(ControlChars.Tab + "API Version: failed")
        End If
        rtbHistory.AppendText(ControlChars.CrLf)
        Refresh()

        'Check the Port Info
        rtbHistory.AppendText("HL_PORTINF")
        Refresh()
        result = Hardlock.HL_PORTINF
        'No UpdateActive/CheckApiReturn, because result value is used for information
        If result <> 0 Then
            rtbHistory.AppendText(ControlChars.Tab + "Port: 0x" + result.ToString("X"))
        Else    'a return value of &H0 indicates USB port
            rtbHistory.AppendText(ControlChars.Tab + "Port : USB")
        End If
        rtbHistory.AppendText(ControlChars.CrLf)
        Refresh()

        'Check for USB Hardlock
        If result = &H0 Then
            Dim idlow, idhigh As Short
            result = Hardlock.HL_READID(idlow, idhigh)
            UpdateActive("HL_READID", result)
            If CheckApiReturn("HL_READID", result) = 1 Then
                Dim temp As Integer
                temp = idlow * 65536 + idhigh
                rtbHistory.AppendText(ControlChars.Tab + "USB ID: 0x" + temp.ToString("X") + ControlChars.CrLf)
            End If
        End If
        Refresh()

        'Check the Access Info - if network supply additional information
        rtbHistory.AppendText("HL_ACCINF")
        result = Hardlock.HL_ACCINF()
        'No UpdateActive/CheckApiReturn, because result value is used for information
        If result = Hardlock.AccessMode.LOCAL_DEVICE Then
            rtbHistory.AppendText(ControlChars.Tab + "Access Mode: local" + ControlChars.CrLf)
            Refresh()
        ElseIf result = Hardlock.AccessMode.NET_DEVICE Then
            rtbHistory.AppendText(ControlChars.Tab + "Access Mode: network" + ControlChars.CrLf)
            Refresh()
            rtbHistory.AppendText("HL_HLSVERS")
            result = Hardlock.HL_HLSVERS()
            Dim temp As Integer
            temp = result \ 100
            rtbHistory.AppendText(ControlChars.Tab + "Server Version: " + temp.ToString + "." + (result - (temp * 100)).ToString + ControlChars.CrLf)
            Refresh()
            'current users for this server
            rtbHistory.AppendText("HL_USERINF")
            result = Hardlock.HL_USERINF
            rtbHistory.AppendText(ControlChars.Tab + "Current Users: " + result.ToString + ControlChars.CrLf)
            Refresh()
            'maximum users for this server
            rtbHistory.AppendText("HL_MAXUSER")
            result = Hardlock.HL_MAXUSER
            rtbHistory.AppendText(ControlChars.Tab + "Maximum Users: " + result.ToString + ControlChars.CrLf)
            Refresh()
        Else
            rtbHistory.AppendText(ControlChars.Tab + "Access Mode: Unknown" + ControlChars.CrLf)
        End If
        Refresh()

        'Encode and Decode some data -> must be multiple of 8
        Dim codedata() As Byte
        codedata = Encoding.Default.GetBytes("Aladdin Hardlock")
        rtbHistory.AppendText("HL_CODE" + ControlChars.Tab)
        OutputEncodedData(codedata)
        rtbHistory.AppendText(" (original)" + ControlChars.CrLf)
        Refresh()
        result = Hardlock.HL_CODE(codedata, 2)
        UpdateActive("HL_CODE", result)
        If result = Hardlock.APIStatus.STATUS_OK Then
            rtbHistory.AppendText("HL_CODE" + ControlChars.Tab)
            OutputEncodedData(codedata)
            rtbHistory.AppendText(" (encoded)" + ControlChars.CrLf)
            Refresh()
            'Decode the result            
            result = Hardlock.HL_CODE(codedata, 2)
            UpdateActive("HL_CODE", result)
            rtbHistory.AppendText("HL_CODE" + ControlChars.Tab)
            OutputEncodedData(codedata)
            rtbHistory.AppendText(" (decoded)" + ControlChars.CrLf)
            Refresh()
        Else
            CheckApiReturn("HL_CODE", result)
        End If
    End Sub

    Private Sub DoMemoryCheck()
        'Do memory checks for the attached Hardlock

        'First check if the Hardlock is having memory at all
        rtbHistory.AppendText("HL_MEMINF")
        Refresh()
        result = Hardlock.HL_MEMINF()
        If result = 0 Then
            rtbHistory.AppendText(ControlChars.Tab + "Hardlock with memory" + ControlChars.CrLf)
        Else
            rtbHistory.AppendText(ControlChars.Tab + "Hardlock without memory. Check skipped" + ControlChars.CrLf)
            Exit Sub
        End If
        Refresh()

        If cbRUS.Checked Then
            'RUS Hardlock detected, no write to memory will be performed to 
            'assure RUS information  will not be destroyed
            'we simply issue the memory by using read block
            'Read the whole memory in a block                
            Dim eeprom(127) As Byte
            rtbHistory.AppendText("HL_READBL" + ControlChars.Tab)
            Refresh()
            result = Hardlock.HL_READBL(eeprom)
            UpdateActive("HL_READBL", result)
            If result = 0 Then                
                OutputMemory(eeprom, 0)
            Else
                CheckApiReturn("HL_READBL", result)
            End If

        Else
            'Read and Write will be done

            'Use HL_READ to read a single word and use HL_WRITE to write this word back            
            Dim regorig, regnew, reg As Short
            'first word of RAM is register 48
            reg = 48
            result = Hardlock.HL_READ(reg, regorig)
            UpdateActive("HL_READ", result)
            If result = Hardlock.APIStatus.STATUS_OK Then                
                rtbHistory.AppendText("HL_READ" + ControlChars.Tab + "register 48: 0x" + regorig.ToString("X") + ControlChars.CrLf)
                'Write back a different value                
                result = Hardlock.HL_WRITE(reg, 65 + 66 * 256) 'Should be an AB
                rtbHistory.AppendText("HL_WRITE" + ControlChars.Tab + "register 48: 0x" + (65 + 66 * 256).ToString("X") + ControlChars.CrLf)
                UpdateActive("HL_WRITE", result)
                'Read this different value                
                result = Hardlock.HL_READ(reg, regnew)
                rtbHistory.AppendText("HL_READ" + ControlChars.Tab + "register 48: 0x" + regnew.ToString("X") + ControlChars.CrLf)
                UpdateActive("HL_READ", result)
                'Write back the initial value                
                rtbHistory.AppendText("HL_WRITE" + ControlChars.Tab + "register 48: 0x" + regorig.ToString("X") + ControlChars.CrLf)
                result = Hardlock.HL_WRITE(reg, regorig)
                UpdateActive("HL_WRITE", result)
                'Read the original value                
                result = Hardlock.HL_READ(reg, regnew)
                rtbHistory.AppendText("HL_READ" + ControlChars.Tab + "register 48: 0x" + regnew.ToString("X"))
                UpdateActive("HL_READ", result)
                If regnew = regorig Then
                    rtbHistory.AppendText("  -> Memory restored" + ControlChars.CrLf)
                End If

                'Read the whole memory in a block                
                Dim eeprom(127) As Byte
                rtbHistory.AppendText("HL_READBL")
                result = Hardlock.HL_READBL(eeprom)
                UpdateActive("HL_READBL", result)
                If result = 0 Then
                    rtbHistory.AppendText(ControlChars.Tab)
                    OutputMemory(eeprom, 0)
                Else
                    CheckApiReturn("HL_READBL", result)
                End If

                'Write some changed memory
                Dim ram(31) As Byte
                ram = Encoding.Default.GetBytes("Protect with Aladdin Hardlock !!")
                rtbHistory.AppendText("HL_WRITEBL" + ControlChars.Tab + "Protect with Aladdin Hardlock !!" + ControlChars.CrLf)
                result = Hardlock.HL_WRITEBL(ram)
                UpdateActive("HL_WRITEBL", result)
                Dim tempeeprom(127) As Byte
                'Read back the memory and show
                rtbHistory.AppendText("HL_READBL" + ControlChars.Tab)
                result = Hardlock.HL_READBL(tempeeprom)
                If result = 0 Then
                    OutputMemory(tempeeprom, 1)
                Else
                    CheckApiReturn("HL_READBL", result)
                End If
                'Write back the initial content
                rtbHistory.AppendText("HL_WRITEBL" + ControlChars.Tab)
                Array.Copy(eeprom, 96, ram, 0, 32)
                rtbHistory.AppendText(Encoding.Default.GetString(ram))
                rtbHistory.AppendText(ControlChars.CrLf)
                result = Hardlock.HL_WRITEBL(ram)
                UpdateActive("HL_WRITEBL", result)
                If result = 0 Then
                    result = Hardlock.HL_READBL(eeprom)
                    UpdateActive("HL_READBL", result)
                    If result = 0 Then
                        rtbHistory.AppendText("HL_READBL" + ControlChars.Tab)
                        OutputMemory(eeprom, 1)
                    Else
                        CheckApiReturn("HL_WRITEBL", result)
                    End If
                Else
                    CheckApiReturn("HL_WRITEBL", result)
                End If
            Else    'the first HL_READ already failed, don't do any other checks
                CheckApiReturn("HL_READ", result)
            End If
        End If
    End Sub

    Private Sub OutputMemory(ByVal mem As Byte(), ByVal ramonly As Boolean)
        Dim I, K As Short
        Dim chararray As Char()
        chararray = Encoding.Default.GetChars(mem)
        If ramonly = 0 Then
            For I = 0 To 2
                If I <> 0 Then rtbHistory.AppendText(ControlChars.Tab + ControlChars.Tab)
                rtbHistory.AppendText("ROM: ")
                For K = 0 To 31
                    If Char.IsControl(chararray(K + I * 32)) Then
                        rtbHistory.AppendText(" ")
                    Else
                        rtbHistory.AppendText(chararray(K + I * 32))
                    End If
                Next K
                rtbHistory.AppendText(ControlChars.CrLf)
                rtbHistory.Refresh()
            Next I
        End If
        If ramonly = 0 Then rtbHistory.AppendText(ControlChars.Tab + ControlChars.Tab)
        rtbHistory.AppendText("RAM: ")
        For K = 0 To 31
            If Char.IsControl(chararray(K + 96)) Then
                rtbHistory.AppendText(" ")
            Else
                rtbHistory.AppendText(chararray(K + 96))
            End If
        Next K
        rtbHistory.AppendText(ControlChars.CrLf)
        rtbHistory.Refresh()
    End Sub

    Private Sub OutputEncodedData(ByVal encdata As Byte())
        Dim chararray As Char()
        chararray = Encoding.Default.GetChars(encdata)
        Dim K As Short
        For K = 0 To encdata.Length - 1
            If Char.IsControl(chararray(K)) Then
                rtbHistory.AppendText(".")
            Else
                rtbHistory.AppendText(chararray(K))
            End If
        Next K
        rtbHistory.Refresh()
    End Sub

    Private Sub DoRUSChecks()
        rtbHistory.AppendText("------RUS API------------" + ControlChars.CrLf)
        'We do all the RUS checks
        Dim slot, id As Integer 'the slots variable and the id for RUS
        Dim max, cur As Integer 'max, cur for HLM_CHECKCOUNTER and HLM_CHECKSLOT

        'Check the ID for the RUS Hardlock        
        result = Hardlock.HLM_ISRUSHL(id)
        UpdateActive("HLM_ISRUSHL", result)
        If CheckApiReturn("HLM_ISRUSHL" + ControlChars.Tab, result) = 1 Then
            rtbHistory.AppendText(ControlChars.Tab + "RUS ID: 0x" + id.ToString("X") + ControlChars.CrLf)
            rtbHistory.Refresh()
        End If

        Dim year, month, day As Short
        'We check only the global expiration date, we do skip the expiration date of network slots
        slot = 0
        result = Hardlock.HLM_CHECKEXPDATE(slot, year, month, day)
        UpdateActive("HLM_CHECKEXPDATE", result)
        If CheckApiReturn("HLM_CHECKEXPDATE", result) = 1 Then
            rtbHistory.AppendText(ControlChars.Tab + day.ToString + "." + month.ToString + "." + year.ToString + "   (Day/Month/Year)" + ControlChars.CrLf)
            rtbHistory.Refresh()
        End If

        'HLM_CHECKCOUNTER - get the maximum and current counter checks
        Dim incval As Short
        result = Hardlock.HLM_CHECKCOUNTER(incval, max, cur)
        UpdateActive("HLM_CHECKCOUNTER", result)
        If CheckApiReturn("HLM_CHECKCOUNTER", result) = 1 Then
            rtbHistory.AppendText(ControlChars.Tab + cur.ToString + "/" + max.ToString + "   (Cur/Max)" + ControlChars.CrLf)
            rtbHistory.Refresh()
        End If

        'Check the single slots from 1-3 
        For slot = 1 To 3
            'HLM_CHECKSLOT            
            max = 0
            cur = 0
            result = Hardlock.HLM_CHECKSLOT(slot, max, cur)
            UpdateActive("HLM_CHECKSLOT", result)
            If CheckApiReturn("HLM_CHECKSLOT(" + slot.ToString + ")", result) = 1 Then
                rtbHistory.AppendText(ControlChars.Tab + cur.ToString + "/" + max.ToString + "   (Cur/Max)" + ControlChars.CrLf)
                rtbHistory.Refresh()
            End If

            'HLM_OCCUPYSLOT            
            result = Hardlock.HLM_OCCUPYSLOT(slot)
            UpdateActive("HLM_OCCUPYSLOT", result)
            If CheckApiReturn("HLM_OCCUPYSLOT(" + slot.ToString + ")", result) = 1 Then
                rtbHistory.AppendText(ControlChars.Tab + "successful" + ControlChars.CrLf)
                rtbHistory.Refresh()
            End If
            'HLM_FREESLOT
            result = Hardlock.HLM_FREESLOT(slot)
            UpdateActive("HLM_FREESLOT", result)
            If CheckApiReturn("HLM_FREESLOT(" + slot.ToString + ")", result) = 1 Then
                rtbHistory.AppendText(ControlChars.Tab + "successful" + ControlChars.CrLf)
                rtbHistory.Refresh()
            End If
        Next slot

        'Check again with HLM_CHECKALLSLOTS
        Dim buflen, slotcount As Integer
        Dim lisstruct As Hardlock.HL_LIS
        Dim buffer As Byte()

        result = Hardlock.HLM_CHECKALLSLOTS(buflen, buffer)
        UpdateActive("HLM_CHECKALLSLOTS", result)
        If result <> Hardlock.APIStatus.BUFFER_TOO_SMALL Then
            CheckApiReturn("HLM_CHECKALLSLOTS", result)
        Else
            ReDim buffer(buflen - 1)
            result = Hardlock.HLM_CHECKALLSLOTS(buflen, buffer)
            UpdateActive("HLM_CHECKALLSLOTS", result)
            If CheckApiReturn("HLM_CHECKALLSLOTS", result) = 1 Then
                Hardlock.BufferToStruct(buffer, lisstruct)
                'We don't output this, because is similar to above checks with OCCUPY/FREE/CHECKSLOT
                'Use Hardlock.ConvertAPIDaysToDate to convert the api days for current and expiration date
                rtbHistory.AppendText(ControlChars.Tab + "successful (" + buflen.ToString + " bytes read)" + ControlChars.CrLf)
            End If
        End If
    End Sub

    Private Sub btnClearHistory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearHistory.Click
        rtbHistory.Clear()
    End Sub

End Class
