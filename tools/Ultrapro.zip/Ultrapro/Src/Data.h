DWORD g_password=0xC9790000;

