/*++

Copyright (c) 2004 Chingachguk & Denger2k All Rights Reserved

Module Name:

    USBKeyEmu.h

Abstract:

    This module contains the common private declarations 
    for the emulation of USB bus and Sentinel key

Environment:

    kernel mode only

Notes:

Revision History:

--*/

#ifndef USBKeyEmu_H
#define USBKeyEmu_H

typedef UCHAR BYTE;
typedef USHORT WORD;
typedef ULONG  DWORD;
//
// The generic ids for installation of key pdo
//
#define VUSB_COMPATIBLE_IDS L"USB\\VID_04b9&PID_0300\0"
#define VUSB_COMPATIBLE_IDS_LENGTH sizeof(VUSB_COMPATIBLE_IDS)

//
// Automatic insert keys on startup of driver
//
#define INSERT_ALL_KEYS_ON_STARTUP 1

//
// Path to dumps in registry
//
#define DUMP_PATH_STR L"\\Registry\\MACHINE\\System\\CurrentControlSet\\UpBus"

//
// Path to log file
//
#define DEFAULT_LOG_FILE_NAME   L"\\??\\C:\\Upbus.log"

//
// Description of key data
//
#pragma pack(1)
typedef struct sentRecTag
{
	BYTE	cell;
	BYTE	qlen;
	BYTE	fullLen;
	BYTE	Qbuf[64];
	BYTE	Rbuf[64];
} sentRecType;


typedef struct sentNodeTag
{
	struct sentNodeTag *left;       // left child
	struct sentNodeTag *right;      // right child
	struct sentNodeTag *parent;     // parent
	ULONG   key;                    // key used for searching
	sentRecType *rec;               // user data
} sentNodeType;

#define EXTRACELLSIZE 32

typedef struct tag_uproDate
{
	WORD year;
	WORD month;
	WORD days;
} SP_UPRO_DATE, *SPP_UPRO_DATE;

typedef struct _KEY_DATA {
    //
    // Dongle type 
    //
    UCHAR   DongleType;     // Type of Dongle (1-HASP,2-HARDLOCK,3-SENTINEL)

    ULONG   password;       // Password for key

    //Static information about SENTINEL key

    UCHAR   SentkeyType;    // Sentinel Type (0-SuperPro,1... other types) NOT USED
	ULONG	SentNumCells;			// 0 = 64 cells, 1 = 128 cells, 2 = 256 cells
    USHORT  CellMem[256];    // Memory content
    UCHAR   CellType[256];   // Cells type
    USHORT  ExtraCell[8*4];   //used for crypt algo 8 sets*4 bytes
    UCHAR   ExtraOfs;       //offset in ExtraCell array
	UCHAR	NumQLongs;				// Upro : number of decrypted Query DWORDS in Extra
    UCHAR   request;        
    UCHAR   TempMem[0x80];
	ULONG   TempLen;
	SP_UPRO_DATE LKDT;
	USHORT	VCells[16];				// Used to store virtual cells 0x70..0x7F for UltraPro with 64 cells
	BYTE	VCode[16];				// As above, but access codes
	sentNodeType	*sentRoot;		// root of ultrapro Q/R binary tree
	ULONG		numSentQueries;		// number of distinct Q/R lines in registry
} KEY_DATA, *PKEYDATA;
#pragma pack()


//
// List of supported dongles
//
enum DONGLE_TYPE {
    DONGLE_HASP                     = 0x01,
    DONGLE_HARDLOCK                 = 0x02,
    DONGLE_SENTINEL                 = 0x03
};


//
// List of supported functions for Sentinel key
//
enum SENT_KEY_FN_LIST
{
	KEY_FN_GET_KEYINFO			= 0x00,
	KEY_FN_01						= 0x01,
	KEY_FN_GET_PARAMETER			= 0x02,
	KEY_FN_SET_PARAMETER			= 0x03,
	KEY_FN_04						= 0x04,
	KEY_FN_GETCAPABILITIES		= 0x05,
	KEY_FN_06						= 0x06,
	KEY_FN_07						= 0x07,
	KEY_FN_08						= 0x08,
	KEY_FN_09						= 0x09,
	KEY_FN_0A						= 0x0A,
	KEY_FN_0B						= 0x0B,
	KEY_FN_0C						= 0x0C,
	KEY_FN_0D						= 0x0D,
	KEY_FN_0E						= 0x0E,
	KEY_FN_0F						= 0x0F,
	KEY_FN_READ						= 0x10,
	KEY_FN_EXTENDED_READ			= 0x11,
	KEY_FN_QUERY_SHORT			= 0x12,
	KEY_FN_QUERY_LONG				= 0x13,
	KEY_FN_WRITE_0					= 0x14,
	KEY_FN_WRITE_1					= 0x15,
	KEY_FN_WRITE_2					= 0x16,
	KEY_FN_WRITE_3					= 0x17,
	KEY_FN_OVERWRITE_0			= 0x18,
	KEY_FN_OVERWRITE_1			= 0x19,
	KEY_FN_OVERWRITE_2			= 0x1A,
	KEY_FN_OVERWRITE_3			= 0x1B,
	KEY_FN_ACTIVATE				= 0x1C,
	KEY_FN_DECREMENT				= 0x1D,
	KEY_FN_1E						= 0x1E,
	KEY_FN_1F						= 0x1F,
	KEY_FN_20						= 0x20,
	KEY_FN_DATA_HASH				= 0x21,
	KEY_FN_22						= 0x22,
	KEY_FN_23						= 0x23,
	KEY_FN_24						= 0x24,
	KEY_FN_OVERWRITE_7         = 0x25,
	KEY_FN_26						= 0x26,
	KEY_FN_27						= 0x27,
	KEY_FN_28						= 0x28,
	KEY_FN_29						= 0x29,
	KEY_FN_2A						= 0x2A,
	KEY_FN_2B						= 0x2B,
	KEY_FN_2C						= 0x2C,
	KEY_FN_2D						= 0x2D,
	KEY_FN_2E						= 0x2E,
	KEY_FN_GET_KEYINFOEX			= 0x2F,
	KEY_FN_GETTIME					= 0x30
};

typedef struct _QUERY
{
	ULONG Type;
	ULONG LFSR1;
	ULONG LFSR2;
	ULONG Descriptor1;
	ULONG Descriptor2;
} QUERY;

typedef enum
{
	HASH_OK = 0,
	HASH_MEM_EXHAUSTED,
	HASH_DUPLICATE_KEY,
	HASH_KEY_NOT_FOUND
} statusEnum;

//
// Status of operation with sentinel key
//
enum KEY_OPERATION_STATUS {
    KEY_OPERATION_STATUS_OK                     = 0,
    KEY_OPERATION_ACCESS_DENIED                 = 1,
    KEY_OPERATION_STATUS_INVALID_MEMORY_ADDRESS = 4,
    KEY_OPERATION_STATUS_LAST                   = 0x1F
};

//
// Structure for request to SENTINEL key
//
#pragma pack(1)
typedef struct _KEY_REQUEST {
    UCHAR   majorFnCode;    // Requested fn number (type of KEY_FN_LIST)
    UCHAR   cellno;
    USHORT  param1;         // Key parameters
    USHORT  param2;         // Key parameters
    USHORT  CryptSeed;      // Key parameters
} KEY_REQUEST, *PKEY_REQUEST;

//
// Structure for respond of HASP key
//
typedef struct _KEY_RESPONSE {
    UCHAR           CRC,         // 
                    status;       // 
    USHORT          data1;     // Output data
    USHORT          data2;     // Output data
    USHORT	    CryptSeed;	
} KEY_RESPONSE, *PKEY_RESPONSE;
#pragma pack()

//
// Defined in USBKeyEmu.c
//

NTSTATUS Bus_HandleUSBIoCtl(IN  PDEVICE_OBJECT  DeviceObject,
                            IN  PIRP            Irp);
NTSTATUS Bus_LoadDumpFromRegistry (ULONG password,
                                   PKEYDATA keyData);
NTSTATUS Bus_LoadDumpsFromRegistry(IN  PDEVICE_OBJECT DeviceObject);

void Cipher(VOID *buf);
void EmulateKey(PKEYDATA pKeyData,
                PKEY_REQUEST request,
                PULONG outBufLen,
                PKEY_RESPONSE outBuf);
LONG GetMemorySize(PKEYDATA pKeyData);
NTSTATUS GetRegKeyData(HANDLE hkey,
                       PWCHAR subKey,
                       VOID *data,
                       ULONG needSize);

__checkReturn
__drv_aliasesMem
sentRecType *Hash_AllocReq_Sent(BYTE *inBuf, __in ULONG len);

__drv_freesMem(Pool)
void Hash_FreeRec_Sent(sentRecType *rec);

void Hash_NodeCopy_Sent(sentNodeType *dest, sentNodeType *src);
ULONG Hash_QHash_Sent(BYTE *buf, ULONG size);
sentNodeType *Hash_AllocNode_Sent(void);
void Hash_FreeNode_Sent(sentNodeType *node);
NTSTATUS Hash_insert_Sent(sentNodeType **proot, ULONG key, sentRecType *rec);
statusEnum Hash_delete_Sent(sentNodeType **proot, ULONG key);
statusEnum Hash_find_Sent(sentNodeType *root, ULONG key, sentRecType *rec);
void Hash_delete_Tree_Sent(sentNodeType *nodePtr);
NTSTATUS Hash_BuildTree_Sent(PKEYDATA pKeyData);
ULONG CRC32_Hash(BYTE *buf, ULONG size);
#endif