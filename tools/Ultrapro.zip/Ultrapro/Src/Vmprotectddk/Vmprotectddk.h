#pragma once

void __stdcall VMProtectBegin(char *);
void __stdcall VMProtectEnd(void);
