

#ifndef regs____H
#define regs____H

typedef UCHAR BYTE;
typedef unsigned short WORD;
typedef unsigned long  DWORD;

struct DWORDREGS
{
	DWORD eax;
	DWORD ebx;
	DWORD ecx;
	DWORD edx;
	DWORD esi;
	DWORD edi;
	DWORD cflag;
};


struct WORDREGS
{
	WORD ax;
	WORD bx;
	WORD cx;
	WORD dx;
	WORD si;
	WORD di;
	WORD cflag;
};


struct BYTEREGS
{
	BYTE al, ah;
	BYTE bl, bh;
	BYTE cl, ch;
	BYTE dl, dh;
};


union REGS
{
	struct DWORDREGS	D;
	struct WORDREGS	W;
	struct BYTEREGS	B;
};


union r32
{
	union
	{
		struct
		{
			BYTE l;
			BYTE h;
		} b;
		WORD val;
	} w;
	DWORD val;
};

/* all global */
// union r32 eax_, ebx_, ecx_, edx_;
// union r32 esi_, edi_, ebp_, esp_, eip_;
// WORD cs, ds, es, ss, fs, gs, flags;

#define eax (eax_.val)
#define ax (eax_.w.val)
#define al (eax_.w.b.l)
#define ah (eax_.w.b.h)

#define ebx (ebx_.val)
#define bx (ebx_.w.val)
#define bl (ebx_.w.b.l)
#define bh (ebx_.w.b.h)

#define ecx (ecx_.val)
#define cx (ecx_.w.val)
#define cl (ecx_.w.b.l)
#define ch (ecx_.w.b.h)

#define edx (edx_.val)
#define dx (edx_.w.val)
#define dl (edx_.w.b.l)
#define dh (edx_.w.b.h)

#define esi (esi_.val)
#define si (esi_.w.val)

#define edi (edi_.val)
#define di (edi_.w.val)

#define ebp (ebp_.val)
#define bp (ebp_.w.val)

#define sp (esp_.w.val)
#define ip (eip_.w.val)


#endif