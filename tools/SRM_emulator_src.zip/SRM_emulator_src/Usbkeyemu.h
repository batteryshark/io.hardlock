/*
 *
 *  All rights reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */
/*++
Copyright (c) 2004 Chingachguk & Denger2k All Rights Reserved
USBKeyEmu.h
This module contains the common private declarations for the emulation of USB bus and HASP key
--*/

#include "EncDecSim.h" // KEY_INFO
#include "dsecurity.h" // KEY_INFO


#include "common_definitions.h"

#ifndef USBKeyEmu_H
#define USBKeyEmu_H

#define F4FFSIZE 4032
#define F5FFSIZE 2048

#define VENDORNAME_HASP  L"SafeNet "
#define MODEL_HASP       L"USB Key"

// #define HASP_FILEID_MAIN_SWAP 0xF0FF
// #define HASP_FILEID_LICENSE_SWAP 0xF2FF
#define HASP_FILEID_RW 0xF4FF
#define HASP_FILEID_RO 0xF5FF

// max possible number  = 248
// max posible user Pro = 39 (416/8 = 52)
// max posible user Max = 231 (1984/8 = 248)

#define SRMFEATURESCOUNT 248

// The generic ids for installation of key pdo
#define VUSB_COMPATIBLE_IDS L"USB\\VID_0529&PID_0001\0"
#define VUSB_COMPATIBLE_IDS_LENGTH sizeof(VUSB_COMPATIBLE_IDS)

#define BUS_HARDWARE_IDS L"USB\\VID_0529&PID_0001&Rev_0325\0\0"
#define BUS_HARDWARE_IDS_LENGTH sizeof (BUS_HARDWARE_IDS)

// Automatic insert keys on startup of driver
#define INSERT_ALL_KEYS_ON_STARTUP 1

// Path to log file
#define DEFAULT_LOG_FILE_NAME   L"\\??\\C:\\vusbsrm.log"

// Description of key data
#pragma pack(1)
typedef struct _HASPTIMEMEMORY
{
	UCHAR curr_time[3];    // time, BCD, SS:MM:HH
	UCHAR curr_date[4];    // date, BCD, DD:MM:WW:YY (WW - weekday ?)
	UCHAR rezerv1[0x19];   // ???
	UCHAR Id[8];           // Id of TIME HASP (4 bytes, but real is - 8?)
	UCHAR FAS[0x10];       // FAS ? There is some infos about progs - ? ExpiryDate's, etc - ?
} tHASPTM;

typedef struct _SRM_FEATURE_PROPERTY
{
	// masterkey - different RW and RO size
	// FF,F4,01,0A,01,80,00,04
	// FF,F5,02,8A,00,20,00,05

	USHORT Number;
	USHORT Position;
	USHORT Size;
	USHORT Type;
} SRM_FEATURE_PROPERTY;

typedef struct _SRM_FEATURE_DATA
{
	// masterkey - different RW and RO size
	// FF,F4,01,0A,01,80,00,04
	// FF,F5,02,8A,00,20,00,05

	USHORT Number;
	USHORT Position;
	USHORT Size;
	USHORT Type;
	USHORT Index;
	USHORT Slot;
	UCHAR  Data[64];
} SRM_FEATURE_DATA;

typedef struct _KEY_DATA
{
	// Dongle type
	UCHAR        DongleType;       // Type of Dongle (1-HASP, 2-HARDLOCK, 3-SENTINEL)
	// Current key state
	UCHAR       isInitDone;        // Is chiperkeys given to key
	UCHAR       isKeyOpened;       // Is valid password is given to key
	UCHAR       encodedStatus;     // Last encoded status
	USHORT      chiperKey1;        // Keys for chiper
	USHORT      chiperKey2;        // Static information about HASP key
	UCHAR       keyType;           // Type of key
	UCHAR       memoryType;        // Memory size of key
	ULONG       password;          // Password for key
	UCHAR       options[14];       // Options for key
	UCHAR       secTable[8];       // ST for key
	UCHAR       netMemory[16];     // NetMemory for key
	tHASPTM     HASPTIMEMEMORY;
	LONGLONG    TimeShift;         // Time shift (relativly OS time)
	UCHAR       memory[4096];      // Memory content
	KEY_INFO    KEY_INFOdata;      // columnMask & prepNotMask]

	// rip from multikey 18.2.1 hasp HL AES
	// int      QisFound;          // ���������� ������������ - ������ �� ������ - ��� ������ ���� ��������� ������ ���� ��������
	long        QA_Buff_Len;       // ����� ������� �� Q&A
	UCHAR       EncDecType;        // ��� �������� ��� ������� 1�/9E, 0-encrypt, 1-decrypt
	UCHAR       EncDecValue;       // �������� �������, 0 1 2 - �������, 4 5 6 - �������
	UCHAR       lastQA_buff[48];   // ����� ������ ���������� ������� ������� 1�
	UCHAR       AesKey[16];        // AES key for encrypt-decrypt for HASP HL

	UCHAR  FeatureProperties[8];
	USHORT FeatureNumber;
	USHORT FeatureIndex;
	USHORT FeatureSize;
	USHORT EncryptFlag;

	int   NewAlgo;
	DWORD ReadOffset;
	DWORD ReadLength;

	UCHAR XorValue[3];
	ULONG CM;

	UCHAR EncDecMode;
	UCHAR Delta;

	UCHAR FuncA1_Val0[3];
	UCHAR FuncA1_Val1[47];
	UCHAR FuncA1_Val2[14];
	UCHAR FuncA1_Val3[8];

	UCHAR FuncA2[1985];
	ULONG FuncA2size; // to diferentiate 1985 or 714 or other sizes

	// SRMFEATURESCOUNT features - for future usage - when not use reg file
	SRM_FEATURE_DATA Feature[SRMFEATURESCOUNT]; 

	UCHAR SRM_RW_Memory[F4FFSIZE]; // RWMem content - Feature_F4FF HASP_FILEID_RW - 4032
	UCHAR SRM_RO_Memory[F5FFSIZE]; // ROMem content - Feature_F5FF HASP_FILEID_RO - 2048

	//	UCHAR DateTime[5]; // converted to dynamic function
	UCHAR plugAES[KEYSIZE];
	UCHAR plugAES_new[KEYSIZE];
	UCHAR plugAES_new_656[KEYSIZE];

	UCHAR VendorAES[KEYSIZE];

	UCHAR WriteAesKEY[KEYSIZE];
	UCHAR WorkAesKEY[KEYSIZE];

	DWORD WriteOffset;
	DWORD WriteLength;

	// UCHAR AesQuery[64];
	// UCHAR AesResponse[64];

	// ********** SECURITY VARIABLE ********** 
	//	UCHAR SecurityRaw[64];
	DONGLE_SECURITY ds;

	ULONG hldSN;
	ULONG srmSN;

	ULONG SrmTableType;

	UCHAR FatData1[128];
	UCHAR FatData2[2048];
	// ********** SECURITY VARIABLE ********** 

	// new generation emulation variables
	ULONG VendorID;
	ULONG SRMKeyID;
	UCHAR VendorAESNew[KEYSIZE];
	// new generation emulation variables

	// used for temp mem
	UCHAR  Temp[4096];

	UCHAR Func2F_Inp[8];
	UCHAR FuncAF_Out[20];

} KEY_DATA, *PKEYDATA;
#pragma pack()

// List of supported functions for HASP key
enum KEY_FN_LIST
{
	KEY_FN_SET_CHIPER_KEYS              = 0x80,
	KEY_FN_CHECK_PASS                   = 0x81,
	KEY_FN_READ_3WORDS                  = 0x82,
	KEY_FN_WRITE_WORD                   = 0x83,
	KEY_FN_READ_ST                      = 0x84,
	KEY_FN_READ_NETMEMORY_3WORDS        = 0x8B,
	KEY_FN_HASH_DWORD                   = 0x98,
	KEY_FN_ECHO_REQUEST                 = 0xA0,   // Echo request to key
	KEY_FN_GET_TIME                     = 0x9C,   // Get time (for HASP time) key
	KEY_FN_PREPARE_CHANGE_TIME          = 0x1D,   // Prepare to change time (for HASP time)
	KEY_FN_COMPLETE_WRITE_TIME          = 0x9D,   // Write time (complete) (for HASP time)
	KEY_FN_PREPARE_DECRYPT              = 0x1E,   // HASP HL Decrypt question
	KEY_FN_COMPLETE_DECRYPT             = 0x9E,   // HASP HL Decrypt answer

	//-------- SRM Functions ----------------
	KEY_FN_READ_STRUCT                  = 0xA1,
	KEY_FN_READ_FAT                     = 0xA2,

	KEY_WRITE_FEATUREMAP_REQUEST        = 0x23,
	KEY_WRITE_FEATUREMAP_RESPONSE       = 0xA3,
	KEY_DELETE_FEATURE_REQUEST          = 0x24,
	KEY_DELETE_FEATURE_RESPONSE         = 0xA4,
	KEY_WRITE_SIGN_FEATURE_REQUEST      = 0x25,
	KEY_WRITE_SIGN_FEATURE_RESPONSE     = 0xA5,

	KEY_READ_REQUEST                    = 0x26,
	KEY_READ_RESPONSE                   = 0xA6,
	KEY_WRITE_REQUEST                   = 0x27,
	KEY_WRITE_RESPONSE                  = 0xA7,
	KEY_FN_SIGNED_READ_REQUEST          = 0x28,
	KEY_FN_SIGNED_READ_RESPONSE         = 0xA8,
	KEY_FN_AES_IN                       = 0x29,
	KEY_FN_AES_OUT                      = 0xA9,
	KEY_FN_ECHO_WBAES_IN                = 0x2F,
	KEY_FN_ECHO_WBAES_OUT               = 0xAF,
	KEY_FN_LOGIN                        = 0xAA,
	KEY_FN_LOGOUT                       = 0xAB,
	KEY_FN_READ_DATE_TIME               = 0xAC
};

// Status of operation with HASP key
enum KEY_OPERATION_STATUS
{
	KEY_OPERATION_STATUS_OK                     = 0,
	KEY_OPERATION_STATUS_ERROR                  = 1,
	KEY_OPERATION_STATUS_INVALID_MEMORY_ADDRESS = 4,
	KEY_OPERATION_STATUS_LAST                   = 0x1F
};

//
// List of supported dongles
//
enum DONGLE_TYPE
{
	DONGLE_HASP         = 0x01,
	DONGLE_HARDLOCK     = 0x02,
	DONGLE_SENTINEL     = 0x03,
	DONGLE_GUARDANT     = 0x04
};

// Structure for request to HASP key
#pragma pack(1)
typedef struct _KEY_REQUEST
{
	UCHAR   majorFnCode;           // Requested fn number (type of KEY_FN_LIST)
	USHORT  param1;                // Key parameters
	USHORT  param2;                // param1 = Value
	USHORT  param3;                // param2 = Index
} KEY_REQUEST, *PKEY_REQUEST;

typedef struct _USBKEY_REQUEST
{
	UCHAR  Request;           // Requested fn number (type of KEY_FN_LIST)
	USHORT Value;             // param1 = Value
	USHORT Index;             // param2 = Index
	USHORT Reserved1;
} USBKEY_REQUEST, *PUSBKEY_REQUEST;

// Structure for respond of HASP key
typedef struct _KEY_RESPONSE
{
	UCHAR   status;                // Status of operation (type of KEY_OPERATION_STATUS)
	UCHAR   encodedStatus;         // CRC of status and majorFnCode
	UCHAR   data[4096];            // Output data
} KEY_RESPONSE, *PKEY_RESPONSE;

#pragma pack()
#endif
