/*
 *
 *  All rights reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */
// Copyright (c) 2004 Chingachguk & Denger2k All Rights Reserved
// USBKeyEmu.c
// This module contains routines for emulation of USB bus and USB HASP key.

#include <ntddk.h>
#include <wdm.h>
#include <usbdi.h>                                //C
#include "usbdlib.h"                              //C
#include <windef.h>                               //C
#include <stdlib.h>                               //C
#include <ntstrsafe.h>

#include "vusb.h"
#include "aes.h"
#include "md5.h"

#include "EncDecSim.h"
#include "common_definitions.h"

#ifdef ALLOC_PRAGMA
#pragma alloc_text (PAGE, Bus_HandleUSBIoCtl)
#pragma alloc_text (PAGE, EmulateHASPKey)
#pragma alloc_text (PAGE, _Chiper)
#pragma alloc_text (PAGE, Chiper)
#pragma alloc_text (PAGE, GetMemorySize)
#pragma alloc_text (PAGE, Bus_LoadDumpsFromRegistry)
#pragma alloc_text (PAGE, Bus_LoadDumpFromRegistry)
#pragma alloc_text (PAGE, GetRegKeySize)
#endif

static WCHAR DUMP_PATH[] = DUMP_PATH_STR_SYS;

// demoma AES keys main feature
UCHAR FeatAesKey_01[KEYSIZE] = {0x63,0x92,0x92,0x55,0xAD,0xDD,0x61,0x16,0x23,0x65,0x4B,0x63,0x16,0xB2,0x02,0x4C};
UCHAR FeatAesKey_02[KEYSIZE] = {0xA1,0xBE,0x48,0x51,0x5A,0x8C,0x2B,0xD3,0x94,0xAB,0x29,0x36,0xF5,0x2A,0xEE,0xD2};
UCHAR FeatAesKey_03[KEYSIZE] = {0xAE,0x26,0x89,0x38,0xC0,0xC0,0x74,0x55,0xFD,0xEB,0xF4,0x73,0xE6,0xE9,0x24,0x2F};
UCHAR FeatAesKey_04[KEYSIZE] = {0x78,0x6D,0x46,0xAD,0xB5,0xF7,0x4D,0xCD,0x46,0x88,0xEE,0xF8,0x4D,0xD6,0x4E,0x23};
UCHAR FeatAesKey_05[KEYSIZE] = {0xC5,0xE1,0x29,0x77,0x82,0xB4,0xE0,0x7B,0xDC,0x17,0x6F,0x36,0xE5,0x98,0x63,0xE6};
UCHAR FeatAesKey_06[KEYSIZE] = {0xBF,0xF0,0x99,0x26,0x72,0x30,0x41,0xC0,0x09,0x35,0x40,0x6E,0x84,0xAC,0xCB,0x8B};

// demoma AES keys feature 1
UCHAR FeatAesKey_01_01[KEYSIZE] = {0x87,0xA5,0x6D,0xBF,0x67,0x45,0x5D,0x75,0x89,0xEE,0xBD,0x17,0xB8,0xC0,0x2F,0xEF};
UCHAR FeatAesKey_06_01[KEYSIZE] = {0xA4,0xE3,0xD0,0xE8,0xC8,0x28,0xDE,0x64,0xAF,0x18,0x17,0x8F,0x7D,0x5B,0x1A,0x7D};

// check Bus_LoadDumpFromRegistry
// Encodes-Decodes all other data - FatData0, FatData1, Features, Crypted Aes QA
// usbtrace, dumptool encrypt with this key
UCHAR dataAESkey[KEYSIZE] = {0};

// Firmware until 3.25
// UCHAR plugAES[KEYSIZE] = {0x03,0x43,0x03,0xF1,0xF1,0xA0,0x9F,0x67,0x5C,0x4D,0x11,0x0C,0x04,0xA0,0xFC,0x23};
// Firmware 3.25
// UCHAR plugAES_new[KEYSIZE] = {0xF9,0xA7,0x4C,0x5E,0x9D,0xC1,0x01,0x1C,0x42,0xDE,0x48,0x1B,0x6B,0x8D,0x13,0x38};
// Hasplms from 6.56 driver
// UCHAR plugAES_new_656[KEYSIZE] = {0x76,0x76,0xD8,0x98,0x01,0xA1,0x01,0xA8,0x48,0x69,0xA2,0x9F,0x51,0x4E,0x00,0xCA};

// used in srm aes_in & aes_out
UCHAR Q_Q[48] = {0};
UCHAR A_A[48] = {0};

UCHAR* GetProcessNameInEprocess(UCHAR *pname)
{
	PEPROCESS peprocess;
	char *pnameoffset;
	if(OffsetNameInErpocess)
	{
		peprocess = IoGetCurrentProcess();
		//		DPRINT("EPROCESS=%08X offset=%04X\n", peprocess, OffsetNameInErpocess);
		pnameoffset = (char *)peprocess + OffsetNameInErpocess;
		//		DPRINT("EPROCESS+offset=%08X\n", pnameoffset);
		RtlCopyMemory(pname, pnameoffset, 16);
	}
	return pname;
}
/*
PVOID AllocatePoolWithTagZero(POOL_TYPE PoolType, SIZE_T NumberOfBytes, ULONG Tag)
{
PVOID Ptr;

Ptr = ExAllocatePoolWithTag(PoolType, NumberOfBytes, Tag);

if (Ptr != NULL)
RtlZeroMemory(Ptr, NumberOfBytes);

return Ptr;
}

VOID FreePoolWithTagSafeR(PVOID *P)
{
if (P != NULL && *P != NULL)
{
ExFreePoolWithTag(*P, VUSB_POOL_TAG);
*P = NULL;
}
}

#define FreePoolWithTagSafe(p) FreePoolWithTagSafeR((void**)&(p))
*/

////////////////////////////////////////////////////////////////////////////////////
#define PLAINREGISTRY    0x00
#define CRYPTREGISTRY    0x01
#define CRYPTREGISTRYMD5 0x11

// regdataType types - used GetExtraRegKeyData
enum REGISTRY_DATA_LIST
{
	HLDATA      = 0x00001002,
	SRMDATA     = 0x00001001,
	SRMTABLE    = 0x00002001,
	SRMTABLEMD5 = 0x00008001, // work in progress -> confirmed stable in 10+ emulators
	DTABLE      = 0x00003001,
	ETABLE      = 0x00004001
};

//-----------------------------------------------------------------
NTSTATUS GetExtraRegKeyData(ULONG RegistryDataType,
							ULONG DonglePassword,
							WCHAR *KeyName,
							VOID  *OutData,
							int   Length,
							ULONG *ActualSize)
{
	NTSTATUS status;
	HANDLE   hKey;
	WCHAR    KeyPath[NUMWCHARS];

	WCHAR KeyNameMD5[96];

	WCHAR *KeyName_Pntr;

	UNICODE_STRING  usPath;
	OBJECT_ATTRIBUTES oa;

	ULONG shDonglePassword = (DonglePassword >> 16) | (DonglePassword << 16);

	//	PAGED_CODE();

	KeyName_Pntr = KeyName;

	*ActualSize = 0;
	RtlZeroMemory(OutData, Length);
	RtlZeroMemory(KeyPath, sizeof(KeyPath));

	switch (RegistryDataType)
	{
	case SRMDATA:
		DPRINT("SRMDATA  \"%ws\", Password = %08X, Length = %d\n", KeyName, shDonglePassword, Length);
		RtlStringCbPrintfExW(KeyPath, NUMWCHARS * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
			L"%ws\\%08X\\SRMData", DUMP_PATH, shDonglePassword);
		break;

	case SRMTABLE:
		DPRINT("SRMTABLE \"%ws\", Password = %08X, Length = %d\n", KeyName, shDonglePassword, Length);
		RtlStringCbPrintfExW(KeyPath, NUMWCHARS * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
			L"%ws\\%08X\\SRMTable", DUMP_PATH, shDonglePassword);
		break;

	case SRMTABLEMD5:
		{
			size_t /*unsigned int*/ len = 0;
			UCHAR MD5v[16] = {0};
			UCHAR ucTemp[96 * 2] = {0};

			DPRINT("SRMTABLEMD5 \"%ws\", Password = %08X, Length = %d\n", KeyName, shDonglePassword, Length);
			RtlStringCbPrintfExW(KeyPath, NUMWCHARS * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
				L"%ws\\%08X\\SRMTable", DUMP_PATH, shDonglePassword);

			RtlZeroMemory(ucTemp, sizeof(ucTemp));

			RtlStringCbPrintfExA(ucTemp, sizeof(ucTemp), NULL, NULL, STRSAFE_NULL_ON_FAILURE,
				"%ws",
				KeyName);

			DPRINT("SRMTABLEMD5 \"%s\"\n", ucTemp);

			RtlZeroMemory(MD5v, sizeof(MD5v));

			RtlStringCchLengthA(ucTemp, sizeof(ucTemp), &len);
			// len = strlen(ucTemp);
			md5(ucTemp, len, MD5v);

			RtlZeroMemory(KeyNameMD5, sizeof(KeyNameMD5));
			// set registry path
			RtlStringCbPrintfExW(KeyNameMD5, sizeof(KeyNameMD5), NULL, NULL, STRSAFE_NULL_ON_FAILURE,
				L"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
				MD5v[0], MD5v[1], MD5v[2], MD5v[3], MD5v[4], MD5v[5], MD5v[6], MD5v[7],
				MD5v[8], MD5v[9], MD5v[10], MD5v[11], MD5v[12], MD5v[13], MD5v[14], MD5v[15]);

			KeyName_Pntr = KeyNameMD5;

			DPRINT("SRMTABLEMD5 \"%ws\"\n", KeyNameMD5);
		}
		break;

	case DTABLE:
		DPRINT("DTABLE \"%ws\", Password = %08X, Length = %d\n", KeyName, shDonglePassword, Length);
		RtlStringCbPrintfExW(KeyPath, NUMWCHARS * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
			L"%ws\\%08X\\DTable", DUMP_PATH, shDonglePassword);
		break;

	case ETABLE:
		DPRINT("ETABLE \"%ws\", Password = %08X, Length = %d\n", KeyName, shDonglePassword, Length);
		RtlStringCbPrintfExW(KeyPath, NUMWCHARS * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
			L"%ws\\%08X\\ETable", DUMP_PATH, shDonglePassword);
		break;

	default:
		DPRINT("default \"%ws\", Password = %08X, Length = %d\n", KeyName, shDonglePassword, Length);
		RtlStringCbPrintfExW(KeyPath, NUMWCHARS * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
			L"%ws\\%08X", DUMP_PATH, shDonglePassword);
		break;

	}

	RtlInitUnicodeString(&usPath, KeyPath);
	InitializeObjectAttributes(&oa, &usPath, OBJ_KERNEL_HANDLE | OBJ_CASE_INSENSITIVE, NULL, NULL);

	DPRINT("KeyName_Pntr \"%ws\" ", KeyName_Pntr);

	status = ZwOpenKey(&hKey, KEY_READ, &oa);
	if (NT_SUCCESS(status))
	{
		NTSTATUS readStatus;
		readStatus = STATUS_SUCCESS;

		//if(RegistryDataType == SRMTABLEMD5)
		//	readStatus += GetRegKeyData(hKey, KeyNameMD5, OutData, Length, ActualSize);
		//else
		//	readStatus += GetRegKeyData(hKey, KeyName, OutData, Length, ActualSize);

		readStatus += GetRegKeyData(hKey, KeyName_Pntr, OutData, Length, ActualSize);

		ZwClose(hKey);

		if (!NT_SUCCESS(readStatus))
			return STATUS_INVALID_PARAMETER;
	}
	else
		return STATUS_INVALID_PARAMETER;

	return STATUS_SUCCESS;
}

//   GetRegKeyData
//   reads bytes from hex: registry keys. needSize bytes are read from registry,
//   the smaller of needSize and the actual amount of data
//   and returns this number in target of actualSize pointer.
NTSTATUS GetRegKeyData(HANDLE hkey, PWCHAR subKey,
					   VOID *data, ULONG needSize, ULONG *actualSize)
{
	NTSTATUS    status;
	ULONG       size;
	UNICODE_STRING valname;
	PKEY_VALUE_PARTIAL_INFORMATION vpip;

	vpip = NULL;

	RtlInitUnicodeString(&valname, subKey);
	size = 0;
	status = ZwQueryValueKey(hkey, &valname, KeyValuePartialInformation, NULL, 0, &size);

	// size = min(size, PAGE_SIZE); // Leave this check as Query tables can be > PAGE_SIZE
	if (status == STATUS_OBJECT_NAME_NOT_FOUND || size == 0)
	{
		DPRINT("GetRegKeyData FAIL  1 for %ws, size=0x%X  needSize=0x%X\n", subKey, size, needSize);
		return STATUS_OBJECT_NAME_NOT_FOUND;
	}
	vpip = (PKEY_VALUE_PARTIAL_INFORMATION) ExAllocatePoolWithTag(PagedPool, size, VUSB_POOL_TAG);
	if (!vpip)
	{
		// DPRINT("GetRegKeyData FAIL vpip alloc for %ws\n", subKey);
		return STATUS_INSUFFICIENT_RESOURCES;
	}
	status = ZwQueryValueKey(hkey, &valname, KeyValuePartialInformation, vpip, size, &size);
	if (!NT_SUCCESS(status))
	{
		if(vpip != NULL)
			ExFreePoolWithTag(vpip, VUSB_POOL_TAG);

		DPRINT("GetRegKeyData FAIL  2 for %ws\n", subKey);
		return STATUS_INVALID_PARAMETER;
	}

	*actualSize = min(vpip->DataLength, needSize);
	RtlCopyMemory(data, vpip->Data, *actualSize );

	if(vpip != NULL)
		ExFreePoolWithTag(vpip, VUSB_POOL_TAG);

	DPRINT("GetRegKeyData SUCCEED for %ws read 0x%X bytes\n", subKey, *actualSize);

	return STATUS_SUCCESS;
}

// returns length in bytes or 0 if not found
ULONG GetRegKeySize(HANDLE hkey, PCWSTR name)
{
	UNICODE_STRING uStr;
	ULONG  res, size;
	PKEY_VALUE_PARTIAL_INFORMATION vpip;
	NTSTATUS status;

	PAGED_CODE();

	DPRINT("GetRegKeySize called for %ws\n", name);

	RtlInitUnicodeString(&uStr, name);
	size = 0;
	status = ZwQueryValueKey(hkey, &uStr, KeyValuePartialInformation, NULL, 0, &size);
	if (status == STATUS_OBJECT_NAME_NOT_FOUND || size == 0)
	{
		DPRINT("%ws not found\n", name);
		return 0;
	}
	//size = min(size, 4*PAGE_SIZE);
	vpip = (PKEY_VALUE_PARTIAL_INFORMATION)ExAllocatePoolWithTag(PagedPool, size, VUSB_POOL_TAG);
	if (!vpip)
	{
		DPRINT("Partial Info is NULL\n");
		return 0;
	}
	status = ZwQueryValueKey(hkey, &uStr, KeyValuePartialInformation, vpip, size, &size);
	if (!NT_SUCCESS(status))
	{
		DPRINT("ZwQueryValue failed\n");
		if(vpip != NULL)
			ExFreePoolWithTag(vpip, VUSB_POOL_TAG);
		return 0;
	}
	res = vpip->DataLength;

	if(vpip != NULL)
		ExFreePoolWithTag(vpip, VUSB_POOL_TAG);

	return res;
}

#define REGULAR_DUMP_REG_PATH  0x01

//---------------------------------
static int Store_KeyDataToRegister(int WritePath,
								   PKEYDATA pKeyData, PCWSTR DataTag, PVOID pKeyNewData, ULONG maxSize)
{
	NTSTATUS status;
	HANDLE   hKey;
	WCHAR    KeyPath[NUMWCHARS];
	UNICODE_STRING usPath;
	OBJECT_ATTRIBUTES oa;

	// ULONG Disposition;

	KIRQL IRQL;
	// ULONG size;

	// Check current IRQL (ZwCreateFile does NOT work under IRQL > PASSIVE_LEVEL )
	if ((IRQL = KeGetCurrentIrql()) != PASSIVE_LEVEL)
		return(1);

	// Try to write data to registry
	RtlZeroMemory(KeyPath, sizeof(KeyPath));

	switch (WritePath)
	{
	case REGULAR_DUMP_REG_PATH: // main dump path
		RtlStringCbPrintfExW(KeyPath, NUMWCHARS * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
			L"%ws", DUMP_PATH);
		break;

	case HLDATA: // regular dump path - "HaspTimeMemory", L"TimeShift", L"Data", 
		RtlStringCbPrintfExW(KeyPath, NUMWCHARS * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
			L"%ws\\%08X", DUMP_PATH, (pKeyData->password >> 16) | (pKeyData->password << 16));
		break;

	case SRMDATA: // we write to SRMDATA section
		RtlStringCbPrintfExW(KeyPath, NUMWCHARS * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
			L"%ws\\%08X\\SRMData", DUMP_PATH, (pKeyData->password >> 16) | (pKeyData->password << 16));
		break;

	default:
		RtlStringCbPrintfExW(KeyPath, NUMWCHARS * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
			L"%ws\\%08X", DUMP_PATH, (pKeyData->password >> 16) | (pKeyData->password << 16));
		break;
	}

	DPRINT("Store_KeyDataToRegister %ws %ws\n", DataTag, KeyPath);

	RtlInitUnicodeString(&usPath, KeyPath);
	InitializeObjectAttributes(&oa, &usPath, OBJ_KERNEL_HANDLE | OBJ_CASE_INSENSITIVE, NULL, NULL);

	status = ZwOpenKey(&hKey, KEY_WRITE, &oa);

	//status = ZwCreateKey(&hKey, KEY_ALL_ACCESS, &oa, 0, &usPath, REG_OPTION_NON_VOLATILE, &Disposition);
	//		if(Disposition == REG_CREATED_NEW_KEY)
	//		{
	//			DPRINT("REG_CREATED_NEW_KEY status = 0x%X\n", status);
	//		}
	//		if(Disposition == REG_OPENED_EXISTING_KEY)
	//		{
	//			DPRINT("REG_OPENED_EXISTING_KEY status = 0x%X\n", status);
	//		}

	// DPRINT("status = 0x%X\n", status);
	// DPRINT("path = %ws\n", path);
	if ( NT_SUCCESS(status) )
	{
		UNICODE_STRING valname;
		// size = GetRegKeySize(hKey, DataTag);
		// DPRINT("size = 0x%X\n", size);
		RtlInitUnicodeString(&valname, DataTag);
		// ZwSetValueKey(hkey, &valname, 0, REG_BINARY, pKeyNewData, min(size, maxSize));
		ZwSetValueKey(hKey, &valname, 0, REG_BINARY, pKeyNewData, maxSize);
		ZwClose(hKey);
	}

	return( ( NT_SUCCESS(status) ) ? 0 : 1 );
}

//------------------------------------------
// Protect inside VMprotect
void hasplms_3_25_untransform(void * buffer)
{
	UCHAR c_buf[16];
	UCHAR mask[64] =
	{
		1, 0, 7, 6, 5, 4, 3, 2,
		0, 7, 6, 5, 4, 3, 2, 1,
		0, 7, 6, 5, 4, 3, 2, 1,
		6, 5, 4, 3, 2, 1, 0, 7,
		6, 5, 4, 3, 2, 1, 0, 7,
		3, 2, 1, 0, 7, 6, 5, 4,
		3, 2, 1, 0, 7, 6, 5, 4,
		7, 6, 5, 4, 3, 2, 1, 0
	};

	UCHAR vector[8] =
	{
		0x58, 0xB1, 0xDC, 0x4C, 0x43, 0xF6, 0xF8, 0xC7
	};

	UCHAR s_box[256] =
	{
		0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01,
		0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76, 0xca, 0x82, 0xc9, 0x7d,
		0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4,
		0x72, 0xc0, 0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc,
		0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15, 0x04, 0xc7,
		0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2,
		0xeb, 0x27, 0xb2, 0x75, 0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e,
		0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
		0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb,
		0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf, 0xd0, 0xef, 0xaa, 0xfb,
		0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c,
		0x9f, 0xa8, 0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5,
		0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2, 0xcd, 0x0c,
		0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d,
		0x64, 0x5d, 0x19, 0x73, 0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a,
		0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
		0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3,
		0xac, 0x62, 0x91, 0x95, 0xe4, 0x79, 0xe7, 0xc8, 0x37, 0x6d,
		0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a,
		0xae, 0x08, 0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6,
		0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a, 0x70, 0x3e,
		0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9,
		0x86, 0xc1, 0x1d, 0x9e, 0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9,
		0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
		0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99,
		0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
	};

	UCHAR ecx = 0, ebx;
	int i, j = 63, k;

	RtlCopyMemory(c_buf, buffer, 16);

	for(k = 0; k < 4; k++)
	{
		for(i = 15; i >= 0; i--, j--)
		{
			c_buf[i] = s_box[vector[mask[j]] ^ c_buf[i]];
		}
	}

	RtlCopyMemory(buffer, c_buf, 16);

	// return;
}

//---------------------------------------------------------------
NTSTATUS Decrypt(UCHAR *AESKey, UCHAR *In, UCHAR *Out, int Length)
{
	int Counter;
	int i;
	aes_context ctx;

	UCHAR *ucTempIn = NULL;

	//VMProtectBegin("Decrypt");

	ucTempIn = (UCHAR *)ExAllocatePoolWithTag(PagedPool, Length, VUSB_POOL_TAG);

	if (!ucTempIn) 
		return STATUS_INSUFFICIENT_RESOURCES;

	RtlZeroMemory(ucTempIn, Length);
	RtlCopyMemory(ucTempIn, In, Length);

	aes_setkey_dec(&ctx, AESKey, 128);

	RtlZeroMemory(Out, Length);
	// RtlZeroMemory function position is important because caller can set IN and OUT same pointer
	// so zero it after copy IN to TempIN

	for(Counter = 0; Counter < Length; Counter += 16)
	{
		aes_crypt_ecb(&ctx, AES_DECRYPT, ucTempIn + Counter, Out + Counter);
		if( Counter >= 16)
			for(i = 0; i < 16; i++)
				Out[Counter + i] ^= ucTempIn[Counter - 16 + i];
	}

	if(ucTempIn) 
		ExFreePoolWithTag(ucTempIn, VUSB_POOL_TAG);

	//VMProtectEnd();

	return STATUS_SUCCESS;
}

//---------------------------------------------------------------
NTSTATUS Encrypt(UCHAR *AESKey, UCHAR *In, UCHAR *Out, int Length)
{
	int Counter;
	int i;
	aes_context ctx;

	UCHAR *ucTempIn = NULL;

	//VMProtectBegin("Encrypt");

	ucTempIn = (UCHAR *)ExAllocatePoolWithTag(PagedPool, Length, VUSB_POOL_TAG);

	if (!ucTempIn) 
		return STATUS_INSUFFICIENT_RESOURCES;

	RtlZeroMemory(ucTempIn, Length);
	RtlCopyMemory(ucTempIn, In, Length);

	aes_setkey_enc(&ctx, AESKey, 128);

	RtlZeroMemory(Out, Length);
	// RtlZeroMemory function position is important because caller can set IN and OUT same pointer
	// so zero it after copy IN to TempIN

	for(Counter = 0; Counter < Length; Counter += 16)
	{
		if(Counter >= 16)
			for(i = 0; i < 16; i++)
				// In[16]=Out[0], In[17]=Out[1], etc
				ucTempIn[Counter + i] ^= Out[Counter - 16 + i];
		aes_crypt_ecb(&ctx, AES_ENCRYPT, ucTempIn + Counter, Out + Counter);
	}

	if(ucTempIn) 
		ExFreePoolWithTag(ucTempIn, VUSB_POOL_TAG);

	//VMProtectEnd();

	return STATUS_SUCCESS;
}

//-------------------------------------------------------------------
NTSTATUS Encrypt_325(UCHAR * AESKey, UCHAR * In, UCHAR * Out, int Length)
{
	int Counter;
	int i;
	aes_context ctx;

	UCHAR *ucTempIn = NULL;

	//VMProtectBegin("Encrypt_325");

	ucTempIn = (UCHAR *)ExAllocatePoolWithTag(PagedPool, Length, VUSB_POOL_TAG);

	if (!ucTempIn) 
		return STATUS_INSUFFICIENT_RESOURCES;

	RtlZeroMemory(ucTempIn, Length);
	RtlCopyMemory(ucTempIn, In, Length);

	aes_setkey_dec(&ctx, AESKey, 128);

	RtlZeroMemory(Out, Length);
	// RtlZeroMemory function position is important because caller can set IN and OUT same pointer
	// so zero it after copy IN to TempIN

	for(Counter = 0; Counter < Length; Counter += 16)
	{
		if(Counter >= 16)
			for(i = 0; i < 16; i++)
				ucTempIn[Counter + i] ^= Out[Counter - 16 + i];

		hasplms_3_25_untransform(ucTempIn + Counter);

		aes_crypt_ecb(&ctx, AES_DECRYPT, ucTempIn + Counter, Out + Counter);

		hasplms_3_25_untransform(Out + Counter);
	}

	if(ucTempIn)
		ExFreePoolWithTag(ucTempIn, VUSB_POOL_TAG);

	//VMProtectEnd();

	return STATUS_SUCCESS;
}

// Routine Description: Encode/decode response/request to key HASP4/HL
// Arguments:
// bufPtr - pointer to a encoded/decoded data
// bufSize - size of encoded information
// key1Ptr, key2Ptr - ptr to chiper keys
// Return Value: none
void _Chiper(void *bufPtr, ULONG bufSize, PUSHORT key1Ptr, PUSHORT key2Ptr)
{
	ULONG i, j;
	UCHAR tmpDL;
	UCHAR *p;

	PAGED_CODE();

	p = (UCHAR *)bufPtr;
	if (bufSize)
	{
		for (i = 0; i < bufSize; i++)
		{
			tmpDL = 0;
			for (j = 0; j < 4; j++)
			{
				tmpDL <<= 1;
				if ( (*key1Ptr) & 0x01 )
				{
					tmpDL |= 0x1;
					*key1Ptr = ((*key1Ptr ^ *key2Ptr) >> 1) | 0x8000;
				}
				else
				{
					*key1Ptr >>= 1;
				}
				tmpDL <<= 1;
				if ( (*key1Ptr) & 0x80 ) tmpDL |= 0x01;
			}
			*p++ ^= tmpDL;
		}
	}
}

// Routine Description: Encode/decode response/request to key (stub only)
// Arguments:
// bufPtr - pointer to a encoded/decoded data
// bufSize - size of encoded information
// pKeyData - ptr to key data
// Return Value: none
void Chiper(VOID *buf, ULONG size, PKEYDATA pKeyData)
{
	PAGED_CODE();
	//	DPRINT("Chiper inChiperKey1=%08X, inChiperKey2=%08X, length=%X\n", pKeyData->chiperKey1, pKeyData->chiperKey2, size);
	_Chiper(buf, size, &pKeyData->chiperKey1, &pKeyData->chiperKey2);
	//	DPRINT("Chiper outChiperKey1=%08X, outChiperKey2=%08X\n", pKeyData->chiperKey1, pKeyData->chiperKey2);
}

//---------------------------------------------------
static EncodeStatus(UCHAR ValidateByte, UCHAR *loopCnt)
{
	int i;
	for (i = 7; i >= 0; i--)
	{
		if ( (*loopCnt = (*loopCnt << 1) | ((ValidateByte >> i) & 0x01)) & 0x10 ) * loopCnt ^= 0x0D;
		*loopCnt &= 0x0F;
	}
}

// Routine Description: Check encoded status (byte after status) for validity
// Arguments:
// AdjustedReqCode - pointer to ((requested fn code) & 7E)
// SetupKeysResult - data[0] response of key to 0x80 function
// BufPtr - ptr to status byte
// Return Value:
// bool, 1 - encoded status ok, 0 - wrong encoded status
ULONG CheckEncodedStatus(UCHAR AdjustedReqCode, UCHAR SetupKeysResult, UCHAR *BufPtr)
{
	UCHAR loopCnt = 0x0F;

	if ((!AdjustedReqCode) || (SetupKeysResult < 2 ))
		return((*BufPtr <= 0x0F) ? 1 : 0);

	if (*BufPtr > 0x1F)
		return(0);

	EncodeStatus(*BufPtr, &loopCnt);
	EncodeStatus(*(BufPtr + 1), &loopCnt);

	return((loopCnt > 0) ? 0 : 1);
}

// Routine Description: Compute memory size of key in bytes
// Arguments:
// pKeyData - ptr to key data
// Return Value:
// memory size of key in bytes
LONG GetMemorySize(PKEYDATA pKeyData)
{
	PAGED_CODE ();

	if (pKeyData->memoryType == 1)
		return 0x80; // 128;

	if (pKeyData->memoryType == 4)
		return 0x1F0; // 496;

	if (pKeyData->memoryType == 0x20)
		return 0xFD0; // 4048; // HL

	if (pKeyData->memoryType == 0x21)
		return 0x70; // 112;
	else
		return 0xFD0; // 4048 memoryType == 0x20
}

//---------- For HASP clock -----
static UCHAR ByteToBCD(UCHAR dByte)
{
	return(((dByte / 10) << 4) | (dByte % 10));
}

static UCHAR BCDToByte(UCHAR BCDByte)
{
	return(((BCDByte >> 4) * 10) + (BCDByte & 0xF));
}
//------------------------------

#define MINUTE 60
#define HOUR  (60 * MINUTE)
#define DAY   (24 * HOUR)
#define YEAR  (365*  DAY)

static int month[12] =
{
	0,
	DAY*(31),
	DAY*(31+29),
	DAY*(31+29+31),
	DAY*(31+29+31+30),
	DAY*(31+29+31+30+31),
	DAY*(31+29+31+30+31+30),
	DAY*(31+29+31+30+31+30+31),
	DAY*(31+29+31+30+31+30+31+31),
	DAY*(31+29+31+30+31+30+31+31+30),
	DAY*(31+29+31+30+31+30+31+31+30+31),
	DAY*(31+29+31+30+31+30+31+31+30+31+30)
};

typedef struct _SRM_TIME {
	unsigned int  tm_mday;    // Input for day value (range 1-31)
	unsigned int  tm_mon;     // hasp is Input for month value (range 1-12) but function use months since January - [0,11]
	unsigned int  tm_year;    // Input for year value (range 1970+)
	unsigned int  tm_hour;    // Input for hour value (range 0-23)
	unsigned int  tm_min;     // Input for minute value (range 0-59)
	unsigned int  tm_sec;     // Input for second value (range 0-59)
} SRM_TIME ;

long kernel_mktime(SRM_TIME *tm)
{
	long res;
	int year;

	year = tm->tm_year - 70;
	/* magic offsets (y+1) needed to get leapyears right.*/
	res = YEAR*year + DAY*((year+1)/4);
	res += month[tm->tm_mon];
	/* and (y+2) here. If it wasn't a leap-year, we have to adjust */
	if (tm->tm_mon>1 && ((year+2)%4))
		res -= DAY;
	res += DAY*(tm->tm_mday-1);
	res += HOUR*tm->tm_hour;
	res += MINUTE*tm->tm_min;
	res += tm->tm_sec;
	return res;
}

#if DBG
static WCHAR *AesEncryptionTypes[] =
{
	L"QUERY 16 ENCRYPT   ", // 0x0
	L"QUERY 16 DECRYPT   ", // 0x1
	L"QUERY 32-16        ", // 0x2
	L"QUERY 32           ", // 0x3
	L"QUERY 48 ENCRYPT   ", // 0x4
	L"QUERY 48 DECRYPT   ", // 0x5
	L"QUERY 32 ENCRYPT 32", // 0x6
	L"QUERY 32 DECRYPT 32", // 0x7
	L"QUERY 32 ENCRYPT 20", // 0x8
	L"QUERY 32 DECRYPT 20", // 0x9
	L"QUERY 16-32 ENCRYPT", // 0xA
	L"QUERY 16-32 DECRYPT"  // 0xB
};

void PrintBufferContent512(WCHAR *prefix, UCHAR *in_buffer, ULONG in_buffer_length)
{
	WCHAR output_wstring[512] = {0};
	WCHAR tmp_wstr[8] = {0};
	ULONG i;

	RtlZeroMemory(output_wstring, sizeof(output_wstring));

	// Check parameters
	if (!in_buffer)
	{
		RtlStringCbPrintfExW(output_wstring, sizeof(output_wstring), NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"NULL (ptr to data)");
		return;
	}

	if (in_buffer_length <= 0)
	{
		RtlStringCbPrintfExW(output_wstring, sizeof(output_wstring), NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"NULL (length)");
		return;
	}

	// Create string
	output_wstring[0] = 0;
	output_wstring[1] = 0;
	output_wstring[2] = 0;
	output_wstring[3] = 0;

	for (i = 0; i < in_buffer_length; i++)
	{
		RtlStringCbPrintfExW(tmp_wstr, sizeof(tmp_wstr),
			NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%02X", (UCHAR)in_buffer[i]);

		RtlStringCbCatExW(output_wstring, sizeof(output_wstring), tmp_wstr, NULL, NULL, STRSAFE_NO_TRUNCATION);
	}

	DPRINT("%ws%ws", prefix, output_wstring);

}
#else
#define PrintBufferContent512(exp) ((void) 0)
#endif

//**********************  HASP 4/HL/SRM KEY EMULATION  **********************
void EmulateHASPKey(PKEYDATA pKeyData, PKEY_REQUEST request, PULONG outBufLen, PKEY_RESPONSE outBuf)
{
	UCHAR encodeOutData;
	UCHAR status;
	UCHAR encodedStatus;

	ULONG outDataLen;
	ULONG Length = 0;

	KEY_RESPONSE *pResp = NULL;

	LARGE_INTEGER time;
	static int WrittenTIMEDataLen;
	static int WrittenTIMEDataOfs;

	WCHAR KeyName96[96] = {0};

	ULONG SecurityFlag = 0;

	//	UCHAR name[20];
	//	UCHAR *pname = &name[0];

	PAGED_CODE();

	//	RtlFillMemory(&name[0], 20, 0);
	//	GetProcessNameInEprocess(pname);
	//	DPRINT("Hasp key : Process name is %s\n", name);

	pResp = (KEY_RESPONSE *)ExAllocatePoolWithTag (PagedPool, sizeof(KEY_RESPONSE), VUSB_POOL_TAG);
	if(pResp == NULL)
		return;

	RtlZeroMemory(pResp, sizeof(KEY_RESPONSE));

	pResp->status = KEY_OPERATION_STATUS_ERROR;

	outDataLen = 0;
	encodeOutData = 0;

	Length = *outBufLen;

	KeQueryTickCount(&time);

#ifdef DBG
	switch (request->majorFnCode)
	{
	case KEY_FN_SET_CHIPER_KEYS:
		DPRINT("KEY_FN_SET_CHIPER_KEYS\n");
		break;
	case KEY_FN_CHECK_PASS:
		DPRINT("KEY_FN_CHECK_PASS\n");
		break;
	case KEY_FN_READ_3WORDS:
		DPRINT("KEY_FN_READ_3WORDS\n");
		break;
	case KEY_FN_WRITE_WORD:
		DPRINT("KEY_FN_WRITE_WORD\n");
		break;
	case KEY_FN_READ_ST:
		DPRINT("KEY_FN_READ_ST\n");
		break;
	case KEY_FN_READ_NETMEMORY_3WORDS:
		DPRINT("KEY_FN_READ_NETMEMORY_3WORDS\n");
		break;
	case KEY_FN_HASH_DWORD:
		DPRINT("KEY_FN_HASH_DWORD\n");
		break;
	case KEY_FN_ECHO_REQUEST:
		DPRINT("KEY_FN_ECHO_REQUEST\n");
		break;
	case KEY_FN_GET_TIME:
		DPRINT("KEY_FN_GET_TIME\n");
		break;
	case KEY_FN_PREPARE_CHANGE_TIME:
		DPRINT("KEY_FN_PREPARE_CHANGE_TIME\n");
		break;
	case KEY_FN_COMPLETE_WRITE_TIME:
		DPRINT("KEY_FN_COMPLETE_WRITE_TIME\n");
		break;
	case KEY_FN_PREPARE_DECRYPT:
		DPRINT("KEY_FN_PREPARE_DECRYPT\n");
		break;
	case KEY_FN_COMPLETE_DECRYPT:
		DPRINT("KEY_FN_COMPLETE_DECRYPT\n");
		break;
	case KEY_FN_READ_STRUCT:
		DPRINT("KEY_FN_READ_STRUCT\n");
		break;
	case KEY_FN_READ_FAT:
		DPRINT("KEY_FN_READ_FAT\n");
		break;

	case KEY_WRITE_FEATUREMAP_REQUEST:
		DPRINT("KEY_WRITE_FEATURE_REQUEST\n");
		break;
	case KEY_WRITE_FEATUREMAP_RESPONSE:
		DPRINT("KEY_WRITE_FEATURE_RESPONSE\n");
		break;
	case KEY_DELETE_FEATURE_REQUEST:
		DPRINT("KEY_DELETE_FEATURE_REQUEST\n");
		break;
	case KEY_DELETE_FEATURE_RESPONSE:
		DPRINT("KEY_DELETE_FEATURE_RESPONSE\n");
		break;
	case KEY_WRITE_SIGN_FEATURE_REQUEST:
		DPRINT("KEY_WRITE_SIGN_FEATURE_REQUEST\n");
		break;
	case KEY_WRITE_SIGN_FEATURE_RESPONSE:
		DPRINT("KEY_WRITE_SIGN_FEATURE_RESPONSE\n");
		break;

	case KEY_READ_REQUEST:
		DPRINT("KEY_READ_REQUEST\n");
		break;
	case KEY_READ_RESPONSE:
		DPRINT("KEY_READ_RESPONSE\n");
		break;
	case KEY_FN_ECHO_WBAES_IN:
//		DPRINT("KEY_FN_ECHO_WBAES_IN\n");
		break;
	case KEY_FN_ECHO_WBAES_OUT:
//		DPRINT("KEY_FN_ECHO_WBAES_OUT\n");
		break;
	case KEY_WRITE_REQUEST:
		DPRINT("KEY_WRITE_REQUEST\n");
		break;
	case KEY_WRITE_RESPONSE:
		DPRINT("KEY_WRITE_RESPONSE\n");
		break;
	case KEY_FN_SIGNED_READ_REQUEST:
		DPRINT("KEY_FN_SIGNED_READ_REQUEST\n");
		break;
	case KEY_FN_SIGNED_READ_RESPONSE:
		DPRINT("KEY_FN_SIGNED_READ_RESPONSE\n");
		break;
	case KEY_FN_AES_IN:
		DPRINT("KEY_FN_AES_IN\n");
		break;
	case KEY_FN_AES_OUT:
		DPRINT("KEY_FN_AES_OUT\n");
		break;
	case KEY_FN_LOGIN:
		DPRINT("KEY_FN_LOGIN\n");
		break;
	case KEY_FN_LOGOUT:
		DPRINT("KEY_FN_LOGOUT\n");
		break;
	case KEY_FN_READ_DATE_TIME:
		DPRINT("KEY_FN_READ_DATE_TIME\n");
		break;

	default:
		DPRINT("UNKNOWN_HASP_FUNC : 0x%X\n", request->majorFnCode);
		break;
	}

	DPRINT("Length = %d [0x%X]\n", Length, Length);
	DPRINT("Value = %04X Index = %04X p3 = %04X\n",
		request->param1, request->param2, request->param3);

#endif

	// check timer - it set isPassSecurity
	/*SecurityFlag = DS_CheckSecurityTimer(pKeyData->ds.allowMinutes);
	pKeyData->ds.isPassSecurity = TRUE;*/

	// and check flag
	// PROTECTION - fools all hasp SRM data - is enough for stop SRM emulation
	/*if((pKeyData->ds.isPassSecurity != TRUE))
	{
		DPRINT("SECURITY TIMER FAIL SRM FUNCTION at EmulateHASPKey\n");
		//RtlZeroMemory(pKeyData->FuncA1_Val0, sizeof(pKeyData->FuncA1_Val0));
		//RtlZeroMemory(pKeyData->FuncA1_Val1, sizeof(pKeyData->FuncA1_Val1));
		//RtlZeroMemory(pKeyData->FuncA1_Val2, sizeof(pKeyData->FuncA1_Val2));
		//RtlZeroMemory(pKeyData->FuncA1_Val3, sizeof(pKeyData->FuncA1_Val3));
		//RtlZeroMemory(pKeyData->FuncA2,      sizeof(pKeyData->FuncA2));

		RtlZeroMemory(pKeyData->plugAES,     sizeof(pKeyData->plugAES));
		RtlZeroMemory(pKeyData->plugAES_new, sizeof(pKeyData->plugAES_new));
		RtlZeroMemory(pKeyData->plugAES_new_656, sizeof(pKeyData->plugAES_new_656));
		RtlZeroMemory(pKeyData->VendorAES,   sizeof(pKeyData->VendorAES));
	}*/

	switch (request->majorFnCode)
	{
	case KEY_FN_SET_CHIPER_KEYS:              // 6C F4 DB 97 D3 6C 08

		pKeyData->chiperKey1 = request->param1;
		pKeyData->chiperKey2 = 0xA0CB;
		// DPRINT("CHIPER %04X %04X \n", pKeyData->chiperKey1, pKeyData->chiperKey2);

		// Setup random encoded status begin value
		pKeyData->encodedStatus = (UCHAR)pKeyData;
		pKeyData->isInitDone = 1;

		// Make key response
		pResp->status = KEY_OPERATION_STATUS_OK;
		pResp->data[0] = 0x02;

		// Time hasp or usual hasp
		pResp->data[1] = 0x0A;
		pResp->data[1] = ((pKeyData->netMemory[4] == 3) || (pKeyData->netMemory[4] == 5)) ? 0x1A : 0x0A;

		DPRINT("keyType %02x\n", pKeyData->keyType);
		if ( pKeyData->keyType > 5 )
			// HASP 3 Time  - 0x12
			// HASP 4 M1    - 0x0A
			// HASP 4 Time  - 0x1A
			// Hasp HL Time - 0xDA
			// Hasp HL      - 0xEA
			// Hasp SRM HL  - 0xFA
			pResp->data[1] = pKeyData->keyType;
		else
			pResp->data[1] = 0x0A;            // default value

		pResp->data[2] = 0x00;

		// Bytes 3, 4 - key sn, set it to low word of ptr to key data - WRONG

		// These are emulated Firmware values 3.25
		pResp->data[3] = 0x19; //(UCHAR)(((USHORT)pKeyData) & 0xFF);
		pResp->data[4] = 0x03 ;//(UCHAR)((((USHORT)pKeyData) >> 8) & 0xFF);

		outDataLen = 5;
		encodeOutData = 1;
		break;

	case KEY_FN_CHECK_PASS:
		// Decode pass
		Chiper(&request->param1, 4, pKeyData);

		DPRINT("reqPassword = %08X\n", *((PULONG)&request->param1));
		DPRINT("keyPassword = %08X\n", pKeyData->password);

		// Show request
		//LogMessage ("KEY_FN_CHECK_PASS pass=%08X, pKeyData->password=%08X, pKeyData->isInitDone=%X\n",
		//*((PULONG)&request->param1), pKeyData->password, pKeyData->isInitDone);
		//DbgPrint("KEY_FN_CHECK_PASS pass=%08X, pKeyData->password=%08X, pKeyData->isInitDone=%X\n",
		//*((PULONG)&request->param1), pKeyData->password, pKeyData->isInitDone);

		// Compare pass
		if (*((PULONG)&request->param1) == pKeyData->password &&
			pKeyData->isInitDone == 1)
		{
			pResp->status = KEY_OPERATION_STATUS_OK;

			// data[0], data[1] - memory size
			pResp->data[0] = (UCHAR)((GetMemorySize(pKeyData)) & 0xFF);
			pResp->data[1] = (UCHAR)((GetMemorySize(pKeyData) >> 8) & 0xFF);
			pResp->data[2] = 0x10;
			// pResp->data[2] = 0x70;            // - it works too ?
			outDataLen = 3;
			encodeOutData = 1;

			// FN_OPEN_KEY
			pKeyData->isKeyOpened = 1;
		}
		break;

	case KEY_FN_READ_NETMEMORY_3WORDS:
		// Decode offset into NetMemory
		Chiper(&request->param1, 2, pKeyData);
		// Typical data into NetMemory:
		// 12 1A 12 0F 03 00 70 00 02 FF 00 00 FF FF FF FF
		// 12 1A 12 0F - sn
		// 03 00 - key type
		// 70 00 - memory size in bytes
		// 02 FF - ?
		// 00 00 - net user count
		// FF FF - ?
		// FF - key type (FF - local, FE - net, FD - time)
		// FF - ?
		// Analyse memory offset
		if (pKeyData->isKeyOpened && request->param1 >= 0 && request->param1 <= 7)
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			RtlCopyMemory(&(pResp->data), &pKeyData->netMemory[request->param1*2], sizeof(USHORT) * 3);

			outDataLen = sizeof(USHORT) * 3;
			encodeOutData = 1;
		}
		break;

	case KEY_FN_READ_3WORDS:
		// Decode memory offset
		Chiper(&request->param1, 2, pKeyData);
		// Do read
		if (pKeyData->isKeyOpened && request->param1 >= 0 && (request->param1 * 2) < GetMemorySize(pKeyData))
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			RtlCopyMemory(&(pResp->data), &pKeyData->memory[request->param1*2], sizeof(USHORT) * 3);
			outDataLen = sizeof(USHORT) * 3;
			encodeOutData = 1;
		}
		break;

	case KEY_FN_WRITE_WORD:
		// Decode memory offset & value
		Chiper(&request->param1, 4, pKeyData);
		DPRINT("offset=%X data=%X\n", request->param1, request->param2);
		// Do write
		if (pKeyData->isKeyOpened && request->param1 >= 0 && (request->param1 * 2) < GetMemorySize(pKeyData))
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			RtlCopyMemory(&pKeyData->memory[request->param1*2], &request->param2, sizeof(USHORT));
			outDataLen = 0;
			encodeOutData = 0;
			// ... and store it
			if ( !Store_KeyDataToRegister(HLDATA,
				pKeyData, HL_DATA_STR, &pKeyData->memory, (ULONG)GetMemorySize(pKeyData)) )
				pResp->status = KEY_OPERATION_STATUS_OK;
		}
		break;

	case KEY_FN_READ_ST:
		// Do read ST
		if (pKeyData->isKeyOpened)
		{
			LONG i;
			pResp->status = KEY_OPERATION_STATUS_OK;
			for (i = 7; i >= 0; i--)
				pResp->data[7-i] = pKeyData->secTable[i];
			outDataLen = 8;
			encodeOutData = 1;
		}
		break;

	case KEY_FN_HASH_DWORD:
		// Decode dword
		Chiper(&request->param1, 4, pKeyData);
		// Do hash dword
		if (pKeyData->isKeyOpened)
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			RtlCopyMemory(&(pResp->data), &request->param1, 4);
			Transform((DWORD *)pResp->data, &pKeyData->KEY_INFOdata);
			outDataLen = sizeof(ULONG);
			encodeOutData = 1;
		}
		break;

	case KEY_FN_GET_TIME:
		{
			LARGE_INTEGER CurrentTime;
			TIME_FIELDS TimeFields;

			if (pKeyData->isKeyOpened)
			{
				pResp->status = KEY_OPERATION_STATUS_OK;
				// Decode dword (parameters)
				// first byte == ofs in data_time[] memory (of key)
				// second byte == len of requested data_time[] from memory
				Chiper(&request->param1, 4, pKeyData);
				// Get system time
				KeQuerySystemTime(&CurrentTime);
				// Correct by self time shift
				*((LONGLONG *)&CurrentTime) += *((LONGLONG *)&pKeyData->TimeShift);
				RtlTimeToTimeFields(&CurrentTime, &TimeFields);
				// Make response
				if (!(request->param1 & 0xFF))
				{
					// Read time (3 bytes) from offset 0
					pResp->data[2] = ByteToBCD((UCHAR)TimeFields.Hour);
					pResp->data[1] = ByteToBCD((UCHAR)TimeFields.Minute);
					pResp->data[0] = ByteToBCD((UCHAR)TimeFields.Second);
				}
				else if ((request->param1 & 0xFF) == 3)
				{
					// Read date (4 bytes) from offset 3
					pResp->data[3] = ByteToBCD((UCHAR)(TimeFields.Year % 100));
					pResp->data[2] = ByteToBCD((UCHAR)TimeFields.Weekday);
					pResp->data[1] = ByteToBCD((UCHAR)TimeFields.Month);
					pResp->data[0] = ByteToBCD((UCHAR)TimeFields.Day);
				}
				else
				{
					// read TIME Memory ?
					RtlCopyMemory(&(pResp->data), &pKeyData->HASPTIMEMEMORY.curr_time[request->param1&0xFF], request->param1 >> 8);
				}
				outDataLen = (request->param1 >> 8);
				encodeOutData = 1;
			}
			break;
		}

	case KEY_FN_PREPARE_CHANGE_TIME:
		{
			if (pKeyData->isKeyOpened)
			{
				pResp->status = KEY_OPERATION_STATUS_OK;
				// Decode dword (parameters)
				// first byte == ofs in data_time[] memory (of key)
				// 4-th byte == len of writing data ? in data_time[] memory
				Chiper(&request->param1, 4, pKeyData);
				// Save offset & len of changing data (for KEY_FN_COMPLETE_WRITE_TIME)
				WrittenTIMEDataOfs = request->param1 & 0xFF;
				// Decode & save written data
				RtlCopyMemory(&pKeyData->HASPTIMEMEMORY.curr_time[WrittenTIMEDataOfs], outBuf, (WrittenTIMEDataLen = request->param2 >> 8));
				Chiper(&pKeyData->HASPTIMEMEMORY.curr_time[WrittenTIMEDataOfs], WrittenTIMEDataLen, pKeyData);
				// We haven't to do anymore: return to caller (like 0xA0 func)
				*outBufLen = 0;

				if(pResp)
					ExFreePoolWithTag(pResp, VUSB_POOL_TAG);
				return;
			}
			break;
		}

	case KEY_FN_COMPLETE_WRITE_TIME:
		{
			LARGE_INTEGER CurrentTime, SelfTime, NewTime;
			TIME_FIELDS TimeFields;

			if (pKeyData->isKeyOpened)
			{
				// Write date & time & etc to data_time[] memory of TIME HASP
				// Enter: no data (see KEY_FN_PREPARE_CHANGE_TIME)
				// Result: no data (only status & encoded status)
				// Here we must to update our clock (data_time[] memory)
				if (WrittenTIMEDataOfs >= 7)
				{
					if (!Store_KeyDataToRegister(HLDATA,
						pKeyData, HL_HASPTIME_MEMORY_STR, &pKeyData->HASPTIMEMEMORY, sizeof(pKeyData->HASPTIMEMEMORY)))
						pResp->status = KEY_OPERATION_STATUS_OK;
					break;                        // No date-time update
				}
				// Get current time (with TimeShift) in PLARGE_INTEGER format
				KeQuerySystemTime(&CurrentTime);
				*((LONGLONG *)&SelfTime) = *((LONGLONG *)&CurrentTime) + *((LONGLONG *)&pKeyData->TimeShift);
				RtlTimeToTimeFields(&SelfTime, &TimeFields);

				// Change TimeFields as aksusb requested us
				if (!WrittenTIMEDataOfs)
				{
					// Change time (ofs=0, len=3)
					pKeyData->HASPTIMEMEMORY.curr_time[0] &= 0x7F;
					TimeFields.Second = BCDToByte(pKeyData->HASPTIMEMEMORY.curr_time[0]);
					TimeFields.Minute = BCDToByte(pKeyData->HASPTIMEMEMORY.curr_time[1]);
					TimeFields.Hour = BCDToByte(pKeyData->HASPTIMEMEMORY.curr_time[2]);
				}
				else
				{
					// Change date (ofs=3, len=4)
					TimeFields.Day = BCDToByte(pKeyData->HASPTIMEMEMORY.curr_date[0]);
					TimeFields.Month = BCDToByte(pKeyData->HASPTIMEMEMORY.curr_date[1]);
					TimeFields.Year = BCDToByte(pKeyData->HASPTIMEMEMORY.curr_date[3]);
					if (TimeFields.Year < 90)
						TimeFields.Year += 2000;
					else
						TimeFields.Year += 1900;
				}
				// Convert time onto PLARGE_INTEGER format
				RtlTimeFieldsToTime(&TimeFields, &NewTime);
				// Calculate new time shift
				*((LONGLONG *)&pKeyData->TimeShift) = *((LONGLONG *)&NewTime) - *((LONGLONG *)&CurrentTime);

				if ( !Store_KeyDataToRegister(HLDATA,
					pKeyData, HL_TIMESHIFT_STR, &pKeyData->TimeShift, sizeof(LONGLONG)))
					pResp->status = KEY_OPERATION_STATUS_OK;
			}
			break;
		}

	case KEY_FN_PREPARE_DECRYPT: //1E - Question
		{
			if (pKeyData->isKeyOpened)
			{
				pKeyData->QA_Buff_Len = *outBufLen;

				// DPRINT("CHIPER %04X %04X \n", pKeyData->chiperKey1, pKeyData->chiperKey2);

				Chiper(&request->param1, 4, pKeyData);
				Chiper(outBuf, pKeyData->QA_Buff_Len, pKeyData);

				pKeyData->EncDecType =  (request->param1 > 3) ? 1 : 0;
				pKeyData->EncDecValue = (request->param1 < 7) ? ((UCHAR)request->param1) : 8;

				RtlZeroMemory(pKeyData->lastQA_buff, sizeof(pKeyData->lastQA_buff));
				RtlCopyMemory(&pKeyData->lastQA_buff, outBuf, min(pKeyData->QA_Buff_Len, sizeof(pKeyData->lastQA_buff)));

				DPRINT("QA_Buff_Len = %02X\n", pKeyData->QA_Buff_Len);
				DPRINT("EncDecType  = %02X\n", pKeyData->EncDecType);
				DPRINT("EncDecValue = %02X\n", pKeyData->EncDecValue);

				// if (pKeyData->options[0] != 0x69)
				// DelayExecutionThread();

				pResp->status = KEY_OPERATION_STATUS_OK;

				if(pResp)
					ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

				return;
			}
			break;
		}
	case KEY_FN_COMPLETE_DECRYPT: //9E - Answer
		{
			DPRINT("QA_Buff_Len = %02X\n", pKeyData->QA_Buff_Len);

			if (pKeyData->isKeyOpened)
			{
				NTSTATUS status1;
				ULONG actualSize = 0;

				UCHAR k;

				// LARGE_INTEGER CurrentTimes = {0, 0};
				// if (pKeyData->options[0] != 0x69)
				// DelayExecutionThread();

				RtlZeroMemory(Q_Q, sizeof(Q_Q));
				RtlZeroMemory(A_A, sizeof(A_A));

				RtlCopyMemory(&Q_Q, pKeyData->lastQA_buff, min(pKeyData->QA_Buff_Len, sizeof(Q_Q)));

				//************************************************************************************************************************ 
				RtlZeroMemory(KeyName96, sizeof(KeyName96));

				switch(pKeyData->QA_Buff_Len)
				{
				case 0x10:
					{
						RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
							L"%ws%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
							L"10:",
							Q_Q[0],Q_Q[1],Q_Q[2],Q_Q[3],Q_Q[4],Q_Q[5],Q_Q[6],Q_Q[7],Q_Q[8],Q_Q[9],Q_Q[10],Q_Q[11],Q_Q[12],Q_Q[13],Q_Q[14],Q_Q[15]);
					}
					break;
				case 0x20:
					{
						RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
							L"%ws%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
							L"20:",
							Q_Q[0],Q_Q[1],Q_Q[2],Q_Q[3],Q_Q[4],Q_Q[5],Q_Q[6],Q_Q[7],Q_Q[8],Q_Q[9],Q_Q[10],Q_Q[11],Q_Q[12],Q_Q[13],Q_Q[14],Q_Q[15],
							Q_Q[16],Q_Q[17],Q_Q[18],Q_Q[19],Q_Q[20],Q_Q[21],Q_Q[22],Q_Q[23],Q_Q[24],Q_Q[25],Q_Q[26],Q_Q[27],Q_Q[28],Q_Q[29],Q_Q[30],Q_Q[31]);
					}
					break;
				case 0x30:
					{
						RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,	
							L"%ws%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
							L"30:",
							Q_Q[0],Q_Q[1],Q_Q[2],Q_Q[3],Q_Q[4],Q_Q[5],Q_Q[6],Q_Q[7],Q_Q[8],Q_Q[9],Q_Q[10],Q_Q[11],Q_Q[12],Q_Q[13],Q_Q[14],Q_Q[15],
							Q_Q[16],Q_Q[17],Q_Q[18],Q_Q[19],Q_Q[20],Q_Q[21],Q_Q[22],Q_Q[23],Q_Q[24],Q_Q[25],Q_Q[26],Q_Q[27],Q_Q[28],Q_Q[29],Q_Q[30],Q_Q[31]);
					}
					break;
				default:
					RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,	
						L"%ws%02X",
						L"default000000:", 0);
					break;
				}

				if (pKeyData->EncDecType == 0)
					status1 = GetExtraRegKeyData(ETABLE, pKeyData->password, KeyName96, A_A, 16, &actualSize);
				else
					status1 = GetExtraRegKeyData(DTABLE, pKeyData->password, KeyName96, A_A, 16, &actualSize);

				if(!NT_SUCCESS(status1))
				{
					DPRINT("don't find in tables, EDValue = %02X\n", pKeyData->EncDecValue);
					switch(pKeyData->EncDecValue)
					{
					case 0: // Encrypt 16 bytes
						{
							Encrypt(FeatAesKey_01, Q_Q, A_A, 16);
						}
						break;
					case 4: // Decrypt 16 bytes
						{
							Decrypt(FeatAesKey_01, Q_Q, A_A, 16);
						}
						break;

					case 1: // Encrypt 32 bytes
						{
							Encrypt(FeatAesKey_02, Q_Q, A_A, 16);
							Encrypt(FeatAesKey_03, Q_Q + 16, A_A + 16, 16);

							for(k = 0; k < 16; k++)
							{
								A_A[k] ^= A_A[k+16];
							}

							memset(A_A + 16, 0, 32);
						}
						break;
					case 2: // Encrypt 48 bytes
						{
							Encrypt(FeatAesKey_02, Q_Q, A_A, 16);
							Encrypt(FeatAesKey_03, Q_Q + 16, A_A + 16, 16);
							Encrypt(FeatAesKey_04, Q_Q + 32, A_A + 32, 16);

							for(k = 0; k < 16; k++)
							{
								A_A[k] ^= A_A[k+16];
								A_A[k] ^= A_A[k+32];
							}

							Encrypt(FeatAesKey_05, A_A, A_A, 16);

							memset(A_A + 16, 0, 32);
						}
						break;

					case 5: // Decrypt 32 bytes
						{
							Decrypt(FeatAesKey_05, Q_Q, A_A, 16);
							Encrypt(FeatAesKey_04, Q_Q + 16, A_A + 16, 16); // yes encrypt!!!

							for(k = 0; k < 16; k++)
							{
								A_A[k] ^= A_A[k+16];
							}

							memset(A_A + 16, 0, 32);
						}
						break;
					case 6: // Decrypt 48 bytes
						{
							Decrypt(FeatAesKey_05, Q_Q, A_A, 16);
							Encrypt(FeatAesKey_04, Q_Q + 16, A_A + 16, 16); // yes encrypt!!!
							Encrypt(FeatAesKey_03, Q_Q + 32, A_A + 32, 16); // yes encrypt!!!

							for(k = 0; k < 16; k++)
							{
								A_A[k] ^= A_A[k+16];
								A_A[k] ^= A_A[k+32];
							}

							Decrypt(FeatAesKey_02, A_A, A_A, 16);

							memset(A_A + 16, 0, 32);
						}
						break;
					}
				}

				PrintBufferContent512(L"Q_Q_HHL: " , Q_Q, sizeof(Q_Q));
				PrintBufferContent512(L"A_A_HHL: " , A_A, sizeof(A_A));

				pResp->status = KEY_OPERATION_STATUS_OK;
				RtlCopyMemory(&(pResp->data), &A_A, pKeyData->QA_Buff_Len);

				outDataLen = 0x10;
				encodeOutData = 1;
			}
			break;
		}

		//********************** SRM FUNCTIONS **********************
#ifdef SRM_EMU
	case KEY_FN_ECHO_WBAES_IN:
		{
			UCHAR Aes2FAF[KEYSIZE] = {0x79,0x4C,0xE1,0x88,0xCB,0xC1,0x78,0x53,0x11,0x69,0xE0,0xB2,0xCA,0x97,0xC9,0x76};
			UCHAR WorkAes2FAF_p[KEYSIZE] = {0xC4,0x24,0x05,0xC9,0x33,0x24,0x4F,0xA5,0x68,0x19,0xAC,0xAA,0xED,0xA5,0xCE,0xF3};
			if (Length == 8)
			{
				// default values ripped from demoma Dongle - 2F-AF is same algo for all SRM dongles
				UCHAR Request2F[8] = {0x29,0x23,0xBE,0x84,0xE1,0x6C,0xD6,0xAE};
				UCHAR ResponsAF[20] = {0xD1,0x12,0x9D,0xE4,0xAA,0xCB,0xA5,0x4F,0xB9,0x67,0x0B,0x84,0x41,0xCC,0x24,0x3B,0x00,0x00,0x02,0x00};
				UCHAR ResponsAF_Seed[4] = {0x00,0x00,0x02,0x00};

				// proper encryption 
				RtlZeroMemory(pKeyData->Func2F_Inp, sizeof(pKeyData->Func2F_Inp));
				RtlZeroMemory(pKeyData->FuncAF_Out, sizeof(pKeyData->FuncAF_Out));

				RtlZeroMemory(Request2F, sizeof(Request2F));
				RtlZeroMemory(ResponsAF, sizeof(ResponsAF));

				RtlZeroMemory(WorkAes2FAF_p, sizeof(WorkAes2FAF_p));

				RtlCopyMemory(&WorkAes2FAF_p[0], &request->param1, 0x04);

				Encrypt(Aes2FAF, WorkAes2FAF_p, WorkAes2FAF_p, 16);

				RtlCopyMemory(Request2F, outBuf, 8);
				RtlCopyMemory(pKeyData->Func2F_Inp, Request2F, 8);

				RtlCopyMemory(&ResponsAF[0], ResponsAF_Seed, 4);
				RtlCopyMemory(&ResponsAF[8], Request2F, 8);
				RtlCopyMemory(&ResponsAF[16], ResponsAF_Seed, 4);

				Encrypt(WorkAes2FAF_p, ResponsAF, ResponsAF, 16);

				RtlCopyMemory(pKeyData->FuncAF_Out, ResponsAF, 20);

//				PrintBufferContent512(L"2F-AF AES : ", WorkAes2FAF_p, sizeof(WorkAes2FAF_p));
//				PrintBufferContent512(L"Input  2F : ", pKeyData->Func2F_Inp, sizeof(pKeyData->Func2F_Inp));
//				PrintBufferContent512(L"Output AF : ", pKeyData->FuncAF_Out, sizeof(pKeyData->FuncAF_Out));

				pResp->status = KEY_OPERATION_STATUS_OK;
				pResp->data[2] = 0x00;

				// *outBufLen = 1;
				// RtlCopyMemory(outBuf, pResp, *outBufLen);
			}

			RtlZeroMemory(Aes2FAF, sizeof(Aes2FAF));
			RtlZeroMemory(WorkAes2FAF_p, sizeof(WorkAes2FAF_p));

			if(pResp)
//				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}

	case KEY_FN_ECHO_WBAES_OUT:
		{

			RtlCopyMemory(&(pResp->data), pKeyData->FuncAF_Out, sizeof(pKeyData->FuncAF_Out));
			outDataLen = 20;
			*outBufLen = 20;

			RtlCopyMemory(outBuf, &(pResp->data), *outBufLen);

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}

	case KEY_FN_ECHO_REQUEST:
	case KEY_FN_LOGIN:
	case KEY_FN_LOGOUT:
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			pResp->data[2] = 0x00;
			*outBufLen = 1;
			RtlCopyMemory(outBuf, pResp, *outBufLen);

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}

	case KEY_FN_READ_DATE_TIME:
		{
			/** HASP timestamp, representing seconds since Jan-01-1970 0:00:00 GMT */
			long hasp_time = 0;
			SRM_TIME t = {0}; // standard tm time.h

			LARGE_INTEGER SystemTime = {0};
			LARGE_INTEGER LocalTime = {0};
			TIME_FIELDS TimeFields;

			KeQuerySystemTime(&SystemTime);
			ExSystemTimeToLocalTime(&SystemTime, &LocalTime);

			// Correct by self time shift
			*((LONGLONG *)&LocalTime) += *((LONGLONG *)&pKeyData->TimeShift);
			RtlTimeToTimeFields(&LocalTime, &TimeFields);
			// Make response
			t.tm_year = TimeFields.Year - 1900;
			t.tm_mon = TimeFields.Month - 1;
			t.tm_mday = TimeFields.Day;

			t.tm_hour = TimeFields.Hour;
			t.tm_min = TimeFields.Minute;
			t.tm_sec = TimeFields.Second;

			hasp_time = kernel_mktime(&t);

			pResp->data[0] = (UCHAR)(hasp_time >> 24);
			pResp->data[1] = (UCHAR)(hasp_time >> 16 );
			pResp->data[2] = (UCHAR)(hasp_time >> 8);
			pResp->data[3] = (UCHAR)(hasp_time);

			// RtlCopyMemory(&(pResp->data), pKeyData->DateTime, 5); // old
			*outBufLen = 5;
			outDataLen = 5;
			RtlCopyMemory(outBuf, &(pResp->data), *outBufLen);

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}
#endif // SRM_EMU
	case KEY_FN_READ_STRUCT:
		{
			switch(request->param1)
			{
			case 0:
				RtlCopyMemory(&(pResp->data), &pKeyData->FuncA1_Val0[0], 3);
				outDataLen = 3;
				*outBufLen = 3;
				break;
			case 1:
				{
					// workaround 2F-AF
					// set ntoskrnl.exe srand(1) - it effects aksusb.sys 2F random generator
					// so we can use table based 2F/AF. It ask every time for sequence
					// 29 23 BE 84 E1 6C D6 AE
					// D1 12 9D E4 AA CB A5 4F B9 67 0B 84 41 CC 24 3B 00 00 02 00 
					// srand(1); 

					RtlCopyMemory(&(pResp->data), &pKeyData->FuncA1_Val1[0], 47);
					outDataLen = 47;
					*outBufLen = 47;
				}
				break;
			case 2:
				RtlCopyMemory(&(pResp->data), &pKeyData->FuncA1_Val2[0], 14);
				outDataLen = 14;
				*outBufLen = 14;
				break;
			case 3:
				RtlCopyMemory(&(pResp->data), &pKeyData->FuncA1_Val3[0], 8);
				outDataLen = 8;
				*outBufLen = 8;
				break;
			}

			RtlCopyMemory(outBuf, &(pResp->data), *outBufLen);

			if(pResp)
				//ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}
#ifdef SRM_EMU
	case KEY_FN_READ_FAT:
		{
			if (request->param1 == 0 && Length == 0x07C1) // 1985
			{
				pResp->status = KEY_OPERATION_STATUS_OK;
				RtlCopyMemory(&(pResp->data), &pKeyData->FuncA2[0], 1985);

				outDataLen = 0x07C1;
				*outBufLen = 0x07C1;

				RtlCopyMemory(outBuf, &(pResp->data), *outBufLen);
			}

			// this prevent crash on pfaff dump
			// Pfaff HASP Pro FAT size is NOT 1985 size
			// in our dump FAT is 417 bytes
			// need to find size for every type HASP Basic, Pro, Max, NET, Time ????????
			// Basic key = 417 bytes confirmed
			// Pro   key = 417 bytes confirmed
			// Max, NET, Time = 1985 confirmed
			if (request->param1 == 0 && Length == 417)
			{
				pResp->status = KEY_OPERATION_STATUS_OK;
				RtlCopyMemory(&(pResp->data), &pKeyData->FuncA2[0], 417);

				outDataLen = 417;
				*outBufLen = 417;

				RtlCopyMemory(outBuf, &(pResp->data), *outBufLen);
			}

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}

	case KEY_WRITE_FEATUREMAP_REQUEST: // function used for program hasp key - emulation NOT complete
		{
			pKeyData->FeatureNumber = request->param1;
			pKeyData->FeatureIndex = (UCHAR)(request->param2 >> 8); // zero based index in feature map

			// FF CE 02 95 00 01 00 09 - in feature map
			// 09 00 02 95 00 00 01 00 BB D6 DD 18 A4 46 CC 30 CF 05 70 9C B2 67 DD 35  - data in usbtrace 8 + 16 ; 16 possible signature
			if(Length == 8 + 16)
			{
				UCHAR TransferBuffer24[8 + 16] = {0};
				UCHAR FeatureProperties[8] = {0};

				USHORT UpdateCounter08;
				USHORT UpdateCounter14;

				UpdateCounter08 =  *(USHORT*)&pKeyData->FuncA1_Val3[1];
				UpdateCounter08 = _byteswap_ushort(UpdateCounter08);
				UpdateCounter08++;
				*(USHORT*)&pKeyData->FuncA1_Val3[1] = _byteswap_ushort(UpdateCounter08);

				UpdateCounter14 = *(USHORT*)&pKeyData->FuncA1_Val2[8];
				UpdateCounter14 = _byteswap_ushort(UpdateCounter14);
				UpdateCounter14++;
				*(USHORT*)&pKeyData->FuncA1_Val2[8] = _byteswap_ushort(UpdateCounter14);

				RtlZeroMemory(TransferBuffer24, sizeof(TransferBuffer24));
				RtlZeroMemory(FeatureProperties, sizeof(FeatureProperties));

				RtlCopyMemory(&TransferBuffer24[0], outBuf, sizeof(TransferBuffer24));

				FeatureProperties[7] = TransferBuffer24[0];

				FeatureProperties[0] = LOBYTE(pKeyData->FeatureNumber);
				FeatureProperties[1] = HIBYTE(pKeyData->FeatureNumber);

				FeatureProperties[2] = TransferBuffer24[2];
				FeatureProperties[3] = TransferBuffer24[3];

				// FeatureProperties[4] = TransferBuffer24[2];
				FeatureProperties[5] = TransferBuffer24[6];

				// RtlCopyMemory(&pKeyData->FuncA2[pKeyData->FeatureIndex * 8], FeatureProperties, 8);
			}

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}
		break;
	case KEY_WRITE_FEATUREMAP_RESPONSE:
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			pResp->data[0] = 0x00;
			outDataLen = 1;
			*outBufLen = 1;
			RtlCopyMemory(outBuf, pResp->data, *outBufLen);

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}
		break;

	case KEY_DELETE_FEATURE_REQUEST: // function used for program hasp key - emulation NOT complete
		{
			USHORT UpdateCounter08;
			USHORT UpdateCounter14;

			pKeyData->FeatureNumber = request->param1;
			pKeyData->FeatureIndex = (UCHAR)(request->param2 >> 8); // zero based index in feature map


			UpdateCounter08 =  *(USHORT*)&pKeyData->FuncA1_Val3[1];
			UpdateCounter08 = _byteswap_ushort(UpdateCounter08);
			UpdateCounter08++;
			*(USHORT*)&pKeyData->FuncA1_Val3[1] = _byteswap_ushort(UpdateCounter08);

			UpdateCounter14 = *(USHORT*)&pKeyData->FuncA1_Val2[8];
			UpdateCounter14 = _byteswap_ushort(UpdateCounter14);
			UpdateCounter14++;
			*(USHORT*)&pKeyData->FuncA1_Val2[8] = _byteswap_ushort(UpdateCounter14);

			if(Length == 16)
			{
				UCHAR TransferBuffer16[16] = {0};
				UCHAR FeatureProperties[8] = {0};

				RtlCopyMemory(&TransferBuffer16[0], outBuf, sizeof(TransferBuffer16)); // possible some signature - need check

				RtlFillMemory(FeatureProperties, sizeof(FeatureProperties), 0xFF);
				// RtlCopyMemory(&pKeyData->FuncA2[pKeyData->FeatureIndex * 8], FeatureProperties, 8);
				// Store_KeyDataToRegister(pKeyData, FUNC_A2_STR, &pKeyData->FuncA2[0], sizeof(pKeyData->FuncA2));
			}

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}
		break;
	case KEY_DELETE_FEATURE_RESPONSE:
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			pResp->data[0] = 0x00;
			outDataLen = 1;
			*outBufLen = 1;
			RtlCopyMemory(outBuf, pResp->data, *outBufLen);

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}
		break;

	case KEY_WRITE_SIGN_FEATURE_REQUEST: // function used for program hasp key - emulation NOT complete
		{
			USHORT UpdateCounter08;
			USHORT UpdateCounter14;

			UpdateCounter08 =  *(USHORT*)&pKeyData->FuncA1_Val3[1];
			UpdateCounter08 = _byteswap_ushort(UpdateCounter08);
			UpdateCounter08++;
			*(USHORT*)&pKeyData->FuncA1_Val3[1] = _byteswap_ushort(UpdateCounter08);

			UpdateCounter14 = *(USHORT*)&pKeyData->FuncA1_Val2[8];
			UpdateCounter14 = _byteswap_ushort(UpdateCounter14);
			UpdateCounter14++;
			*(USHORT*)&pKeyData->FuncA1_Val2[8] = _byteswap_ushort(UpdateCounter14);

			pKeyData->FeatureNumber = request->param1;
			pKeyData->FeatureIndex = (UCHAR)(request->param2 >> 8); // zero based index in feature map

			if(Length > 8 + 16)
			{
				UCHAR TransferBuffer164[164] = {0};
				USHORT WriteOffset;
				USHORT WriteLength;

				RtlZeroMemory(TransferBuffer164, sizeof(TransferBuffer164));
				RtlCopyMemory(&TransferBuffer164[0], outBuf, min(sizeof(TransferBuffer164), Length));

				WriteOffset = ((UCHAR)TransferBuffer164[2] | (UCHAR)TransferBuffer164[1]  << 8) * 16;
				WriteLength = (UCHAR)TransferBuffer164[4];

				PrintBufferContent512(L"08: ", TransferBuffer164, 8);
				PrintBufferContent512(L"16: ", &TransferBuffer164[8], 16);
				PrintBufferContent512(L"DD: ", &TransferBuffer164[8 + 16], WriteLength);

				if(pKeyData->FeatureNumber == 0xF5FF)
				{
					if(8 + 16 + WriteLength == Length)
					{
						RtlCopyMemory(&pKeyData->SRM_RO_Memory[0 + WriteOffset], &TransferBuffer164[8 + 16], WriteLength);
						Store_KeyDataToRegister(SRMDATA,
							pKeyData, RO_MEM_STR, &pKeyData->SRM_RO_Memory[0], F5FFSIZE);
					}
				}

				if(pKeyData->FeatureNumber == 0xF4FF)
				{
					if(8 + 16 + WriteLength == Length)
					{
						RtlCopyMemory(&pKeyData->SRM_RW_Memory[0 + WriteOffset], &TransferBuffer164[8 + 16], WriteLength);
						Store_KeyDataToRegister(SRMDATA,
							pKeyData, RW_MEM_STR, &pKeyData->SRM_RW_Memory[0], F4FFSIZE);
					}
				}
			}

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}
		break;
	case KEY_WRITE_SIGN_FEATURE_RESPONSE:
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			pResp->data[0] = 0x00;
			outDataLen = 1;
			*outBufLen = 1;
			RtlCopyMemory(outBuf, pResp->data, *outBufLen);

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}
		break;

	case KEY_READ_REQUEST:
		{
			UCHAR TransferBuffer16[16] = {0};
			UCHAR Plain16[16] = {0};

			pKeyData->FeatureNumber = request->param1;
			pKeyData->FeatureIndex = (UCHAR)(request->param2 >> 8); // zero based index in feature map
			pKeyData->EncryptFlag  = (UCHAR)(request->param2 & 0xFF) == 0x80 ? 1 : 0; // 80 - set encryption flag???


			RtlZeroMemory(TransferBuffer16, sizeof(TransferBuffer16));
			RtlCopyMemory(&TransferBuffer16[0], outBuf, 3);

			pKeyData->ReadOffset = ((UCHAR)TransferBuffer16[2] | (UCHAR)TransferBuffer16[1]  << 8) * 16;

			PrintBufferContent512(L"TransferBuffer IN:\n", TransferBuffer16, sizeof(TransferBuffer16));

			DPRINT("FeatureNumber = 0x%X;  FeatureIndex = 0x%X; EncryptFlag = 0x%X; ReadOffset = 0x%X;\n",
				pKeyData->FeatureNumber,
				pKeyData->FeatureIndex,
				pKeyData->EncryptFlag,
				pKeyData->ReadOffset
				);

			if(Length == 16) // or EncryptFlag
			{
				RtlCopyMemory(&TransferBuffer16[0], outBuf, 16);
				RtlCopyMemory(&pKeyData->XorValue[0], &TransferBuffer16[12], 3);

				PrintBufferContent512(L"TransferBuffer IN 2:\n", TransferBuffer16, sizeof(TransferBuffer16));

				pKeyData->CM = (pKeyData->XorValue[0] << 16) | (pKeyData->XorValue[1] << 8) | (pKeyData->XorValue[2] );

				// little optimised!!!!
				RtlZeroMemory(&Plain16[0], sizeof(Plain16));
				RtlCopyMemory(&Plain16[0], &TransferBuffer16[8], 4);

				if((pKeyData->FeatureNumber != HASP_FILEID_RW) &&
					(pKeyData->FeatureNumber != HASP_FILEID_RO))
				{
					// __asm {int 0x03};

					if(TransferBuffer16[15] == 0x02) // NewAlgo for 6.56
					{
						DPRINT("NewAlgo from 6.56\n");
						pKeyData->NewAlgo = TRUE;
						Encrypt(pKeyData->plugAES_new_656, Plain16, pKeyData->WorkAesKEY, 16);
					}
					else if(TransferBuffer16[15] == 0x01) // NewAlgo 3.25
					{
						DPRINT("NewAlgo 3.25\n");
						pKeyData->NewAlgo = TRUE;
						Encrypt(pKeyData->plugAES_new, Plain16, pKeyData->WorkAesKEY, 16);
					}
					else
					{
						pKeyData->NewAlgo = FALSE;
						Encrypt(pKeyData->plugAES, Plain16, pKeyData->WorkAesKEY, 16);
					}
				}
				else
				{
					if(TransferBuffer16[15] == 1) // NewAlgo for RW RO
					{
						DPRINT("WARNING!!! WBAES in KEY_READ_REQUEST\n");
					}

					Encrypt(pKeyData->VendorAES, Plain16, pKeyData->WorkAesKEY, 16);

					Plain16[4] = pKeyData->FuncA1_Val3[0];
					Plain16[5] = pKeyData->FuncA1_Val3[1];
					Plain16[6] = pKeyData->FuncA1_Val3[2];
					Encrypt(pKeyData->VendorAES, Plain16, pKeyData->WriteAesKEY, 16);
				}
			}

			pKeyData->FeatureNumber = request->param1; // Gets address for data

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}

	case KEY_READ_RESPONSE:
		{
			int i;
			ULONG ReadLength = 0;
			ReadLength = Length - 1;

			RtlZeroMemory(pKeyData->Temp, sizeof(pKeyData->Temp));

			DPRINT("FeatureNumber = 0x%X;  FeatureIndex = 0x%X; EncryptFlag = 0x%X; ReadOffset = 0x%X; ReadLength = 0x%X;\n",
				pKeyData->FeatureNumber,
				pKeyData->FeatureIndex,
				pKeyData->EncryptFlag,
				pKeyData->ReadOffset,
				ReadLength);

			switch(pKeyData->FeatureNumber)
			{
			case 0xF4FF:
				RtlCopyMemory(pKeyData->Temp, &pKeyData->SRM_RW_Memory[0 + pKeyData->ReadOffset], ReadLength);
				outDataLen = F4FFSIZE + 1; // <------ wrong - for reading AKS driver is set max 1024+1 bytes buffer
				break;
			case 0xF5FF:
				RtlCopyMemory(pKeyData->Temp, &pKeyData->SRM_RO_Memory[0 + pKeyData->ReadOffset], ReadLength);
				outDataLen = F5FFSIZE + 1; // <------ wrong - for reading AKS driver is set max 1024+1 bytes buffer
				break;
			default:
				{
					USHORT i = 0;
					USHORT SlotNum = 0;

					for(i = 0; i < SRMFEATURESCOUNT; i++)
					{
						if(pKeyData->FeatureNumber == pKeyData->Feature[i].Number)
						{
							SlotNum = i;
							DPRINT("Found match in Feature data structure at slot: %08X (%d)\n", SlotNum, SlotNum);
							break;
						}
					}

					DPRINT("SlotNum: %08X SlotNumF: %08X FeatureNumber: %04X, FeatureIndex: %04X FeatureSize: %04X\n",
						SlotNum,
						pKeyData->Feature[SlotNum].Slot,
						pKeyData->Feature[SlotNum].Number,
						pKeyData->Feature[SlotNum].Index,
						pKeyData->Feature[SlotNum].Size);

					RtlCopyMemory(pKeyData->Temp, pKeyData->Feature[SlotNum].Data, min(ReadLength, pKeyData->Feature[SlotNum].Size));
					outDataLen = ReadLength + 1;
				}
				break;
			}

			for(i = 0; i < 3; i++)
				pKeyData->Temp[i] ^= pKeyData->XorValue[i];

			pKeyData->CM++;
			pKeyData->XorValue[0] = (UCHAR)(pKeyData->CM >> 16) & 0xFF;
			pKeyData->XorValue[1] = (UCHAR)(pKeyData->CM >> 8) & 0xFF;
			pKeyData->XorValue[2] = (UCHAR)pKeyData->CM & 0xFF;

			switch(pKeyData->FeatureNumber)
			{
			case 0xF4FF:
			case 0xF5FF:
				Encrypt(pKeyData->WorkAesKEY, pKeyData->Temp, pKeyData->Temp, ReadLength);
				break;
			default:
				DPRINT("%ws\n", pKeyData->NewAlgo ? L"NewAlgo == TRUE, Encrypt_325\n" : L"NewAlgo == FALSE, Encrypt\n");

				if(pKeyData->NewAlgo == FALSE)
					Encrypt(pKeyData->WorkAesKEY, pKeyData->Temp, pKeyData->Temp, ReadLength);
				else // does a aes_setkey_enc(&ctx, AESKey, 128) and then a aes_crypt_ecb(&ctx, AES_ENCRYPT, In+Counter, Out+Counter) for each 16 bytes
					Encrypt_325(pKeyData->WorkAesKEY, pKeyData->Temp, pKeyData->Temp, ReadLength);
				break;
			}

			RtlCopyMemory(&(pResp->data), pKeyData->Temp, ReadLength);

			// For miguel -> Attention !!!! See changes below !
			*outBufLen = min(outDataLen, Length); // <--- Attention ! New code !

			// ????????? wtf ?????????
			pKeyData->ReadOffset = 0000;

			RtlCopyMemory(outBuf, &(pResp->data), *outBufLen);

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}

		// not 100% tested, hovewer currently pass C2V creation - only function we know 28-A8 is used
		// also dumpers use this command to read features

	case KEY_FN_SIGNED_READ_REQUEST: // = 0x28,
		{
			UCHAR TransferBuffer16[16] = {0};

			pKeyData->FeatureNumber = request->param1;
			pKeyData->FeatureIndex = (UCHAR)(request->param2 >> 8); // zero based index in feature map
			pKeyData->EncryptFlag  = (UCHAR)(request->param2 & 0xFF) == 0x80 ? 1 : 0; // 80 - set encryption flag???

			RtlZeroMemory(TransferBuffer16, sizeof(TransferBuffer16));

			if(Length == 4)
			{
				RtlCopyMemory(TransferBuffer16, outBuf, 4);
				DPRINT("%02X%02X%02X%02X",
					TransferBuffer16[0], TransferBuffer16[1], TransferBuffer16[2], TransferBuffer16[3]);

				pKeyData->ReadOffset = ((UCHAR)TransferBuffer16[2] | (UCHAR)TransferBuffer16[1]  << 8) * 16;
			}

			PrintBufferContent512(L"TransferBuffer IN:\n", TransferBuffer16, sizeof(TransferBuffer16));

			DPRINT("FeatureNumber = 0x%X;  FeatureIndex = 0x%X; EncryptFlag = 0x%X; ReadOffset = 0x%X;\n",
				pKeyData->FeatureNumber,
				pKeyData->FeatureIndex,
				pKeyData->EncryptFlag,
				pKeyData->ReadOffset
				);

			pResp->status = KEY_OPERATION_STATUS_OK;

			outDataLen = 0;
			*outBufLen = 0;

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}

		// not 100% tested
	case KEY_FN_SIGNED_READ_RESPONSE: // = 0xA8,
		{
			ULONG ReadLength = 0;
			UCHAR FeatureProperties1[8] = {0};

			ReadLength = Length - 8 - 16 - 1;

			DPRINT("ReadOffset = 0x%X [%d], ReadLength = 0x%X [%d]",
				pKeyData->ReadOffset, pKeyData->ReadOffset, ReadLength, ReadLength);

			RtlZeroMemory(pKeyData->Temp, sizeof(pKeyData->Temp));

			// get feature properties from featuremap (A2)
			RtlCopyMemory(FeatureProperties1, &pKeyData->FuncA2[8 * pKeyData->FeatureIndex], 8);

			switch(pKeyData->FeatureNumber)
			{
			case 0xF4FF:
				{
					RtlCopyMemory(pKeyData->Temp, &pKeyData->SRM_RW_Memory[0 + pKeyData->ReadOffset], ReadLength);
					// RtlZeroMemory(pKeyData->Temp, sizeof(pKeyData->Temp));
					(pResp->data[2]) = (UCHAR)FeatureProperties1[5];
					(pResp->data[1]) = (UCHAR)FeatureProperties1[4];
					// outDataLen = ((UCHAR)FeatureProperties[5] << 4);
				}
				break;
			case 0xF5FF:
				{
					RtlCopyMemory(pKeyData->Temp, &pKeyData->SRM_RO_Memory[0 + pKeyData->ReadOffset], ReadLength);
					// RtlZeroMemory(pKeyData->Temp, sizeof(pKeyData->Temp));
					(pResp->data[2]) = (UCHAR)FeatureProperties1[5];
					(pResp->data[1]) = (UCHAR)FeatureProperties1[4];
					// outDataLen = ((UCHAR)FeatureProperties[5] << 4);
				}
				break;

			default: // generic
				{
					USHORT i = 0;
					USHORT SlotNum = 0;

					for(i = 0; i < SRMFEATURESCOUNT; i++)
					{
						if(pKeyData->FeatureNumber == pKeyData->Feature[i].Number)
						{
							SlotNum = i;
							DPRINT("Found match in Feature data structure at slot: %08X (%d)\n", SlotNum, SlotNum);
							break;
						}
					}

					DPRINT("SlotNum: %08X SlotNumF: %08X FeatureNumber: %04X, FeatureIndex: %04X FeatureSize: %04X\n",
						SlotNum,
						pKeyData->Feature[SlotNum].Slot,
						pKeyData->Feature[SlotNum].Number,
						pKeyData->Feature[SlotNum].Index,
						pKeyData->Feature[SlotNum].Size);

					RtlCopyMemory(pKeyData->Temp, pKeyData->Feature[SlotNum].Data, min(ReadLength, pKeyData->Feature[SlotNum].Size));
					(pResp->data[2]) = (UCHAR)FeatureProperties1[5];
				}
				break;
			}

			RtlCopyMemory(&(pResp->data[8]), pKeyData->Temp, ReadLength);

			pResp->data[Length] = 0xFF; // set to good answer - bypass Create C2V function

			// *outBufLen = min(outDataLen, Length);
			*outBufLen = Length;

			RtlCopyMemory(outBuf, &(pResp->data), *outBufLen);

			pResp->status = KEY_OPERATION_STATUS_OK;

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			pKeyData->ReadOffset = 0;

			return;
		}

	case KEY_WRITE_REQUEST:
		{
			int i = 0;
			UCHAR Plain16[16] = {0};

			UCHAR TransferBuffer16[16] = {0};

			pKeyData->FeatureNumber = request->param1;
			pKeyData->FeatureIndex = (UCHAR)(request->param2 >> 8); // zero based index in feature map
			pKeyData->EncryptFlag  = (UCHAR)(request->param2 & 0xFF) == 0x80 ? 1 : 0; // 80 - set encryption flag???


			RtlCopyMemory(TransferBuffer16, outBuf, min(Length, sizeof(TransferBuffer16)));

			PrintBufferContent512(L"TransferBuffer IN:\n", TransferBuffer16, sizeof(TransferBuffer16));
			DPRINT("FeatureNumber = 0x%X; FeatureIndex = 0x%X; EncryptFlag = 0x%X;\n",
				pKeyData->FeatureNumber,
				pKeyData->FeatureIndex,
				pKeyData->EncryptFlag);

			if(pKeyData->FeatureNumber == 0xF4FF) // pKeyData->LastFeature // Only for RW_Mem (Feature 0xF4FF)
			{
				RtlZeroMemory(pKeyData->Temp, sizeof(pKeyData->Temp));

				// TransferBuffer
				RtlCopyMemory(pKeyData->Temp, outBuf, Length);

				pKeyData->WriteOffset = ((UCHAR)pKeyData->Temp[2] | (UCHAR)pKeyData->Temp[1]  << 8) * 16;

				if((Length % 16) == 0)
				{
					RtlCopyMemory(&pKeyData->XorValue[0], &pKeyData->Temp[12], 3);
					pKeyData->CM = (pKeyData->XorValue[0] << 16) | (pKeyData->XorValue[1] << 8) | (pKeyData->XorValue[2] );

					RtlZeroMemory(&Plain16[0], 16);
					RtlCopyMemory(&Plain16[0], &pKeyData->Temp[8], 4);

					Encrypt(pKeyData->VendorAES, Plain16, pKeyData->WorkAesKEY, 16);

					Plain16[4] = pKeyData->FuncA1_Val3[0];
					Plain16[5] = pKeyData->FuncA1_Val3[1];
					Plain16[6] = pKeyData->FuncA1_Val3[2];
					Encrypt(pKeyData->VendorAES, Plain16, pKeyData->WriteAesKEY, 16);

					pKeyData->WriteLength = Length - 16;
					Decrypt(pKeyData->WriteAesKEY, &pKeyData->Temp[16], pKeyData->Temp, pKeyData->WriteLength);
				}
				else
				{
					pKeyData->WriteLength = Length - 8;
					Decrypt(pKeyData->WriteAesKEY, &pKeyData->Temp[8], pKeyData->Temp, pKeyData->WriteLength);
				}

				DPRINT("WriteOffset = 0x%X (%d), WriteLength = %d\n", pKeyData->WriteOffset, pKeyData->WriteOffset, pKeyData->WriteLength);

				for(i = 0; i < 3; i++)
					pKeyData->Temp[i] ^= pKeyData->XorValue[i];

				pKeyData->CM++;
				pKeyData->XorValue[0] = (UCHAR)(pKeyData->CM >> 16) & 0xFF;
				pKeyData->XorValue[1] = (UCHAR)(pKeyData->CM >> 8) & 0xFF;
				pKeyData->XorValue[2] = (UCHAR)pKeyData->CM & 0xFF;

				RtlCopyMemory(&pKeyData->SRM_RW_Memory[0 + pKeyData->WriteOffset], pKeyData->Temp, pKeyData->WriteLength);

				if (!Store_KeyDataToRegister(SRMDATA,
					pKeyData, RW_MEM_STR, &pKeyData->SRM_RW_Memory[0], F4FFSIZE))
					pResp->status = KEY_OPERATION_STATUS_OK;
				else
					pResp->status = KEY_OPERATION_STATUS_ERROR;

				*outBufLen = 0;
			}

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}

	case KEY_WRITE_RESPONSE:
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			pResp->data[0] = 0x00;
			outDataLen = 1;
			*outBufLen = 1;
			RtlCopyMemory(outBuf, pResp->data, *outBufLen);

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}

	case KEY_FN_AES_IN:
		{
			NTSTATUS status1;

			int Length = *outBufLen;
			int Counter;

			int Offset = 8;

			UCHAR TransferBuffer64[64] = {0}; // AES_IN request buffer AKS hasp is max 64 bytes

			UCHAR k;

			ULONG actualSize = 0;

			ULONG internalAES = FALSE;
			ULONG SrmTableType = 0;

			UCHAR A_Adbg[48] = {0};

			pKeyData->FeatureNumber = request->param1;
			pKeyData->FeatureIndex = (UCHAR)(request->param2 >> 8); // zero based index in feature map
			pKeyData->EncryptFlag  = (UCHAR)(request->param2 & 0xFF) == 0x80 ? 1 : 0; // 80 - set encryption flag???

			DPRINT("FeatureNumber = 0x%X; FeatureIndex = 0x%X; EncryptFlag = 0x%X;\n",
				pKeyData->FeatureNumber, pKeyData->FeatureIndex, pKeyData->EncryptFlag);

			RtlZeroMemory(TransferBuffer64, sizeof(TransferBuffer64));
			///////////////////////////////////////////
			RtlCopyMemory(TransferBuffer64, outBuf, min(Length, sizeof(TransferBuffer64)));

			pKeyData->EncDecMode = (UCHAR)TransferBuffer64[0];
			pKeyData->Delta      = (UCHAR)TransferBuffer64[1]; // delta is different of query 16 to 32 length - for example query 20 bytes have delta 4 = 16 + 4

			DPRINT("EncDecMode = %02X Delta = %02X\n",pKeyData->EncDecMode, pKeyData->Delta);

			RtlZeroMemory(Q_Q, sizeof(Q_Q));
			RtlZeroMemory(A_A, sizeof(A_A));

			internalAES = FALSE;
			Offset = 8;

			if((Length == 32) || (Length == 48) || (Length == 64)) // lenght = 64 is used when many/intensive request to driver - actually to set new WorkAesKEY
			{
				UCHAR Plain16[16] = {0};

				if(TransferBuffer64[15] == 1) // NewAlgo for AES_IN
				{
					DPRINT("WARNING!!! WBAES in KEY_FN_AES_IN\n");
				}

				Offset = 16;

				RtlCopyMemory(&pKeyData->XorValue[0], &TransferBuffer64[12], 3);
				pKeyData->CM = (pKeyData->XorValue[0] << 16) | (pKeyData->XorValue[1] << 8) | (pKeyData->XorValue[2] );

				RtlZeroMemory(Plain16, 16);
				RtlCopyMemory(Plain16, &TransferBuffer64[8], 4);
				Encrypt(pKeyData->VendorAES, Plain16, pKeyData->WorkAesKEY, 16);

				// new writeaesKey
				Plain16[4] = pKeyData->FuncA1_Val3[0];
				Plain16[5] = pKeyData->FuncA1_Val3[1];
				Plain16[6] = pKeyData->FuncA1_Val3[2];
				Encrypt(pKeyData->VendorAES, Plain16, pKeyData->WriteAesKEY, 16);
			}

			// START HERE decrypt aes request - max length is 48 -> Length - Offset = buffer lenght to decrypt
			Decrypt(pKeyData->WorkAesKEY, &TransferBuffer64[Offset], Q_Q, min(sizeof(Q_Q), Length - Offset));

			for(Counter = 0; Counter < 3; ++Counter)
				Q_Q[Counter] ^= pKeyData->XorValue[Counter];

			pKeyData->CM++;
			pKeyData->XorValue[0] = (UCHAR)(pKeyData->CM >> 16) & 0xFF;
			pKeyData->XorValue[1] = (UCHAR)(pKeyData->CM >> 8) & 0xFF;
			pKeyData->XorValue[2] = (UCHAR)pKeyData->CM & 0xFF;
			// END HERE decrypt request

			// here fully decrypted request buffer
			// Q_Q
			RtlZeroMemory(KeyName96, sizeof(KeyName96));

			// get feature real aes keys - if known
			RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
				REG_SRM_FEATURE_AESKEY_STR,
				pKeyData->FeatureNumber,
				0x01);
			GetExtraRegKeyData(SRMTABLE, pKeyData->password, KeyName96, FeatAesKey_01, 16, &actualSize);
			GetExtraRegKeyData(SRMTABLE, pKeyData->password, KeyName96, FeatAesKey_01_01, 16, &actualSize);

			RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
				REG_SRM_FEATURE_AESKEY_STR,
				pKeyData->FeatureNumber,
				0x02);
			GetExtraRegKeyData(SRMTABLE, pKeyData->password, KeyName96, FeatAesKey_02, 16, &actualSize);

			RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
				REG_SRM_FEATURE_AESKEY_STR,
				pKeyData->FeatureNumber,
				0x03);
			GetExtraRegKeyData(SRMTABLE, pKeyData->password, KeyName96, FeatAesKey_03, 16, &actualSize);

			RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
				REG_SRM_FEATURE_AESKEY_STR,
				pKeyData->FeatureNumber,
				0x04);
			GetExtraRegKeyData(SRMTABLE, pKeyData->password, KeyName96, FeatAesKey_04, 16, &actualSize);

			RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
				REG_SRM_FEATURE_AESKEY_STR,
				pKeyData->FeatureNumber,
				0x05);
			GetExtraRegKeyData(SRMTABLE, pKeyData->password, KeyName96, FeatAesKey_05, 16, &actualSize);

			RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
				REG_SRM_FEATURE_AESKEY_STR,
				pKeyData->FeatureNumber,
				0x06);
			GetExtraRegKeyData(SRMTABLE, pKeyData->password, KeyName96, FeatAesKey_06, 16, &actualSize);
			GetExtraRegKeyData(SRMTABLE, pKeyData->password, KeyName96, FeatAesKey_06_01, 16, &actualSize);

			PrintBufferContent512(L"FAES_01: ", FeatAesKey_01, sizeof(FeatAesKey_01));
			PrintBufferContent512(L"FAES_02: ", FeatAesKey_02, sizeof(FeatAesKey_02));
			PrintBufferContent512(L"FAES_03: ", FeatAesKey_03, sizeof(FeatAesKey_03));
			PrintBufferContent512(L"FAES_04: ", FeatAesKey_04, sizeof(FeatAesKey_04));
			PrintBufferContent512(L"FAES_05: ", FeatAesKey_05, sizeof(FeatAesKey_05));
			PrintBufferContent512(L"FAES_06: ", FeatAesKey_06, sizeof(FeatAesKey_06));

			RtlZeroMemory(KeyName96, sizeof(KeyName96));

			// SrmTableType = pKeyData->SrmTableType;
			if(pKeyData->ds.isEncryptedRegistry == CRYPTREGISTRYMD5)
				SrmTableType = SRMTABLEMD5;
			else
				SrmTableType = SRMTABLE;

			switch(pKeyData->EncDecMode)
			{
			case 0: // Encrypt 16
			case 1: // Decrypt 16
				{
					// set registry path
					RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
						REG_SRM_AES_16_REQUEST_STR,
						pKeyData->EncDecMode,
						pKeyData->FeatureNumber, // feature slot
						Q_Q[0], Q_Q[1], Q_Q[2], Q_Q[3], Q_Q[4], Q_Q[5], Q_Q[6], Q_Q[7],
						Q_Q[8], Q_Q[9], Q_Q[10], Q_Q[11], Q_Q[12], Q_Q[13], Q_Q[14], Q_Q[15]);

					status1 = GetExtraRegKeyData(SrmTableType, pKeyData->password, KeyName96, A_A, 16, &actualSize);
					if(!NT_SUCCESS(status1))
					{
						internalAES = TRUE;
						if(pKeyData->EncDecMode == 0) // encrypt
							Encrypt(FeatAesKey_01, Q_Q, A_A, 16);

						if(pKeyData->EncDecMode == 1) // decrypt
							Decrypt(FeatAesKey_01, Q_Q, A_A, 16);
					}
					else
					{
						// data from registry decryption
						if(pKeyData->ds.isEncryptedRegistry != PLAINREGISTRY)
							Decrypt(dataAESkey, A_A, A_A, 16);
					}

					RtlCopyMemory(A_Adbg, A_A, 48);

					// set output crypted
					for(Counter = 0; Counter < 16; ++Counter)
						A_A[Counter] ^= TransferBuffer64[Offset + Counter];

					Encrypt(pKeyData->WorkAesKEY, A_A, A_A, 16);

					break;
				}

			case 2: // "Encrypt 32+ bytes");
				{
					// set registry path
					RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
						REG_SRM_AES_32_REQUEST_STR,
						pKeyData->EncDecMode,
						pKeyData->FeatureNumber, // feature slot
						Q_Q[0], Q_Q[1], Q_Q[2], Q_Q[3],	Q_Q[4], Q_Q[5], Q_Q[6], Q_Q[7],	Q_Q[8], Q_Q[9], Q_Q[10], Q_Q[11], Q_Q[12], Q_Q[13], Q_Q[14], Q_Q[15],
						Q_Q[16], Q_Q[17], Q_Q[18], Q_Q[19], Q_Q[20], Q_Q[21], Q_Q[22], Q_Q[23],	Q_Q[24], Q_Q[25], Q_Q[26], Q_Q[27],	Q_Q[28], Q_Q[29], Q_Q[30], Q_Q[31]);

					status1 = GetExtraRegKeyData(SrmTableType, pKeyData->password, KeyName96, A_A, 16, &actualSize);
					if(!NT_SUCCESS(status1))
					{
						internalAES = TRUE;

						Encrypt(FeatAesKey_02, Q_Q, A_A, 16);
						Encrypt(FeatAesKey_03, Q_Q + 16, A_A + 16, 16);

						for(k = 0; k < 16; k++)
						{
							A_A[k] ^= A_A[k+16];
						}
						memset(A_A + 16, 0, 32);
					}
					else
					{
						// data from registry decryption
						if(pKeyData->ds.isEncryptedRegistry != PLAINREGISTRY)
							Decrypt(dataAESkey, A_A, A_A, 16);
					}

					RtlCopyMemory(A_Adbg, A_A, 48);
					// set output crypted
					for(Counter = 0; Counter < 16; ++Counter)
						A_A[Counter] ^= TransferBuffer64[Offset + Counter + 16];

					Encrypt(pKeyData->WorkAesKEY, A_A, A_A, 16);

					break;
				}

			case 3: // "Decrypt 32+ bytes"
				{
					// set registry path
					RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
						REG_SRM_AES_32_REQUEST_STR,
						pKeyData->EncDecMode,
						pKeyData->FeatureNumber, // feature slot
						Q_Q[0], Q_Q[1], Q_Q[2], Q_Q[3],	Q_Q[4], Q_Q[5], Q_Q[6], Q_Q[7],	Q_Q[8], Q_Q[9], Q_Q[10], Q_Q[11], Q_Q[12], Q_Q[13], Q_Q[14], Q_Q[15],
						Q_Q[16], Q_Q[17], Q_Q[18], Q_Q[19], Q_Q[20], Q_Q[21], Q_Q[22], Q_Q[23],	Q_Q[24], Q_Q[25], Q_Q[26], Q_Q[27],	Q_Q[28], Q_Q[29], Q_Q[30], Q_Q[31]);

					status1 = GetExtraRegKeyData(SrmTableType, pKeyData->password, KeyName96, A_A, 32, &actualSize);
					if(!NT_SUCCESS(status1))
					{
						internalAES = TRUE;

						Decrypt(FeatAesKey_05, Q_Q, A_A, 16);
						Encrypt(FeatAesKey_04, Q_Q + 16, A_A + 16, 16); // yes encrypt!!!

						for(k = 0; k < 16; k++)
						{
							A_A[k] ^= A_A[k+16];
						}
						memset(A_A + 16, 0, 32);
					}
					else
					{
						// data from registry decryption
						if(pKeyData->ds.isEncryptedRegistry != PLAINREGISTRY)
							Decrypt(dataAESkey, A_A, A_A, 16);
					}

					RtlCopyMemory(A_Adbg, A_A, 48);
					// set output crypted
					for(Counter = 0; Counter < 16; ++Counter)
						A_A[Counter] ^= TransferBuffer64[Offset + Counter + 16];

					Encrypt(pKeyData->WorkAesKEY, A_A, A_A, 16);
					RtlCopyMemory(A_A + 16, A_A + 8, 8);
					RtlCopyMemory(A_A + 24, A_A + 8, 8);

					break;
				}

			case 4: // "Encrypt 48(32+) bytes"
			case 5: // "Decrypt 48(32+) bytes"
				{
					// set registry path
					RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
						REG_SRM_AES_32_REQUEST_STR,
						pKeyData->EncDecMode,
						pKeyData->FeatureNumber, // feature slot
						Q_Q[0], Q_Q[1], Q_Q[2], Q_Q[3],	Q_Q[4], Q_Q[5], Q_Q[6], Q_Q[7],	Q_Q[8], Q_Q[9], Q_Q[10], Q_Q[11], Q_Q[12], Q_Q[13], Q_Q[14], Q_Q[15],
						Q_Q[16], Q_Q[17], Q_Q[18], Q_Q[19], Q_Q[20], Q_Q[21], Q_Q[22], Q_Q[23],	Q_Q[24], Q_Q[25], Q_Q[26], Q_Q[27],	Q_Q[28], Q_Q[29], Q_Q[30], Q_Q[31]);

					status1 = GetExtraRegKeyData(SrmTableType, pKeyData->password, KeyName96, A_A, 48, &actualSize);
					if(!NT_SUCCESS(status1))
					{
						internalAES = TRUE;

						RtlCopyMemory(A_A, Q_Q, 48);

						if(pKeyData->EncDecMode == 4) // encrypt
						{
							Encrypt(FeatAesKey_02, Q_Q, A_A, 16);
							Encrypt(FeatAesKey_03, Q_Q + 16, A_A + 16, 16);
							Encrypt(FeatAesKey_04, Q_Q + 32, A_A + 32, 16);

							for(k = 0; k < 16; k++)
							{
								A_A[k] ^= A_A[k+16];
								A_A[k] ^= A_A[k+32];
							}

							Encrypt(FeatAesKey_05, A_A, A_A, 16);

							memset(A_A + 16, 0, 32);
						}

						if(pKeyData->EncDecMode == 5) // decrypt
						{
							Decrypt(FeatAesKey_05, Q_Q, A_A, 16);
							Encrypt(FeatAesKey_04, Q_Q + 16, A_A + 16, 16); // yes encrypt!!!
							Encrypt(FeatAesKey_03, Q_Q + 32, A_A + 32, 16); // yes encrypt!!!

							for(k = 0; k < 16; k++)
							{
								A_A[k] ^= A_A[k+16];
								A_A[k] ^= A_A[k+32];
							}

							Decrypt(FeatAesKey_02, A_A, A_A, 16);

							memset(A_A + 16, 0, 32);
						}
					}
					else
					{
						// data from registry decryption
						if(pKeyData->ds.isEncryptedRegistry != PLAINREGISTRY)
							Decrypt(dataAESkey, A_A, A_A, 16);
					}

					RtlCopyMemory(A_Adbg, A_A, 48);
					// set output crypted
					for(Counter = 0; Counter < 16; ++Counter)
						A_A[Counter] ^= TransferBuffer64[Offset + Counter + 32];

					Encrypt(pKeyData->WorkAesKEY, A_A, A_A, 16);

					RtlCopyMemory(A_A + 16, A_A + 8, 8);
					RtlCopyMemory(A_A + 24, A_A + 8, 8);
					RtlCopyMemory(A_A + 32, A_A + 8, 8);
					RtlCopyMemory(A_A + 40, A_A + 8, 8);

					break;
				}

			case 0x0A:
			case 0x0B:
				{
					// set registry path
					RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
						REG_SRM_AES_16_REQUEST_STR,
						pKeyData->EncDecMode,
						pKeyData->FeatureNumber, // feature slot
						Q_Q[0], Q_Q[1], Q_Q[2], Q_Q[3], Q_Q[4], Q_Q[5], Q_Q[6], Q_Q[7],
						Q_Q[8], Q_Q[9], Q_Q[10], Q_Q[11], Q_Q[12], Q_Q[13], Q_Q[14], Q_Q[15]);

					status1 = GetExtraRegKeyData(SrmTableType, pKeyData->password, KeyName96, A_A, 32, &actualSize);
					if(!NT_SUCCESS(status1))
					{
						internalAES = TRUE;

						if(pKeyData->EncDecMode == 0x0A) // encrypt
						{
							Encrypt(FeatAesKey_06_01, Q_Q, A_A, 16);
							Encrypt(FeatAesKey_06_01, A_A, A_A + 16, 16);
						}

						if(pKeyData->EncDecMode == 0x0B) // decrypt
						{
							Decrypt(FeatAesKey_06_01, Q_Q, A_A, 16);
							Decrypt(FeatAesKey_06_01, A_A, A_A + 16, 16);
						}
					}
					else
					{
						// data from registry decryption
						if(pKeyData->ds.isEncryptedRegistry != PLAINREGISTRY)
						{
							Decrypt(dataAESkey, A_A, A_A, 16);
							Decrypt(dataAESkey, A_A + 16, A_A + 16, 16);
						}
					}

					RtlCopyMemory(A_Adbg, A_A, 48);
					// set output crypted
					for(Counter = 0; Counter < 16; ++Counter)
						A_A[Counter] ^= TransferBuffer64[Offset + Counter];

					Encrypt(pKeyData->WorkAesKEY, A_A, A_A, 32);

					break;
				}

			case 6: // "Encrypt 32 bytes"
			case 7: // "Decrypt 32 bytes"
			case 8: // "Encrypt 20 bytes"
			case 9: // "Decrypt 20 bytes"
				{
					// set registry path
					RtlStringCbPrintfExW(KeyName96, 96 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
						REG_SRM_AES_32_REQUEST_STR,
						pKeyData->EncDecMode,
						pKeyData->FeatureNumber, // feature slot
						Q_Q[0], Q_Q[1], Q_Q[2], Q_Q[3],	Q_Q[4], Q_Q[5], Q_Q[6], Q_Q[7],Q_Q[8], Q_Q[9], Q_Q[10], Q_Q[11], Q_Q[12], Q_Q[13], Q_Q[14], Q_Q[15],
						Q_Q[16], Q_Q[17], Q_Q[18], Q_Q[19], Q_Q[20], Q_Q[21], Q_Q[22], Q_Q[23],Q_Q[24], Q_Q[25], Q_Q[26], Q_Q[27],	Q_Q[28], Q_Q[29], Q_Q[30], Q_Q[31]);

					status1 = GetExtraRegKeyData(SrmTableType, pKeyData->password, KeyName96, A_A, 32, &actualSize);
					if(!NT_SUCCESS(status1))
					{
						UCHAR Q_Qtmp[48] = {0};
						internalAES = TRUE;

						RtlCopyMemory(A_A, Q_Q, 32);
						RtlCopyMemory(Q_Qtmp, Q_Q, 48);

						if((pKeyData->EncDecMode == 6) || (pKeyData->EncDecMode == 8))// encrypt
						{
							if(pKeyData->Delta == 0)
							{
								Encrypt(FeatAesKey_01, Q_Qtmp, A_A, 16);
								Encrypt(FeatAesKey_01, Q_Qtmp + 16, A_A + 16, 16);
							}
							else
							{
								Encrypt(FeatAesKey_01, Q_Qtmp, A_A + 16, 16);

								for(k = 0; k < 16; k++)
								{
									Q_Qtmp[k + 16] ^= A_A[k + 16];
								}

								Encrypt(FeatAesKey_01, Q_Qtmp + 16, A_A, 16);
							}
						}

						if((pKeyData->EncDecMode == 7) || (pKeyData->EncDecMode == 9))// decrypt
						{
							if(pKeyData->Delta == 0)
							{
								Decrypt(FeatAesKey_01, Q_Qtmp, A_A, 16);
								Decrypt(FeatAesKey_01, Q_Qtmp + 16, A_A + 16, 16);
							}
							else
							{
								Decrypt(FeatAesKey_01, Q_Qtmp, A_A, 16);

								for(k = 0; k < 16; k++)
								{
									A_A[k+16] ^= A_A[k];
								}

								for(k = 0; k < 16 - pKeyData->Delta; k++)
								{
									Q_Qtmp[k + 16 + pKeyData->Delta] = A_A[k + 16 + pKeyData->Delta];
								}

								Decrypt(FeatAesKey_01, Q_Qtmp + 16, A_A, 16);
							}
						}
					}
					else
					{
						// data from registry decryption
						if(pKeyData->ds.isEncryptedRegistry != PLAINREGISTRY)
						{
							Decrypt(dataAESkey, A_A, A_A, 16);
							Decrypt(dataAESkey, A_A + 16, A_A + 16, 16);
						}
					}

					RtlCopyMemory(A_Adbg, A_A, 48);
					// set output crypted
					for(Counter = 0; Counter < 16; ++Counter)
						A_A[Counter] ^= TransferBuffer64[Offset + Counter + 16];

					Encrypt(pKeyData->WorkAesKEY, A_A, A_A, 32);

					break;
				}

			default:

				break;
			}

			// debug output

			PrintBufferContent512(L"AES_INP: ", TransferBuffer64, min(Offset, sizeof(TransferBuffer64)));
			PrintBufferContent512(L"AES_INP: ", &TransferBuffer64[Offset], sizeof(TransferBuffer64) - 16);
			PrintBufferContent512(L"AES_OUT: ", A_A, sizeof(A_A));

#if DBG
			DPRINT("%ws [%02X]\n",
				(pKeyData->EncDecMode >= 0 && pKeyData->EncDecMode <= 0xB) ? AesEncryptionTypes[pKeyData->EncDecMode] : L"UNKNOWN\0",
				pKeyData->EncDecMode);
#endif
			DPRINT("%ws\n",
				internalAES ? L"INTERNAL AES\0" : L"REGISTRY AES\0");

			PrintBufferContent512(L"Q_Q_SRM: ", Q_Q, sizeof(Q_Q));
			PrintBufferContent512(L"A_A_SRM: ", A_Adbg, sizeof(A_Adbg));


			// debug output

			if(pResp)
			{
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);
				pResp = NULL;
			}

			return;
		}

	case KEY_FN_AES_OUT:
		{
			UCHAR AesResponse[64] = {0};
			RtlZeroMemory(AesResponse, sizeof(AesResponse));

			switch(pKeyData->EncDecMode)
			{
			case 0:
			case 1:
			case 2:
				RtlCopyMemory(AesResponse, A_A, 16);
				RtlCopyMemory(&(pResp->data), AesResponse, 17);
				outDataLen = 17;
				*outBufLen = 17;
				RtlCopyMemory(outBuf, &(pResp->data), *outBufLen);
				break;

			case 3:

			case 6:
			case 7:		
			case 8:
			case 9:

			case 0x0A:
			case 0x0B:
				RtlCopyMemory(AesResponse, A_A, 32);
				RtlCopyMemory(&(pResp->data), AesResponse, 33);
				outDataLen = 33;
				*outBufLen = 33;
				RtlCopyMemory(outBuf, &(pResp->data), *outBufLen);
				break;

			case 4:
			case 5:
				RtlCopyMemory(AesResponse, A_A, 48);
				RtlCopyMemory(&(pResp->data), AesResponse, 49);
				outDataLen = 49;
				*outBufLen = 49;
				RtlCopyMemory(outBuf, &(pResp->data), *outBufLen);
				break;
			}

			// or RtlCopyMemory(outBuf, AesResponse, min(sizeof(AesResponse), *outBufLen));

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

			return;
		}
		//------------------ SRM Functions End ------------------
#endif // SRM_EMU
	default:
		{
			DPRINT("UNKNOWN_HASP_FUNC : 0x%X\n", request->majorFnCode);

			if (pKeyData->isKeyOpened)
			{
				pResp->status = KEY_OPERATION_STATUS_OK;
			}
			// return with no deal

			*outBufLen = 0;
			break;
		}

	}

	// Return results
	LogMessage ("Create encodedStatus\n"); // Create encodedStatus
	// Randomize encodedStatus
	pKeyData->encodedStatus ^= (UCHAR)time.LowPart;

	// If status in range
	if ((pResp->status >= KEY_OPERATION_STATUS_OK) && (pResp->status <= KEY_OPERATION_STATUS_LAST))
		// Then create encoded status
		do
		{
			pResp->encodedStatus = ++pKeyData->encodedStatus;
		}
		while (CheckEncodedStatus((UCHAR)(request->majorFnCode & 0x7F), 0x02, (UCHAR *)&pResp->status) == 0);

		// Store encoded status
		status = pResp->status;
		encodedStatus = pResp->encodedStatus;

		LogMessage ("Encoded status: %02X\n", encodedStatus);
		// Crypt status & encoded status
		Chiper(&pResp->status, 2, pKeyData);

		// Crypt output data
		if (encodeOutData)
		{
			Chiper(pResp->data, outDataLen, pKeyData);
		}

		// Shuffle encoding keys + Ching
		if (status == 0)
		{
			pKeyData->chiperKey2 = (pKeyData->chiperKey2 & 0xFF) | (encodedStatus << 8);
			LogMessage ("Shuffle keys: chiperKey1=%08X, chiperKey2=%08X,\n", pKeyData->chiperKey1, pKeyData->chiperKey2);
		}

		// Set out data size
		*outBufLen = min(sizeof(USHORT) + outDataLen, *outBufLen);
		LogMessage ("Out data size: %X\n", *outBufLen);

		// Copy data into out buffer
		RtlCopyMemory(outBuf, pResp, *outBufLen);

		if(pResp)
			ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

}

#ifdef DBG

// USB function codes to description string conversion list
static WCHAR *fnCodeList[] =
{
	L"URB_FUNCTION_SELECT_CONFIGURATION",
	L"URB_FUNCTION_SELECT_INTERFACE",
	L"URB_FUNCTION_ABORT_PIPE",
	L"URB_FUNCTION_TAKE_FRAME_LENGTH_CONTROL",
	L"URB_FUNCTION_RELEASE_FRAME_LENGTH_CONTROL",
	L"URB_FUNCTION_GET_FRAME_LENGTH",
	L"URB_FUNCTION_SET_FRAME_LENGTH",
	L"URB_FUNCTION_GET_CURRENT_FRAME_NUMBER",
	L"URB_FUNCTION_CONTROL_TRANSFER",
	L"URB_FUNCTION_BULK_OR_INTERRUPT_TRANSFER",
	L"URB_FUNCTION_ISOCH_TRANSFER",
	L"URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE",
	L"URB_FUNCTION_SET_DESCRIPTOR_TO_DEVICE",
	L"URB_FUNCTION_SET_FEATURE_TO_DEVICE",
	L"URB_FUNCTION_SET_FEATURE_TO_INTERFACE",
	L"URB_FUNCTION_SET_FEATURE_TO_ENDPOINT",
	L"URB_FUNCTION_CLEAR_FEATURE_TO_DEVICE",
	L"URB_FUNCTION_CLEAR_FEATURE_TO_INTERFACE",
	L"URB_FUNCTION_CLEAR_FEATURE_TO_ENDPOINT",
	L"URB_FUNCTION_GET_STATUS_FROM_DEVICE",
	L"URB_FUNCTION_GET_STATUS_FROM_INTERFACE",
	L"URB_FUNCTION_GET_STATUS_FROM_ENDPOINT",
	L"URB_FUNCTION_RESERVED_0X0016",
	L"URB_FUNCTION_VENDOR_DEVICE",
	L"URB_FUNCTION_VENDOR_INTERFACE",
	L"URB_FUNCTION_VENDOR_ENDPOINT",
	L"URB_FUNCTION_CLASS_DEVICE",
	L"URB_FUNCTION_CLASS_INTERFACE",
	L"URB_FUNCTION_CLASS_ENDPOINT",
	L"URB_FUNCTION_RESERVE_0X001D",
	L"URB_FUNCTION_SYNC_RESET_PIPE_AND_CLEAR_STALL",
	L"URB_FUNCTION_CLASS_OTHER",
	L"URB_FUNCTION_VENDOR_OTHER",
	L"URB_FUNCTION_GET_STATUS_FROM_OTHER",
	L"URB_FUNCTION_CLEAR_FEATURE_TO_OTHER",
	L"URB_FUNCTION_SET_FEATURE_TO_OTHER",
	L"URB_FUNCTION_GET_DESCRIPTOR_FROM_ENDPOINT",
	L"URB_FUNCTION_SET_DESCRIPTOR_TO_ENDPOINT",
	L"URB_FUNCTION_GET_CONFIGURATION",
	L"URB_FUNCTION_GET_INTERFACE",
	L"URB_FUNCTION_GET_DESCRIPTOR_FROM_INTERFACE",
	L"URB_FUNCTION_SET_DESCRIPTOR_TO_INTERFACE",
	L"URB_FUNCTION_GET_MS_FEATURE_DESCRIPTOR",
	L"URB_FUNCTION_RESERVE_0X002B",
	L"URB_FUNCTION_RESERVE_0X002C",
	L"URB_FUNCTION_RESERVE_0X002D",
	L"URB_FUNCTION_RESERVE_0X002E",
	L"URB_FUNCTION_RESERVE_0X002F",
	L"URB_FUNCTION_SYNC_RESET_PIPE",
	L"URB_FUNCTION_SYNC_CLEAR_STALL",
};
#endif

//--------------------------------------------------------------------------
NTSTATUS Bus_HandleUSBIoCtl (IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp)
{
	PIO_STACK_LOCATION      irpStack;
	NTSTATUS                status;
	ULONG                   inlen, outlen, i;
	PVOID                   buffer;
	PWCHAR                  str1, str2;
	PURB                    urb;
	PPDO_DEVICE_DATA        pdoData;

	NTSTATUS                status1;
	HANDLE                  FileHandle;
	IO_STATUS_BLOCK         ioStatusBlock;

	PAGED_CODE ();

	pdoData = (PPDO_DEVICE_DATA) DeviceObject->DeviceExtension;

	// Bus_KdPrint(pdoData, BUS_DBG_IOCTL_TRACE, ("Recive IRP_MJ_INTERNAL_DEVICE_CONTROL\n"));

	// We only take Device Control requests for the devices.
	if (pdoData->IsFDO)
	{
		// These commands are only allowed to go to the devices.
		status = STATUS_INVALID_DEVICE_REQUEST;
		Irp->IoStatus.Status = status;
		IoCompleteRequest (Irp, IO_NO_INCREMENT);
		return status;
	}

	// Check to see whether the bus is removed
	if (pdoData->DevicePnPState == Deleted)
	{
		Irp->IoStatus.Status = status = STATUS_DELETE_PENDING;
		IoCompleteRequest (Irp, IO_NO_INCREMENT);
		return status;
	}

	// Get IRP packet info
	irpStack = IoGetCurrentIrpStackLocation (Irp);

	buffer = Irp->AssociatedIrp.SystemBuffer;
	inlen  = irpStack->Parameters.DeviceIoControl.InputBufferLength;
	outlen = irpStack->Parameters.DeviceIoControl.OutputBufferLength;

	// Get URB
	urb = irpStack->Parameters.Others.Argument1;

	// And set status to 'unhandled device request'
	status = STATUS_INVALID_DEVICE_REQUEST;


	// Analyse requested IoControlCode
	switch (irpStack->Parameters.DeviceIoControl.IoControlCode)
	{
		// Request for USB bus, handle it
	case IOCTL_INTERNAL_USB_SUBMIT_URB:
		// Bus_KdPrint(pdoData, BUS_DBG_IOCTL_TRACE, ("Recive IOCTL_INTERNAL_USB_SUBMIT_URB\n"));
		if (urb)
		{
#ifdef DEBUG_FULL
			//
			// Print request info
			//
			str1 = ExAllocatePoolWithTag (PagedPool, 4096, VUSB_POOL_TAG);
			if (!str1)
			{
				status = STATUS_INSUFFICIENT_RESOURCES;
				break;
			}
			else
				RtlZeroMemory(str1, 4096);

			str2 = ExAllocatePoolWithTag (PagedPool, 4096, VUSB_POOL_TAG);
			if (!str2)
			{
				ExFreePool(str1);
				status = STATUS_INSUFFICIENT_RESOURCES;
				break;
			}
			else
				RtlZeroMemory(str2, 4096);


			if (urb->UrbHeader.Function == URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE || urb->UrbHeader.Function==URB_FUNCTION_VENDOR_DEVICE)
			{
				if(urb->UrbControlVendorClassRequest.TransferBufferLength < 1024)
				{
					PrintBufferContent(str1,
						urb->UrbControlVendorClassRequest.TransferBuffer,
						urb->UrbControlVendorClassRequest.TransferBufferLength);
				}
				else
				{
					PrintBufferContent(str1,
						urb->UrbControlVendorClassRequest.TransferBuffer,
						1024);
				}

				PrintBufferContent(str2,
					&urb->UrbControlVendorClassRequest.Request,
					1+2+2+2);

				LogMessage ("Bus_HandleUSBIoCtl(): in\n"
					"\tFunction:  %ws (%X)\n"
					"\tLength:    %X\n"
					"\tTransfer buffer length:     %X\n"
					"\tTransfer buffer contents:   %ws\n"
					"\tRequest buffer:             %ws\n"
					"\tRequest:        %X\n"
					"\tValue:          %X\n"
					"\tIndex:          %X\n"
					"\tTransferFlags:  %X\n"
					"\tDescriptorType: %X\n"
					"\tLanguageId:     %X\n",
					(urb->UrbHeader.Function>=0 && urb->UrbHeader.Function<=0x31)?fnCodeList[urb->UrbHeader.Function]:L"UNKNOWN\0",
					urb->UrbHeader.Function,
					urb->UrbHeader.Length,
					urb->UrbControlVendorClassRequest.TransferBufferLength,
					str1,
					str2,
					urb->UrbControlVendorClassRequest.Request,
					urb->UrbControlVendorClassRequest.Value,
					urb->UrbControlVendorClassRequest.Index,
					urb->UrbControlVendorClassRequest.TransferFlags,
					urb->UrbControlDescriptorRequest.DescriptorType,
					urb->UrbControlDescriptorRequest.LanguageId);
			}
			else
				LogMessage ("Bus_HandleUSBIoCtl(): in\n"
				"\tFunction:  %ws (%X)\n"
				"\tLength:    %X\n",
				(urb->UrbHeader.Function>=0 && urb->UrbHeader.Function<=0x31)?fnCodeList[urb->UrbHeader.Function]:L"UNKNOWN\0",
				urb->UrbHeader.Function,
				urb->UrbHeader.Length);
#endif
			// Analyse requested URB function code

			/*
			DPRINT("Function:  %ws (%X)\n",
			(urb->UrbHeader.Function >= 0 && urb->UrbHeader.Function <= 0x31) ? fnCodeList[urb->UrbHeader.Function] : L"UNKNOWN\0",
			urb->UrbHeader.Function);
			*/

			switch (urb->UrbHeader.Function)
			{
				// Get info about device fn
			case URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE:
				switch (urb->UrbControlDescriptorRequest.DescriptorType)
				{
					// Info about hardware of USB device
				case USB_DEVICE_DESCRIPTOR_TYPE:
					{
						USB_DEVICE_DESCRIPTOR deviceDesc;

						DPRINT("IN case USB_DEVICE_DESCRIPTOR_TYPE");

						deviceDesc.bLength = sizeof(deviceDesc);
						deviceDesc.bDescriptorType = USB_DEVICE_DESCRIPTOR_TYPE;
						deviceDesc.bcdUSB = 0x0200;
						deviceDesc.bDeviceClass = USB_DEVICE_CLASS_VENDOR_SPECIFIC;
						deviceDesc.bDeviceSubClass = 0;
						deviceDesc.bDeviceProtocol = 0;
						deviceDesc.bMaxPacketSize0 = 8;
						deviceDesc.idVendor = 0x529;
						deviceDesc.idProduct = 1;
						deviceDesc.bcdDevice = 0x325;
						deviceDesc.iManufacturer = 1;
						deviceDesc.iProduct = 2;
						deviceDesc.iSerialNumber = 0;
						deviceDesc.bNumConfigurations = 1;

						urb->UrbControlVendorClassRequest.TransferBufferLength =
							min(urb->UrbControlVendorClassRequest.TransferBufferLength, sizeof(deviceDesc));

						RtlCopyMemory(urb->UrbControlVendorClassRequest.TransferBuffer,
							&deviceDesc,
							urb->UrbControlVendorClassRequest.TransferBufferLength);

						status = STATUS_SUCCESS;
						URB_STATUS(urb) = USBD_STATUS_SUCCESS;
					}
					break;

					// Info about possible configurations of USB device
				case USB_CONFIGURATION_DESCRIPTOR_TYPE:
					{
						struct
						{
							USB_CONFIGURATION_DESCRIPTOR configDesc;
							USB_INTERFACE_DESCRIPTOR interfaceDesc;
						} configInfo;

						DPRINT("IN case USB_CONFIGURATION_DESCRIPTOR_TYPE");

						configInfo.configDesc.bLength = sizeof(configInfo.configDesc);
						configInfo.configDesc.bDescriptorType = USB_CONFIGURATION_DESCRIPTOR_TYPE;
						configInfo.configDesc.wTotalLength = sizeof(configInfo.configDesc) + sizeof(configInfo.interfaceDesc);
						configInfo.configDesc.bNumInterfaces = 1;
						configInfo.configDesc.bConfigurationValue = 1;
						configInfo.configDesc.iConfiguration = 0;
						configInfo.configDesc.bmAttributes = USB_CONFIG_BUS_POWERED;
						configInfo.configDesc.MaxPower = 0x19;

						configInfo.interfaceDesc.bLength = sizeof(configInfo.interfaceDesc);
						configInfo.interfaceDesc.bDescriptorType = USB_INTERFACE_DESCRIPTOR_TYPE;
						configInfo.interfaceDesc.bInterfaceNumber = 0;
						configInfo.interfaceDesc.bAlternateSetting = 0;
						configInfo.interfaceDesc.bNumEndpoints = 0;
						configInfo.interfaceDesc.bInterfaceClass = USB_DEVICE_CLASS_VENDOR_SPECIFIC;
						configInfo.interfaceDesc.bInterfaceSubClass = 0;
						configInfo.interfaceDesc.bInterfaceProtocol = 0;
						configInfo.interfaceDesc.iInterface = 0;

						urb->UrbControlVendorClassRequest.TransferBufferLength =
							min(urb->UrbControlVendorClassRequest.TransferBufferLength, sizeof(configInfo.configDesc) + sizeof(configInfo.interfaceDesc));

						RtlCopyMemory(urb->UrbControlVendorClassRequest.TransferBuffer,
							&configInfo,
							urb->UrbControlVendorClassRequest.TransferBufferLength);

						status = STATUS_SUCCESS;
						URB_STATUS(urb) = USBD_STATUS_SUCCESS;
					}
					break;

				case USB_STRING_DESCRIPTOR_TYPE: 
					{
						UCHAR Length;

						UCHAR SupportedLanguage[4] =
						{
							2 + 2,
							USB_STRING_DESCRIPTOR_TYPE,
							0x09, 0x04 //  US English only..
						};

						UCHAR Manufacturer[8] =
						{
							6 + 2,
							USB_STRING_DESCRIPTOR_TYPE,
							'A', 0, 'K', 0, 'S', 0
						};

						UCHAR Product[32] =
						{
							30 + 2,
							USB_STRING_DESCRIPTOR_TYPE,
							'H', 0, 'A', 0, 'S', 0, 'P', 0, ' ', 0, 'H', 0, 'L', 0,
							' ', 0, '3', 0, '.', 0, '2', 0, '5', 0, 0, 0, 0, 0, 0, 0
						};


						UCHAR SerialNumber[] = // ??????? never see in usbtrace log
						{
							30 + 2,
							USB_STRING_DESCRIPTOR_TYPE,
							'H', 0, 'A', 0, 'S', 0, 'P', 0, ' ', 0, 'H', 0, 'L', 0,
							' ', 0, '3', 0, '.', 0, '2', 0, '5', 0, 0, 0, 0, 0, 0, 0
						};

						switch (urb->UrbControlDescriptorRequest.Index) 
						{
						case 0x00:
							{
								Length = SupportedLanguage[0];

								urb->UrbControlVendorClassRequest.TransferBufferLength =
									min(urb->UrbControlVendorClassRequest.TransferBufferLength, Length);

								RtlCopyMemory(urb->UrbControlVendorClassRequest.TransferBuffer,
									&SupportedLanguage[0],
									urb->UrbControlVendorClassRequest.TransferBufferLength);
							}
							break;

						case 0x01:
							{
								Length = Manufacturer[0];

								urb->UrbControlVendorClassRequest.TransferBufferLength =
									min(urb->UrbControlVendorClassRequest.TransferBufferLength, Length);

								RtlCopyMemory(urb->UrbControlVendorClassRequest.TransferBuffer,
									&Manufacturer[0],
									urb->UrbControlVendorClassRequest.TransferBufferLength);
							}
							break;

						case 0x02:
							{
								Length = Product[0];

								urb->UrbControlVendorClassRequest.TransferBufferLength =
									min(urb->UrbControlVendorClassRequest.TransferBufferLength, Length);

								RtlCopyMemory(urb->UrbControlVendorClassRequest.TransferBuffer,
									&Product[0],
									urb->UrbControlVendorClassRequest.TransferBufferLength);
							}
							break; 

						case 0x03:
							{
								Length = SerialNumber[0];

								urb->UrbControlVendorClassRequest.TransferBufferLength =
									min(urb->UrbControlVendorClassRequest.TransferBufferLength, Length);

								RtlCopyMemory(urb->UrbControlVendorClassRequest.TransferBuffer,
									&SerialNumber[0],
									urb->UrbControlVendorClassRequest.TransferBufferLength);
							}
							break;
						}

						status = STATUS_SUCCESS;
						URB_STATUS(urb) = USBD_STATUS_SUCCESS;
						break;
					}

					/*
					case USB_STRING_DESCRIPTOR_TYPE:
					{
					USB_STRING_DESCRIPTOR LanguageID;
					USB_STRING_DESCRIPTOR Product;

					LanguageID.bLength = sizeof(LanguageID);
					LanguageID.bDescriptorType = USB_STRING_DESCRIPTOR_TYPE;
					LanguageID.bString[0] = (WCHAR) 0x0409;

					Product.bLength = sizeof(Product);
					Product.bDescriptorType = USB_STRING_DESCRIPTOR_TYPE;
					Product.bString[0] = (WCHAR)"HASP HL 3.25";

					DPRINT("IN case USB_STRING_DESCRIPTOR_TYPE %X", urb->UrbControlDescriptorRequest.Index);

					switch (urb->UrbControlDescriptorRequest.Index)
					{
					case 0x00:
					RtlCopyMemory(urb->UrbControlVendorClassRequest.TransferBuffer,
					&LanguageID,
					sizeof(LanguageID));
					break;

					case 0x02:
					RtlCopyMemory(urb->UrbControlVendorClassRequest.TransferBuffer,
					&Product,
					sizeof(Product));
					break;
					}
					status = STATUS_SUCCESS;
					URB_STATUS(urb) = USBD_STATUS_SUCCESS;
					}
					break;
					*/
				}
				break;

				// Select configurations of USB device
			case URB_FUNCTION_SELECT_CONFIGURATION:
				{
					typedef struct _URB_SELECT_CONFIGURATION *PURB_SELECT_CONFIGURATION;
					PURB_SELECT_CONFIGURATION selectConfig;
					selectConfig = (PURB_SELECT_CONFIGURATION)urb;
					selectConfig->Interface.InterfaceNumber = 0;
					selectConfig->Interface.AlternateSetting = 0;
					selectConfig->Interface.Class = USB_DEVICE_CLASS_VENDOR_SPECIFIC;
					selectConfig->Interface.SubClass = 0;
					selectConfig->Interface.Protocol = 0;

					status = STATUS_SUCCESS;
					URB_STATUS(urb) = USBD_STATUS_SUCCESS;
				}
				break;

				// IO request to USB hardware
			case URB_FUNCTION_VENDOR_DEVICE:
				{
					// Emulate request to key
					EmulateHASPKey(&pdoData->keyData,
						(PKEY_REQUEST)&urb->UrbControlVendorClassRequest.Request,
						&urb->UrbControlVendorClassRequest.TransferBufferLength,
						(PKEY_RESPONSE)urb->UrbControlVendorClassRequest.TransferBuffer);

					// I/O with key is successful
					status = STATUS_SUCCESS;
					URB_STATUS(urb) = USBD_STATUS_SUCCESS;
				}
				break;
			}

#ifdef DEBUG_FULL
			//
			// Print request result
			//
			RtlZeroMemory(str1, 4096);
			RtlZeroMemory(str2, 4096);

			if (urb->UrbHeader.Function == URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE || urb->UrbHeader.Function == URB_FUNCTION_VENDOR_DEVICE)
			{
				if(urb->UrbControlVendorClassRequest.TransferBufferLength < 1024)
				{
					PrintBufferContent(str1,
						urb->UrbControlVendorClassRequest.TransferBuffer,
						urb->UrbControlVendorClassRequest.TransferBufferLength);
				}
				else
				{
					PrintBufferContent(str1,
						urb->UrbControlVendorClassRequest.TransferBuffer,
						1024);
				}

				LogMessage ("Bus_HandleUSBIoCtl(): out\n"
					"\tTransfer buffer length:     %X\n"
					"\tTransfer buffer contents:   %ws\n"
					"\tStatus:                     %X\n",
					urb->UrbControlVendorClassRequest.TransferBufferLength,
					str1,
					URB_STATUS(urb));
			}
			else
				LogMessage ("Bus_HandleUSBIoCtl(): out\n"
				"\tStatus: %X\n",
				URB_STATUS(urb));

			ExFreePoolWithTag(str2, VUSB_POOL_TAG);
			ExFreePoolWithTag(str1, VUSB_POOL_TAG);
#endif
		}
		break;

	default:
		break;                                // default status is STATUS_INVALID_PARAMETER
	}

	Irp->IoStatus.Status = status;
	IoCompleteRequest (Irp, IO_NO_INCREMENT);
	return status;
}

// HASP secret table generator vectors, it is used to create ST for old HASP keys
static UCHAR HASP_rows[8][8] =
{
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 1, 0, 1, 0, 1, 0, 1},
	{1, 0, 1, 0, 1, 0, 1, 0},
	{0, 0, 1, 1, 0, 0, 1, 1},
	{1, 1, 0, 0, 1, 1, 0, 0},
	{0, 0, 0, 0, 1, 1, 1, 1},
	{1, 1, 1, 1, 0, 0, 0, 0},
	{1, 1, 1, 1, 1, 1, 1, 1}
};

NTSTATUS DS_InitHaspHLKeyData(PKEYDATA keyData, ULONG reserved)
{
	NTSTATUS readStatus, hasOption, hasSecTable;
	// NTSTATUS hasFatData0;
	ULONG actualSize = 0;

	readStatus = STATUS_SUCCESS;

	readStatus += GetExtraRegKeyData(0, keyData->password, HL_TYPE_STR,      &keyData->keyType,      sizeof(keyData->keyType), &actualSize);
	readStatus += GetExtraRegKeyData(0, keyData->password, HL_MEMORY_STR,    &keyData->memoryType,   sizeof(keyData->memoryType), &actualSize);
	readStatus += GetExtraRegKeyData(0, keyData->password, HL_NETMEMORY_STR, &keyData->netMemory[0], sizeof(keyData->netMemory), &actualSize);
	readStatus += GetExtraRegKeyData(0, keyData->password, HL_SN_STR,        &keyData->netMemory[0], sizeof(ULONG), &actualSize);
	readStatus += GetExtraRegKeyData(0, keyData->password, HL_DATA_STR,      keyData->memory,        min(GetMemorySize(keyData), sizeof(keyData->memory)), &actualSize);

	hasOption =   GetExtraRegKeyData(0, keyData->password, HL_OPTIONS_STR,    &keyData->options[0],  sizeof(keyData->options),  &actualSize);
	hasSecTable = GetExtraRegKeyData(0, keyData->password, HL_SECTABLE_STR,  &keyData->secTable[0], sizeof(keyData->secTable), &actualSize);

	if (NT_SUCCESS(readStatus))
	{
		if (!(NT_SUCCESS(hasSecTable)))
		{ // Universal ST case
			ULONG password = keyData->password, i, j;
			UCHAR alBuf[8];

			DPRINT("Revert to universal ST\n");

			password ^= 0x09071966;
			for (i = 0; i < 8; i++)
			{
				alBuf[i] = (UCHAR)(password & 7);
				password = password >> 3;
			}
			RtlZeroMemory(keyData->secTable, sizeof(keyData->secTable));
			for(i = 0; i < 8; i++)
				for(j = 0; j < 8; j++)
					keyData->secTable[j] |= HASP_rows[alBuf[i]][j] << (7 - i);
		}

		if (GetExtraRegKeyData(0, keyData->password, HL_NETMEMORY_STR, &keyData->netMemory[4], sizeof(keyData->netMemory) - sizeof(ULONG), &actualSize) != STATUS_SUCCESS)
		{
			RtlFillMemory(&keyData->netMemory[4], sizeof(keyData->netMemory) - sizeof(ULONG), 0xFF);
			if (keyData->memoryType == 4)
			{ // Unlimited Net key
				keyData->netMemory[6+4] = 0xFF;
				keyData->netMemory[7+4] = 0xFF;
				keyData->netMemory[10+4] = 0xFE;
			}
			else
			{ // Local key
				keyData->netMemory[6+4] = 0;
				keyData->netMemory[7+4] = 0;
				keyData->netMemory[10+4] = 0;
			}
		}

		RtlZeroMemory(&keyData->KEY_INFOdata, sizeof(keyData->KEY_INFOdata));

		GetExtraRegKeyData(0, keyData->password, HL_COLUMNMASK_STR, &keyData->KEY_INFOdata.columnMask, sizeof(keyData->KEY_INFOdata.columnMask), &actualSize);
		GetExtraRegKeyData(0, keyData->password, HL_CRYPTINITVECT_STR, &keyData->KEY_INFOdata.cryptInitVect, sizeof(keyData->KEY_INFOdata.cryptInitVect), &actualSize);

		// If parameters for 3C/3D are not defined, we'll use non-parameters variant by tch2000
		if ((!keyData->KEY_INFOdata.columnMask) && (!keyData->KEY_INFOdata.cryptInitVect ))
		{ // It will be used as flag too
			keyData->KEY_INFOdata.password = keyData->password;
		}

		// Copy ST to KEY_INFOdata
		RtlCopyMemory(&keyData->KEY_INFOdata.secTable, &keyData->secTable, sizeof(keyData->secTable));
		// Read info for time's function(s)
		GetExtraRegKeyData(0, keyData->password, HL_TIMESHIFT_STR, &keyData->TimeShift, sizeof(keyData->TimeShift), &actualSize);
		GetExtraRegKeyData(0, keyData->password, HL_HASPTIME_MEMORY_STR, &keyData->HASPTIMEMEMORY, sizeof(keyData->HASPTIMEMEMORY), &actualSize);

		/*
		if (!(NT_SUCCESS(GetExtraRegKeyData(0, keyData->password, L"AesKey", &keyData->AesKey, sizeof(keyData->AesKey), &actualSize)))) 
		{
		UCHAR AES[16] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F };
		DPRINT("HASP HL AesKey NOT READ. actualSize = %d\n", actualSize);
		RtlCopyMemory(keyData->AesKey, AES, sizeof(AES));
		}
		*/
	}

	return readStatus;
}

NTSTATUS DS_InitHaspSRMKeyData(PKEYDATA keyData, ULONG reserved)
{
	NTSTATUS srmStatus;
	ULONG actualSize = 0;

	WCHAR KeyName12[12] = {0};

	USHORT i = 0;
	NTSTATUS readStatus = 0;

	USHORT FeatureNumber2 = 0;
	USHORT FeatureIndex = 0;
	USHORT FeatureSlot = 0;
	USHORT FeatureSize = 0;

	UCHAR FeatureDataTemp64[64] = {0};

	SRM_FEATURE_PROPERTY FeatureProperty = {0};

	//	ULONG RegistryDataType = SRMDATA;
	srmStatus = STATUS_SUCCESS;

	GetExtraRegKeyData(SRMDATA, keyData->password, RW_MEM_STR, keyData->SRM_RW_Memory, sizeof(keyData->SRM_RW_Memory), &actualSize);
	GetExtraRegKeyData(SRMDATA, keyData->password, RO_MEM_STR, keyData->SRM_RO_Memory, sizeof(keyData->SRM_RO_Memory), &actualSize);

	if(keyData->ds.isEncryptedRegistry == PLAINREGISTRY)
	{
		DPRINT("SECURITY USE PLAIN SRM");
		srmStatus += GetExtraRegKeyData(SRMDATA, keyData->password, FIRSTSESSION_STR, keyData->VendorAES, sizeof(keyData->VendorAES), &actualSize);
		srmStatus += GetExtraRegKeyData(SRMDATA, keyData->password, FUNC_A1_VAL0_STR, keyData->FuncA1_Val0, sizeof(keyData->FuncA1_Val0), &actualSize);
		srmStatus += GetExtraRegKeyData(SRMDATA, keyData->password, FUNC_A1_VAL1_STR, keyData->FuncA1_Val1, sizeof(keyData->FuncA1_Val1), &actualSize);
		srmStatus += GetExtraRegKeyData(SRMDATA, keyData->password, FUNC_A1_VAL2_STR, keyData->FuncA1_Val2, sizeof(keyData->FuncA1_Val2), &actualSize);
		srmStatus += GetExtraRegKeyData(SRMDATA, keyData->password, FUNC_A1_VAL3_STR, keyData->FuncA1_Val3, sizeof(keyData->FuncA1_Val3), &actualSize);
		srmStatus += GetExtraRegKeyData(SRMDATA, keyData->password, FUNC_A2_STR,      keyData->FuncA2, sizeof(keyData->FuncA2), &actualSize);
		// keyData->FuncA2size = actualSize;
	}
	else
		// if(keyData->ds.isEncryptedRegistry == CRYPTREGISTRY || keyData->ds.isEncryptedRegistry == CRYPTREGISTRYMD5)
	{
		DPRINT("SECURITY USE ENCRYPTED SRM");
		srmStatus += GetExtraRegKeyData(SRMDATA, keyData->password, FATDATA_1_STR, keyData->FatData1,  128, &actualSize);
		srmStatus += GetExtraRegKeyData(SRMDATA, keyData->password, FATDATA_2_STR, keyData->FatData2, 2048, &actualSize);

		Decrypt(dataAESkey, keyData->FatData1, keyData->FatData1, sizeof(keyData->FatData1));
		//if(*(ULONG*)&keyData->FatData1[112] ==  SIGNBEGIN) // used as signature
		{
			DPRINT("FatData1 DECRYPT SUCCESS AND SIGNATURE IS VALID\n");
			RtlCopyMemory((void *)&(keyData->VendorAES[0]),   (void *)&(keyData->FatData1[0]),  sizeof(keyData->VendorAES));
			RtlCopyMemory((void *)&(keyData->FuncA1_Val0[0]), (void *)&(keyData->FatData1[16]), sizeof(keyData->FuncA1_Val0));
			RtlCopyMemory((void *)&(keyData->FuncA1_Val1[0]), (void *)&(keyData->FatData1[32]), sizeof(keyData->FuncA1_Val1));
			RtlCopyMemory((void *)&(keyData->FuncA1_Val2[0]), (void *)&(keyData->FatData1[80]), sizeof(keyData->FuncA1_Val2));
			RtlCopyMemory((void *)&(keyData->FuncA1_Val3[0]), (void *)&(keyData->FatData1[96]), sizeof(keyData->FuncA1_Val3));
		}

		Decrypt(dataAESkey, keyData->FatData2, keyData->FatData2, sizeof(keyData->FatData2));
		//if(*(ULONG*)&keyData->FatData2[2032] == SIGNBEGIN)
		{
			DPRINT("FatData2 DECRYPT SUCCESS AND SIGNATURE IS VALID\n");
			keyData->FuncA2size = *(ULONG*)&keyData->FatData2[0];
			RtlCopyMemory((void *)&(keyData->FuncA2[0]), (void *)&(keyData->FatData2[16]), sizeof(keyData->FuncA2));
			DPRINT("FatData2 DECRYPT FuncA2size %d\n", keyData->FuncA2size);
		}
	}

	// read all features  according to feature map (A2 data) - need 100% correct A2 data
	FeatureIndex = 0;
	FeatureSlot = 0;
	for(i = 0, FeatureIndex = 0; i < 1984; i = i + 8, FeatureIndex++)
	{
		if(RtlEqualMemory((void *)&(keyData->FuncA2[i]), "\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF", 16))
			break;

		if(RtlEqualMemory((void *)&(keyData->FuncA2[i]), "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00", 16))
			break;

		// FW Revision:	4.25 // HW Revision:	7.0.0 // Dongle Form:	131 (83)
		if(RtlEqualMemory((void *)&(keyData->FuncA2[i]), "\xFF\xFF\x00\x00\x00\x00\x00\x09", 8))
			break;

		if(RtlEqualMemory((void *)&(keyData->FuncA2[i]), "\xFF\xFF\x00\x00\x00\x00\x00\x0B", 8))
			break;

		// FW Revision:	4.27 // HW Revision:	7.2.0 // Dongle Form:	131 (83)
		if(RtlEqualMemory((void *)&(keyData->FuncA2[i]), "\xFF\xFF\x00\x00\x00\x00\x00\x09", 8))
			break;

		if(RtlEqualMemory((void *)&(keyData->FuncA2[i]), "\xFF\xFF\x00\x00\x00\x00\x00\x0C", 8))
			break;
		// get feature properties from featuremap (A2) // need perfect A2 data
		RtlCopyMemory((void *)&FeatureProperty, (void *)&(keyData->FuncA2[i]), 8);

		DPRINT("\n");
		DPRINT("FeatureIndex  %04X (%d)\n", FeatureIndex, FeatureIndex);
		DPRINT("FeatureNumber %04X\n", FeatureProperty.Number);
		DPRINT("FeaturePositi %04X\n", _byteswap_ushort(FeatureProperty.Position));
		DPRINT("FeatureSize   %04X (%d)\n", (USHORT)FeatureProperty.Size >> 4, (USHORT)FeatureProperty.Size >> 4);
		DPRINT("FeatureType   %04X\n", FeatureProperty.Type);

		FeatureNumber2 = FeatureProperty.Number;
		FeatureSize = (USHORT)FeatureProperty.Size >> 4;
		if(FeatureSize <= sizeof(FeatureDataTemp64)) // 64 bytes - no need to search registry for big features
		{
			RtlZeroMemory(FeatureDataTemp64, sizeof(FeatureDataTemp64));
			RtlZeroMemory(KeyName12, sizeof(KeyName12));

			RtlStringCbPrintfExW(KeyName12, 12 * 2, NULL, NULL, STRSAFE_NULL_ON_FAILURE,
				L"%04X", FeatureNumber2);

			readStatus = GetExtraRegKeyData(SRMDATA, keyData->password,
				KeyName12, FeatureDataTemp64, sizeof(FeatureDataTemp64), &actualSize);

			if(!NT_SUCCESS(readStatus))
			{
				DPRINT("FEATURE REGISTRY FAIL FeatureNumber = %04X, actualSize = %d\n", FeatureNumber2, actualSize);
			}
			else
			{
				DPRINT("FEATURE REGISTRY SUCCESS FeatureNumber = %04X, actualSize = %d\n", FeatureNumber2, actualSize);
				if((actualSize == 16) || (actualSize == 32) || (actualSize == 48) || (actualSize == 64)) // i found CEFF with size 64 bytes, but for some reason fail to emulate it, workaround use known CEFF value with size 16 bytes
				{
					DPRINT("FeatureSlot = %04X (%d)\n", FeatureSlot, FeatureSlot);
					keyData->Feature[FeatureSlot].Number = FeatureProperty.Number;
					keyData->Feature[FeatureSlot].Position = FeatureProperty.Position;
					keyData->Feature[FeatureSlot].Size  = min((USHORT)actualSize, FeatureSize);
					keyData->Feature[FeatureSlot].Type  = FeatureProperty.Type;
					keyData->Feature[FeatureSlot].Index  = FeatureIndex;
					keyData->Feature[FeatureSlot].Slot  = FeatureSlot;

					// data from registry decryption
					if(keyData->ds.isEncryptedRegistry != PLAINREGISTRY)
						Decrypt(dataAESkey, FeatureDataTemp64, FeatureDataTemp64, keyData->Feature[FeatureSlot].Size);

					RtlCopyMemory(&keyData->Feature[FeatureSlot].Data, FeatureDataTemp64, keyData->Feature[FeatureSlot].Size);

					FeatureSlot++; // move to next feature slot
				}
			}
		}
	}

#ifdef _NEW_SRM_FORMAT_
	DPRINT("\nGet SRM Data new format\n");
	GetExtraRegKeyData(SRMDATA, keyData->password, L"VendorID",  &keyData->VendorID, sizeof(ULONG), &actualSize);
	DPRINT("VendorID %08X, %d\n", keyData->VendorID, actualSize);
	if(actualSize == sizeof(ULONG))
	{
		keyData->FuncA1_Val1[40] = HIBYTE(HIWORD(keyData->VendorID));
		keyData->FuncA1_Val1[41] = LOBYTE(HIWORD(keyData->VendorID));
		keyData->FuncA1_Val1[42] = HIBYTE(LOWORD(keyData->VendorID));
		keyData->FuncA1_Val1[43] = LOBYTE(LOWORD(keyData->VendorID));
	}

	GetExtraRegKeyData(SRMDATA, keyData->password, L"SRMKeyID",  &keyData->SRMKeyID, sizeof(ULONG), &actualSize);
	DPRINT("SRMKeyID %08X, %d\n", keyData->SRMKeyID, actualSize);
	if(actualSize == sizeof(ULONG))
	{
		//	keyData->FuncA1_Val1[0] = keyData->netMemory[3];
		//	keyData->FuncA1_Val1[1] = keyData->netMemory[2];
		//	keyData->FuncA1_Val1[2] = keyData->netMemory[1];
		//	keyData->FuncA1_Val1[3] = keyData->netMemory[0];

		//	keyData->FuncA1_Val2[0] = keyData->netMemory[3];
		//	keyData->FuncA1_Val2[1] = keyData->netMemory[2];
		//	keyData->FuncA1_Val2[2] = keyData->netMemory[1];
		//	keyData->FuncA1_Val2[3] = keyData->netMemory[0];

		keyData->FuncA1_Val1[0] = HIBYTE(HIWORD(keyData->SRMKeyID));
		keyData->FuncA1_Val1[1] = LOBYTE(HIWORD(keyData->SRMKeyID));
		keyData->FuncA1_Val1[2] = HIBYTE(LOWORD(keyData->SRMKeyID));
		keyData->FuncA1_Val1[3] = LOBYTE(LOWORD(keyData->SRMKeyID));

		keyData->FuncA1_Val2[0] = HIBYTE(HIWORD(keyData->SRMKeyID));
		keyData->FuncA1_Val2[1] = LOBYTE(HIWORD(keyData->SRMKeyID));
		keyData->FuncA1_Val2[2] = HIBYTE(LOWORD(keyData->SRMKeyID));
		keyData->FuncA1_Val2[3] = LOBYTE(LOWORD(keyData->SRMKeyID));
	}

	GetExtraRegKeyData(SRMDATA, keyData->password, L"VendorAES", keyData->VendorAESNew, sizeof(keyData->VendorAESNew), &actualSize);
	if(actualSize == sizeof(keyData->VendorAESNew))
	{
		RtlCopyMemory((void *)&(keyData->VendorAES[0]), (void *)&(keyData->VendorAESNew[0]), sizeof(keyData->VendorAES));
	}

#endif

	DPRINT("\nSet SRM LM AES keys\n");

	// Set SRM LM AES keys
	// Firmware until 3.25
	((DWORD *)&keyData->plugAES)[0] = 0xF1034303;
	((DWORD *)&keyData->plugAES)[1] = 0x679FA0F1;
	((DWORD *)&keyData->plugAES)[2] = 0x0C114D5C;
	((DWORD *)&keyData->plugAES)[3] = 0x23FCA004;

	// Firmware 3.25
	((DWORD *)&keyData->plugAES_new)[0] = 0x5E4CA7F9;
	((DWORD *)&keyData->plugAES_new)[1] = 0x1C01C19D;
	((DWORD *)&keyData->plugAES_new)[2] = 0x1B48DE42;
	((DWORD *)&keyData->plugAES_new)[3] = 0x38138D6B;

	// HASPlms.exe 6.56 //
	((DWORD *)&keyData->plugAES_new_656)[0] = 0x98D87676;
	((DWORD *)&keyData->plugAES_new_656)[1] = 0xA801A101;
	((DWORD *)&keyData->plugAES_new_656)[2] = 0x9FA26948;
	((DWORD *)&keyData->plugAES_new_656)[3] = 0xCA004E51;

	return srmStatus;
}

NTSTATUS DS_InitHaspSRMKeyDataDEFAULT(PKEYDATA keyData, ULONG setVendorID)
{
	NTSTATUS srmStatus = STATUS_SUCCESS;

	ULONG VendorID = setVendorID;
	UCHAR A10[3] = { 0x01,0x00,0x00 };
	UCHAR A11[47] =
	{
		0x00,0x00,0x00,0x00, // SN
		0x06,0x01,0x00,0x00,
		0x02,0xCA,0x00,0x0E,0x00,0x00,0x39,0x37,
		0x02,0x24,0x00,0x02,0x00,0x02,0x00,0x00,
		0x03,0x19,0x22,0xC3,0x7B,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0xF8,0x00,0x03,0x7E,
		0x00,0x00,0x92,0x8B, // VendorID
		0x00,0x00,0x00
	};

	UCHAR A12[14] =
	{
		0x00,0x00,0x00,0x00, // SN
		0x00,0x00,0x01,0x00,0x01,0x21,0x00,0x00,0x01,0x00
	};

	UCHAR A13[8] =
	{
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
	};

	UCHAR k[0x07C1], j;
	UCHAR A2[96 + 8] =
	{
		0xFF,0xC0,0x00,0x00,0x00,0x04,0x04,0x00,
		0xFF,0xC1,0x00,0x04,0x00,0x01,0x00,0x01,
		0xFF,0xC2,0x00,0x05,0x00,0xFD,0x00,0x02,
		0xFF,0xC8,0x01,0x02,0x00,0x08,0x04,0x03,
		0xFF,0xC9,0x02,0x89,0x00,0x02,0x00,0x07,
		0xFF,0xCC,0x02,0x8B,0x00,0x06,0x04,0x0D,
		0xFF,0xF4,0x01,0x0A,0x00,0xFC,0x00,0x04,
		0xFF,0xF5,0x02,0x06,0x00,0x80,0x00,0x05,
		0xFF,0xCA,0x02,0x86,0x00,0x03,0x00,0x06,
		0xFF,0xCD,0x02,0x91,0x00,0x01,0x00,0x09,
		0xFF,0xCB,0x02,0x92,0x00,0x01,0x00,0x0B,
		0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
		0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF
	};

	A11[0] = keyData->netMemory[3];
	A11[1] = keyData->netMemory[2];
	A11[2] = keyData->netMemory[1];
	A11[3] = keyData->netMemory[0];

	A11[40] = HIBYTE(HIWORD(VendorID));
	A11[41] = LOBYTE(HIWORD(VendorID));
	A11[42] = HIBYTE(LOWORD(VendorID));
	A11[43] = LOBYTE(LOWORD(VendorID));

	A12[0] = keyData->netMemory[3];
	A12[1] = keyData->netMemory[2];
	A12[2] = keyData->netMemory[1];
	A12[3] = keyData->netMemory[0];

	RtlCopyMemory((void *)&(keyData->FuncA1_Val0[0]), A10, sizeof(keyData->FuncA1_Val0));
	RtlCopyMemory((void *)&(keyData->FuncA1_Val1[0]), A11, sizeof(keyData->FuncA1_Val1));
	RtlCopyMemory((void *)&(keyData->FuncA1_Val2[0]), A12, sizeof(keyData->FuncA1_Val2));
	RtlCopyMemory((void *)&(keyData->FuncA1_Val3[0]), A13, sizeof(keyData->FuncA1_Val3));

	RtlFillMemory(&k, 0x07C1, 0xFF);
	RtlCopyMemory(&k, &A2, sizeof(A2));
	k[0x07C0] = 0x00;
	RtlCopyMemory((void *)&(keyData->FuncA2[0]),      k, sizeof(keyData->FuncA2));

	return srmStatus;
}

//#define MAKEDATE(y, m, d) (DWORD)((y << 16) + (m << 8) + d)

//-----------------------------------------------------------------
NTSTATUS Bus_LoadDumpFromRegistry(ULONG password, PKEYDATA keyData)
{
	NTSTATUS status;
	ULONG actualSize = 0;

	// Encodes-Decodes Security Data
	UCHAR securityAESkey[KEYSIZE] = {0};
	UCHAR Buf16[16] = {0};

	PAGED_CODE();

	RtlZeroMemory(keyData, sizeof(KEY_DATA));

	// Password stored in shuffled form
	keyData->password = (password >> 16) | (password << 16);
	keyData->hldSN = 0;
	keyData->srmSN = 0;
	keyData->DongleType = DONGLE_HASP; // enabled by default //
	// for vmprotect hide constants
	((DWORD *)&securityAESkey)[0] = SECURITYAESK0;
	((DWORD *)&securityAESkey)[1] = SECURITYAESK1;
	((DWORD *)&securityAESkey)[2] = SECURITYAESK2;
	((DWORD *)&securityAESkey)[3] = SECURITYAESK3;

	// for vmprotect hide constants
	((DWORD *)&dataAESkey)[0] = DATAAESK0;
	((DWORD *)&dataAESkey)[1] = DATAAESK1;
	((DWORD *)&dataAESkey)[2] = DATAAESK2;
	((DWORD *)&dataAESkey)[3] = DATAAESK3;
	//////////////////////////////////////////////////

	// SystemID store
	DS_Prepare_SystemIDRawData(Buf16);
	Encrypt(securityAESkey, Buf16, Buf16, 16);

	((DWORD *)&Buf16)[0] ^= USERXOR;
	((DWORD *)&Buf16)[1] ^= USERXOR;
	((DWORD *)&Buf16)[2] ^= USERXOR;
	((DWORD *)&Buf16)[3] ^= USERXOR;

	Store_KeyDataToRegister(REGULAR_DUMP_REG_PATH,
		keyData, L"SystemID", Buf16, 16);
	////////////////////////////////////
	/*status = GetExtraRegKeyData(0, keyData->password, DONGLE_TYPE_STR,
		&keyData->DongleType, sizeof(keyData->DongleType), &actualSize);*/
	status = STATUS_SUCCESS; // enabled by default DONGLE_HASP only //
	/////////////////////////////////////
	if (NT_SUCCESS(status))
	{
		NTSTATUS readStatus;
		NTSTATUS srmStatus;

		readStatus = STATUS_SUCCESS;
		srmStatus =  STATUS_SUCCESS;

		if (keyData->DongleType == DONGLE_HASP)
		{
			readStatus += DS_InitHaspHLKeyData(keyData, 0);
			srmStatus  += DS_InitHaspSRMKeyDataDEFAULT(keyData, 0x0000928B);// DEMOMA VendorID
			srmStatus  += DS_InitHaspSRMKeyData(keyData, 0);
			// SECURITY PART
			/*GetExtraRegKeyData(0, keyData->password, L"Security",
				&keyData->ds, sizeof(keyData->ds), &actualSize);

			Decrypt(securityAESkey, (void *)&keyData->ds, (void *)&keyData->ds, sizeof(keyData->ds));

			if((keyData->ds.signatureBegin == SIGNBEGIN) && (keyData->ds.signatureEnd == SIGNENDEE))
			{
				DPRINT("SECURITY DATA SIGNATURES OK", actualSize);
				srmStatus  += DS_InitHaspSRMKeyData(keyData, 0);
			}
			else
			{
				DPRINT("SECURITY DATA SIGNATURES FAIL", actualSize);
				RtlZeroMemory(&keyData->ds, sizeof(keyData->ds));
			}

			// need check with basic keys
			keyData->hldSN = *(ULONG*)&keyData->netMemory[0];
			keyData->srmSN = ((*(BYTE*)&keyData->FuncA1_Val1[0] << 24) |
				(*(BYTE*)&keyData->FuncA1_Val1[1] << 16) |
				(*(BYTE*)&keyData->FuncA1_Val1[2] << 8) |
				(*(BYTE*)&keyData->FuncA1_Val1[3]));

				keyData->ds.isPassSecurity = FALSE;

			// check security data VendorAES
			if(RtlEqualMemory(keyData->ds.Param0, keyData->VendorAES, 16))
				DS_CheckDongleSecurity(&keyData->ds, keyData->password, keyData->hldSN, keyData->srmSN);

			if(keyData->ds.isPassSecurity == TRUE)
			{
				DPRINT("SECURITY PASS SET LM SRM DATA");
			}
			else
			{
				DPRINT("SECURITY FAIL FOOL SRM DATA");
				RtlZeroMemory(&keyData->ds, sizeof(keyData->ds));

				//RtlZeroMemory(keyData->FuncA1_Val0, sizeof(keyData->FuncA1_Val0));
				//RtlZeroMemory(keyData->FuncA1_Val1, sizeof(keyData->FuncA1_Val1));
				//RtlZeroMemory(keyData->FuncA1_Val2, sizeof(keyData->FuncA1_Val2));
				//RtlZeroMemory(keyData->FuncA1_Val3, sizeof(keyData->FuncA1_Val3));
				//RtlZeroMemory(keyData->FuncA2,      sizeof(keyData->FuncA2));
				RtlZeroMemory(keyData->plugAES,     sizeof(keyData->plugAES));
				RtlZeroMemory(keyData->plugAES_new, sizeof(keyData->plugAES_new));
				RtlZeroMemory(keyData->plugAES_new_656, sizeof(keyData->plugAES_new_656));
				RtlZeroMemory(keyData->VendorAES,   sizeof(keyData->VendorAES));
			}*/
			// END SECURITY
		}

		if (!NT_SUCCESS(readStatus))
			return STATUS_INVALID_PARAMETER;
		// else keysAttached++; // Chingachguk: key successful installed
	}
	else
		return STATUS_INVALID_PARAMETER;

	return STATUS_SUCCESS;
}

//-----------------------------------------------------------------
NTSTATUS Bus_LoadDumpsFromRegistry(IN PDEVICE_OBJECT DeviceObject)
{
	NTSTATUS        status;
	HANDLE          hkey;
	ULONG           keysAttached;
	WCHAR           path[128];
	UNICODE_STRING  usPath;
	OBJECT_ATTRIBUTES   oa;
	PFDO_DEVICE_DATA    fdoData;

	PAGED_CODE();

	//VMProtectBegin("Bus_LoadDumpsFromRegistry");

	fdoData = (PFDO_DEVICE_DATA) DeviceObject->DeviceExtension;
	Bus_IncIoCount (fdoData);

	keysAttached = 0;
	RtlInitUnicodeString(&usPath, DUMP_PATH);
	InitializeObjectAttributes(&oa, &usPath, OBJ_KERNEL_HANDLE | OBJ_CASE_INSENSITIVE, NULL, NULL);

	// Enum keys in registry and attach it
	status = ZwOpenKey(&hkey, KEY_READ, &oa);
	if (NT_SUCCESS(status))
	{
		ULONG size, i;
		PKEY_FULL_INFORMATION fip;

		ZwQueryKey(hkey, KeyFullInformation, NULL, 0, &size);
		size = min(size, PAGE_SIZE);
		fip = (PKEY_FULL_INFORMATION) ExAllocatePoolWithTag(PagedPool, size, VUSB_POOL_TAG);
		ZwQueryKey(hkey, KeyFullInformation, fip, size, &size);

		for (i = 0; i < fip->SubKeys; ++i)
		{
			ULONG curChar, password, isPasswordValid;
			PKEY_BASIC_INFORMATION bip;

			ZwEnumerateKey(hkey, i, KeyBasicInformation, NULL, 0, &size);
			size = min(size, PAGE_SIZE);
			bip = (PKEY_BASIC_INFORMATION)ExAllocatePoolWithTag(PagedPool, size, VUSB_POOL_TAG);
			ZwEnumerateKey(hkey, i, KeyBasicInformation, bip, size, &size);

			// Convert key name into password
			password = 0;
			isPasswordValid = 1;
			for (curChar = 0; curChar < bip->NameLength / 2; curChar++)
			{
				if (bip->Name[curChar] >= L'0' && bip->Name[curChar] <= L'9')
					password = (password << 4) + (bip->Name[curChar] - L'0');
				else if (bip->Name[curChar] >= L'A' && bip->Name[curChar] <= L'F')
					password = (password << 4) + (bip->Name[curChar] - L'A') + 10;
				else if (bip->Name[curChar] >= L'a' && bip->Name[curChar] <= L'f')
					password = (password << 4) + (bip->Name[curChar] - L'a') + 10;
				else
				{
					isPasswordValid = 0;
					break;
				}
			}

			if (isPasswordValid && INSERT_ALL_KEYS_ON_STARTUP)
			{
				UCHAR                    buf[sizeof(VUSB_PLUGIN_HARDWARE)+BUS_HARDWARE_IDS_LENGTH];
				PVUSB_PLUGIN_HARDWARE    pOneKeyInfo;
				NTSTATUS                 status;

				DPRINT("Found key %08X\n", password);

				pOneKeyInfo = (PVUSB_PLUGIN_HARDWARE)buf;
				pOneKeyInfo->Size = sizeof(VUSB_PLUGIN_HARDWARE);
				pOneKeyInfo->SerialNo = ++keysAttached;
				pOneKeyInfo->Password = password;
				RtlCopyMemory(pOneKeyInfo->HardwareIDs, BUS_HARDWARE_IDS, BUS_HARDWARE_IDS_LENGTH);

				status = Bus_PlugInDevice(pOneKeyInfo, sizeof(VUSB_PLUGIN_HARDWARE) + BUS_HARDWARE_IDS_LENGTH, fdoData);
				if (!NT_SUCCESS (status))
					keysAttached--;
			}
			else
			{
				DPRINT("Found bad key\n");
			}

			ExFreePool(bip);
		}
		ExFreePool(fip);
		ZwClose(hkey);
		Bus_DecIoCount (fdoData);

		return STATUS_SUCCESS;
	}

	//VMProtectEnd();
	return STATUS_SUCCESS;
}

/*
void DelayExecutionThread()
{
LARGE_INTEGER tim;
tim.QuadPart = 0x9C40* (-0x04);
KeDelayExecutionThread(0, 0, &tim);
}
*/
