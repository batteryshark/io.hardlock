if your dongle attached to your pc and monitor can not log, you have to
right-click on UsbFilter_Install.inf and then press install. it will
ask you to restart. press yes. after restart it will work correctly

