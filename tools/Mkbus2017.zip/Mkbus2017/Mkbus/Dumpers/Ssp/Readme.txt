install your program
connect your dongle
check if your program is starting.
Close your program

Be careful not lo lock dongle u should know password first or try brute force it....
