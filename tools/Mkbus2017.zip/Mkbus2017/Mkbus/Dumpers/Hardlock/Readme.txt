install your program
connect your dongle
check if your program is starting.
Close your program

-extract my dumper into a new folder
-double click in the hl-brut.reg to add to registry before tool start
-close all running applications
-run the dumper
-it will search for all connected dongle modad�s, this can delay from minutes  to hours
-once it create 2 files, you can to cancel it...


-double click in the hl-orig.reg to restore the registry

send me the created files.
