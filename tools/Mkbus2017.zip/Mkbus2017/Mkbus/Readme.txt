Registy path is:

[-HKEY_LOCAL_MACHINE\System\CurrentControlSet\Mkbus\1234ABCD]

where 1234ABCD -is your dongle password.

"DongleType"=dword:00000001 - Hasp

"DongleType"=dword:00000002 - Hardlock

"DongleType"=dword:00000003 - Spp ultra Pro

see keys for examples.

100% compatible to Multikey 0.18.2.4.

Enjoy!