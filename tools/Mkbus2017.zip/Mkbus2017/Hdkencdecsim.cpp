//---------------------------------------------------------------------------
extern "C" {
#include <ntddk.h>
#include <WinDef.h>
}
#include "HdkEncDecSim.h"
#include "USBKeyEmu.h"

//---------------------------------------------------------------------------
#ifdef ALLOC_PRAGMA
#pragma alloc_text (PAGE, HL_CRYPT)
#pragma alloc_text (PAGE, transform0)
#pragma alloc_text (PAGE, Transform0_HW)
#pragma alloc_text (PAGE,HL_CALC)
#pragma alloc_text (PAGE, EncryptDword)

#pragma alloc_text (PAGE, HL_CODE)
#pragma alloc_text (PAGE, SetDongleData)
#pragma alloc_text (PAGE, GetBitFromDongleData)
#pragma alloc_text (PAGE, BYTEROL)
#pragma alloc_text (PAGE, InitgVar12)
#pragma alloc_text (PAGE, InitgSeeds)
#endif

//---------------------------------------------------------------------------
extern "C" void InitgVar12(PHL_CODE_STRUCT TempData)
{
	TempData->gVar1=0xf;
	TempData->gVar2=0x0;
}

//---------------------------------------------------------------------------
extern "C" void SetDongleData(BYTE Data,PHL_CODE_STRUCT TempData, PKEYDATA pKeyData)
{
	if ((pKeyData->password&0x1F0000)==0x1F0000)
	{
		TempData->gVar1 ^= (Data & 0xF) ^ TempData->gSeedArray[TempData->gPtrArray[TempData->gVar1]]; //old
	}
	else
	{
		Data &= 0xF;
		BYTE tmpPtr=TempData->gPtrArray[TempData->gVar1];
		TempData->gVar4 = (TempData->gVar4 << 4) | tmpPtr;
		TempData->gVar1 ^= Data;
		TempData->gVar1 ^= TempData->gVar2;
		TempData->gVar1 ^= TempData->gSeedArray[tmpPtr];
		TempData->gVar2 = (((TempData->gVar2 << 2)+tmpPtr) >> 1) & 0xF;
	}
}


//---------------------------------------------------------------------------
extern "C" BYTE GetBitFromDongleData(PHL_CODE_STRUCT TempData, PKEYDATA pKeyData)
{
	if ((pKeyData->password&0x1F0000)==0x1F0000)
	{
		return (TempData->gPtrArray[TempData->gVar1] & 1); //old
	}
	else
	{
		return (HIBYTE(TempData->gVar4)>>4)&1;
		/*              WORD mygvar4=TempData->gVar4;
		_asm {
		mov     ax, mygvar4
		shr     ah, 4
		mov     al, ah
		and     eax, 1
		}
		*/      }
}


//---------------------------------------------------------------------------
extern "C" BYTE BYTEROL(BYTE Value,BYTE Shift)
{
	return (Value << Shift) | (Value >> (8-Shift));
	/*  _asm
	{
	mov al,Value
	mov cl,Shift
	rol al,cl
	}
	*/
}

//---------------------------------------------------------------------------
extern "C" BYTE CipherFunction(DWORD *R,DWORD *tmpR,PHL_CODE_STRUCT TempData, PKEYDATA pKeyData)
{
	BYTE *Data=(BYTE *)tmpR;

	BYTE SumOfBitFromDongle=0;
	int OuterLoopCounter;
	int InnerLoopCounter;
	BYTE BitFromDongle;

	BitFromDongle=1;
	OuterLoopCounter=9;
	InitgVar12(TempData);
	while(OuterLoopCounter>0) {
		InnerLoopCounter=0;

		BYTE tmp1;
		BYTE tmp2;
		BYTE tmp3;
		while(InnerLoopCounter<4) {
			tmp1=Data[InnerLoopCounter];
			tmp1=BYTEROL(tmp1,1);

			SetDongleData(Data[InnerLoopCounter],TempData,pKeyData);
			tmp2  = BitFromDongle+InnerLoopCounter+1;
			tmp2 &= 3;

			tmp3 = Data[tmp2]+tmp2+tmp1;
			tmp3 = BYTEROL(tmp3,1);

			Data[InnerLoopCounter]=tmp3;

			InnerLoopCounter++;
		}

		BitFromDongle=GetBitFromDongleData(TempData,pKeyData);
		SumOfBitFromDongle += BitFromDongle;

		OuterLoopCounter--;
	}


	*R ^=*tmpR;
	return SumOfBitFromDongle;
}

//---------------------------------------------------------------------------

extern "C" void __fastcall EncryptDword(DWORD MYDATA, PKEYDATA pKeyData,BYTE *ResponseData)
{
	HL_CODE_STRUCT TempData,*pTempData;
	pTempData=&TempData;

	InitgSeeds(pKeyData,pTempData);

	DWORD Data[0x02];

	RtlFillMemory(&Data[0],0x08,0);
	Data[1]=MYDATA;

	DWORD *R=&Data[0];
	DWORD *tmpR2=&Data[1];

	BYTE DongleBitCounter;
	DongleBitCounter = CipherFunction(R,tmpR2,pTempData,pKeyData);

	RtlCopyMemory(ResponseData, &Data[0x0], 4); //copy back crypted data
	RtlCopyMemory(ResponseData+4, &DongleBitCounter, 1); //copy back crypted data
}
//---------------------------------------------------------------------------
/*extern "C" void __fastcall HL_CALC(DWORD HlDataIn, PKEYDATA pKeyData,BYTE *ResponseData)
{
int i;
HL_CODE_STRUCT TempData,*pTempData;
pTempData=&TempData;

if ((pKeyData->password&0x1F0000)==0x1F0000)
{
InitgVar12(pTempData);
InitgSeeds(pKeyData,pTempData);

for (i = 0; i < 8; i++) {
BYTE	tData = (BYTE)(((HlDataIn >> 28) - ((i ^ 1) * 4)) & 0x0F);
pTempData->gVar1 ^= tData ^ pTempData->gSeedArray[pTempData->gPtrArray[pTempData->gVar1]];
pTempData->gVar4 = (pTempData->gVar4 << 1) | (pTempData->gPtrArray[pTempData->gVar1] & 1);
}
RtlCopyMemory(ResponseData, &pTempData->gVar4, 2);
}
else
{
BYTE Data[0x02]={0xFF,0xFE};
RtlCopyMemory(ResponseData, &Data[0x00], 2);
}

}
*/
extern "C" BYTE __fastcall HL_CALC(PKEYDATA pkeyData, USHORT p1, USHORT p2)
{
	ULONG Input;
	USHORT i, Var1, Var2, Var4, tmpPtr;
	BYTE  k, i1, i2, i3, i4, PtrArray[16], SeedArray[4], Output;

	if ((pkeyData->password&0x1F0000)==0x1F0000)   //old key
	{

		SeedArray[0] = (pkeyData->HdkSeed3 & 0xF000) >> 12;
		SeedArray[1] = (pkeyData->HdkSeed3 & 0xF00) >> 8;
		SeedArray[2] = (pkeyData->HdkSeed3 & 0xF0) >> 4;
		SeedArray[3] = pkeyData->HdkSeed3 & 0xF;

		for (i=0; i<16; i++) 
		{
			PtrArray[i]  = ((pkeyData->HdkSeed1 >> i) & 1) << 1;
			PtrArray[i] |= (pkeyData->HdkSeed2 >> i) & 1;
		}

		Output = 0;


		i1 = (p2 >> 8) & 0xFF;
		i2 = p2 & 0xFF;
		i3 = (p1 >> 8) & 0xFF;
		i4 = p1 & 0xFF;
		i1 = BYTEROL(i1, 4);
		i2 = BYTEROL(i2, 4);
		i3 = BYTEROL(i3, 4);
		i4 = BYTEROL(i4, 4);

		Input = ((ULONG)i1 << 24) | ((ULONG)i2 << 16) | ((ULONG)i3 << 8) | (ULONG)i4;

		//    KdPrint(("   input to HL_CALC = 0x%8.8X\n", Input));

		Var1 = 0xf;
		Var2 = 0x0;


		for(i=0; i<8; i++)
		{

			tmpPtr = PtrArray[Var1];

			Var1 ^= Input & 0x0F;
			Var1 ^= SeedArray[tmpPtr];

			Var2 = PtrArray[Var1];
			Var4 = tmpPtr | (Var4 << 4);

			Output <<= 1;
			Output |= PtrArray[Var1] & 1;
			Input >>= 4;
		}
		k=Output;
		Output=~(((k<<7)&0x80)|((k<<5)&0x40)|((k<<3)&0x20)|((k<<1)&0x10)|((k>>7)&0x01)|((k>>5)&0x02)|((k>>3)&0x04)|((k>>1)&0x08));
	}
	else   { Output=0xFF; }

	return Output;
}

//---------------------------------------------------------------------------
extern "C" void __fastcall HL_CODE (PKEYDATA pKeyData,BYTE *ResponseData) // 0x 38 byte data that actual data is in 0x28
{

	HL_CODE_STRUCT TempData,*pTempData;
	pTempData=&TempData;

	InitgSeeds(pKeyData,pTempData);

	BYTE Data[0x50];

	RtlFillMemory(&Data[0],0x38,0);
	RtlCopyMemory(&Data[0x28], &pKeyData->HdkTempMem[0], 8); //copy data to crypt

	BYTE *tmpData=Data;
	WORD *DongleBitCounter=(WORD *)(Data+0x1C);
	int LoopCounter=6;


	DWORD *L=(DWORD *)&Data[0x28];
	DWORD *R=(DWORD *)&Data[0x2C];
	DWORD *tmpR1=(DWORD *)&Data[0x20];
	DWORD *tmpR2=(DWORD *)&Data[0x24];

	while(LoopCounter>0) {
		*tmpR1=*R;
		*tmpR2=*R;

		*DongleBitCounter += CipherFunction(R,tmpR2,pTempData,pKeyData);
		*R ^= *L;

		*L=*tmpR1;

		tmpData+=4;
		*(DWORD *)(tmpData-4)=*tmpR2;

		LoopCounter--;
	}

	RtlCopyMemory(ResponseData+0x00, &Data[0x04], 4); //copy back crypted data
	RtlCopyMemory(ResponseData+0x04, &Data[0x00], 4); //copy back crypted data
	RtlCopyMemory(ResponseData+0x08, &Data[0x0C], 4); //copy back crypted data
	RtlCopyMemory(ResponseData+0x0C, &Data[0x08], 4); //copy back crypted data
	RtlCopyMemory(ResponseData+0x10, &Data[0x14], 4); //copy back crypted data
	RtlCopyMemory(ResponseData+0x14, &Data[0x10], 4); //copy back crypted data
	RtlCopyMemory(ResponseData+0x18, &Data[0x1C], 2); //copy back crypted data

}


//---------------------------------------------------------------------------

extern "C" void InitgSeeds(PKEYDATA pKeyData,PHL_CODE_STRUCT TempData)
{
	TempData->gSeedArray[0]=(pKeyData->HdkSeed3 & 0xF000) >> 12;
	TempData->gSeedArray[1]=(pKeyData->HdkSeed3 & 0xF00) >> 8;
	TempData->gSeedArray[2]=(pKeyData->HdkSeed3 & 0xF0) >> 4;
	TempData->gSeedArray[3]=pKeyData->HdkSeed3 & 0xF;

	int i;
	for (i=0; i<16; i++) {
		TempData->gPtrArray[i]  = ((pKeyData->HdkSeed1 >> i) & 1) << 1;
		TempData->gPtrArray[i] |= (pKeyData->HdkSeed2 >> i) & 1;
	}

}

//---------------------------------------------------------------------------

WORD Transform0_HW(WORD W0, WORD retW, PHL_CODE_STRUCT TempData, PKEYDATA pKeyData)
{
	for (int i=0; i<4; ++i) {
		for (int j=0; j<4; ++j) {
			SetDongleData((W0 & 0xFF) >> 2,TempData,pKeyData);
			if (W0 & 0x8000) {
				W0 <<= 1; W0++;
			}
			else {
				W0 <<= 1;
			}
		}
		retW >>= 1;
		DWORD nb=(TempData->gVar4 >> 12) & 1;
		if (nb == 0) {
			//tmpStatus++;
			retW |= 0x8000;
		}
	}

	return retW;
}

//---------------------------------------------------------------------------

WORD transform0(WORD WORD3, WORD WORD4, PHL_CODE_STRUCT TempData, PKEYDATA pKeyData)
{
	InitgVar12(TempData);
	WORD ax = WORD4 ^ Transform0_HW(WORD4, Transform0_HW( WORD3, 0, TempData,pKeyData),TempData,pKeyData);
	ax = (ax >> 15)+(ax << 1);
	((BYTE*)&ax)[0] = (((BYTE*)&ax)[0] + ((BYTE*)&ax)[1]) & 0xFF;
	return ax;
}

//---------------------------------------------------------------------------

extern "C" void __fastcall HL_CRYPT(PKEYDATA pKeyData,BYTE *ResponseData)  // 0x8 byte data that actual data is in 0x0
{
	WORD Word1, Word2, Word3, Word4;
	//BYTE i=0;
	//tmpStatus = 0;
	BYTE *Data=ResponseData;

	HL_CODE_STRUCT TempData,*pTempData;
	pTempData=&TempData;

	InitgSeeds(pKeyData,pTempData);

	Word1 = ((WORD*)Data)[0];
	Word2 = ((WORD*)Data)[1];
	Word3 = ((WORD*)Data)[2];
	Word4 = ((WORD*)Data)[3];
	for (int i=0; i<5; i++ ) {
		WORD transf = Word3^Word4^transform0(Word3,Word4,pTempData,pKeyData);
		BYTE tmp1=((BYTE*)&transf)[1]+((BYTE*)&transf)[0];
		tmp1=tmp1*2+(tmp1>>7);
		tmp1++;
		tmp1=tmp1*2+(tmp1>>7);
		BYTE tmp2=((BYTE*)&transf)[0]+tmp1;
		tmp2=tmp2*2+(tmp2>>7);
		tmp2=tmp2*2+(tmp2>>7);
		transf=(tmp1<<8)+tmp2;
		WORD _Word4=transf+Word4;
		_Word4=((_Word4+1)&0xFF)+(_Word4&0xFF00);
		_Word4=(_Word4>>15)+(_Word4*2);
		_Word4=(_Word4>>15)+(_Word4*2);
		transf^=Word1;
		_Word4^=Word2;
		Word1=Word3;
		Word2=Word4;
		Word3^=transf;
		Word4^=_Word4;
	}
	((WORD*)Data)[0] = Word3;
	((WORD*)Data)[1] = Word4;
	((WORD*)Data)[2] = Word1;
	((WORD*)Data)[3] = Word2;
	//      if ((tmpStatus<=0x26)&&(tmpStatus>=2))
	//              return 1;
	//      else
	//              return 0;
}

//---------------------------------------------------------------------------
