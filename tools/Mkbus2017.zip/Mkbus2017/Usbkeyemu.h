/*++

Copyright (c) 2004 Chingachguk & Denger2k All Rights Reserved

Module Name:

USBKeyEmu.h

Abstract:

This module contains the common private declarations
for the emulation of USB bus and HASP key

Environment:

kernel mode only

Notes:

Revision History:

--*/

#include "EncDecSim.h" // KEY_INFO

#ifndef USBKeyEmu_H
#define USBKeyEmu_H

//
// The generic ids for installation of key pdo
//
#define VUSB_COMPATIBLE_IDS L"USB\\VID_0529&PID_0001\0"
#define VUSB_COMPATIBLE_IDS_LENGTH sizeof(VUSB_COMPATIBLE_IDS)

#define BUS_HARDWARE_IDS L"USB\\VID_0529&PID_0001&Rev_0325\0\0"
#define BUS_HARDWARE_IDS_LENGTH sizeof (BUS_HARDWARE_IDS)

#define VUSB_COMPATIBLE_SENT_IDS L"USB\\VID_04b9&PID_0300\0"
#define VUSB_COMPATIBLE_SENT_IDS_LENGTH sizeof(VUSB_COMPATIBLE_SENT_IDS)

#define BUS_HARDWARE_SENT_IDS L"USB\\VID_04b9&PID_0300&Rev_0004\0\0"
#define BUS_HARDWARE_SENT_IDS_LENGTH sizeof (BUS_HARDWARE_SENT_IDS)

#define VUSB_COMPATIBLE_GRD_IDS L"USB\\VID_0A89&PID_0001\0"
#define VUSB_COMPATIBLE_GRD_IDS_LENGTH sizeof(VUSB_COMPATIBLE_GRD_IDS)

#define BUS_HARDWARE_GRD_IDS L"USB\\VID_0A89&PID_0001&Rev_0000\0\0"
#define BUS_HARDWARE_GRD_IDS_LENGTH sizeof (BUS_HARDWARE_GRD_IDS)

#define VENDORFW_H6  L"HASP HL 3.25   "
#define VENDORFW_H5  L"HASP HL 2.16"
#define VENDORFW_H4  L"HASP4 USB 1.33"
#define VENDOR1  L"AKS"

#define VENDORNAME_HASP  L"SafeNet "
#define MODEL_HASP       L"USB Key"
//
// Automatic insert keys on startup of driver
//
#define INSERT_ALL_KEYS_ON_STARTUP 1

//
// Path to dumps in registry
//
#define DUMP_PATH_STR L"\\Registry\\MACHINE\\System\\CurrentControlSet\\Mkbus"

//
// Description of key data
//
#pragma pack(1)
BYTE tmpbuf[48];
BYTE tmpbuf2[48];

//
//
// List of supported dongles
//
enum DONGLE_TYPE {
	DONGLE_HASP                     = 0x01,
	DONGLE_HARDLOCK                 = 0x02,
	DONGLE_SENTINEL                 = 0x03
};

typedef struct _PVH
{
	IN ULONG Size;
	IN ULONG SerialNo;
	IN ULONG password;
	IN WCHAR Dump_name[20]; //name of dump in registry
	//IN  WCHAR   HardwareIDs[];

} PVH, *PPVH;

typedef struct _HASPTIMEMEMORY
{
	UCHAR curr_time[3]; // time, BCD, SS:MM:HH
	UCHAR curr_date[4]; // date, BCD, DD:MM:WW:YY (WW - weekday ?)
	UCHAR rezerv1[0x19]; // ???
	UCHAR Id[8]; // Id of TIME HASP (4 bytes, but real is - 8?)
	UCHAR FAS[0x10]; // FAS ? There is some infos about progs - ? ExpiryDate's, etc - ?
} tHASPTIMEMEMORY;

typedef struct _KEY_DATA {
	//
	// Dongle type
	//
	UCHAR   DongleType;     // Type of Dongle (1-HASP,2-HARDLOCK,3-SENTINEL)
	//
	// Current key state
	//
	UCHAR   isInitDone;     // Is chiperkeys given to key
	UCHAR   isKeyOpened;    // Is valid password is given to key
	UCHAR   encodedStatus;  // Last encoded status
	UCHAR	srm_f2x_param[8]; // AF-2F
	USHORT  chiperKey1,     // Keys for chiper
		chiperKey2;

	//
	//Static information about HARDLOCK key
	//
	//UCHAR   HdkkeyType;   // Old or New Hardlock (0-old,1-new) NOT USED
	ULONG   HdkID;          // ID
	UCHAR   HdkHasMem;      //
	UCHAR   HdkMem[0x80];   // Memory content (0x60 ROM + 0x20 RAM)
	USHORT  HdkSeed1,       // Seeds for crypting
		HdkSeed2,
		HdkSeed3;

	UCHAR   HdkTempMem[8];    // Used for hl_code & hl_crypt calculation

	//Static information about SENTINEL key

	UCHAR   SentkeyType;    // Sentinel Type (0-SuperPro,1-UltraPro,2... other types)
	USHORT  CellMem[256];    // Memory content
	UCHAR   CellType[256];   // Cells type
	USHORT  ExtraCell[32];   //used for crypt algo 8 sets*4 bytes
	UCHAR   ExtraOfs;       //offset in ExtraCell array
	UCHAR   request;
	UCHAR   SentTempMem[80];
	ULONG   SentBufLen;         //������ ������ �������, ��� ������ ������ >8

	//
	// Static information about HASP key
	//
	UCHAR   keyType;        // Type of key
	UCHAR   memoryType;     // Memory size of key
	ULONG   password;       // Password for key
	UCHAR   options[14];    // Options for key
	UCHAR   secTable[8];    // ST for key
	UCHAR   netMemory[16];  // NetMemory for key
	tHASPTIMEMEMORY HASPTIMEMEMORY;
	LONGLONG TimeShift;     // Time shift (relativly OS time)
	UCHAR   memory[0x1000]; // Memory content
	KEY_INFO KEY_INFOdata;  // columnMask & prepNotMask
	int QisFound;           //���������� ������������ - ������ �� ������ - ��� ������ ���� ��������� ������ ���� ��������
	long QA_Buff_Len;       //����� ������� �� Q&A
	UCHAR EncDecType;       //��� �������� ��� ������� 1�/9E, 0-encrypt, 1-decrypt
	UCHAR EncDecValue;      //�������� �������, 0 1 2 - �������, 4 5 6 - �������
	UCHAR lastQA_buff[48];  //����� ������ ���������� ������� ������� 1�
	WCHAR d_name[20];       //��� ������� �������
	UCHAR AesKey[16];       // AES key for encrypt-decrypt
} KEY_DATA, *PKEYDATA;
#pragma pack()
//
// List of supported functions for HASP key
//
enum KEY_FN_LIST {
	//Hasp HL - function
	KEY_FN_SET_CHIPER_KEYS              = 0x80,
	KEY_FN_CHECK_PASS                   = 0x81,
	KEY_FN_READ_3WORDS                  = 0x82,
	KEY_FN_WRITE_WORD                   = 0x83,
	KEY_FN_READ_ST                      = 0x84,
	KEY_FN_READ_NETMEMORY_3WORDS        = 0x8B,
	KEY_FN_HASH_DWORD                   = 0x98,
	KEY_FN_ECHO_REQUEST                 = 0xA0,   // Echo request to key
	KEY_FN_GET_TIME                     = 0x9C,   // Get time (for HASP time) key
	KEY_FN_PREPARE_CHANGE_TIME          = 0x1D,   // Prepare to change time (for HASP time)
	KEY_FN_COMPLETE_WRITE_TIME          = 0x9D,   // Write time (complete) (for HASP time)
	KEY_FN_PREPARE_DECRYPT              = 0x1E,   // HASP HL Decrypt question // name is diferent in older souce:KEY_FN_PREPARE_DECRYPT
	KEY_FN_COMPLETE_DECRYPT             = 0x9E,   // HASP HL Decrypt answer //name is diferent in older souce:KEY_FN_COMPLETE_DECRYPT
	//Hasp SRM - function
	KEY_FN_READ_STRUCT                  = 0xA1,
	KEY_FN_SRM_A2						= 0xA2,	  // name is diferent in other souce
	KEY_FN_READ_26						= 0x26,	  // name is diferent in older souce
	KEY_FN_READ_A6						= 0xA6,	  // name is diferent in older souce
	KEY_FN_SRM_2F						= 0x2F,
	KEY_FN_SRM_AF						= 0xAF,
	KEY_FN_LOGIN                        = 0xAA,
	KEY_FN_LOGOUT                       = 0xAB
};

//
// List of supported functions for HARDLOCK key
//
enum HARDLOCK_KEY_FN_LIST {
	HDK_KEY_FN_SET_CHIPER_KEYS          = 0x80,
	HDK_KEY_FN_CHECK_PASS               = 0x81,
	HDK_KEY_FN_READ_WORD                = 0x82,
	HDK_KEY_FN_WRITE_WORD               = 0x83,
	HDK_KEY_FN_HL_VERKEY                = 0x87,
	HDK_KEY_FN_READ_ID                  = 0x8B,
	HDK_KEY_FN_HL_CODE                  = 0x8C,
	HDK_KEY_FN_HL_CRYPT                 = 0x8D,
	HDK_KEY_FN_HL_CODE_PAR              = 0x0C,
	HDK_KEY_FN_HL_CRYPT_PAR             = 0x0D,
	HDK_KEY_FN_HL_CALC					= 0x89
};

//
// List of supported functions for Sentinel key
//
enum SENT_KEY_FN_LIST {
	SENT_KEY_FN_FIND_FIRST_UNIT          = 0x10,
	SENT_KEY_FN_READ                     = 0x11,
	SENT_KEY_FN_QUERY_SHORT              = 0x12,
	SENT_KEY_FN_QUERY_LONG               = 0x13,
	SENT_KEY_FN_WRITE_0                  = 0x14,
	SENT_KEY_FN_WRITE_1                  = 0x15,
	SENT_KEY_FN_WRITE_2                  = 0x16,
	SENT_KEY_FN_WRITE_3                  = 0x17,
	SENT_KEY_FN_OVERWRITE_0              = 0x18,
	SENT_KEY_FN_OVERWRITE_1              = 0x19,
	SENT_KEY_FN_OVERWRITE_2              = 0x1A,
	SENT_KEY_FN_OVERWRITE_3              = 0x1B,
	SENT_KEY_FN_ACTIVATE                 = 0x1C,
	SENT_KEY_FN_DECREMENT                = 0x1D,
	SENT_KEY_FN_GET_KEYINFO              = 0x00,
	SENT_KEY_FN_SET_PARAMETER            = 0x03,
	SENT_KEY_FN_GET_PARAMETER            = 0x02,
	USENT_KEY_FN_GET_LOGIN               = 0x05,   //for ULTRA
	USENT_KEY_FN_LOGIN_21                = 0x21,
	USENT_KEY_FN_AES_QUERY               = 0x07,
	USENT_KEY_FN_2F                      = 0x2F
};

//
// Status of operation with HASP key
//
enum KEY_OPERATION_STATUS {
	KEY_OPERATION_STATUS_OK                     = 0,
	KEY_OPERATION_STATUS_ERROR                  = 1,
	KEY_OPERATION_STATUS_INVALID_MEMORY_ADDRESS = 4,
	KEY_OPERATION_STATUS_LAST                   = 0x1F
};

//
// Structure for request to HASP key
//
#pragma pack(1)
typedef struct _KEY_REQUEST {
	UCHAR   majorFnCode;    // Requested fn number (type of KEY_FN_LIST)
	USHORT  param1,         // Key parameters
		param2, param3;
} KEY_REQUEST, *PKEY_REQUEST;

//
// Structure for respond of HASP key
//
typedef struct _KEY_RESPONSE {
	UCHAR           status,         // Status of operation (type of KEY_OPERATION_STATUS)
		encodedStatus;  // CRC of status and majorFnCode
	UCHAR           data[48];       // Output data
} KEY_RESPONSE, *PKEY_RESPONSE;

#pragma pack()

//
// Structure for request to SENTINEL key
//
#pragma pack(1)
typedef struct _KEY_SENT_REQUEST {
	UCHAR   majorFnCode;    // Requested fn number (type of KEY_FN_LIST)
	UCHAR   cellno;
	USHORT  param1;         // Key parameters
	USHORT  param2;         // Key parameters
	USHORT  CryptSeed;      // Key parameters
	USHORT  data[80];      //for ultra
} KEY_SENT_REQUEST, *PKEY_SENT_REQUEST;

//
// Structure for respond of SENTINEL key
//
typedef struct _KEY_SENT_RESPONSE {
	UCHAR           CRC,         //
		status;       //
	USHORT          data1;     // Output data
	USHORT          data2;     // Output data
	USHORT      CryptSeed;
	UCHAR       data3[80];    //for ultra , �������� �����
} KEY_SENT_RESPONSE, *PKEY_SENT_RESPONSE;
#pragma pack()

//
// Defined in USBKeyEmu.c
//
__drv_dispatchType(IRP_MJ_INTERNAL_DEVICE_CONTROL) // mew
	DRIVER_DISPATCH Bus_HandleUSBIoCtl;
NTSTATUS Bus_HandleUSBIoCtl(IN  PDEVICE_OBJECT  DeviceObject,
	IN  PIRP            Irp);
NTSTATUS Bus_LoadDumpFromRegistry (PPVH pvh,
	PKEYDATA keyData);
NTSTATUS Bus_LoadDumpsFromRegistry(IN  PDEVICE_OBJECT DeviceObject);

void _Chiper(VOID *bufPtr,
	ULONG bufSize,
	PUSHORT key1Ptr,
	PUSHORT key2Ptr);
void Chiper(VOID *buf,
	ULONG size,
	PKEYDATA pKeyData);
void EmulateKey(PKEYDATA pKeyData,
	PKEY_REQUEST request,
	PULONG outBufLen,
	PKEY_RESPONSE outBuf);
void EmulateKeyHARDLOCK(PKEYDATA pKeyData,
	PKEY_REQUEST request,
	PULONG outBufLen,
	PKEY_RESPONSE outBuf);
// for Sentinel
// void ChiperSent(VOID *buf);
void EmulateKeySent(PKEYDATA pKeyData,
	PKEY_SENT_REQUEST request,
	PULONG outBufLen,
	PKEY_SENT_RESPONSE outBuf);
LONG GetMemorySize(PKEYDATA pKeyData);
NTSTATUS GetRegKeyData(HANDLE hkey,
	PWCHAR subKey,
	VOID *data,
	ULONG needSize);
ULONG GetRegKeyDataSize(HANDLE hkey,
	PWCHAR subKey);
void DelayExecutionThread();
extern int Store_KeyDataToRegister(PCWSTR DataTag, PVOID pKeyNewData, ULONG DataSize, PKEYDATA pKeyData);

#endif
