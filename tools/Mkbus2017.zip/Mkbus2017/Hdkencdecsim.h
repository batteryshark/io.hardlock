//---------------------------------------------------------------------------
#ifndef HdkEncDecSimH
#define HdkEncDecSimH

#include "USBKeyEmu.h"

//---------------------------------------------------------------------------
typedef UCHAR   BYTE;
typedef USHORT  WORD;
typedef ULONG   DWORD;
//---------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif

	//---------------------------------------------------------------------------

	typedef struct _HL_CODE_STRUCT {
		WORD gVar1;
		WORD gVar2;
		WORD gVar4;
		WORD tmpStatus;
		BYTE gPtrArray[16];
		BYTE gSeedArray[4];
	} HL_CODE_STRUCT,*PHL_CODE_STRUCT;

	//---------------------------------------------------------------------------

	WORD Transform0_HW(WORD W0, WORD retW, PHL_CODE_STRUCT TempData,PKEYDATA pKeyData);
	WORD transform0(WORD WORD3, WORD WORD4, PHL_CODE_STRUCT TempData,PKEYDATA pKeyData);
	void __fastcall HL_CRYPT(PKEYDATA pKeyData,BYTE *ResponseData);
	BYTE __fastcall HL_CALC(PKEYDATA pkeyData, USHORT p1, USHORT p2);
	void __fastcall EncryptDword(DWORD MYDATA, PKEYDATA pKeyData, BYTE *ResponseData);
	void __fastcall HL_CODE(PKEYDATA pKeyData,BYTE *ResponseData);

	void SetDongleData(BYTE Data,PHL_CODE_STRUCT TempData,PKEYDATA pKeyData);
	BYTE GetBitFromDongleData(PHL_CODE_STRUCT TempData,PKEYDATA pKeyData);
	void InitgVar12(PHL_CODE_STRUCT TempData);
	void InitgSeeds(PKEYDATA pKeyData,PHL_CODE_STRUCT TempData);

	BYTE BYTEROL(BYTE Value,BYTE Shift);

	//---------------------------------------------------------------------------
#ifdef __cplusplus
}
#endif
//---------------------------------------------------------------------------
#endif
