/*++

Copyright (c) 2004 Chingachguk & Denger2k All Rights Reserved

Module Name:

Debug.c

Abstract:

Debug functions

Environment:

kernel mode only

Notes:


Revision History:


--*/
#include <ntddk.h>
#include <wdm.h>
#include <stdarg.h>
#include <usbdi.h>                                //C
#include "usbdlib.h"                              //C
#include <windef.h>                               //C
#include <stdlib.h>                               //C
#include <stdio.h>
#include <ntstrsafe.h>
#include "Debug.h"

#ifdef ALLOC_PRAGMA
#ifdef DEBUG_FULL
#pragma alloc_text (PAGE, PrintBufferContent)
#pragma alloc_text (PAGE, LogMessage)
#endif
#endif

//
// Global Debug Level
//

#if DBG
void PrintBufferContent512(WCHAR *prefix, UCHAR *in_buffer, ULONG in_buffer_length)
{
	WCHAR output_wstring[512] = {0};
	WCHAR tmp_wstr[8] = {0};
	ULONG i;

	RtlZeroMemory(output_wstring, sizeof(output_wstring));

	// Check parameters
	if (!in_buffer)
	{
		RtlStringCbPrintfExW(output_wstring, sizeof(output_wstring), NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"NULL (ptr to data)");
		return;
	}

	if (in_buffer_length <= 0)
	{
		RtlStringCbPrintfExW(output_wstring, sizeof(output_wstring), NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"NULL (length)");
		return;
	}

	// Create string
	output_wstring[0] = 0;
	output_wstring[1] = 0;
	output_wstring[2] = 0;
	output_wstring[3] = 0;

	for (i = 0; i < in_buffer_length; i++)
	{
		RtlStringCbPrintfExW(tmp_wstr, sizeof(tmp_wstr),
			NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%02X", (UCHAR)in_buffer[i]);

		RtlStringCbCatExW(output_wstring, sizeof(output_wstring), tmp_wstr, NULL, NULL, STRSAFE_NO_TRUNCATION);
	}

	DPRINT("%ws%ws", prefix, output_wstring);

}
#else
#define PrintBufferContent512(exp) ((void) 0)
#endif

#ifdef DEBUG_FULL

// Routine Description:
// Print buffer content in hex format into string
// Arguments:
// outStr - ptr to output string buffer
// buf - ptr to buffer
// length - length of buffer
// Return Value: none
void PrintBufferContent(OUT PWCHAR outStr, UCHAR *buf, ULONG length)
{
	PWCHAR tmpBuf;
	ULONG i;

	PAGED_CODE ();

	// Check parameters
	if (!buf)
	{
		RtlStringCbPrintfExW(outStr, 4096, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"NULL (ptr to data)");
		return;
	}

	if (length <= 0)
	{
		RtlStringCbPrintfExW(outStr, 4096, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"NULL (length)");
		return;
	}

	// Create string
	outStr[0] = 0;
	outStr[1] = 0;
	outStr[2] = 0;
	outStr[3] = 0;

	tmpBuf = ExAllocatePoolWithTag (PagedPool, 512, VUSB_POOL_TAG);
	if (!tmpBuf)
		return;

	for (i = 0; i < length; i++)
	{
		RtlStringCbPrintfExW(tmpBuf, 512, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%02X ", (UCHAR)buf[i]);
		RtlStringCbCatExW(outStr, 4096, tmpBuf, NULL, NULL, STRSAFE_NO_TRUNCATION);
	}

	ExFreePoolWithTag(tmpBuf, VUSB_POOL_TAG);
}

CHAR messagebuf[4096] = {0};
CHAR buf[4096]= {0};

// Routine Description:
// Log msg into debug console and file
// Arguments:
// szFormat - message format string
// ... - data
// Return Value: NT status code
NTSTATUS LogMessage(PCHAR szFormat, ...)
{
	ULONG Length;
	// char messagebuf[1024];

	va_list va;

	IO_STATUS_BLOCK  IoStatus;

	OBJECT_ATTRIBUTES objectAttributes;
	NTSTATUS status;
	HANDLE FileHandle;
	UNICODE_STRING fileName;

	PAGED_CODE ();

	RtlZeroMemory(messagebuf, 4096);
	RtlZeroMemory(buf, 4096);

	//format the string
	va_start(va, szFormat);
	RtlStringCbVPrintfA(messagebuf, 4096, szFormat, va);
	va_end(va);

	//get a handle to the log file object
	fileName.Buffer = NULL;
	fileName.Length = 0;
	fileName.MaximumLength = sizeof(DEFAULT_LOG_FILE_NAME) + sizeof(UNICODE_NULL)+2;

	fileName.Buffer = ExAllocatePoolWithTag(PagedPool, fileName.MaximumLength, VUSB_POOL_TAG);

	if (!fileName.Buffer)
	{
		DbgPrint ("LogMessageInFile: FAIL. ExAllocatePool Failed.\n");
		return FALSE;
	}

	RtlZeroMemory(fileName.Buffer, fileName.MaximumLength);

	status = RtlAppendUnicodeToString(&fileName, (PWSTR)DEFAULT_LOG_FILE_NAME);

	InitializeObjectAttributes (&objectAttributes,
		(PUNICODE_STRING)&fileName,
		OBJ_KERNEL_HANDLE | OBJ_CASE_INSENSITIVE,
		NULL, NULL);

	status = ZwCreateFile(&FileHandle,
		FILE_APPEND_DATA,
		&objectAttributes,
		&IoStatus,
		0,
		FILE_ATTRIBUTE_NORMAL,
		FILE_SHARE_WRITE,
		FILE_OPEN_IF,
		FILE_SYNCHRONOUS_IO_NONALERT,
		NULL, 0);

	if (NT_SUCCESS(status))
	{
		// CHAR buf[1024];

		RtlStringCbPrintfExA(buf, 4096, NULL, NULL, STRSAFE_NULL_ON_FAILURE, "%s", messagebuf);

		//format the string to make sure it appends a newline carrage-return to the
		//end of the string.
		Length = strlen(buf);
		if (buf[Length-1] == '\n')
		{
			buf[Length-1] = '\r';
			RtlStringCbCatExA(buf, 4096, "\n", NULL, NULL, STRSAFE_NULL_ON_FAILURE);
			Length++;
		}
		else
		{
			RtlStringCbCatExA(buf, 4096, "\r\n", NULL, NULL, STRSAFE_NULL_ON_FAILURE);
			Length+=2;
		}

		DbgPrint("%s", buf);
		ZwWriteFile( FileHandle, NULL, NULL, NULL, &IoStatus, buf, Length, NULL, NULL );
		ZwClose( FileHandle );
	}

	if (fileName.Buffer)
	{
		ExFreePoolWithTag(fileName.Buffer, VUSB_POOL_TAG);
	}

	return STATUS_SUCCESS;
}
#endif
