#ifndef H__CipSnt32
#define H__CipSnt32
#endif
void ChiperSent(BYTE *bufPtr)
{
	int i;

	ULONG ecx = bufPtr[6];
	ULONG edx = bufPtr[7];

	ULONG eax = 6;
	ULONG ebx = 0;

	for (i = 0; i < 6; i++)
	{
		eax = LOBYTE(eax) + LOBYTE(ecx);
		if (!(LOBYTE(eax) & 1))
			eax = eax ^ 0xBA;
		eax = eax >> 1;
		ecx = LOBYTE(ecx) ^ LOBYTE(eax);
		eax = LOBYTE(eax) + LOBYTE(edx);
		if (!(LOBYTE(eax) & 1))
			eax = eax + 0x126;
		eax = eax >> 1;
		edx = LOBYTE(eax);
		bufPtr[i] = bufPtr[i] ^ LOBYTE(edx);
	}

	edx = bufPtr[6];
	ebx = bufPtr[7];

	ecx = 6;

	for (i = 0; i < 6; i++)
	{
		// eax = LOBYTE(edx);
		eax = LOBYTE(edx) + LOBYTE(ecx);
		if (!(LOBYTE(eax) & 1))
			eax = eax ^ 0xBA;
		eax = eax >> 1;
		edx = LOBYTE(edx) ^ LOBYTE(eax);
		// ecx = LOBYTE(ebx);
		ecx = LOBYTE(ebx) + LOBYTE(eax);
		if (!(LOBYTE(ecx) & 1))
			ecx = ecx + 0x126;
		ecx = ecx >> 1;
		ebx = LOBYTE(ecx);
	}

	//  printf("eax %08X\n", eax);
	//  printf("ecx %08X\n", ecx);
	//  printf("edx %08X\n", edx);
	//  printf("ebx %08X\n", ebx);

	eax = LOBYTE(ecx);

	for (i = 5; i >= 0; i--)
	{
		// eax = LOBYTE(ecx);
		eax = LOBYTE(eax) + LOBYTE(ebx);
		if (!(LOBYTE(eax) & 1))
			eax = eax ^ 0xE4;
		eax = eax >> 1;
		ebx = LOBYTE(ebx) ^ LOBYTE(eax);
		// ecx = edx;
		edx = LOBYTE(edx) + LOBYTE(eax);
		if (!(LOBYTE(edx) & 1))
			edx = edx + 0x148;
		edx = edx >> 1;
		eax = bufPtr[i];
		eax = LOBYTE(eax) + LOBYTE(edx);
		// ecx = LOBYTE(eax);
		bufPtr[i] = LOBYTE(eax);
	}
}
