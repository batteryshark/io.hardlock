﻿/*++

Copyright (c) 2004 Chingachguk & Denger2k All Rights Reserved

Module Name:

USBKeyEmu.c

Abstract:

This module contains routines for emulation of USB bus and USB HASP key.

Environment:

kernel mode only

Revision History:

--*/

#include <ntddk.h>
#include <wdm.h>
#include <stdarg.h>
#include <usbdi.h>                                //C
#include "usbdlib.h"                              //C
#include <windef.h>                               //C
#include <stdlib.h>                               //C
#include <stdio.h>

#include "Chiper.h"
#include "Data.h"
#include ".\Include\driver.h"
#include "vusb.h"
#include "EncDecSim.h"
#include "HdkEncDecSim.h"
#include "SentEncDecSim.h"
#include "Aes.h"

#ifdef ALLOC_PRAGMA
#pragma alloc_text (PAGE, Bus_HandleUSBIoCtl)
#pragma alloc_text (PAGE, EmulateKey)
#pragma alloc_text (PAGE, EmulateKeyHARDLOCK)
#pragma alloc_text (PAGE, EmulateKeySent)
#pragma alloc_text (PAGE, _Chiper)
#pragma alloc_text (PAGE, Chiper)
#pragma alloc_text (PAGE, GetMemorySize)
#pragma alloc_text (PAGE, Bus_LoadDumpsFromRegistry)
#pragma alloc_text (PAGE, Bus_LoadDumpFromRegistry)
#pragma alloc_text (PAGE, Store_KeyDataToRegister)
#endif

static WCHAR DUMP_PATH[] = DUMP_PATH_STR;
static ULONG LastPassword; // Last presented password missing in 64 bit
#define _ROL(x,n) ( ((x) << (n)) | ((x) >> (8-(n))) )
#define _ROR(x,n) ( ((x) >> (n)) | ((x) << (8-(n))) )

//--------------------------------------- New SRM Algo ----------------------------------------
//----------------------------------------------------------------------------------------
void ConvertToSecondsFrom1970(CONST PLARGE_INTEGER pFrom, PULONG pTo, PULONG pMillseconds)
	//----------------------------------------------------------------------------------------
{
	TIME_FIELDS tf1970;
	LARGE_INTEGER t1970, tmp;

	if(!pFrom || !pTo) return;

	tf1970.Year = 1970;
	tf1970.Day = 1;
	tf1970.Hour = 0;
	tf1970.Minute = 0;
	tf1970.Second = 1;
	tf1970.Month = 1;
	tf1970.Milliseconds = 0;

	RtlTimeFieldsToTime(&tf1970, &t1970);
	tmp.QuadPart = pFrom->QuadPart - t1970.QuadPart;
	*pTo = (ULONG)(*((__int64 *) &tmp) / 10000000U);

	if(pMillseconds)
	{
		*pMillseconds = (ULONG)(*((__int64 *) &tmp) % 10000000U) / 1000;
	}
}

//-----------------------------------------
void hasplms_3_25_transform(void * buffer)
	//-----------------------------------------
{
	UCHAR c_buf[16];

	UCHAR mask[64] = 
	{
		1, 0, 7, 6, 5, 4, 3, 2,
		0, 7, 6, 5, 4, 3, 2, 1, 
		0, 7, 6, 5, 4, 3, 2, 1,
		6, 5, 4, 3, 2, 1, 0, 7, 
		6, 5, 4, 3, 2, 1, 0, 7, 
		3, 2, 1, 0, 7, 6, 5, 4, 
		3, 2, 1, 0, 7, 6, 5, 4, 
		7, 6, 5, 4, 3, 2, 1, 0
	};

	UCHAR vector[8] =
	{
		0x58, 0xB1, 0xDC, 0x4C, 0x43, 0xF6, 0xF8, 0xC7
	};

	UCHAR is_box[256] = 
	{
		0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 
		0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb, 
		0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87, 
		0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb, 
		0x54, 0x7b, 0x94, 0x32, 0xa6, 0xc2, 0x23, 0x3d, 
		0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e, 
		0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 
		0x76, 0x5b, 0xa2, 0x49, 0x6d, 0x8b, 0xd1, 0x25, 
		0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16, 
		0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92, 
		0x6c, 0x70, 0x48, 0x50, 0xfd, 0xed, 0xb9, 0xda, 
		0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84, 
		0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 
		0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06, 
		0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02, 
		0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b, 
		0x3a, 0x91, 0x11, 0x41, 0x4f, 0x67, 0xdc, 0xea, 
		0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73, 
		0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 
		0xe2, 0xf9, 0x37, 0xe8, 0x1c, 0x75, 0xdf, 0x6e, 
		0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89, 
		0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b, 
		0xfc, 0x56, 0x3e, 0x4b, 0xc6, 0xd2, 0x79, 0x20, 
		0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4, 
		0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 
		0xb1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xec, 0x5f, 
		0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d, 
		0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef, 
		0xa0, 0xe0, 0x3b, 0x4d, 0xae, 0x2a, 0xf5, 0xb0, 
		0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61, 
		0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 
		0xe1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0c, 0x7d
	};

	UCHAR ecx = 0, ebx;
	int i, j = 0, k;

	memcpy((void*)&c_buf, buffer, 16);

	for(k=0; k < 4; k++)
	{
		for(i=0; i < 16; i++)
		{
			ecx = c_buf[i];
			ecx = is_box[ecx];
			c_buf[i] = ecx;
			ebx = mask[j];
			j++;
			ebx = vector[ebx];
			ebx = ebx^ecx;
			c_buf[i] = ebx;
			ecx++;
		}
	}

	memcpy(buffer, (void*)&c_buf, 16);

	return;
}
//--------------------------------------- New SRM Algo End ------------------------------------

void _Chiper(void *bufPtr, ULONG bufSize, PUSHORT key1Ptr, PUSHORT key2Ptr) {
	/*++
	Routine Description:

	Encode/decode response/request to key

	Arguments:

	bufPtr - pointer to a encoded/decoded data

	bufSize - size of encoded information

	key1Ptr, key2Ptr - ptr to chiper keys

	Return Value:

	none

	--*/
	ULONG i, j;
	UCHAR tmpDL;
	UCHAR *p= (UCHAR *)bufPtr;

	if (bufSize)
	{
		for (i= 0; i < bufSize; i++)
		{
			tmpDL= 0;
			for (j= 0; j < 4; j++)
			{
				tmpDL<<= 1;
				if ( (*key1Ptr)&0x01 )
				{
					tmpDL|= 0x1;
					*key1Ptr= ((*key1Ptr^*key2Ptr)>>1)|0x8000;
				}
				else
				{
					*key1Ptr>>= 1;
				}
				tmpDL<<= 1;
				if ( (*key1Ptr)&0x80 ) tmpDL|= 0x01;
			}
			*p++^= tmpDL;
		}
	}
}

void Chiper(VOID *buf, ULONG size, PKEYDATA pKeyData) {
	/*++
	Routine Description:

	Encode/decode response/request to key (stub only)

	Arguments:

	bufPtr - pointer to a encoded/decoded data

	bufSize - size of encoded information

	pKeyData - ptr to key data

	Return Value:

	none

	--*/
	LogMessage ("Chiper inChiperKey1=%08X, inChiperKey2=%08X, length=%X\n",
		pKeyData->chiperKey1, pKeyData->chiperKey2, size);
	_Chiper(buf, size, &pKeyData->chiperKey1, &pKeyData->chiperKey2);
	LogMessage ("Chiper outChiperKey1=%08X, outChiperKey2=%08X\n",
		pKeyData->chiperKey1, pKeyData->chiperKey2);
}

static sub_12D50(UCHAR ValidateByte, UCHAR *loopCnt)
{
	int i;

	for (i= 7; i >= 0; i--)
	{
		if ( (*loopCnt= (*loopCnt<<1)|((ValidateByte>>i)&0x01))&0x10 ) *loopCnt^= 0x0D;
		*loopCnt&= 0x0F;
	}
}

ULONG CheckEncodedStatus(UCHAR AdjustedReqCode, UCHAR SetupKeysResult, UCHAR *BufPtr) {
	/*++
	Routine Description:

	Check encoded status (byte after status) for validity

	Arguments:

	AdjustedReqCode - pointer to ((requested fn code) & 7E)

	SetupKeysResult - data[0] response of key to 0x80 function

	BufPtr - ptr to status byte

	Return Value:

	bool, 1 - encoded status ok, 0 - wrong encoded status

	--*/
	UCHAR loopCnt= 0x0F;

	if ( ( !AdjustedReqCode ) || ( SetupKeysResult < 2 ) )
		return( (*BufPtr <= 0x0F ) ? 1 : 0 );
	if ( *BufPtr > 0x1F )
		return(0);
	sub_12D50(*BufPtr, &loopCnt);
	sub_12D50(*(BufPtr+1), &loopCnt);
	return( ( loopCnt > 0 ) ? 0 : 1 );
}

/*
Ф-ия считывает параметр keyData->keyType
затем делается расшифровка, в итоге у нас
есть след. ключи:
112 байт,
128 байт,
496 байт,
4048 байт.
размер памяти возвращается в eax
*/
LONG GetMemorySize(PKEYDATA pKeyData) {
	/*
	Routine Description:
	Compute memory size of key in bytes
	Arguments:
	pKeyData - ptr to key data
	Return Value:
	memory size of key in bytes
	*/
	if (pKeyData->memoryType==1)
		return 0x80;//0x80h - для HL
	if (pKeyData->memoryType==4)
		return 0x1F0;//496 - 0x01F0
	if (pKeyData->memoryType==0x20)//0x20
		return 0xFD0;// 0x0FD0 - для HL
	if (pKeyData->memoryType==0x21)
		return 0x70;
	else return 0xFD0;/*memoryType==0x21*/
}

// Store key data (memory, etc) to register (after update it by KEY_FN_WRITE_WORD, etc)
// ZwSetValueKey(hkey, &valname, 0, REG_BINARY, pKeyData->memory, (ULONG)GetMemorySize(pKeyData));
extern int Store_KeyDataToRegister(PCWSTR DataTag, PVOID pKeyNewData, ULONG DataSize, PKEYDATA pKeyData)
{
	NTSTATUS status;
	HANDLE hkey;
	WCHAR path[128];
	UNICODE_STRING usPath;
	OBJECT_ATTRIBUTES oa;
	KIRQL IRQL;

	// Check current IRQL (ZwCreateFile doesnt works under IRQL > PASSIVE_LEVEL )
	if ( (IRQL= KeGetCurrentIrql()) != PASSIVE_LEVEL ) return(1);
	// Try to write data (memory of key) to registry
	RtlFillMemory(path, sizeof(path), 0); 
	RtlStringCbPrintfExW(path, 256, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%ws\\%ws", DUMP_PATH, pKeyData->d_name);
	RtlInitUnicodeString(&usPath, path);
	InitializeObjectAttributes(&oa, &usPath, OBJ_CASE_INSENSITIVE, NULL, NULL);
	status= ZwOpenKey(&hkey, KEY_WRITE, &oa);
	if ( NT_SUCCESS(status) )
	{
		UNICODE_STRING valname;
		// RtlInitUnicodeString(&valname, L"Data");
		RtlInitUnicodeString(&valname, DataTag);
		// ZwSetValueKey(hkey, &valname, 0, REG_BINARY, pKeyData->memory, (ULONG)GetMemorySize(pKeyData));
		ZwSetValueKey(hkey, &valname, 0, REG_BINARY, pKeyNewData, DataSize);
		ZwClose(hkey);
	}
	return( ( NT_SUCCESS(status) ) ? 0 : 1 );
}

// For HASP clock
static UCHAR ByteToBCD(UCHAR dByte)
{
	return( ((dByte/10)<<4)|(dByte%10) );
}

static UCHAR BCDToByte(UCHAR BCDByte)
{
	return( ((BCDByte>>4)*10)+(BCDByte&0xF) );
}

UCHAR* GetProcessNameInEprocess(UCHAR *pname)
{
	PEPROCESS peprocess;
	char *pnameoffset;
	if ( OffsetNameInErpocess )
	{
		peprocess = IoGetCurrentProcess();
		DPRINT("EPROCESS=%08X offset=%04X\n",peprocess,OffsetNameInErpocess);
		pnameoffset = (char *)peprocess + OffsetNameInErpocess;
		DPRINT("EPROCESS+offset=%08X\n",pnameoffset);
		RtlCopyMemory(pname,pnameoffset,16);
	}
	return pname;
}

#if DBG
static WCHAR *AesEncryptionTypes[] =
{
	L"QUERY 16 ENCRYPT   ", // 0x0
	L"QUERY 16 DECRYPT   ", // 0x1
	L"QUERY 32-16        ", // 0x2
	L"QUERY 32           ", // 0x3
	L"QUERY 48 ENCRYPT   ", // 0x4
	L"QUERY 48 DECRYPT   ", // 0x5
	L"QUERY 32 ENCRYPT 32", // 0x6
	L"QUERY 32 DECRYPT 32", // 0x7
	L"QUERY 32 ENCRYPT 20", // 0x8
	L"QUERY 32 DECRYPT 20", // 0x9
	L"QUERY 16-32 ENCRYPT", // 0xA
	L"QUERY 16-32 DECRYPT"  // 0xB
};
#endif
//
// Emulate HASP Sentinel HL / SRM / HL / HASP4 dongle
//

void EmulateKey(PKEYDATA pKeyData, PKEY_REQUEST request, PULONG outBufLen, PKEY_RESPONSE outBuf) 
{
	UCHAR encodeOutData;
	UCHAR status;
	UCHAR encodedStatus;

	ULONG outDataLen;
	ULONG Length = 0;

	KEY_RESPONSE *pResp = NULL;

	LARGE_INTEGER time;
	static int WrittenTIMEDataLen;
	static int WrittenTIMEDataOfs;

	//
	// Get time data, it used as random number source
	//
	NTSTATUS        status1;
	HANDLE          hkey;
	WCHAR           path[128];
	UNICODE_STRING  usPath;
	OBJECT_ATTRIBUTES oa;

	WCHAR KeyName96[96] = {0};
	ULONG SecurityFlag = 0;

	//	UCHAR name[20];
	//	UCHAR *pname = &name[0];

	PAGED_CODE();

	//	RtlFillMemory(&name[0], 20, 0);
	//	GetProcessNameInEprocess(pname);
	//	DPRINT("Hasp key : Process name is %s\n", name);

	pResp = (KEY_RESPONSE *)ExAllocatePoolWithTag (PagedPool, sizeof(KEY_RESPONSE), VUSB_POOL_TAG);
	if(pResp == NULL)
		return;

	RtlZeroMemory(pResp, sizeof(KEY_RESPONSE));
	pResp->status = KEY_OPERATION_STATUS_ERROR;

	outDataLen = 0;
	encodeOutData = 0;

	Length = *outBufLen;

	KeQueryTickCount(&time);
#ifdef DBG
	switch (request->majorFnCode)
	{
	case KEY_FN_SET_CHIPER_KEYS:
		DPRINT("KEY_FN_SET_CHIPER_KEYS\n");
		break;
	case KEY_FN_CHECK_PASS:
		DPRINT("KEY_FN_CHECK_PASS\n");
		break;
	case KEY_FN_READ_NETMEMORY_3WORDS:
		DPRINT("KEY_FN_READ_NETMEMORY_3WORDS\n");
		break;
	case KEY_FN_READ_3WORDS:
		DPRINT("KEY_FN_READ_3WORDS\n");
		break;
	case KEY_FN_WRITE_WORD:
		DPRINT("KEY_FN_WRITE_WORD\n");
		break;
	case KEY_FN_READ_ST:
		DPRINT("KEY_FN_READ_ST\n");
		break;
	case KEY_FN_HASH_DWORD:
		DPRINT("KEY_FN_HASH_DWORD\n");
		break;
	case KEY_FN_ECHO_REQUEST:
		DPRINT("KEY_FN_ECHO_REQUEST\n");
		break;
	case KEY_FN_LOGIN:
		DPRINT("KEY_FN_LOGIN\n");
		break;
	case KEY_FN_LOGOUT:
		DPRINT("KEY_FN_LOGOUT\n");
		break;
	case KEY_FN_SRM_2F:
		DPRINT("KEY_FN_SRM_2F\n");
		break;
	case KEY_FN_SRM_AF:
		DPRINT("KEY_FN_SRM_AF\n");
		break;
	case KEY_FN_SRM_A2:
		DPRINT("KEY_FN_SRM_A2\n");
		break;
	case KEY_FN_READ_26:
		DPRINT("KEY_FN_READ_26\n");
		break;
	case KEY_FN_READ_A6:
		DPRINT("KEY_FN_READ_A6\n");
		break;
	case KEY_FN_GET_TIME:
		DPRINT("KEY_FN_GET_TIME\n");
		break;
	case KEY_FN_PREPARE_CHANGE_TIME:
		DPRINT("KEY_FN_PREPARE_CHANGE_TIME\n");
		break;
	case KEY_FN_COMPLETE_WRITE_TIME:
		DPRINT("KEY_FN_COMPLETE_WRITE_TIME\n");
		break;
	case KEY_FN_PREPARE_DECRYPT:
		DPRINT("KEY_FN_PREPARE_DECRYPT\n");
		break;
	case KEY_FN_COMPLETE_DECRYPT:
		DPRINT("KEY_FN_COMPLETE_DECRYPT\n");
		break;
	case KEY_FN_READ_STRUCT:
		DPRINT("KEY_FN_READ_STRUCT\n");
		break;
	default:
		DPRINT("UNKNOWN_HASP_FUNC : 0x%X\n", request->majorFnCode);
		break;
	}

	DPRINT("Value = %04X Index = %04X p3 = %04X\n",
		request->param1, request->param2, request->param3);

#endif

	//
	// Analyse fn number
	//
	LogMessage ("Analyse fn number\n");

	// DPRINT("HASP_FN_XXX_REQUEST=%02X (%08X)",request->majorFnCode,pKeyData->HdkID); // sp ?????

	switch (request->majorFnCode) 
	{
	case KEY_FN_SET_CHIPER_KEYS:              // 6C F4 DB 97 D3 6C 08
		pKeyData->chiperKey1 = request->param1;
		pKeyData->chiperKey2 = 0xA0CB;
		// DPRINT("CHIPER %04X %04X \n", pKeyData->chiperKey1, pKeyData->chiperKey2);

		// Setup random encoded status begin value
		pKeyData->encodedStatus = (UCHAR)pKeyData;
		pKeyData->isInitDone = 1;

		// Make key response
		pResp->status = KEY_OPERATION_STATUS_OK;
		pResp->data[0] = 0x02;

		// Time hasp or usual hasp
		pResp->data[1] = 0x0A;
		pResp->data[1] = ((pKeyData->netMemory[4] == 3) || (pKeyData->netMemory[4] == 5)) ? 0x1A : 0x0A;

		DPRINT("keyType %02x\n", pKeyData->keyType);
		if ( pKeyData->keyType > 5 )
			// HASP 3 Time  - 0x12
			// HASP 4 M1    - 0x0A
			// HASP 4 Time  - 0x1A
			// Hasp HL Time - 0xDA
			// Hasp HL      - 0xEA
			// Hasp SRM HL  - 0xFA
			pResp->data[1] = pKeyData->keyType;
		else
			pResp->data[1] = 0x0A;            // default value

		pResp->data[2] = 0x00;

		// Bytes 3, 4 - key sn, set it to low word of ptr to key data - WRONG

		pResp->data[3] = (UCHAR)(((USHORT)pKeyData) & 0xFF);
		pResp->data[4] = (UCHAR)((((USHORT)pKeyData) >> 8) & 0xFF);

		outDataLen = 5;
		encodeOutData = 1;
		break;

	case KEY_FN_CHECK_PASS:
		// Decode pass
		Chiper(&request->param1, 4, pKeyData);

		DPRINT("reqPassword = %08X\n", *((PULONG)&request->param1));
		DPRINT("keyPassword = %08X\n", pKeyData->password);
		// Compare pass
		if (*((PULONG)&request->param1)==pKeyData->password && pKeyData->isInitDone==1)
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			// data[0], data[1] - memory size
			pResp->data[0] = (UCHAR)((GetMemorySize(pKeyData)) & 0xFF);
			pResp->data[1] = (UCHAR)((GetMemorySize(pKeyData) >> 8) & 0xFF);
			pResp->data[2] = 0x10;
			// pResp->data[2] = 0x70;            // - it works too ?
			outDataLen = 3;
			encodeOutData = 1;
			// FN_OPEN_KEY
			pKeyData->isKeyOpened = 1;
			// Store last accessed password
			LastPassword= pKeyData->password;
		}
		break;

	case KEY_FN_READ_NETMEMORY_3WORDS:
		// Decode offset into NetMemory
		Chiper(&request->param1, 2, pKeyData);
		// Typical data into NetMemory:
		// 12 1A 12 0F 03 00 70 00 02 FF 00 00 FF FF FF FF
		// 12 1A 12 0F - sn
		// 03 00 - key type
		// 70 00 - memory size in bytes
		// 02 FF - ?
		// 00 00 - net user count
		// FF FF - ?
		// FF - key type (FF - local, FE - net, FD - time)
		// FF - ?
		// Analyse memory offset
		if (pKeyData->isKeyOpened && request->param1 >= 0 && request->param1 <= 7)
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			RtlCopyMemory(&(pResp->data), &pKeyData->netMemory[request->param1*2], sizeof(USHORT) * 3);

			outDataLen = sizeof(USHORT) * 3;
			encodeOutData = 1;
		}
		break;

	case KEY_FN_READ_3WORDS:
		// Decode memory offset
		Chiper(&request->param1, 2, pKeyData);
		// Do read
		if (pKeyData->isKeyOpened && request->param1 >= 0 && (request->param1 * 2) < GetMemorySize(pKeyData))
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			RtlCopyMemory(&(pResp->data), &pKeyData->memory[request->param1*2], sizeof(USHORT) * 3);
			outDataLen = sizeof(USHORT) * 3;
			encodeOutData = 1;
		}
		break;

	case KEY_FN_WRITE_WORD:
		// Decode memory offset & value
		Chiper(&request->param1, 4, pKeyData);
		DPRINT("offset=%X data=%X\n", request->param1, request->param2);
		// Do write
		if (pKeyData->isKeyOpened && request->param1 >= 0 && (request->param1 * 2) < GetMemorySize(pKeyData))
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			RtlCopyMemory(&pKeyData->memory[request->param1*2], &request->param2, sizeof(USHORT));
			outDataLen = 0;
			encodeOutData = 0;
			// ... and store it
			if ( !Store_KeyDataToRegister(L"Data", &pKeyData->memory, (ULONG)GetMemorySize(pKeyData),pKeyData))
				pResp->status = KEY_OPERATION_STATUS_OK;
		}
		break;

	case KEY_FN_READ_ST:
		// Do read ST
		if (pKeyData->isKeyOpened)
		{
			LONG i;
			pResp->status = KEY_OPERATION_STATUS_OK;
			for (i = 7; i >= 0; i--)
				pResp->data[7-i] = pKeyData->secTable[i];
			outDataLen = 8;
			encodeOutData = 1;
		}
		break;

	case KEY_FN_HASH_DWORD:
		// Decode dword
		Chiper(&request->param1, 4, pKeyData);
		// Do hash dword
		if (pKeyData->isKeyOpened)
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			RtlCopyMemory(&(pResp->data), &request->param1, 4);
			Transform((DWORD *)pResp->data, &pKeyData->KEY_INFOdata);
			outDataLen = sizeof(ULONG);
			encodeOutData = 1;
		}
		break;

	case KEY_FN_GET_TIME:
		{
			LARGE_INTEGER CurrentTime;
			TIME_FIELDS TimeFields;

			if (pKeyData->isKeyOpened)
			{
				pResp->status = KEY_OPERATION_STATUS_OK;
				// Decode dword (parameters)
				// first byte == ofs in data_time[] memory (of key)
				// second byte == len of requested data_time[] from memory
				Chiper(&request->param1, 4, pKeyData);
				// Get system time
				KeQuerySystemTime(&CurrentTime);
				// Correct by self time shift
				*((LONGLONG *)&CurrentTime) += *((LONGLONG *)&pKeyData->TimeShift);
				RtlTimeToTimeFields(&CurrentTime, &TimeFields);
				// Make response
				if (!(request->param1 & 0xFF))
				{
					// Read time (3 bytes) from offset 0
					pResp->data[2] = ByteToBCD((UCHAR)TimeFields.Hour);
					pResp->data[1] = ByteToBCD((UCHAR)TimeFields.Minute);
					pResp->data[0] = ByteToBCD((UCHAR)TimeFields.Second);
				}
				else if ((request->param1 & 0xFF) == 3)
				{
					// Read date (4 bytes) from offset 3
					pResp->data[3] = ByteToBCD((UCHAR)(TimeFields.Year % 100));
					pResp->data[2] = ByteToBCD((UCHAR)TimeFields.Weekday);
					pResp->data[1] = ByteToBCD((UCHAR)TimeFields.Month);
					pResp->data[0] = ByteToBCD((UCHAR)TimeFields.Day);
				}
				else
				{
					// read TIME Memory ?
					RtlCopyMemory(&(pResp->data), &pKeyData->HASPTIMEMEMORY.curr_time[request->param1&0xFF], request->param1 >> 8);
				}
				outDataLen = (request->param1 >> 8);
				encodeOutData = 1;
			}
			break;
		}

	case KEY_FN_PREPARE_CHANGE_TIME:
		{
			if (pKeyData->isKeyOpened)
			{
				pResp->status = KEY_OPERATION_STATUS_OK;
				// Decode dword (parameters)
				// first byte == ofs in data_time[] memory (of key)
				// 4-th byte == len of writing data ? in data_time[] memory
				Chiper(&request->param1, 4, pKeyData);
				// Save offset & len of changing data (for KEY_FN_COMPLETE_WRITE_TIME)
				WrittenTIMEDataOfs = request->param1 & 0xFF;
				// Decode & save written data
				RtlCopyMemory(&pKeyData->HASPTIMEMEMORY.curr_time[WrittenTIMEDataOfs], outBuf, (WrittenTIMEDataLen = request->param2 >> 8));
				Chiper(&pKeyData->HASPTIMEMEMORY.curr_time[WrittenTIMEDataOfs], WrittenTIMEDataLen, pKeyData);
				// We haven't to do anymore: return to caller (like 0xA0 func)
				*outBufLen = 0;

				if(pResp)
					ExFreePoolWithTag(pResp, VUSB_POOL_TAG);
				return;
			}
			break;
		}

	case KEY_FN_COMPLETE_WRITE_TIME:
		{
			LARGE_INTEGER CurrentTime, SelfTime, NewTime;
			TIME_FIELDS TimeFields;

			if (pKeyData->isKeyOpened)
			{
				// Write date & time & etc to data_time[] memory of TIME HASP
				// Enter: no data (see KEY_FN_PREPARE_CHANGE_TIME)
				// Result: no data (only status & encoded status)
				// Here we must to update our clock (data_time[] memory)
				if (WrittenTIMEDataOfs >= 7)
				{
					if ( !Store_KeyDataToRegister(L"HaspTimeMemory", &pKeyData->HASPTIMEMEMORY, sizeof(pKeyData->HASPTIMEMEMORY), pKeyData) )
						pResp->status = KEY_OPERATION_STATUS_OK;
					break;                        // No date-time update
				}
				// Get current time (with TimeShift) in PLARGE_INTEGER format
				KeQuerySystemTime(&CurrentTime);
				*((LONGLONG *)&SelfTime) = *((LONGLONG *)&CurrentTime) + *((LONGLONG *)&pKeyData->TimeShift);
				RtlTimeToTimeFields(&SelfTime, &TimeFields);

				// Change TimeFields as aksusb requested us
				if (!WrittenTIMEDataOfs)
				{
					// Change time (ofs=0, len=3)
					pKeyData->HASPTIMEMEMORY.curr_time[0] &= 0x7F;
					TimeFields.Second = BCDToByte(pKeyData->HASPTIMEMEMORY.curr_time[0]);
					TimeFields.Minute = BCDToByte(pKeyData->HASPTIMEMEMORY.curr_time[1]);
					TimeFields.Hour = BCDToByte(pKeyData->HASPTIMEMEMORY.curr_time[2]);
				}
				else
				{
					// Change date (ofs=3, len=4)
					TimeFields.Day = BCDToByte(pKeyData->HASPTIMEMEMORY.curr_date[0]);
					TimeFields.Month = BCDToByte(pKeyData->HASPTIMEMEMORY.curr_date[1]);
					TimeFields.Year = BCDToByte(pKeyData->HASPTIMEMEMORY.curr_date[3]);
					if (TimeFields.Year < 90)
						TimeFields.Year += 2000;
					else
						TimeFields.Year += 1900;
				}
				// Convert time onto PLARGE_INTEGER format
				RtlTimeFieldsToTime(&TimeFields, &NewTime);
				// Calculate new time shift
				*((LONGLONG *)&pKeyData->TimeShift) = *((LONGLONG *)&NewTime) - *((LONGLONG *)&CurrentTime);
				if ( !Store_KeyDataToRegister(L"TimeShift", &pKeyData->TimeShift, sizeof(LONGLONG), pKeyData))
					pResp->status = KEY_OPERATION_STATUS_OK;
			}
			break;
		}

	case KEY_FN_PREPARE_DECRYPT: //1E - Question
		{
			if (pKeyData->isKeyOpened)
			{
				pKeyData->QA_Buff_Len = *outBufLen;

				DPRINT("CHIPER %04X %04X \n", pKeyData->chiperKey1, pKeyData->chiperKey2);

				Chiper(&request->param1, 4, pKeyData);
				Chiper(outBuf, pKeyData->QA_Buff_Len, pKeyData);

				pKeyData->EncDecType =  (request->param1 > 3) ? 1 : 0;
				pKeyData->EncDecValue = (request->param1 < 7) ? ((UCHAR)request->param1) : 8;

				RtlZeroMemory(pKeyData->lastQA_buff, sizeof(pKeyData->lastQA_buff));
				RtlCopyMemory(&pKeyData->lastQA_buff, outBuf, min(pKeyData->QA_Buff_Len, sizeof(pKeyData->lastQA_buff)));

				DPRINT("QA_Buff_Len = %02X\n", pKeyData->QA_Buff_Len);
				DPRINT("EncDecType  = %02X\n", pKeyData->EncDecType);
				DPRINT("EncDecValue = %02X\n", pKeyData->EncDecValue);

				// if (pKeyData->options[0]!= 0x69){DelayExecutionThread();}
				pResp->status = KEY_OPERATION_STATUS_OK;

				if(pResp)
					ExFreePoolWithTag(pResp, VUSB_POOL_TAG);

				return;
			}
			break;
		}

	case KEY_FN_COMPLETE_DECRYPT: //9E - Answer
		{
			if (pKeyData->isKeyOpened)
			{
				UCHAR a_a[48];
				UCHAR q_q[48];
				UCHAR k;
				aes_context ctx;

				// if (pKeyData->options[0]!= 0x69){DelayExecutionThread();}
				DPRINT("buffer length = %02X\n",pKeyData->QA_Buff_Len);
				RtlZeroMemory(a_a, sizeof(a_a));
				RtlZeroMemory(q_q, sizeof(q_q));
				RtlCopyMemory(&q_q, pKeyData->lastQA_buff,min(pKeyData->QA_Buff_Len, sizeof(q_q)));
				RtlCopyMemory(&a_a, pKeyData->lastQA_buff,min(pKeyData->QA_Buff_Len, sizeof(a_a)));

				if (pKeyData->EncDecType==0) 
				{ 
					RtlFillMemory(path, sizeof(path), 0);
					RtlStringCbPrintfExW(path, 256, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%ws\\%ws\\%ws", DUMP_PATH, pKeyData->d_name, L"ETable");
				} else { 
					RtlFillMemory(path, sizeof(path), 0);
					RtlStringCbPrintfExW(path, 256, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%ws\\%ws\\%ws", DUMP_PATH, pKeyData->d_name, L"DTable");
				}
				DPRINT("path : %ws\n",path);
				RtlInitUnicodeString(&usPath, path);
				InitializeObjectAttributes(&oa, &usPath, /* OBJ_KERNEL_HANDLE | */ OBJ_CASE_INSENSITIVE, NULL, NULL);
				status1 = ZwOpenKey(&hkey, KEY_READ, &oa);
				if (NT_SUCCESS(status1))
				{
					RtlFillMemory(&path[0],sizeof(path),0);
					switch(pKeyData->QA_Buff_Len)
					{
					case 0x10:
						{
							RtlFillMemory(path, sizeof(path), 0);
							RtlStringCbPrintfExW(path, 256, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%ws%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",L"10:",q_q[0],q_q[1],q_q[2],q_q[3],q_q[4],q_q[5],q_q[6],q_q[7],q_q[8],q_q[9],q_q[10],q_q[11],q_q[12],q_q[13],q_q[14],q_q[15]);
							DPRINT("ED : %ws\n",path);
						}
						break;
					case 0x20:
						{
							RtlFillMemory(path, sizeof(path), 0);
							RtlStringCbPrintfExW(path, 256, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%ws%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",L"20:",q_q[0],q_q[1],q_q[2],q_q[3],q_q[4],q_q[5],q_q[6],q_q[7],q_q[8],q_q[9],q_q[10],q_q[11],q_q[12],q_q[13],q_q[14],q_q[15],q_q[16],q_q[17],q_q[18],q_q[19],q_q[20],q_q[21],q_q[22],q_q[23],q_q[24],q_q[25],q_q[26],q_q[27],q_q[28],q_q[29],q_q[30],q_q[31]);
							DPRINT("ED : %ws\n",path);
						}
						break;
					case 0x30:
						{
							RtlFillMemory(path, sizeof(path), 0);
							RtlStringCbPrintfExW(path, 256, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%ws%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",L"30:",q_q[0],q_q[1],q_q[2],q_q[3],q_q[4],q_q[5],q_q[6],q_q[7],q_q[8],q_q[9],q_q[10],q_q[11],q_q[12],q_q[13],q_q[14],q_q[15],q_q[16],q_q[17],q_q[18],q_q[19],q_q[20],q_q[21],q_q[22],q_q[23],q_q[24],q_q[25],q_q[26],q_q[27],q_q[28],q_q[29],q_q[30],q_q[31]);
							DPRINT("ED : %ws\n",path);
						}
						break;
					}
					status1=GetRegKeyData(hkey, path, &q_q, 0x10);
					ZwClose(hkey);

				}
				if(!NT_SUCCESS(status1))
				{
					DPRINT("don't find in tables, EDValue = %02X\n",pKeyData->EncDecValue);
					switch(pKeyData->EncDecValue)
					{
					case 0:
						{
							aes_setkey_enc(&ctx,pKeyData->AesKey,128);
							aes_crypt_ecb(&ctx,10,a_a,q_q);
						} break;
					case 1:
						{
							aes_setkey_enc(&ctx,pKeyData->AesKey,128);
							aes_crypt_ecb(&ctx,10,a_a,q_q);
							for (k=0; k<16; k++) {q_q[k]^=a_a[k+16];}
						} break;
					case 2:
						{
							aes_setkey_enc(&ctx,pKeyData->AesKey,128);
							aes_crypt_ecb(&ctx,10,a_a,q_q);
							for (k=0; k<16; k++) {q_q[k]^=a_a[k+16];}
							for (k=0; k<16; k++) {q_q[k]^=a_a[k+32];}
						} break;
					case 4:
						{
							aes_setkey_dec(&ctx,pKeyData->AesKey,128);
							aes_crypt_ecb(&ctx,10,a_a,q_q);
						} break;
					case 5:
						{
							for (k=0; k<16; k++) {q_q[k]^=a_a[k+16];}
						} break;
					case 6:
						{
							for (k=0; k<16; k++) {a_a[k]^=a_a[k+16];}
							for (k=0; k<16; k++) {a_a[k]^=a_a[k+32];}
							aes_setkey_dec(&ctx,pKeyData->AesKey,128);
							aes_crypt_ecb(&ctx,10,a_a,q_q);
						} break;
					}
				}

				DPRINT("Out buffer : \n");
				PrintBufferContent512(L"Q_Q_HHL: " , q_q, sizeof(q_q));
				PrintBufferContent512(L"A_A_HHL: " , a_a, sizeof(a_a));

				pResp->status = KEY_OPERATION_STATUS_OK;
				RtlCopyMemory(&(pResp->data), &q_q, pKeyData->QA_Buff_Len);
				outDataLen=0x10;
				encodeOutData=1;
			}
			break;
		}

	case KEY_FN_ECHO_REQUEST:
	case KEY_FN_LOGIN:
	case KEY_FN_LOGOUT:
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			pResp->data[2] = 0x00;
			outDataLen = 1;
			*outBufLen = 1;
			RtlCopyMemory(outBuf, pResp->data, *outBufLen);

			if(pResp)
				ExFreePoolWithTag(pResp, VUSB_POOL_TAG);
			return;
		}

	case KEY_FN_READ_STRUCT:
		switch (request->param1)
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
		case 0:
			{
				UCHAR data[0x03]={0x01,0x00,0x00};
				RtlCopyMemory(outBuf, &data, 0x03);
				//outBuf->status+=1;
				break;
			}
		case 1:
			{
				UCHAR data[0x2F]={0x12,0x34,0x56,0x78, // SN
					0x06,0x01,0x00,0x00,
					0x02,0xCA,0x00,0x0E,0x00,0x00,0x39,0x37,
					0x02,0x24,0x00,0x02,0x00,0x02,0x00,0x00,
					0x03,0x19,0x22,0xC3,0x7B,0x00,0x00,0x00,
					0x00,0x00,0x00,0x00,0xF8,0x00,0x03,0x7E,
					0x00,0x00,0x92,0x8B, // VendorID
					0x00,0x00,0x00};
				data[0]=pKeyData->netMemory[3];
				data[1]=pKeyData->netMemory[2];
				data[2]=pKeyData->netMemory[1];
				data[3]=pKeyData->netMemory[0];
				RtlCopyMemory(outBuf, &data, 0x2F);
				break;
			}
		case 2:
			{
				UCHAR data[0x0E]={0x12,0x34,0x56,0x78, // SN
					0x00,0x00,0x01,0x00,0x01,0x21,0x00,0x00,0x01,0x00};
				data[0]=pKeyData->netMemory[3];
				data[1]=pKeyData->netMemory[2];
				data[2]=pKeyData->netMemory[1];
				data[3]=pKeyData->netMemory[0];
				RtlCopyMemory(outBuf, &data, 0x0E);
				break;
			}
		case 3:
			{
				UCHAR data[0x08]={0x00,0x00,0x08,0x00,0x00,0x00,0x00,0x00};
				RtlCopyMemory(outBuf, &data, 0x08);
				break;
			}
		}
		if(pResp)
			ExFreePoolWithTag(pResp, VUSB_POOL_TAG);
		return;

	case KEY_FN_SRM_2F:  //new srm check_pass
		{
			pResp->status = KEY_OPERATION_STATUS_OK;
			RtlZeroMemory(&pKeyData->srm_f2x_param[0],sizeof(pKeyData->srm_f2x_param));
			RtlCopyMemory(&pKeyData->srm_f2x_param[0], &request->param1, 0x04);
			RtlCopyMemory(&pKeyData->srm_f2x_param[4], outBuf, min(0x08,*outBufLen)); 
			DPRINT ("KEY_FN_SRM_2F\n");
		}
		if(pResp)
			ExFreePoolWithTag(pResp, VUSB_POOL_TAG);
		return;

	case KEY_FN_SRM_AF:  //new srm check_pass
		{
			aes_context ctx;
			UCHAR session_key[16]; 
			UCHAR Temp[16]; 
			UCHAR WorkAES[20]; 

			UCHAR aes[16]={0x79,0x4C,0xE1,0x88,0xCB,0xC1,0x78,0x53,0x11,0x69,0xE0,0xB2,0xCA,0x97,0xC9,0x76};
			DPRINT ("KEY_FN_SRM_AF\n");

			RtlZeroMemory(outBuf,*outBufLen); 
			RtlZeroMemory(&Temp,sizeof(Temp));

			Temp[0]=pKeyData->srm_f2x_param[0];

			aes_setkey_enc(&ctx, aes, 128);
			aes_crypt_ecb(&ctx,10,Temp,session_key);

			RtlZeroMemory(&WorkAES,sizeof(WorkAES));
			RtlZeroMemory(&Temp,sizeof(Temp));
			RtlCopyMemory(&Temp[8],&pKeyData->srm_f2x_param[4],0x08);
			Temp[2]=(Temp[8]^Temp[9])&0x1F;
			WorkAES[18]=Temp[2];

			aes_setkey_enc(&ctx, session_key, 128);
			aes_crypt_ecb(&ctx, 10, Temp, WorkAES);
			pResp->status = KEY_OPERATION_STATUS_OK;
			RtlCopyMemory(outBuf,&WorkAES,*outBufLen);
		}
		if(pResp)
			ExFreePoolWithTag(pResp, VUSB_POOL_TAG);
		return;

	case KEY_FN_SRM_A2:
		DPRINT ("param1=%02X len=%02X\n",request->param1,*outBufLen);
		pResp->status = KEY_OPERATION_STATUS_OK;
		if (request->param1 == 0 && *outBufLen == 0x07C1)
		{
			UCHAR data[0x07C1];
			UCHAR t[0x70]={0xFF,0xC0,0x00,0x00,0x00,0x04,0x04,0x00,
				0xFF,0xC1,0x00,0x04,0x00,0x01,0x00,0x01,
				0xFF,0xC2,0x00,0x05,0x00,0xFD,0x00,0x02,
				0xFF,0xC8,0x01,0x02,0x00,0x08,0x04,0x03,
				0xFF,0xC9,0x02,0x89,0x00,0x02,0x00,0x07,
				0xFF,0xCC,0x02,0x8B,0x00,0x06,0x04,0x0D,
				0xFF,0xF4,0x01,0x0A,0x00,0xFC,0x00,0x04,
				0xFF,0xF5,0x02,0x06,0x00,0x80,0x00,0x05,
				0xFF,0xCA,0x02,0x86,0x00,0x03,0x00,0x06,
				0xFF,0xCD,0x02,0x91,0x00,0x01,0x00,0x09,
				0xFF,0xCB,0x02,0x92,0x00,0x01,0x00,0x0B,
				0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
				0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
				0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
			RtlFillMemory(&data,0x07C1,0xFF);
			RtlCopyMemory(&data, &t, sizeof(t));
			data[0x07C0]=0x00;
			outDataLen = 0x07C1;
			*outBufLen = 0x07C1;
			RtlCopyMemory(outBuf, &data, *outBufLen);
		}
		else if (request->param1 == 0 && Length == 0x01A1)
		{
			UCHAR data[0x01A1];
			UCHAR t[0x70]={0xFF,0xC0,0x00,0x00,0x00,0x04,0x04,0x00,
				0xFF,0xC1,0x00,0x04,0x00,0x01,0x00,0x01,
				0xFF,0xC2,0x00,0x05,0x00,0xFD,0x00,0x02,
				0xFF,0xC8,0x01,0x02,0x00,0x08,0x04,0x03,
				0xFF,0xC9,0x02,0x89,0x00,0x02,0x00,0x07,
				0xFF,0xCC,0x02,0x8B,0x00,0x06,0x04,0x0D,
				0xFF,0xF4,0x01,0x0A,0x00,0xFC,0x00,0x04,
				0xFF,0xF5,0x02,0x06,0x00,0x80,0x00,0x05,
				0xFF,0xCA,0x02,0x86,0x00,0x03,0x00,0x06,
				0xFF,0xCD,0x02,0x91,0x00,0x01,0x00,0x09,
				0xFF,0xCB,0x02,0x92,0x00,0x01,0x00,0x0B,
				0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
				0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
				0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
			RtlFillMemory(&data,0x01A1,0xFF);
			RtlCopyMemory(&data, &t, sizeof(t));
			data[0x01A0]=0x00;
			outDataLen = 0x01A1;
			*outBufLen = 0x01A1;
			RtlCopyMemory(outBuf, &data, *outBufLen);
		}
		if(pResp)
			ExFreePoolWithTag(pResp, VUSB_POOL_TAG);
		return;

	default:
		{
			LogMessage ("Unknown_HASP_FN_XXX_REQUEST\n");
			DPRINT("Unknown_HASP_FN_XXX_REQUEST=%02X",request->majorFnCode);
			if (pKeyData->isKeyOpened)
			{
				pResp->status = KEY_OPERATION_STATUS_OK;
			}
			// return with no deal
			*outBufLen= 0;
			break;
		}
	}

	//
	// Return results
	//

	LogMessage ("Create encodedStatus\n"); // Create encodedStatus
	// Randomize encodedStatus
	pKeyData->encodedStatus ^= (UCHAR)time.LowPart;

	// If status in range
	if ((pResp->status >= KEY_OPERATION_STATUS_OK) && (pResp->status <= KEY_OPERATION_STATUS_LAST))
		// Then create encoded status
		do
		{
			pResp->encodedStatus = ++pKeyData->encodedStatus;
		}
		while (CheckEncodedStatus((UCHAR)(request->majorFnCode & 0x7F), 0x02, (UCHAR *)&pResp->status) == 0);

		// Store encoded status
		status = pResp->status;
		encodedStatus = pResp->encodedStatus;

		LogMessage ("Encoded status: %02X\n", encodedStatus);
		// Crypt status & encoded status
		Chiper(&pResp->status, 2, pKeyData);

		// Crypt output data
		if (encodeOutData)
		{
			Chiper(pResp->data, outDataLen, pKeyData);
		}

		// Shuffle encoding keys + Ching
		if (status == 0)
		{
			pKeyData->chiperKey2 = (pKeyData->chiperKey2 & 0xFF) | (encodedStatus << 8);
			LogMessage ("Shuffle keys: chiperKey1=%08X, chiperKey2=%08X,\n", pKeyData->chiperKey1, pKeyData->chiperKey2);
		}

		// Set out data size
		*outBufLen = min(sizeof(USHORT) + outDataLen, *outBufLen);
		LogMessage ("Out data size: %X\n", *outBufLen);

		// Copy data into out buffer
		RtlCopyMemory(outBuf, pResp, *outBufLen);

		if(pResp)
			ExFreePoolWithTag(pResp, VUSB_POOL_TAG);
}

//
// Emulate HARDLOCK dongle
//

void EmulateKeyHARDLOCK(PKEYDATA pKeyData, PKEY_REQUEST request, PULONG outBufLen, PKEY_RESPONSE outBuf) {
	/*++
	Routine Description:

	Emulation of key main procedure (IOCTL_INTERNAL_USB_SUBMIT_URB handler)

	Arguments:

	pKeyData - ptr to key data

	request - ptr to request buffer

	outBufLen - ptr to out buffer size variable

	outBuf - ptr to out buffer

	Return Value:

	none

	--*/
	UCHAR encodeOutData, status, encodedStatus;
	ULONG outDataLen;
	LARGE_INTEGER   time;
	ULONG IsParamFunction;
	ULONG Length = 0;
	KEY_RESPONSE *pResp = NULL;

	PAGED_CODE();

	pResp = (KEY_RESPONSE *)ExAllocatePoolWithTag (PagedPool, sizeof(KEY_RESPONSE), VUSB_POOL_TAG);
	if(pResp == NULL)
		return;

	RtlZeroMemory(pResp, sizeof(KEY_RESPONSE));
	pResp->status = KEY_OPERATION_STATUS_ERROR;

	outDataLen = 0;
	encodeOutData = 0;
	IsParamFunction=0;

	Length = *outBufLen;
	//
	// Get time data, it used as random number source
	//
	KeQueryTickCount(&time);

	//
	// Setup answer
	//
	LogMessage ("Setup answer\n");

	//
	// Analyse fn number
	//
	LogMessage ("Analyse HARDLOCK fn number\n");

	//        DPRINT("HL_FN_XXX_REQUEST=%02X (%08X)",request->majorFnCode,pKeyData->HdkID); // sp

	switch (request->majorFnCode) {
	case HDK_KEY_FN_SET_CHIPER_KEYS:
		LogMessage ("HDK_KEY_FN_SET_CHIPER_KEYS\n");
		pKeyData->chiperKey1=request->param1;
		pKeyData->chiperKey2=0xA0CB;
		// Setup random encoded status begin value
		pKeyData->encodedStatus=(UCHAR)pKeyData;
		pKeyData->isInitDone=1;

		// Make key response
		pResp->status=KEY_OPERATION_STATUS_OK;
		pResp->data[0]=0x01; //key type
		pResp->data[1]=0x01; //subkey type
		pResp->data[2]=0X00; //
		// Bytes 3, 4 - key sn, set it to low word of ptr to key data
		pResp->data[3]=(UCHAR)(((USHORT)pKeyData) & 0xFF);
		pResp->data[4]=(UCHAR)((((USHORT)pKeyData) >> 8) & 0xFF);
		outDataLen=5;
		encodeOutData=1;
		break;

	case HDK_KEY_FN_CHECK_PASS:
		// Decode pass
		Chiper(&request->param1, 4, pKeyData);
		// Show request
		LogMessage ("HDK_KEY_FN_CHECK_PASS pass=%08X, pKeyData->password=%08X, pKeyData->isInitDone=%X\n",
			*((PULONG)&request->param1), pKeyData->password, pKeyData->isInitDone);
		// Compare pass
		if (*((PULONG)&request->param1)==pKeyData->password && pKeyData->isInitDone==1) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			// data[0], data[1] - memory size
			pResp->data[0]=(pKeyData->HdkHasMem) ? 0x80:0x00;
			pResp->data[1]=0;
			pResp->data[2]=0x20;
			outDataLen=3;
			encodeOutData=1;
			// FN_OPEN_KEY
			pKeyData->isKeyOpened=1;
		}
		break;

	case HDK_KEY_FN_READ_WORD:
		// Decode memory offset
		Chiper(&request->param1, 2, pKeyData);
		// Do read
		LogMessage ("HDK_KEY_FN_READ_WORD offset = %X\n",request->param1);
		if (pKeyData->isKeyOpened && request->param1>=0 && (request->param1*2)<sizeof(pKeyData->HdkMem) && pKeyData->HdkHasMem) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			RtlCopyMemory(&(pResp->data), &pKeyData->HdkMem[request->param1*2], sizeof(USHORT)*3);
			outDataLen=sizeof(USHORT)*3;
			encodeOutData=1;
		}
		break;

	case HDK_KEY_FN_WRITE_WORD:
		LogMessage ("HDK_KEY_FN_WRITE_WORD\n");
		// Decode memory offset & value
		Chiper(&request->param1, 4, pKeyData);
		LogMessage ("offset=%X data=%X\n", request->param1, request->param2);
		// Do write
		if (pKeyData->isKeyOpened && request->param1>=0 && (request->param1*2)<sizeof(pKeyData->HdkMem) && pKeyData->HdkHasMem) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			RtlCopyMemory(&pKeyData->HdkMem[request->param1*2], &request->param2, sizeof(USHORT));
			outDataLen=0;
			encodeOutData=0;
			if ( !Store_KeyDataToRegister(L"HdkMemory", &pKeyData->HdkMem, (ULONG)GetMemorySize(pKeyData),pKeyData) )
				pResp->status=KEY_OPERATION_STATUS_OK;
		}
		break;

	case HDK_KEY_FN_READ_ID:
		Chiper(&request->param1, 2, pKeyData);
		LogMessage ("HDK_KEY_FN_READ_ID  ID = %X, offset = %X\n",pKeyData->HdkID, request->param1);
		if (pKeyData->isKeyOpened) {
			pResp->status=KEY_OPERATION_STATUS_INVALID_MEMORY_ADDRESS;
			if (request->param1==0x0D) {
				RtlCopyMemory(pResp->data+2, &pKeyData->HdkID, 4);
				pResp->status=KEY_OPERATION_STATUS_OK;
			}
			if (request->param1==0x0C) {
				RtlCopyMemory(pResp->data+4, &pKeyData->HdkID, 4);
				pResp->status=KEY_OPERATION_STATUS_OK;
			}
			outDataLen=6;
			encodeOutData=1;
		}
		break;

	case HDK_KEY_FN_HL_CRYPT_PAR:
		// Decode dword
		Chiper(&request->param1, 4, pKeyData);
		Chiper(&outBuf->status, 4, pKeyData);
		LogMessage ("HDK_KEY_FN_HL_CRYPT_PAR Data=%08X%08X \n",*((PULONG)&request->param1),*((PULONG)&outBuf->status));
		if (pKeyData->isKeyOpened) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			RtlCopyMemory(&pKeyData->HdkTempMem[4], &request->param1, 4);
			RtlCopyMemory(&pKeyData->HdkTempMem[0], &outBuf->status, 4);
			outDataLen=0;
			encodeOutData=0;
			IsParamFunction=1;
		}
		break;

	case HDK_KEY_FN_HL_CALC:
		Chiper(&request->param1, 4, pKeyData);
		DPRINT ("HDK_KEY_FN_HL_CALC Data=%08X \n",*((PULONG)&request->param1));
		if (pKeyData->isKeyOpened){
			pResp->status=KEY_OPERATION_STATUS_OK;
			pResp->data[0]=HL_CALC(pKeyData, request->param1, request->param2);
			DPRINT ("HDK_KEY_FN_HL_CALC Response=%04X \n",*((PULONG)&(pResp->data[0])));
			outDataLen=2;
			encodeOutData=1;
		}
		break;

	case HDK_KEY_FN_HL_CRYPT:
		// Decode dword
		if (pKeyData->isKeyOpened) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			LogMessage ("HDK_KEY_FN_HL_CRYPT BufferedData=%08X%08X \n",*((PULONG)&pKeyData->HdkTempMem[0]),*((PULONG)&pKeyData->HdkTempMem[4]));
			RtlCopyMemory(&(pResp->data), &pKeyData->HdkTempMem[0], 8);
			HL_CRYPT(pKeyData,(BYTE *)pResp->data);
			LogMessage ("HDK_KEY_FN_HL_CRYPT Response=%08X%08X \n",*((PULONG)&pResp->data[0]),*((PULONG)&pResp->data[4]));
			outDataLen=8;
			encodeOutData=1;
		}
		break;

	case HDK_KEY_FN_HL_CODE_PAR:
		// Decode dword
		Chiper(&request->param1, 4, pKeyData);
		Chiper(&outBuf->status, 4, pKeyData);
		LogMessage ("HDK_KEY_FN_HL_CODE_PAR Data=%08X%08X \n",*((PULONG)&request->param1),*((PULONG)&outBuf->status));
		// Copy data to crypt
		if (pKeyData->isKeyOpened) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			RtlCopyMemory(&pKeyData->HdkTempMem[0], &request->param1, 4);
			RtlCopyMemory(&pKeyData->HdkTempMem[4], &outBuf->status, 4);
			outDataLen=0;
			encodeOutData=0;
			IsParamFunction=1;
		}
		break;

	case HDK_KEY_FN_HL_CODE:
		LogMessage ("HDK_KEY_FN_HL_CODE\n");
		if (pKeyData->isKeyOpened) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			LogMessage ("HDK_KEY_FN_HL_CODE BufferedData=%08X%08X \n",*((PULONG)&pKeyData->HdkTempMem[0]),*((PULONG)&pKeyData->HdkTempMem[4]));
			HL_CODE(pKeyData,(BYTE *)pResp->data);
			LogMessage ("HDK_KEY_FN_HL_CODE Response=%08X%08X \n",*((PULONG)&pResp->data[0]),*((PULONG)&pResp->data[4]));
			LogMessage ("HDK_KEY_FN_HL_CODE Response=%08X%08X \n",*((PULONG)&pResp->data[8]),*((PULONG)&pResp->data[12]));
			LogMessage ("HDK_KEY_FN_HL_CODE Response=%08X%08X \n",*((PULONG)&pResp->data[16]),*((PULONG)&pResp->data[20]));
			LogMessage ("HDK_KEY_FN_HL_CODE Response=%04X \n",*((PUSHORT)&pResp->data[24]));
			outDataLen=0x1A;
			encodeOutData=1;
		}
		break;

	case HDK_KEY_FN_HL_VERKEY:
		// Decode dword
		Chiper(&request->param1, 4, pKeyData);
		LogMessage ("HDK_KEY_FN_HL_VERKEY request=%08X \n",*((PULONG)&request->param1));
		// Do hash dword
		if (pKeyData->isKeyOpened) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			EncryptDword(*((PULONG)&request->param1), pKeyData,(BYTE *)pResp->data);
			outDataLen=6;
			encodeOutData=1;
		}
		break;
		// sp
	default:
		{
			LogMessage ("Unknown_HL_FN_XXX_REQUEST\n");
			DPRINT("Unknown_HL_FN_XXX_REQUEST=%02X",request->majorFnCode);
			if (pKeyData->isKeyOpened)
			{
				pResp->status=KEY_OPERATION_STATUS_OK;
			}
			// return with no deal
			*outBufLen= 0;
			break;
		}
		// sp
	}

	//
	// Return results
	//

	if (IsParamFunction) {
		LogMessage ("Parameter function. Out data size = 0 \n");
		*outBufLen=0;
		return;
	}

	// Create encodedStatus
	LogMessage ("Create encodedStatus\n");
	// Randomize encodedStatus
	pKeyData->encodedStatus^=(UCHAR)time.LowPart;
	// If status in range KEY_OPERATION_STATUS_OK...KEY_OPERATION_STATUS_LAST
	if (pResp->status>=KEY_OPERATION_STATUS_OK && pResp->status<=KEY_OPERATION_STATUS_LAST)
		// Then create encoded status
		do 
		{
			pResp->encodedStatus=++pKeyData->encodedStatus;
		}
		while (CheckEncodedStatus((UCHAR)(request->majorFnCode & 0x7F), 0x02, (UCHAR *)&pResp->status) == 0);
		// Store encoded status
		status=pResp->status;
		encodedStatus=pResp->encodedStatus;
		LogMessage ("Encoded status: %02X\n", encodedStatus);

		// Crypt status & encoded status
		Chiper(&pResp->status, 2, pKeyData);

		// Crypt data
		if (encodeOutData)
		{
			Chiper(pResp->data, outDataLen, pKeyData);
		}

		// Shuffle encoding keys
		if (status==0)
		{
			pKeyData->chiperKey2=(pKeyData->chiperKey2 & 0xFF) | (encodedStatus << 8);
			LogMessage ("Shuffle keys: chiperKey1=%08X, chiperKey2=%08X,\n",
				pKeyData->chiperKey1, pKeyData->chiperKey2);
		}

		// Set out data size
		*outBufLen=min(sizeof(USHORT)+outDataLen, *outBufLen);
		LogMessage ("Out data size: %X\n", *outBufLen);

		// Copy data into out buffer
		RtlCopyMemory(outBuf, pResp, *outBufLen);

		if(pResp)
			ExFreePoolWithTag(pResp, VUSB_POOL_TAG);
}

//
// Emulate SENTINEL dongle
//

void EmulateKeySent(PKEYDATA pKeyData, PKEY_SENT_REQUEST request, PULONG outBufLen, PKEY_SENT_RESPONSE outBuf) {
	/*++
	Routine Description:

	Emulation of key main procedure (IOCTL_INTERNAL_USB_SUBMIT_URB handler)

	Arguments:

	pKeyData - ptr to key data

	request - ptr to request buffer

	outBufLen - ptr to out buffer size variable

	outBuf - ptr to out buffer

	Return Value:

	none

	--*/
	UCHAR encodeOutData;
	ULONG outDataLen;
	KEY_SENT_RESPONSE *pResp = NULL;
	ULONG Length = 0;
	LARGE_INTEGER   time;
	UCHAR * tmpPtr;
	UCHAR tmpInLQ[80];//
	UCHAR tmpOutLQ[80];//
	UCHAR tmpOutLQ_[80];
	ULONG tmpLenLQ; //длина лонг-квери кратно 4
	UCHAR tmpflag, k;  //биты крипт-сида

	ULONG i;

	ULONG Descriptor;
	UCHAR celltype;
	USHORT cellmem;
	USHORT tmpCryptSeed;

	NTSTATUS        status1;
	HANDLE          hkey;
	WCHAR           path[128];
	UNICODE_STRING  usPath;
	OBJECT_ATTRIBUTES oa;

	PAGED_CODE();

	pResp = (KEY_SENT_RESPONSE *)ExAllocatePoolWithTag (PagedPool, sizeof(KEY_SENT_RESPONSE), VUSB_POOL_TAG);
	if(pResp == NULL)
		return;

	RtlZeroMemory(pResp, sizeof(KEY_SENT_RESPONSE));
	pResp->status = KEY_OPERATION_STATUS_ERROR;

	outDataLen = 0;
	encodeOutData = 0;

	Length = *outBufLen;

	//
	// Get time data, it used as random number source
	//
	KeQueryTickCount(&time);

	//
	// Setup answer
	//
	DPRINT ("Setup answer\n");

	//Decrypt packet
	tmpPtr=&request->majorFnCode;
	// DPRINT ("In Packet before: %02X %02X %02X %02X %02X %02X %02X %02X \n",tmpPtr[0],tmpPtr[1],tmpPtr[2],tmpPtr[3],tmpPtr[4],tmpPtr[5],tmpPtr[6],tmpPtr[7]);

	ChiperSent(&request->majorFnCode);

	//
	// Analyse fn number
	//
	// tmpPtr=&request->majorFnCode;
	// DPRINT ("In Packet : %02X %02X %02X %02X %02X %02X %02X %02X \n",tmpPtr[0],tmpPtr[1],tmpPtr[2],tmpPtr[3],tmpPtr[4],tmpPtr[5],tmpPtr[6],tmpPtr[7]);

	DPRINT ("Analyse fn number\n");

	switch (request->majorFnCode) {

		//************************************************************************************************************************
		//************************************************************************************************************************
		//************************************************************************************************************************
	case SENT_KEY_FN_QUERY_LONG:
		if (pKeyData->SentkeyType==0)
		{
			DPRINT ("SENT_KEY_FN_QUERY_LONG(%X) Cell=%X, Data=%X%X\n",request->majorFnCode,request->cellno,request->param1,request->param2);
			pResp->status=KEY_OPERATION_STATUS_OK;
			if (pKeyData->CellType[request->cellno]==3) {
				ULONG QueryData[14];
				ULONG QDataOfs;LONG i;
				RtlZeroMemory(&QueryData, sizeof(QueryData));
				RtlCopyMemory(&QueryData[0],&request->param1,4);
				QDataOfs=1;
				for (i=pKeyData->ExtraOfs;i>=0;i-=2) {
					RtlCopyMemory(&QueryData[QDataOfs],&pKeyData->ExtraCell[i],4);
					QDataOfs++;
				}
				DPRINT ("celltype=%02X\n",pKeyData->CellType[request->cellno]);
				Descriptor=(pKeyData->CellMem[request->cellno+1] <<16) | pKeyData->CellMem[request->cellno];
				DPRINT ("DataIn %08.8X%08.8X%08.8X%08.8X%08.8X%08.8X%08.8X%08.8X%08.8X\n",QueryData[0],QueryData[1],QueryData[2],QueryData[3],QueryData[4],QueryData[5],QueryData[6],QueryData[7],QueryData[8]);
				DoQuery(&QueryData[0],14,Descriptor,pKeyData->CellMem[4],pKeyData->CellMem[6]);
				DPRINT ("DataOut %08.8X%08.8X%08.8X%08.8X%08.8X%08.8X%08.8X%08.8X%08.8X\n",QueryData[0],QueryData[1],QueryData[2],QueryData[3],QueryData[4],QueryData[5],QueryData[6],QueryData[7],QueryData[8]);
				QDataOfs=0;
				for (i=pKeyData->ExtraOfs;i>=0;i-=2) {
					RtlCopyMemory(&pKeyData->ExtraCell[i],&QueryData[QDataOfs],4);
					QDataOfs++;
				}
				RtlCopyMemory(&(pResp->data1),&QueryData[QDataOfs],4);
			} else      // для не алго ячеек ответ равер запросу !!!
			{
				ULONG QueryData[14];
				ULONG QDataOfs;LONG i;
				RtlZeroMemory(&QueryData, sizeof(QueryData));
				RtlCopyMemory(&QueryData[0],&request->param1,4);
				QDataOfs=1;
				for (i=pKeyData->ExtraOfs;i>=0;i-=2) {
					RtlCopyMemory(&QueryData[QDataOfs],&pKeyData->ExtraCell[i],4);
					QDataOfs++;
				}
				//Descriptor=(pKeyData->CellMem[request->cellno+1] <<16) | pKeyData->CellMem[request->cellno];
				//DPRINT ("DataIn %08.8X%08.8X%08.8X%08.8X%08.8X%08.8X%08.8X%08.8X%08.8X\n",QueryData[0],QueryData[1],QueryData[2],QueryData[3],QueryData[4],QueryData[5],QueryData[6],QueryData[7],QueryData[8]);
				//DoQuery(&QueryData[0],14,Descriptor,pKeyData->CellMem[4],pKeyData->CellMem[6]);
				//DPRINT ("DataIn %08.8X%08.8X%08.8X%08.8X%08.8X%08.8X%08.8X%08.8X%08.8X\n",QueryData[0],QueryData[1],QueryData[2],QueryData[3],QueryData[4],QueryData[5],QueryData[6],QueryData[7],QueryData[8]);
				QDataOfs=0;
				for (i=pKeyData->ExtraOfs;i>=0;i-=2) {
					RtlCopyMemory(&pKeyData->ExtraCell[i],&QueryData[QDataOfs],4);
					QDataOfs++;
				}
				RtlCopyMemory(&(pResp->data1),&QueryData[QDataOfs],4);
			}
		}
		//************************************************************************************************************************
		if (pKeyData->SentkeyType>=1)
		{
			DPRINT ("ultra SENT_KEY_FN_QUERY_LONG(%X) Cell=%X, BufLen=%02x, Data=%X%X%X%X\n",request->majorFnCode,request->cellno,*outBufLen,tmpPtr[2],tmpPtr[3],tmpPtr[4],tmpPtr[5]);
			pResp->status=KEY_OPERATION_STATUS_OK;
			DPRINT ("In Packet 01 : %02X %02X %02X %02X %02X %02X %02X %02X \n",tmpPtr[0],tmpPtr[1],tmpPtr[2],tmpPtr[3],tmpPtr[4],tmpPtr[5],tmpPtr[6],tmpPtr[7]);
			//декриптуем все данные
			for (i=1;i<(*outBufLen>>3);i++)
			{
				ChiperSent(&tmpPtr[i*8]);
				DPRINT ("In Packet %02X : %02X %02X %02X %02X %02X %02X %02X %02X \n",i+1,tmpPtr[i*8],tmpPtr[i*8+1],tmpPtr[i*8+2],tmpPtr[i*8+3],tmpPtr[i*8+4],tmpPtr[i*8+5],tmpPtr[i*8+6],tmpPtr[i*8+7]);
			}
			//копируем входные данные в буфер без крипт-сидов
			RtlFillMemory(&tmpOutLQ[0],sizeof(tmpOutLQ),0);        //обнуляем промежуточный буфер
			RtlFillMemory(&tmpInLQ[0],sizeof(tmpInLQ),0);
			RtlCopyMemory(&tmpInLQ[0],&request->param1,0x04); //копируем первые 4 байта
			for (i=1;i<(*outBufLen>>3);i++) //копируем в цикле остальные байты кроме крипт-сидов
			{
				RtlCopyMemory(&tmpOutLQ[(i-1)*6], &tmpPtr[i*8], 0x06);  //в буфере подряд данные кроме первой строки
			}
			//проверка содержимого
			for (i=0;i<(*outBufLen>>3);i++) 
			{
				DPRINT("TempOutLQ %02X :  %02X %02X %02X %02X %02X %02X %02X %02X \n",i+1,tmpPtr[i*8],tmpPtr[i*8+1],tmpPtr[i*8+2],tmpPtr[i*8+3],tmpPtr[i*8+4],tmpPtr[i*8+5],tmpPtr[i*8+6],tmpPtr[i*8+7]);
			}
			//определяем длину запроса(кратно 4)
			tmpLenLQ=*outBufLen-(*outBufLen>>3)*2-2;
			DPRINT("in_tmpLenLQ=%02x\n",tmpLenLQ);
			tmpflag=(tmpPtr[6]) & (0x06);
			// switch (tmpflag) { case 4 : tmpLenLQ-=2;case 2 : tmpLenLQ-=4; }
			if (tmpflag==4){tmpLenLQ-=2;}
			if (tmpflag==2){tmpLenLQ-=4;}
			DPRINT("tmpflag=%02X tmpLenLQ=%02x\n",tmpflag,tmpLenLQ);
			//формируем правильный буфер лонг-квери
			k=1;
			for (i=(tmpLenLQ>>2)-1;i>0;i--)
			{
				RtlCopyMemory(&tmpInLQ[k*4],&tmpOutLQ[(i-1)*4],0x04);
				k++;
			}

			if (pKeyData->CellType[request->cellno]==3) 
			{
				RtlFillMemory(&tmpOutLQ[0],sizeof(tmpOutLQ),0);
				RtlFillMemory(&tmpOutLQ_[0],sizeof(tmpOutLQ_),0);
				for (i=0;i<tmpLenLQ;i++) {tmpOutLQ_[i]=0x69^tmpInLQ[i];}
				RtlFillMemory(path, sizeof(path), 0);
				RtlStringCbPrintfExW(path, 256, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%ws\\%ws\\%ws%02x", DUMP_PATH, pKeyData->d_name,L"cell_",request->cellno);
				DPRINT("path : %ws\n",path);
				RtlInitUnicodeString(&usPath, path);
				InitializeObjectAttributes(&oa, &usPath, OBJ_CASE_INSENSITIVE, NULL, NULL);
				status1 = ZwOpenKey(&hkey, KEY_READ, &oa);
				if (NT_SUCCESS(status1))
				{
					RtlFillMemory(&path[0],sizeof(path),0);
					//swprintf(path,L"%02X%02X%02X%02X",tmpPtr[2],tmpPtr[3],tmpPtr[4],tmpPtr[5]);
					//DPRINT("ED first : %ws\n",path);
					//for (i=1;i<(*outBufLen>>3);i++) 
					//{
					//swprintf(path,L"%ws%02X%02X%02X%02X%02X%02X",path,tmpPtr[i*8],tmpPtr[i*8+1],tmpPtr[i*8+2],tmpPtr[i*8+3],tmpPtr[i*8+4],tmpPtr[i*8+5]);
					//}
					for (i=0;i<(tmpLenLQ>>2);i++) 
					{
						RtlFillMemory(path, sizeof(path), 0);
						RtlStringCbPrintfExW(path, 256, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%ws%02X%02X%02X%02X",path,tmpInLQ[i*4+0],tmpInLQ[i*4+1],tmpInLQ[i*4+2],tmpInLQ[i*4+3]);
					}
					DPRINT("ED : %ws tmpLenLQ=%02X tmpflag=%02X\n",path,tmpLenLQ,tmpflag);
					status1=GetRegKeyData(hkey, path, &tmpOutLQ_[0],tmpLenLQ);
					DPRINT("reg status : %x \n",status1);

					for (i=0;i<(*outBufLen>>3);i++)
					{
						DPRINT ("Reg data %02X : %02X %02X %02X %02X %02X %02X %02X %02X \n",i+1,tmpOutLQ_[i*8+0],tmpOutLQ_[i*8+1],tmpOutLQ_[i*8+2],tmpOutLQ_[i*8+3],tmpOutLQ_[i*8+4],tmpOutLQ_[i*8+5],tmpOutLQ_[i*8+6],tmpOutLQ_[i*8+7]);
					}
					ZwClose(hkey);
				}
				if (!NT_SUCCESS(status1))
					DPRINT("reg status : %x \n",status1);

				k=0;
				for (i=(tmpLenLQ>>2);i>0;i--)
				{
					RtlCopyMemory(&tmpOutLQ[k*4],&tmpOutLQ_[(i-1)*4],0x04);
					k++;
				}
				RtlCopyMemory(&(pResp->data1), &tmpOutLQ[0], 0x04);

				tmpPtr=&pResp->CRC;
				DPRINT ("out Packet before 01 : %02X %02X %02X %02X %02X %02X %02X %02X \n",tmpPtr[0],tmpPtr[1],tmpPtr[2],tmpPtr[3],tmpPtr[4],tmpPtr[5],tmpPtr[6],tmpPtr[7]);

				for (i=1;i<(*outBufLen>>3);i++)
				{
					RtlCopyMemory(&(pResp->data3[(i-1)*8]), &tmpOutLQ[i*6-2], 0x06);
					tmpCryptSeed=(USHORT)time.LowPart;
					tmpCryptSeed^=(USHORT)(i*1234);
					RtlCopyMemory(&(pResp->data3[i*8-2]), &tmpCryptSeed, 0x02);
					DPRINT ("Out Packet before %02X : %02X %02X %02X %02X %02X %02X %02X %02X \n",i+1,tmpPtr[i*8],tmpPtr[i*8+1],tmpPtr[i*8+2],tmpPtr[i*8+3],tmpPtr[i*8+4],tmpPtr[i*8+5],tmpPtr[i*8+6],tmpPtr[i*8+7]);
					ChiperSent(&(pResp->data3[(i-1)*8]));
				}
			}
			else 
			{
				k=0;
				for (i=(tmpLenLQ>>2);i>0;i--)
				{
					RtlCopyMemory(&tmpOutLQ[k*4],&tmpInLQ[(i-1)*4],0x04);
					k++;
				}
				RtlCopyMemory(&(pResp->data1), &tmpOutLQ[0], 0x04);

				tmpPtr=&pResp->CRC;
				DPRINT ("out Packet before 01 : %02X %02X %02X %02X %02X %02X %02X %02X \n",tmpPtr[0],tmpPtr[1],tmpPtr[2],tmpPtr[3],tmpPtr[4],tmpPtr[5],tmpPtr[6],tmpPtr[7]);

				for (i=1;i<(*outBufLen>>3);i++)
				{
					RtlCopyMemory(&(pResp->data3[(i-1)*8]), &tmpOutLQ[i*6-2], 0x06);
					tmpCryptSeed=(USHORT)time.LowPart;
					tmpCryptSeed^=(USHORT)(i*1234);
					RtlCopyMemory(&(pResp->data3[i*8-2]), &tmpCryptSeed, 0x02);
					DPRINT ("Out Packet before %02X : %02X %02X %02X %02X %02X %02X %02X %02X \n",i+1,tmpPtr[i*8],tmpPtr[i*8+1],tmpPtr[i*8+2],tmpPtr[i*8+3],tmpPtr[i*8+4],tmpPtr[i*8+5],tmpPtr[i*8+6],tmpPtr[i*8+7]);
					ChiperSent(&(pResp->data3[(i-1)*8]));
				} 
			}
		}
		//outDataLen=8;
		outDataLen=*outBufLen;
		encodeOutData=1;
		break;

		//************************************************************************************************************************
		//************************************************************************************************************************
		//************************************************************************************************************************
	case SENT_KEY_FN_QUERY_SHORT:
		if (pKeyData->SentkeyType==0)
		{
			DPRINT ("SENT_KEY_FN_QUERY_SHORT(%X) Cell=%X, BufLen=%x, Data=%X%X%X%X\n",request->majorFnCode,request->cellno,*outBufLen,tmpPtr[2],tmpPtr[3],tmpPtr[4],tmpPtr[5]);
			pResp->status=KEY_OPERATION_STATUS_OK;
			if (pKeyData->CellType[request->cellno]==3) {
				Descriptor=(pKeyData->CellMem[request->cellno+1] <<16) | pKeyData->CellMem[request->cellno];
				DoQuery((ULONG *)&request->param1,1,Descriptor,pKeyData->CellMem[4],pKeyData->CellMem[6]);
				pResp->data1 = request->param1;
				pResp->data2 = request->param2;
			} else {
				pResp->data1 = request->param1;
				pResp->data2 = request->param2;
			}
		}
		//************************************************************************************************************************
		if (pKeyData->SentkeyType>=1)
		{
			DPRINT ("ultra SENT_KEY_FN_QUERY_SHORT(%X) Cell=%X, BufLen=%02x, Data=%X%x%x%x\n",request->majorFnCode,request->cellno,*outBufLen,tmpPtr[2],tmpPtr[3],tmpPtr[4],tmpPtr[5]);
			pResp->status=KEY_OPERATION_STATUS_OK;
			RtlCopyMemory(&(pResp->data1), &request->param1, 0x04);
			if (pKeyData->CellType[request->cellno]==3)
			{
				pResp->data1^=0x69ad;
				pResp->data2^=0x5c9f;
				RtlFillMemory(path, sizeof(path), 0);
				RtlStringCbPrintfExW(path, 256, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%ws\\%ws\\%ws%02x", DUMP_PATH, pKeyData->d_name,L"cell_",request->cellno);
				DPRINT("path : %ws\n",path);
				RtlInitUnicodeString(&usPath, path);
				InitializeObjectAttributes(&oa, &usPath, /* OBJ_KERNEL_HANDLE | */ OBJ_CASE_INSENSITIVE, NULL, NULL);
				status1 = ZwOpenKey(&hkey, KEY_READ, &oa);
				if (NT_SUCCESS(status1))
				{
					RtlFillMemory(&path[0],sizeof(path),0);
					RtlStringCbPrintfExW(path, 256, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%02X%02X%02X%02X%",tmpPtr[2],tmpPtr[3],tmpPtr[4],tmpPtr[5]);
					DPRINT("ED : %ws\n",path);
					status1=GetRegKeyData(hkey, path, &(pResp->data1), 0x04);
					ZwClose(hkey);
				}
			}

		}
		outDataLen=8;
		encodeOutData=1;
		break;
		/********************************************************************************************
		*										Function 0x10										*
		*********************************************************************************************/
	case SENT_KEY_FN_FIND_FIRST_UNIT:
		DPRINT ("KEY_FN_FIND_FIRST_UNIT(%X) Cell=%X \n",request->majorFnCode,request->cellno);
		if ((pKeyData->CellType[request->cellno]>=3)||((request->cellno > 63)&&(pKeyData->SentkeyType==0))||((request->cellno > 255)&&(pKeyData->SentkeyType==1)) || ((request->cellno > 127)&&(pKeyData->SentkeyType==2)))
		{
			pResp->data1=0x0101;
			pResp->data2=0;
		}
		else
		{
			RtlCopyMemory(&(pResp->data1), &pKeyData->CellMem[request->cellno], sizeof(USHORT));
			pResp->data2=0;
			pResp->status=KEY_OPERATION_STATUS_OK;
		}
		outDataLen=8;
		encodeOutData=1;
		break;

		/*******************************************************************************************************
		*										Function 0x11													*
		********************************************************************************************************/
	case SENT_KEY_FN_READ:
		DPRINT ("KEY_FN_READ(%X) Cell %X \n",request->majorFnCode,request->cellno);
		if (((request->cellno > 63)&&(pKeyData->SentkeyType==0))||((request->cellno > 255)&&(pKeyData->SentkeyType==1)) || ((request->cellno > 127)&&(pKeyData->SentkeyType==2)))
		{
			pResp->data1=0x0101;
			pResp->data2=0;
		}
		else
		{
			if (pKeyData->CellType[request->cellno]>=3)
			{
				pResp->data1=0;
				pResp->data2=0x0003;
			}
			else
			{
				celltype = (pKeyData->CellType[request->cellno]) & 3;
				cellmem = pKeyData->CellMem[request->cellno];
				pResp->data1 = ((USHORT)time.LowPart & 0xFF00) | ((cellmem >> 14) & 3);
				pResp->data2 = (cellmem << 2) | celltype ;
				pResp->status=KEY_OPERATION_STATUS_OK;
			}
		}
		outDataLen=8;
		encodeOutData=1;
		break;

		/********************************************************************************************************
		*									Function 0x05														*
		********************************************************************************************************/
	case USENT_KEY_FN_GET_LOGIN:
		DPRINT ("KEY_FN_GET_LOGIN(%X) \n",request->majorFnCode);

		pResp->status=KEY_OPERATION_STATUS_OK;
		pResp->data1=0x7C07;	
		pResp->data2=0x0400;	

		outDataLen=8;
		encodeOutData=1;                    
		break;
		/********************************************************************************************************
		*									Function 0x21														*
		*********************************************************************************************************/
	case USENT_KEY_FN_LOGIN_21:
		DPRINT ("KEY_FN_LOGIN_21(%X),Param1=%X, Param2=%X\n",request->majorFnCode,request->param1,request->param2);
		if (pKeyData->SentkeyType>=1)
		{
			ULONG var_param1, var_param2, var1,var2,var11;
			LONG i;
			var_param1 = request->param1;
			var_param2 = request->param2;
			var11 = var_param2&0xFF00;
			var_param2 <<=0x10;
			var_param2|=var11;
			var_param2 <<=8;
			var11 = var_param1&0xFF00;
			var_param1 <<=0x10;
			var_param1|=var11;
			var_param1 &=0x00FFFF00;
			var_param1 >>=8;
			for ( i=0x20; i>0; i--)
			{
				var2 = var_param2 & 0xFFFF0000;
				var1= var_param1;
				var2 <<=0x0F;
				var2 = var_param2 & 0xFFFFF000;
				var1 <<=0x0C;
				var2 ^=var1;
				var1 = var_param2 & 0xFFF00000;
				var2 <<=8;
				var2 ^=var1;
				var2 <<=0x0B;
				var_param2 >>=1;
				var_param2|=var2;
				var_param1 >>=1;
			}
			RtlCopyMemory(&(pResp->data1),&var_param2, sizeof(USHORT));
			pResp->data2 = request ->param2;
			pResp->status=KEY_OPERATION_STATUS_OK;
		}
		outDataLen=8;
		encodeOutData=1;                    
		break;

	case SENT_KEY_FN_WRITE_0:
		DPRINT ("SENT_KEY_FN_WRITE_0(%X) Cell=%X, Value=%X, WP=%X\n",request->majorFnCode,request->cellno,request->param1,request->param2);
		//_asm int 3; // sp
		if ( (pKeyData->CellType[request->cellno]==0) && (pKeyData->CellMem[4]==request->param2) ) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			pResp->data1=0xabcd;       //garbish
			pResp->data2=0x1234;       //garbish
			pKeyData->CellType[request->cellno]=0;
			pKeyData->CellMem[request->cellno]=request->param1;
		}
		outDataLen=8;
		encodeOutData=1;
		break;
	case SENT_KEY_FN_WRITE_1:
		DPRINT ("SENT_KEY_FN_WRITE_1(%X) Cell=%X, Value=%X, WP=%X\n",request->majorFnCode,request->cellno,request->param1,request->param2);
		if ((pKeyData->CellType[request->cellno]==0) && (pKeyData->CellMem[4]==request->param2)) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			pResp->data1=0xabcd;       //garbish
			pResp->data2=0x1234;       //garbish
			pKeyData->CellType[request->cellno]=1;
			pKeyData->CellMem[request->cellno]=request->param1;
		}
		outDataLen=8;
		encodeOutData=1;
		break;
	case SENT_KEY_FN_WRITE_2:
		DPRINT ("SENT_KEY_FN_WRITE_2(%X) Cell=%X, Value=%X, WP=%X\n",request->majorFnCode,request->cellno,request->param1,request->param2);
		if ((pKeyData->CellType[request->cellno]==0) && (pKeyData->CellMem[4]==request->param2)) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			pResp->data1=0xabcd;       //garbish
			pResp->data2=0x1234;       //garbish
			pKeyData->CellType[request->cellno]=2;
			pKeyData->CellMem[request->cellno]=request->param1;
		}
		outDataLen=8;
		encodeOutData=1;
		break;
	case SENT_KEY_FN_WRITE_3:
		DPRINT ("SENT_KEY_FN_WRITE_3(%X) Cell=%X, Value=%X, WP=%X\n",request->majorFnCode,request->cellno,request->param1,request->param2);
		if ((pKeyData->CellType[request->cellno]==0) && (pKeyData->CellMem[4]==request->param2)) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			pResp->data1=0xabcd;       //garbish
			pResp->data2=0x1234;       //garbish
			pKeyData->CellType[request->cellno]=3;
			pKeyData->CellMem[request->cellno]=request->param1;
		}
		outDataLen=8;
		encodeOutData=1;
		break;
	case SENT_KEY_FN_OVERWRITE_0:
		DPRINT ("SENT_KEY_FN_OVERWRITE_0(%X) Cell=%X, Value=%X, WP=%X\n",request->majorFnCode,request->cellno,request->param1,request->param2);
		if ((pKeyData->CellMem[4]==request->param2) && (pKeyData->CellMem[2]==pKeyData->ExtraCell[0]) && (pKeyData->CellMem[3]==pKeyData->ExtraCell[1])) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			pResp->data1=0xabcd;       //garbish
			pResp->data2=0x1234;       //garbish
			pKeyData->CellType[request->cellno]=0;
			pKeyData->CellMem[request->cellno]=request->param1;
		}
		outDataLen=8;
		encodeOutData=1;
		break;
	case SENT_KEY_FN_OVERWRITE_1:
		DPRINT ("SENT_KEY_FN_OVERWRITE_1(%X) Cell=%X, Value=%X, WP=%X\n",request->majorFnCode,request->cellno,request->param1,request->param2);
		if ((pKeyData->CellMem[4]==request->param2) && (pKeyData->CellMem[2]==pKeyData->ExtraCell[0]) && (pKeyData->CellMem[3]==pKeyData->ExtraCell[1])) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			pResp->data1=0xabcd;       //garbish
			pResp->data2=0x1234;       //garbish
			pKeyData->CellType[request->cellno]=1;
			pKeyData->CellMem[request->cellno]=request->param1;
		}
		outDataLen=8;
		encodeOutData=1;
		break;
	case SENT_KEY_FN_OVERWRITE_2:
		DPRINT ("SENT_KEY_FN_OVERWRITE_2(%X) Cell=%X, Value=%X, WP=%X\n",request->majorFnCode,request->cellno,request->param1,request->param2);
		if ((pKeyData->CellMem[4]==request->param2) && (pKeyData->CellMem[2]==pKeyData->ExtraCell[0]) && (pKeyData->CellMem[3]==pKeyData->ExtraCell[1])) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			pResp->data1=0xabcd;       //garbish
			pResp->data2=0x1234;       //garbish
			pKeyData->CellType[request->cellno]=2;
			pKeyData->CellMem[request->cellno]=request->param1;
		}
		outDataLen=8;
		encodeOutData=1;
		break;
	case SENT_KEY_FN_OVERWRITE_3:
		DPRINT ("SENT_KEY_FN_OVERWRITE_3(%X) Cell=%X, Value=%X, WP=%X\n",request->majorFnCode,request->cellno,request->param1,request->param2);
		if ((pKeyData->CellMem[4]==request->param2) && (pKeyData->CellMem[2]==pKeyData->ExtraCell[0]) && (pKeyData->CellMem[3]==pKeyData->ExtraCell[1])) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			pResp->data1=0xabcd;       //garbish
			pResp->data2=0x1234;       //garbish
			pKeyData->CellType[request->cellno]=3;
			pKeyData->CellMem[request->cellno]=request->param1;
		}
		outDataLen=8;
		encodeOutData=1;
		break;
	case SENT_KEY_FN_DECREMENT:
		DPRINT ("SENT_KEY_FN_DECREMENT(%X) Cell=%X, WP=%X \n",request->majorFnCode,request->param2);
		if (((pKeyData->CellType[request->cellno]==0) || (pKeyData->CellType[request->cellno]==2)) && (pKeyData->CellMem[4]==request->param2)) {
			pResp->status=KEY_OPERATION_STATUS_OK;
			pResp->data1=0xabcd;       //garbish
			pResp->data2=0x1234;       //garbish
			pKeyData->CellMem[request->cellno]=pKeyData->CellMem[request->cellno]-1;
		}
		outDataLen=8;
		encodeOutData=1;
		break;
	case SENT_KEY_FN_GET_KEYINFO:
		DPRINT ("SENT_KEY_FN_GET_KEYINFO(%X) \n",request->majorFnCode);

		pResp->status=KEY_OPERATION_STATUS_OK;
		switch (pKeyData->SentkeyType)
		{
		case 0:
			pResp->data1=0x0400;
			pResp->data2=0xA703;
			break;
		case 1:
			pResp->data1=0x0002;
			pResp->data2=0xB203;
			break;
		case 2:
			pResp->data1=0x0300;
			pResp->data2=0xA703;
			break;
		}

		outDataLen=8;
		encodeOutData=1;
		break;
	case SENT_KEY_FN_SET_PARAMETER:
		DPRINT ("SENT_KEY_FN_SET_PARAMETER(%X) SetNo=%X, Param1=%X, Param2=%X\n",request->majorFnCode,request->cellno,request->param1,request->param2);
		pResp->status=KEY_OPERATION_STATUS_OK;
		RtlCopyMemory(&pKeyData->ExtraCell[(request->cellno)/2],&request->param1,4);
		pKeyData->ExtraOfs=(request->cellno)/2; // transform in USHORT
		DPRINT ("ExtraOfs=%X \n",pKeyData->ExtraOfs);
		switch (pKeyData->SentkeyType)
		{
		case 0:
			pResp->data1=0x0400;
			pResp->data2=0xA703;
			break;
		case 1:
			pResp->data1=0x0002;
			pResp->data2=0xB203;
			break;
		case 2:
			pResp->data1=0x0002;
			pResp->data2=0xA003;
			break;
		}

		outDataLen=8;
		encodeOutData=1;
		break;
	case SENT_KEY_FN_GET_PARAMETER:
		DPRINT ("SENT_KEY_FN_GET_PARAMETER(%X) SetNo=%X\n",request->majorFnCode,request->cellno);
		pResp->status=KEY_OPERATION_STATUS_OK;
		pResp->data1=pKeyData->ExtraCell[request->cellno/2];
		pResp->data2=pKeyData->ExtraCell[request->cellno/2+1];
		DPRINT("Response.data1=%04X, Response.data2=%04X \n",pResp->data1,pResp->data2);
		outDataLen=8;
		encodeOutData=1;
		break;

	case USENT_KEY_FN_AES_QUERY:
		DPRINT("USENT_KEY_FN_AES_QUERY(%X)",request->majorFnCode);
		pResp->status= 0x0F;
		outDataLen=*outBufLen;
		encodeOutData=1;
		break;

	case USENT_KEY_FN_2F:
		DPRINT("USENT_KEY_FN_2F(%X)",request->majorFnCode);
		pResp->status= KEY_OPERATION_STATUS_OK;
		outDataLen=*outBufLen;
		encodeOutData=1;
		break;

	default:
		DPRINT("Unknown_SENT_KEY_FN_XXX_REQUEST=%02X",request->majorFnCode);
		pResp->status= KEY_OPERATION_STATUS_OK;
		outDataLen=*outBufLen;
		encodeOutData=1;
		break;
	}

	//
	// Return results
	//

	//Set CRC field
	tmpPtr=&pResp->CRC;
	tmpPtr+= sizeof(pResp->CRC);
	pResp->CRC= tmpPtr[0]+tmpPtr[1]+tmpPtr[2]+tmpPtr[3]+tmpPtr[4];
	//                Status          DATA1               DATA2

	// Crypt data

	pResp->CryptSeed=(USHORT)time.LowPart;
	// sp
	//tmpPtr=&pResp->CRC;
	//DPRINT ("Out packet before: %02X %02X %02X %02X %02X %02X %02X %02X \n",tmpPtr[0],tmpPtr[1],tmpPtr[2],tmpPtr[3],tmpPtr[4],tmpPtr[5],tmpPtr[6],tmpPtr[7]);
	// sp
	if (encodeOutData)
	{
		tmpPtr=&pResp->CRC;
		DPRINT ("Out Packet 01 before: %02X %02X %02X %02X %02X %02X %02X %02X \n",tmpPtr[0],tmpPtr[1],tmpPtr[2],tmpPtr[3],tmpPtr[4],tmpPtr[5],tmpPtr[6],tmpPtr[7]);
		ChiperSent(&pResp->CRC);

		//tmpPtr=&pResp->CRC;
		//DPRINT ("Out Packet 01: %02X %02X %02X %02X %02X %02X %02X %02X \n",tmpPtr[0],tmpPtr[1],tmpPtr[2],tmpPtr[3],tmpPtr[4],tmpPtr[5],tmpPtr[6],tmpPtr[7]);
	}
	// Set out data size
	*outBufLen=min(sizeof(USHORT)+outDataLen, *outBufLen);
	LogMessage ("Out data size: %X\n", *outBufLen);

	for (i=0;i<(*outBufLen>>3);i++)
	{ 
		DPRINT ("Out Packet %02X : %02X %02X %02X %02X %02X %02X %02X %02X \n",i+1,tmpPtr[i*8+0],tmpPtr[i*8+1],tmpPtr[i*8+2],tmpPtr[i*8+3],tmpPtr[i*8+4],tmpPtr[i*8+5],tmpPtr[i*8+6],tmpPtr[i*8+7]);
	}

	// Copy data into out buffer
	RtlCopyMemory(outBuf, pResp, *outBufLen);

	pKeyData->SentBufLen=*outBufLen; //для поддержки ультры

	if(pResp)
		ExFreePoolWithTag(pResp, VUSB_POOL_TAG);
}


#ifdef DEBUG_FULL
//
// USB function codes to description string conversion list
//
static WCHAR *fnCodeList[] = {
	L"URB_FUNCTION_SELECT_CONFIGURATION",
	L"URB_FUNCTION_SELECT_INTERFACE",
	L"URB_FUNCTION_ABORT_PIPE",
	L"URB_FUNCTION_TAKE_FRAME_LENGTH_CONTROL",
	L"URB_FUNCTION_RELEASE_FRAME_LENGTH_CONTROL",
	L"URB_FUNCTION_GET_FRAME_LENGTH",
	L"URB_FUNCTION_SET_FRAME_LENGTH",
	L"URB_FUNCTION_GET_CURRENT_FRAME_NUMBER",
	L"URB_FUNCTION_CONTROL_TRANSFER",
	L"URB_FUNCTION_BULK_OR_INTERRUPT_TRANSFER",
	L"URB_FUNCTION_ISOCH_TRANSFER",
	L"URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE",
	L"URB_FUNCTION_SET_DESCRIPTOR_TO_DEVICE",
	L"URB_FUNCTION_SET_FEATURE_TO_DEVICE",
	L"URB_FUNCTION_SET_FEATURE_TO_INTERFACE",
	L"URB_FUNCTION_SET_FEATURE_TO_ENDPOINT",
	L"URB_FUNCTION_CLEAR_FEATURE_TO_DEVICE",
	L"URB_FUNCTION_CLEAR_FEATURE_TO_INTERFACE",
	L"URB_FUNCTION_CLEAR_FEATURE_TO_ENDPOINT",
	L"URB_FUNCTION_GET_STATUS_FROM_DEVICE",
	L"URB_FUNCTION_GET_STATUS_FROM_INTERFACE",
	L"URB_FUNCTION_GET_STATUS_FROM_ENDPOINT",
	L"URB_FUNCTION_RESERVED_0X0016",
	L"URB_FUNCTION_VENDOR_DEVICE",
	L"URB_FUNCTION_VENDOR_INTERFACE",
	L"URB_FUNCTION_VENDOR_ENDPOINT",
	L"URB_FUNCTION_CLASS_DEVICE",
	L"URB_FUNCTION_CLASS_INTERFACE",
	L"URB_FUNCTION_CLASS_ENDPOINT",
	L"URB_FUNCTION_RESERVE_0X001D",
	L"URB_FUNCTION_SYNC_RESET_PIPE_AND_CLEAR_STALL",
	L"URB_FUNCTION_CLASS_OTHER",
	L"URB_FUNCTION_VENDOR_OTHER",
	L"URB_FUNCTION_GET_STATUS_FROM_OTHER",
	L"URB_FUNCTION_CLEAR_FEATURE_TO_OTHER",
	L"URB_FUNCTION_SET_FEATURE_TO_OTHER",
	L"URB_FUNCTION_GET_DESCRIPTOR_FROM_ENDPOINT",
	L"URB_FUNCTION_SET_DESCRIPTOR_TO_ENDPOINT",
	L"URB_FUNCTION_GET_CONFIGURATION",
	L"URB_FUNCTION_GET_INTERFACE",
	L"URB_FUNCTION_GET_DESCRIPTOR_FROM_INTERFACE",
	L"URB_FUNCTION_SET_DESCRIPTOR_TO_INTERFACE",
	L"URB_FUNCTION_GET_MS_FEATURE_DESCRIPTOR",
	L"URB_FUNCTION_RESERVE_0X002B",
	L"URB_FUNCTION_RESERVE_0X002C",
	L"URB_FUNCTION_RESERVE_0X002D",
	L"URB_FUNCTION_RESERVE_0X002E",
	L"URB_FUNCTION_RESERVE_0X002F",
	L"URB_FUNCTION_SYNC_RESET_PIPE",
	L"URB_FUNCTION_SYNC_CLEAR_STALL",
};
#endif

// static char szBus_HandleUSBIoCtl[]= "Bus_HandleUSBIoCtl";

NTSTATUS
	Bus_HandleUSBIoCtl (
	IN  PDEVICE_OBJECT  DeviceObject,
	IN  PIRP            Irp
	)
	/*++
	Routine Description:

	Handle user mode PlugIn, UnPlug and device Eject requests.

	Arguments:

	DeviceObject - pointer to a device object.

	Irp - pointer to an I/O Request Packet.

	Return Value:

	NT status code

	--*/
{
	PIO_STACK_LOCATION      irpStack;
	NTSTATUS                status;
	ULONG                   inlen, outlen;
	PVOID                   buffer;
	PURB                    urb;
	PPDO_DEVICE_DATA        pdoData;
#if defined (DEBUG_FULL)
	PWCHAR                  str1, str2;
#endif
	PAGED_CODE ();

	pdoData = (PPDO_DEVICE_DATA) DeviceObject->DeviceExtension;

	//Bus_KdPrint(pdoData, BUS_DBG_IOCTL_TRACE, ("Recive IRP_MJ_INTERNAL_DEVICE_CONTROL\n"));

	//
	// We only take Device Control requests for the devices.
	//

	if (pdoData->IsFDO) {

		//
		// These commands are only allowed to go to the devices.
		//
		status = STATUS_INVALID_DEVICE_REQUEST;
		Irp->IoStatus.Status = status;
		IoCompleteRequest (Irp, IO_NO_INCREMENT);
		return status;

	}

	//
	// Check to see whether the bus is removed
	//

	if (pdoData->DevicePnPState == Deleted) {
		Irp->IoStatus.Status = status = STATUS_DELETE_PENDING;
		IoCompleteRequest (Irp, IO_NO_INCREMENT);
		return status;
	}

	//
	// Get IRP packet info
	//
	irpStack = IoGetCurrentIrpStackLocation (Irp);

	buffer = Irp->AssociatedIrp.SystemBuffer;
	inlen  = irpStack->Parameters.DeviceIoControl.InputBufferLength;
	outlen = irpStack->Parameters.DeviceIoControl.OutputBufferLength;

	//
	// Get URB
	//
	urb = irpStack->Parameters.Others.Argument1;

	//
	// And set status to 'unhandled device request'
	//
	status = STATUS_INVALID_DEVICE_REQUEST;

	//
	// Analyse requested IoControlCode
	//


	switch (irpStack->Parameters.DeviceIoControl.IoControlCode) {
		//
		// Request for USB bus, handle it
		//
	case IOCTL_INTERNAL_USB_SUBMIT_URB:
		//Bus_KdPrint(pdoData, BUS_DBG_IOCTL_TRACE, ("Recive IOCTL_INTERNAL_USB_SUBMIT_URB\n"));
		if (urb) {
#ifdef DEBUG_FULL
			//
			// Print request info
			//
			str1 = ExAllocatePoolWithTag (PagedPool, 4096, VUSB_POOL_TAG);
			if (!str1)
			{
				status = STATUS_INSUFFICIENT_RESOURCES;
				break;
			}
			else
				RtlZeroMemory(str1, 4096);

			str2 = ExAllocatePoolWithTag (PagedPool, 4096, VUSB_POOL_TAG);
			if (!str2)
			{
				ExFreePool(str1);
				status = STATUS_INSUFFICIENT_RESOURCES;
				break;
			}
			else
				RtlZeroMemory(str2, 4096);


			if (urb->UrbHeader.Function == URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE || urb->UrbHeader.Function==URB_FUNCTION_VENDOR_DEVICE)
			{
				if(urb->UrbControlVendorClassRequest.TransferBufferLength < 1024)
				{
					PrintBufferContent(str1,
						urb->UrbControlVendorClassRequest.TransferBuffer,
						urb->UrbControlVendorClassRequest.TransferBufferLength);
				}
				else
				{
					PrintBufferContent(str1,
						urb->UrbControlVendorClassRequest.TransferBuffer,
						1024);
				}

				PrintBufferContent(str2,
					&urb->UrbControlVendorClassRequest.Request,
					1+2+2+2);

				LogMessage ("Bus_HandleUSBIoCtl(): in\n"
					"\tFunction:  %ws (%X)\n"
					"\tLength:    %X\n"
					"\tTransfer buffer length:     %X\n"
					"\tTransfer buffer contents:   %ws\n"
					"\tRequest buffer:             %ws\n"
					"\tRequest:        %X\n"
					"\tValue:          %X\n"
					"\tIndex:          %X\n"
					"\tTransferFlags:  %X\n"
					"\tDescriptorType: %X\n"
					"\tLanguageId:     %X\n",
					(urb->UrbHeader.Function>=0 && urb->UrbHeader.Function<=0x31)?fnCodeList[urb->UrbHeader.Function]:L"UNKNOWN\0",
					urb->UrbHeader.Function,
					urb->UrbHeader.Length,
					urb->UrbControlVendorClassRequest.TransferBufferLength,
					str1,
					str2,
					urb->UrbControlVendorClassRequest.Request,
					urb->UrbControlVendorClassRequest.Value,
					urb->UrbControlVendorClassRequest.Index,
					urb->UrbControlVendorClassRequest.TransferFlags,
					urb->UrbControlDescriptorRequest.DescriptorType,
					urb->UrbControlDescriptorRequest.LanguageId);
			}
			else
				LogMessage ("Bus_HandleUSBIoCtl(): in\n"
				"\tFunction:  %ws (%X)\n"
				"\tLength:    %X\n",
				(urb->UrbHeader.Function>=0 && urb->UrbHeader.Function<=0x31)?fnCodeList[urb->UrbHeader.Function]:L"UNKNOWN\0",
				urb->UrbHeader.Function,
				urb->UrbHeader.Length);
#endif
			// Analyse requested URB function code
			switch (urb->UrbHeader.Function) 
			{
				//
				// Get info about device fn
				//
			case URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE:
				switch (urb->UrbControlDescriptorRequest.DescriptorType) {
					//
					// Info about hardware of USB device
					//
				case USB_DEVICE_DESCRIPTOR_TYPE: {
					// Analyse dongle type
					//
					USB_DEVICE_DESCRIPTOR deviceDesc;
					deviceDesc.bLength=sizeof(deviceDesc);
					deviceDesc.bDescriptorType=USB_DEVICE_DESCRIPTOR_TYPE;
					deviceDesc.bcdUSB=0x200;
					deviceDesc.bDeviceClass=USB_DEVICE_CLASS_VENDOR_SPECIFIC;
					deviceDesc.bDeviceSubClass=0;
					deviceDesc.bDeviceProtocol=0;
					deviceDesc.bMaxPacketSize0=8;
					DPRINT("URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE, DongleType=%02X\n",pdoData->keyData.DongleType);

					switch (pdoData->keyData.DongleType)
					{
					case DONGLE_HASP:
						{
							deviceDesc.idVendor=0x529;
							deviceDesc.idProduct=1;
							deviceDesc.bcdDevice=0x325;
							deviceDesc.iManufacturer=1;
							deviceDesc.iProduct=2;
						}
						break;
					case DONGLE_HARDLOCK:
						{
							deviceDesc.idVendor=0x529;
							deviceDesc.idProduct=1;
							deviceDesc.bcdDevice=0x100;
							deviceDesc.iManufacturer=1;
							deviceDesc.iProduct=2;
						}
						break;
					case DONGLE_SENTINEL:
						{
							deviceDesc.idVendor=0x4b9;
							deviceDesc.idProduct=0x300;
							deviceDesc.bcdDevice=4;
							deviceDesc.iManufacturer=0;
							deviceDesc.iProduct=1;
						}
						break;
					}

					deviceDesc.iSerialNumber=0;
					deviceDesc.bNumConfigurations=1;

					urb->UrbControlVendorClassRequest.TransferBufferLength=
						min(urb->UrbControlVendorClassRequest.TransferBufferLength, sizeof(deviceDesc));

					RtlCopyMemory(urb->UrbControlVendorClassRequest.TransferBuffer,
						&deviceDesc,
						urb->UrbControlVendorClassRequest.TransferBufferLength
						);

					status = STATUS_SUCCESS;
					URB_STATUS(urb) = USBD_STATUS_SUCCESS;
					DPRINT("URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE,  USB_DEVICE_DESCRIPTOR_TYPE. \n");
												 }
												 break;

												 //
												 // Info about possible configurations of USB device
												 //
				case USB_CONFIGURATION_DESCRIPTOR_TYPE: {
					struct  {
						USB_CONFIGURATION_DESCRIPTOR configDesc;
						USB_INTERFACE_DESCRIPTOR interfaceDesc;
					} configInfo;
					configInfo.configDesc.bLength=sizeof(configInfo.configDesc);
					configInfo.configDesc.bDescriptorType=USB_CONFIGURATION_DESCRIPTOR_TYPE;
					configInfo.configDesc.wTotalLength=sizeof(configInfo.configDesc)+sizeof(configInfo.interfaceDesc);
					configInfo.configDesc.bNumInterfaces=1;
					configInfo.configDesc.bConfigurationValue=1;
					configInfo.configDesc.iConfiguration=0;
					configInfo.configDesc.bmAttributes=USB_CONFIG_BUS_POWERED;
					configInfo.configDesc.MaxPower=54/2;

					configInfo.interfaceDesc.bLength=sizeof(configInfo.interfaceDesc);
					configInfo.interfaceDesc.bDescriptorType=USB_INTERFACE_DESCRIPTOR_TYPE;
					configInfo.interfaceDesc.bInterfaceNumber=0;
					configInfo.interfaceDesc.bAlternateSetting=0;
					configInfo.interfaceDesc.bNumEndpoints=0;
					configInfo.interfaceDesc.bInterfaceClass=USB_DEVICE_CLASS_VENDOR_SPECIFIC;
					configInfo.interfaceDesc.bInterfaceSubClass=0;
					configInfo.interfaceDesc.bInterfaceProtocol=0;
					configInfo.interfaceDesc.iInterface=0;

					urb->UrbControlVendorClassRequest.TransferBufferLength=
						min(urb->UrbControlVendorClassRequest.TransferBufferLength, sizeof(configInfo.configDesc)+sizeof(configInfo.interfaceDesc));

					RtlCopyMemory(urb->UrbControlVendorClassRequest.TransferBuffer,
						&configInfo,
						urb->UrbControlVendorClassRequest.TransferBufferLength
						);

					status = STATUS_SUCCESS;
					URB_STATUS(urb) = USBD_STATUS_SUCCESS;
					DPRINT("URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE,  USB_CONFIGURATION_DESCRIPTOR_TYPE. \n");
														}
														break;
				case USB_STRING_DESCRIPTOR_TYPE: {
					UCHAR stringDesc[256];
					switch (pdoData->keyData.DongleType)
					{
					case DONGLE_HASP:
						{
							stringDesc[0]=2;  // bLength
							stringDesc[1] = USB_STRING_DESCRIPTOR_TYPE;  // bDescriptorType
							switch (urb->UrbControlDescriptorRequest.Index) {

							case 0:
								{ //04 03 09 04
									stringDesc[0]=0x04;
									stringDesc[1]=0x03;
									stringDesc[2]=0x09;
									stringDesc[3]=0x04;
								}
								break;

							case 1:
								{ //AKS
									stringDesc[0]=sizeof(VENDOR1);
									RtlCopyMemory(&stringDesc[2],&VENDOR1,sizeof(VENDOR1)-2);
								}
								break;

							case 2:
								{   //HASP HL 3.25
									stringDesc[0]=sizeof(VENDORFW_H6);//0x20;  //HASP HL 3.25
									RtlCopyMemory(&stringDesc[2],&VENDORFW_H6,sizeof(VENDORFW_H6)-2);
								}
								break;
							}

							DPRINT("URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE,  USB_STRING_DESCRIPTOR_TYPE. \n");
							DPRINT("len=%02X type=%02X string=%02X%02X%02X%02X\n", stringDesc[0],stringDesc[1],stringDesc[2],stringDesc[3],stringDesc[4],stringDesc[5]);
							urb->UrbControlVendorClassRequest.TransferBufferLength = min(urb->UrbControlVendorClassRequest.TransferBufferLength, stringDesc[0]);
							RtlCopyMemory(urb->UrbControlVendorClassRequest.TransferBuffer, &stringDesc[0], urb->UrbControlVendorClassRequest.TransferBufferLength );
							//__asm {int 0x03};
							status = STATUS_SUCCESS;
							URB_STATUS(urb) = USBD_STATUS_SUCCESS;
						}
						break;
					}
												 }
												 break;
				}
				//
				// Select configurations of USB device
				//
			case URB_FUNCTION_SELECT_CONFIGURATION: {
				typedef struct _URB_SELECT_CONFIGURATION *PURB_SELECT_CONFIGURATION;
				PURB_SELECT_CONFIGURATION selectConfig;
				selectConfig=(PURB_SELECT_CONFIGURATION)urb;
				selectConfig->Interface.InterfaceNumber=0;
				selectConfig->Interface.AlternateSetting=0;
				selectConfig->Interface.Class=USB_DEVICE_CLASS_VENDOR_SPECIFIC;
				selectConfig->Interface.SubClass=0;
				selectConfig->Interface.Protocol=0;

				status = STATUS_SUCCESS;
				URB_STATUS(urb) = USBD_STATUS_SUCCESS;
													}
													break;

													//
													// IO request to USB hardware
													//
			case URB_FUNCTION_VENDOR_DEVICE:
				{
					// Emulate request to key
					// Analyse dongle type
					//
					if (pdoData->keyData.DongleType == DONGLE_HARDLOCK )
					{
						EmulateKeyHARDLOCK(&pdoData->keyData,
							(PKEY_REQUEST)&urb->UrbControlVendorClassRequest.Request,
							&urb->UrbControlVendorClassRequest.TransferBufferLength,
							(PKEY_RESPONSE)urb->UrbControlVendorClassRequest.TransferBuffer);
					}
					if (pdoData->keyData.DongleType == DONGLE_HASP )
					{
						EmulateKey(&pdoData->keyData,
							(PKEY_REQUEST)&urb->UrbControlVendorClassRequest.Request,
							&urb->UrbControlVendorClassRequest.TransferBufferLength,
							(PKEY_RESPONSE)urb->UrbControlVendorClassRequest.TransferBuffer);
					}

					// I/o with key is succeful
					status = STATUS_SUCCESS;
					URB_STATUS(urb) = USBD_STATUS_SUCCESS;
				} break;
				//
				// IO request to USB hardware
				//
			case URB_FUNCTION_VENDOR_INTERFACE: 
				{
					if (pdoData->keyData.DongleType == DONGLE_SENTINEL )
					{
						if (urb->UrbControlVendorClassRequest.TransferFlags==0)
						{
							EmulateKeySent(
								&pdoData->keyData,
								(PKEY_SENT_REQUEST)urb->UrbControlVendorClassRequest.TransferBuffer,
								&urb->UrbControlVendorClassRequest.TransferBufferLength,
								(PKEY_SENT_RESPONSE)urb->UrbControlVendorClassRequest.TransferBuffer);

							pdoData->keyData.request=urb->UrbControlVendorClassRequest.Request;
							RtlCopyMemory(&pdoData->keyData.SentTempMem,
								urb->UrbControlVendorClassRequest.TransferBuffer,
								urb->UrbControlVendorClassRequest.TransferBufferLength);
							urb->UrbControlVendorClassRequest.TransferBufferLength=0;

						}
						if (urb->UrbControlVendorClassRequest.TransferFlags==3)
						{
							if (urb->UrbControlVendorClassRequest.Request==pdoData->keyData.request)
								RtlCopyMemory(urb->UrbControlVendorClassRequest.TransferBuffer,
								&pdoData->keyData.SentTempMem,pdoData->keyData.SentBufLen);
							urb->UrbControlVendorClassRequest.TransferBufferLength=pdoData->keyData.SentBufLen;
						}
					}
					status = STATUS_SUCCESS;
					URB_STATUS(urb) = USBD_STATUS_SUCCESS;
				} break;

			}

#ifdef DEBUG_FULL
			//
			// Print request result
			//
			RtlZeroMemory(str1, 4096);
			RtlZeroMemory(str2, 4096);

			if (urb->UrbHeader.Function == URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE || urb->UrbHeader.Function == URB_FUNCTION_VENDOR_DEVICE)
			{
				if(urb->UrbControlVendorClassRequest.TransferBufferLength < 1024)
				{
					PrintBufferContent(str1,
						urb->UrbControlVendorClassRequest.TransferBuffer,
						urb->UrbControlVendorClassRequest.TransferBufferLength);
				}
				else
				{
					PrintBufferContent(str1,
						urb->UrbControlVendorClassRequest.TransferBuffer,
						1024);
				}

				LogMessage ("Bus_HandleUSBIoCtl(): out\n"
					"\tTransfer buffer length:     %X\n"
					"\tTransfer buffer contents:   %ws\n"
					"\tStatus:                     %X\n",
					urb->UrbControlVendorClassRequest.TransferBufferLength,
					str1,
					URB_STATUS(urb));
			}
			else
				LogMessage ("Bus_HandleUSBIoCtl(): out\n"
				"\tStatus: %X\n",
				URB_STATUS(urb));

			ExFreePoolWithTag(str2, VUSB_POOL_TAG);
			ExFreePoolWithTag(str1, VUSB_POOL_TAG);
#endif
		}
		break;

	default:
		break; // default status is STATUS_INVALID_PARAMETER
	}

	Irp->IoStatus.Status = status;
	IoCompleteRequest (Irp, IO_NO_INCREMENT);
	return status;
}

NTSTATUS
	Bus_LoadDumpsFromRegistry(
	IN  PDEVICE_OBJECT          DeviceObject
	)
	/*++

	Routine Description:

	This routine enum dumps of HASP keys in registry and load it

	Arguments:

	DeviceObject        A device object in the stack in which we attach HASP keys

	Return Value:

	NTSTATUS

	--*/
{
	//
	// Search for HASP key dumps in registry
	// and attach it as USB devices
	//
	NTSTATUS        status;
	HANDLE          hkey;
	ULONG           keysAttached;

	UNICODE_STRING  usPath;
	OBJECT_ATTRIBUTES   oa;
	PFDO_DEVICE_DATA    fdoData;
	ULONG           DongleType;

	PAGED_CODE();

	fdoData = (PFDO_DEVICE_DATA) DeviceObject->DeviceExtension;
	Bus_IncIoCount (fdoData);

	keysAttached=0;

	RtlInitUnicodeString(&usPath, DUMP_PATH);
	InitializeObjectAttributes(&oa, &usPath,
		OBJ_KERNEL_HANDLE|OBJ_CASE_INSENSITIVE, NULL, NULL);

	//
	// Enum keys in registry and attach it
	//
	status = ZwOpenKey(&hkey, KEY_READ, &oa);
	if (NT_SUCCESS(status))
	{
		ULONG size, i;
		PKEY_FULL_INFORMATION fip;

		ZwQueryKey(hkey, KeyFullInformation, NULL, 0, &size);
		size = min(size, PAGE_SIZE);
		fip = (PKEY_FULL_INFORMATION) ExAllocatePoolWithTag(PagedPool, size, VUSB_POOL_TAG);
		ZwQueryKey(hkey, KeyFullInformation, fip, size, &size);

		for (i = 0; i < fip->SubKeys; ++i)
		{
			ULONG curChar, password, isPasswordValid;
			PKEY_BASIC_INFORMATION bip;

			ZwEnumerateKey(hkey, i, KeyBasicInformation, NULL, 0, &size);
			size = min(size, PAGE_SIZE);
			bip = (PKEY_BASIC_INFORMATION)ExAllocatePoolWithTag(PagedPool, size, VUSB_POOL_TAG);
			ZwEnumerateKey(hkey, i, KeyBasicInformation, bip, size, &size);

			// Convert key name into password
			password=0; isPasswordValid=1;
			DPRINT("password name lenght 0x%02X\n",bip->NameLength);
			for (curChar=0; curChar<min(0x10/2,bip->NameLength/2); curChar++) {
				if (bip->Name[curChar]>=L'0' && bip->Name[curChar]<=L'9')
					password=(password << 4) + (bip->Name[curChar] - L'0');
				else
					if (bip->Name[curChar]>=L'A' && bip->Name[curChar]<=L'F')
						password=(password << 4) + (bip->Name[curChar] - L'A') + 10;
					else
						if (bip->Name[curChar]>=L'a' && bip->Name[curChar]<=L'f')
							password=(password << 4) + (bip->Name[curChar] - L'a') + 10;
						else {
							isPasswordValid=0;
							break;
						}
			}

			if (bip->NameLength>0x12){isPasswordValid=0;}
			DPRINT("password 0x%08X, valid 0x%02X\n",password,isPasswordValid);

			if (isPasswordValid && INSERT_ALL_KEYS_ON_STARTUP)
			{
				NTSTATUS        status;
				HANDLE          hkey;
				WCHAR           path[128];
				UNICODE_STRING  usPath;

				OBJECT_ATTRIBUTES oa;
				WCHAR           path_name[20];
				DongleType=0;
				RtlFillMemory(&path_name,sizeof(path_name),0);
				RtlCopyMemory(&path_name,&bip->Name,bip->NameLength);
				RtlFillMemory(path, sizeof(path), 0);
				RtlStringCbPrintfExW(path, 256, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%ws\\%ws", DUMP_PATH, path_name);
				DPRINT("path : %ws\n",path);
				RtlInitUnicodeString(&usPath, path);
				InitializeObjectAttributes(&oa, &usPath, /* OBJ_KERNEL_HANDLE | */ OBJ_CASE_INSENSITIVE, NULL, NULL);

				status = ZwOpenKey(&hkey, KEY_READ, &oa);
				if (NT_SUCCESS(status))
				{
					GetRegKeyData(hkey, L"DongleType", &DongleType, sizeof(DongleType));
					DPRINT("DongleType=%02X\n",DongleType);
					ZwClose(hkey);
				}
				if ((DongleType>0)&&(DongleType<=2))
				{
					UCHAR                       buf[sizeof(VUSB_PLUGIN_HARDWARE)+BUS_HARDWARE_IDS_LENGTH];
					PVUSB_PLUGIN_HARDWARE    pOneKeyInfo;
					NTSTATUS                    status;
					DPRINT("Found key HASP or HARDLOCK %08X\n", password);
					pOneKeyInfo=(PVUSB_PLUGIN_HARDWARE)buf;
					pOneKeyInfo->Size=sizeof(VUSB_PLUGIN_HARDWARE);
					pOneKeyInfo->SerialNo=++keysAttached;
					pOneKeyInfo->Password=password;
					RtlFillMemory(&pOneKeyInfo->Dump_name,sizeof(pOneKeyInfo->Dump_name),0);
					RtlCopyMemory(&pOneKeyInfo->Dump_name,&bip->Name,bip->NameLength);
					RtlCopyMemory(pOneKeyInfo->HardwareIDs, BUS_HARDWARE_IDS, BUS_HARDWARE_IDS_LENGTH);
					status=Bus_PlugInDevice(pOneKeyInfo, sizeof(VUSB_PLUGIN_HARDWARE)+BUS_HARDWARE_IDS_LENGTH, fdoData);
					if (!NT_SUCCESS (status))
						keysAttached--;
				}
				if (DongleType==3)//sentinel
				{
					UCHAR                       buf[sizeof(VUSB_PLUGIN_HARDWARE)+BUS_HARDWARE_SENT_IDS_LENGTH];
					PVUSB_PLUGIN_HARDWARE    pOneKeyInfo;
					NTSTATUS                    status;
					DPRINT("Found key SENTINEL %08X\n", password);
					pOneKeyInfo=(PVUSB_PLUGIN_HARDWARE)buf;
					pOneKeyInfo->Size=sizeof(VUSB_PLUGIN_HARDWARE);
					pOneKeyInfo->SerialNo=++keysAttached;
					pOneKeyInfo->Password=password;
					RtlFillMemory(&pOneKeyInfo->Dump_name,sizeof(pOneKeyInfo->Dump_name),0);
					RtlCopyMemory(&pOneKeyInfo->Dump_name,&bip->Name,bip->NameLength);
					RtlCopyMemory(pOneKeyInfo->HardwareIDs, BUS_HARDWARE_SENT_IDS, BUS_HARDWARE_SENT_IDS_LENGTH);
					status=Bus_PlugInDevice(pOneKeyInfo, sizeof(VUSB_PLUGIN_HARDWARE)+BUS_HARDWARE_SENT_IDS_LENGTH, fdoData);
					if (!NT_SUCCESS (status))
						keysAttached--;
				}
				if (DongleType>3 || DongleType<1)
					LogMessage("Found bad key\n");

			} else
				LogMessage("Found bad key\n");

			ExFreePool(bip);
		}

		ExFreePool(fip);

		ZwClose(hkey);

		Bus_DecIoCount (fdoData);

		//if (keysAttached>0)
		//    IoInvalidateDeviceRelations (FdoData->UnderlyingPDO, BusRelations);

		return STATUS_SUCCESS;
	}

	return STATUS_SUCCESS;
}

NTSTATUS
	GetRegKeyData(
	HANDLE hkey,
	PWCHAR subKey,
	VOID *data,
	ULONG needSize)
	/*++
	Routine Description:
	This routine read data from registry key
	Arguments:
	hkey        Ptr to registry key
	subKey      Name of subkey
	data        Ptr to buffer, in which we read information
	needSize    Size of buffer
	Return Value:
	NTSTATUS
	--*/
{
	NTSTATUS    status;
	ULONG       size;
	UNICODE_STRING valname;
	PKEY_VALUE_PARTIAL_INFORMATION vpip;

	vpip = NULL;

	RtlInitUnicodeString(&valname, subKey);
	size=0;
	status = ZwQueryValueKey(hkey, &valname, KeyValuePartialInformation, NULL, 0, &size);

	// size = min(size, PAGE_SIZE); // Leave this check as Query tables can be > PAGE_SIZE
	if (status == STATUS_OBJECT_NAME_NOT_FOUND || size == 0)
		return STATUS_OBJECT_NAME_NOT_FOUND;

	vpip = (PKEY_VALUE_PARTIAL_INFORMATION) ExAllocatePoolWithTag(PagedPool, size, VUSB_POOL_TAG);
	if (!vpip)
		return STATUS_INSUFFICIENT_RESOURCES;

	status = ZwQueryValueKey(hkey, &valname, KeyValuePartialInformation, vpip, size, &size);

	if (!NT_SUCCESS(status))
	{
		if(vpip != NULL)
			ExFreePoolWithTag(vpip, VUSB_POOL_TAG);
		return STATUS_INVALID_PARAMETER;
	}

	RtlCopyMemory(data, vpip->Data, needSize);
		
	if(vpip != NULL)
		ExFreePoolWithTag(vpip, VUSB_POOL_TAG);

	return STATUS_SUCCESS;
}

ULONG GetRegKeyDataSize(HANDLE hkey,
	PWCHAR subKey)
	/*++
	Routine Description:
	This routine read size of data from registry key
	Arguments:
	hkey        Ptr to registry key
	subKey      Name of subkey
	Return Value:
	ULONG
	--*/
{
	NTSTATUS    status;
	ULONG       size;
	UNICODE_STRING valname;

	RtlInitUnicodeString(&valname, subKey);
	size=0;
	status = ZwQueryValueKey(hkey, &valname, KeyValuePartialInformation, NULL, 0, &size);
	if (status == STATUS_OBJECT_NAME_NOT_FOUND && size<=PAGE_SIZE)
		return -1;
	return size;
}
//
// HASP secret table generator vectors, it used to create ST for old HASP keys
//
static UCHAR HASP_rows[8][8]={
	{0,0,0,0,0,0,0,0},
	{0,1,0,1,0,1,0,1},
	{1,0,1,0,1,0,1,0},
	{0,0,1,1,0,0,1,1},
	{1,1,0,0,1,1,0,0},
	{0,0,0,0,1,1,1,1},
	{1,1,1,1,0,0,0,0},
	{1,1,1,1,1,1,1,1}
};


// Chingachguk
// static ULONG keysAttached= 0; // Number of attached keys

NTSTATUS
	Bus_LoadDumpFromRegistry(
	PPVH pvh,
	PKEYDATA keyData)
	/*++

	Routine Description:

	This routine read dump of one HASP key from registry

	Arguments:

	password    Password of key
	keyData     Ptr to structure with key data

	Return Value:

	NTSTATUS

	--*/
{
	NTSTATUS        status;
	HANDLE          hkey;
	WCHAR           path[128];
	UNICODE_STRING  usPath;

	OBJECT_ATTRIBUTES oa;

	PAGED_CODE();

	RtlZeroMemory(keyData, sizeof(keyData));
	//
	// Try to read data about key from registry
	//
	RtlFillMemory(path, sizeof(path), 0);
	RtlStringCbPrintfExW(path, 256, NULL, NULL, STRSAFE_NULL_ON_FAILURE, L"%ws\\%ws", DUMP_PATH, pvh->Dump_name);
	RtlInitUnicodeString(&usPath, path);
	InitializeObjectAttributes(&oa, &usPath, /* OBJ_KERNEL_HANDLE | */ OBJ_CASE_INSENSITIVE, NULL, NULL);

	status = ZwOpenKey(&hkey, KEY_READ, &oa);
	if (NT_SUCCESS(status)) 
	{
		NTSTATUS readStatus, hasOption, hasSecTable;
		readStatus=STATUS_SUCCESS;
		keyData->password=(pvh->password >> 16) | (pvh->password << 16); // Password stored in shuffled form
		//check type of dongle
		readStatus+=GetRegKeyData(hkey, L"DongleType", &keyData->DongleType, sizeof(keyData->DongleType));

		if (keyData->DongleType == DONGLE_HASP) {
			readStatus+=GetRegKeyData(hkey, L"Type", &keyData->keyType, sizeof(keyData->keyType));
			readStatus+=GetRegKeyData(hkey, L"Memory", &keyData->memoryType, sizeof(keyData->memoryType));
			readStatus+=GetRegKeyData(hkey, L"SN", &keyData->netMemory[0], sizeof(ULONG));
			readStatus+=GetRegKeyData(hkey, L"Data", keyData->memory, min(GetMemorySize(keyData), sizeof(keyData->memory)));
			hasOption=GetRegKeyData(hkey, L"Option", &keyData->options[0], sizeof(keyData->options));
			hasSecTable=GetRegKeyData(hkey, L"SecTable", &keyData->secTable[0], sizeof(keyData->secTable));

			if (NT_SUCCESS(readStatus)) {
				if (!(NT_SUCCESS(hasSecTable))) {
					// Universal ST case
					ULONG   password=keyData->password, i, j;
					UCHAR   alBuf[8];

					LogMessage("Revert to universal ST\n");

					password^=0x09071966;

					for (i=0; i<8; i++) {
						alBuf[i]= (UCHAR)(password & 7);
						password = password >> 3;
					}

					RtlZeroMemory(keyData->secTable, sizeof(keyData->secTable));

					for(i=0; i<8; i++)
						for(j=0; j<8; j++)
							keyData->secTable[j]|=HASP_rows[alBuf[i]][j] << (7 - i);
				}
				if (GetRegKeyData(hkey, L"NetMemory", &keyData->netMemory[4], sizeof(keyData->netMemory)-sizeof(ULONG))!=STATUS_SUCCESS) {
					RtlFillMemory(&keyData->netMemory[4], sizeof(keyData->netMemory)-sizeof(ULONG), 0xFF);
					if (keyData->memoryType==4) {
						// Unlimited Net key
						keyData->netMemory[6+4]=0xFF;
						keyData->netMemory[7+4]=0xFF;
						keyData->netMemory[10+4]=0xFE;
					} else {
						// Local key
						keyData->netMemory[6+4]=0;
						keyData->netMemory[7+4]=0;
						keyData->netMemory[10+4]=0;
					}
				}
				RtlZeroMemory(&keyData->KEY_INFOdata, sizeof(keyData->KEY_INFOdata));
				GetRegKeyData(hkey, L"ColumnMask", &keyData->KEY_INFOdata.columnMask, sizeof(keyData->KEY_INFOdata.columnMask));
				GetRegKeyData(hkey, L"CryptInitVect", &keyData->KEY_INFOdata.cryptInitVect, sizeof(keyData->KEY_INFOdata.cryptInitVect));
				// If parameters for 3C/3D are not defined, we'll use non-parameters variant by tch2000
				if ( ( !keyData->KEY_INFOdata.columnMask ) && ( !keyData->KEY_INFOdata.cryptInitVect ) )
				{
					// It will be used as flag too
					keyData->KEY_INFOdata.password= keyData->password;
				}
				// Copy ST to KEY_INFOdata
				RtlCopyMemory(&keyData->KEY_INFOdata.secTable, &keyData->secTable, sizeof(keyData->secTable));
				// Read info for time's function(s)
				GetRegKeyData(hkey, L"TimeShift", &keyData->TimeShift, sizeof(keyData->TimeShift));
				GetRegKeyData(hkey, L"HaspTimeMemory", &keyData->HASPTIMEMEMORY, sizeof(keyData->HASPTIMEMEMORY));

				if (!(NT_SUCCESS(GetRegKeyData(hkey, L"AesKey", &keyData->AesKey, sizeof(keyData->AesKey))))) 
				{
					UCHAR AesKey[16]={0x79,0x4C,0xE1,0x88,0xCB,0xC1,0x78,0x53,0x11,0x69,0xE0,0xB2,0xCA,0x97,0xC9,0x76};
					RtlCopyMemory(&keyData->AesKey,&AesKey,sizeof(AesKey));
				}
			}
		}
		if (keyData->DongleType == DONGLE_HARDLOCK) {
			//readStatus+=GetRegKeyData(hkey, L"Type", &keyData->HdkkeyType, sizeof(keyData->HdkkeyType));
			readStatus+=GetRegKeyData(hkey, L"withMemory", &keyData->HdkHasMem, sizeof(keyData->HdkHasMem));
			readStatus+=GetRegKeyData(hkey, L"ID", &keyData->HdkID, sizeof(keyData->HdkID));
			if (keyData->HdkHasMem) readStatus+=GetRegKeyData(hkey, L"HlkMemory", keyData->HdkMem, min(0x80,sizeof(keyData->HdkMem)));
			// else readStatus+=GetRegKeyData(hkey, L"HlkMemory", keyData->HdkMem, min(0x60,sizeof(keyData->HdkMem)));
			readStatus+=GetRegKeyData(hkey, L"Seed1", &keyData->HdkSeed1, sizeof(keyData->HdkSeed1));
			readStatus+=GetRegKeyData(hkey, L"Seed2", &keyData->HdkSeed2, sizeof(keyData->HdkSeed2));
			readStatus+=GetRegKeyData(hkey, L"Seed3", &keyData->HdkSeed3, sizeof(keyData->HdkSeed3));
		}
		if (keyData->DongleType == DONGLE_SENTINEL)
		{
			readStatus+=GetRegKeyData(hkey, L"Type", &keyData->SentkeyType, sizeof(keyData->SentkeyType));
			readStatus+=GetRegKeyData(hkey, L"sntMemory", keyData->CellMem, sizeof(keyData->CellMem));
			readStatus+=GetRegKeyData(hkey, L"CellType", &keyData->CellType, sizeof(keyData->CellType));
		}

		RtlFillMemory(&keyData->d_name,sizeof(keyData->d_name),0);
		RtlCopyMemory(&keyData->d_name,&pvh->Dump_name,sizeof(keyData->d_name));
		ZwClose(hkey);
		// else keysAttached++; // Chingachguk: key successful installed
	}
	else if (!NT_SUCCESS(status))
		return STATUS_INVALID_PARAMETER;

	return STATUS_SUCCESS;
}

void DelayExecutionThread()
{
	LARGE_INTEGER tim;
	tim.QuadPart = 0x9C40* (-0x04);
	KeDelayExecutionThread(0,0,&tim);
}

// Disable warn 'function changes ebp register'
/* #pragma warning(disable:4731)

void ChiperSent(VOID *bufPtr)
/*++
Routine Description:

Encode/decode response/request to key

Arguments:

bufPtr - pointer to a encoded/decoded data

Return Value:

none

--*/

#pragma warning(default:4731)

/*
DWORD GetHardwareID( )
{
DWORD * BiosMem;
DWORD UniqID = 0;
BiosMem = (DWORD*)MmMapIoSpace(RtlConvertLongToLargeInteger(0xFFFF0) , 0x10, MmNonCached );
if( BiosMem )
{
for( int i = 0; i < 4; ++i )
{
UniqID += BiosMem[i] ^ ((i < 3 ) ? BiosMem[i+1] : 'HeR!');
UniqID = _rotr( UniqID, UniqID & 0x1F );
}
MmUnmapIoSpace(BiosMem, 0x10);
}
return UniqID;
}

*/