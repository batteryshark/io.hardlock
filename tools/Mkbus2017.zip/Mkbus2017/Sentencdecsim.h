//---------------------------------------------------------------------------
#ifndef SentEncDecSimH
#define SentEncDecSimH
//---------------------------------------------------------------------------
typedef UCHAR   BYTE;
typedef USHORT  WORD;
typedef ULONG   DWORD;
//---------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
	//-----------------------------------------------------
	typedef struct {
		ULONG Type;
		ULONG LFSR1;
		ULONG LFSR2;
		ULONG Descriptor1;
		ULONG Descriptor2;
	}QUERY;
	//---------------------------------------------------------------------------
	ULONG QueryInit(void* QueryStruct, ULONG Descriptor, ULONG WP, ULONG C6);
	ULONG Query(void* QueryStruct, ULONG Input);
	void DoQuery(ULONG* QueryData, ULONG QueryLen, ULONG Descriptor, ULONG WP, ULONG C6);

	//---------------------------------------------------------------------------
#ifdef __cplusplus
}
#endif
//---------------------------------------------------------------------------
#endif