DWORD g_password=0x3C3925A0;
