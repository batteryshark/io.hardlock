/*++

Copyright (c) 2004 Chingachguk & Denger2k All Rights Reserved

Module Name:

VUSB.H

Abstract:

This module contains the common private declarations
for the virtual USB Bus enumerator.

Environment:

kernel mode only

Notes:


Revision History:


--*/
#ifndef VUSB_H
#define VUSB_H
#include <ntstrsafe.h>
#include <wmilib.h> // required for WMILIB_CONTEXT
#include "USBKeyEmu.h"
#include "Debug.h"

//
extern ULONG VUsbDebugLevel;
extern ULONG OffsetNameInErpocess;

//
// These are the states a PDO or FDO transition upon
// receiving a specific PnP Irp. Refer to the PnP Device States
// diagram in DDK documentation for better understanding.
//

typedef enum _DEVICE_PNP_STATE {
	NotStarted = 0,         // Not started yet
	Started,                // Device has received the START_DEVICE IRP
	StopPending,            // Device has received the QUERY_STOP IRP
	Stopped,                // Device has received the STOP_DEVICE IRP
	RemovePending,          // Device has received the QUERY_REMOVE IRP
	SurpriseRemovePending,  // Device has received the SURPRISE_REMOVE IRP
	Deleted,                // Device has received the REMOVE_DEVICE IRP
	UnKnown                 // Unknown state
}    DEVICE_PNP_STATE;


typedef struct _GLOBALS {
	//
	// Path to the driver's Services Key in the registry
	//

	UNICODE_STRING  RegistryPath;
} GLOBALS;

extern GLOBALS  Globals;

//
// A common header for the device extensions of the PDOs and FDO
//

typedef struct _COMMON_DEVICE_DATA {
	// A back pointer to the device object for which this is the extension

	PDEVICE_OBJECT      Self;

	// This flag helps distinguish between PDO and FDO

	BOOLEAN             IsFDO;

	// We track the state of the device with every PnP Irp
	// that affects the device through these two variables.

	DEVICE_PNP_STATE    DevicePnPState;

	DEVICE_PNP_STATE    PreviousPnPState;

	ULONG               DebugLevel;

	// Stores the current system power state

	SYSTEM_POWER_STATE  SystemPowerState;

	// Stores current device power state

	DEVICE_POWER_STATE  DevicePowerState;
} COMMON_DEVICE_DATA, *PCOMMON_DEVICE_DATA;

//
// The device extension for the PDOs.
// That's of the USB HASP device which this bus driver enumerates.
//

typedef struct _PDO_DEVICE_DATA {
	COMMON_DEVICE_DATA;

	// A back pointer to the bus

	PDEVICE_OBJECT  ParentFdo;

	// An array of (zero terminated wide character strings).
	// The array itself also null terminated

	PWCHAR          HardwareIDs;

	// Unique serail number of the device on the bus

	ULONG           SerialNo;

	// Link point to hold all the PDOs for a single bus together

	LIST_ENTRY      Link;

	//
	// Present is set to TRUE when the PDO is exposed via PlugIn IOCTL,
	// and set to FALSE when a UnPlug IOCTL is received.
	// We will delete the PDO in IRP_MN_REMOVE only after we have reported
	// to the Plug and Play manager that it's missing.
	//

	BOOLEAN         Present;
	BOOLEAN         ReportedMissing;
	UCHAR           Reserved[2]; // for 4 byte alignment

	//
	// Used to track the intefaces handed out to other drivers.
	// If this value is non-zero, we fail query-remove.
	//
	ULONG           VUsbInterfaceRefCount;

	//
	// In order to reduce the complexity of the driver, I chose not
	// to use any queues for holding IRPs when the system tries to
	// rebalance resources to accommodate a new device, and stops our
	// device temporarily. But in a real world driver this is required.
	// If you hold Irps then you should also support Cancel and
	// Cleanup functions. The function driver demonstrates these techniques.
	//
	// The queue where the incoming requests are held when
	// the device is stopped for resource rebalance.

	//LIST_ENTRY          PendingQueue;

	// The spin lock that protects access to  the queue

	//KSPIN_LOCK          PendingQueueLock;

	// ������, ����������� ��� HASP-������
	KEY_DATA        keyData;
} PDO_DEVICE_DATA, *PPDO_DEVICE_DATA;


//
// The device extension of the bus itself.  From whence the PDO's are born.
//

typedef struct _FDO_DEVICE_DATA {
	COMMON_DEVICE_DATA;

	PDEVICE_OBJECT          UnderlyingPDO;

	// The underlying bus PDO and the actual device object to which our
	// FDO is attached

	PDEVICE_OBJECT          NextLowerDriver;

	// List of PDOs created so far

	LIST_ENTRY              ListOfPDOs;

	// The PDOs currently enumerated.

	ULONG                   NumPDOs;

	// A synchronization for access to the device extension.

	FAST_MUTEX              Mutex;

	//
	// The number of IRPs sent from the bus to the underlying device object
	//

	ULONG                   OutstandingIO; // Biased to 1

	//
	// On remove device plug & play request we must wait until all outstanding
	// requests have been completed before we can actually delete the device
	// object. This event is when the Outstanding IO count goes to zero
	//

	KEVENT                  RemoveEvent;

	//
	// This event is set when the Outstanding IO count goes to 1.
	//

	KEVENT                  StopEvent;

	// The name returned from IoRegisterDeviceInterface,
	// which is used as a handle for IoSetDeviceInterfaceState.

	UNICODE_STRING          InterfaceName;

	//
	// Auto insert all dumps at startup flag
	//
	LONG                    isAutoInsert;

	// WMI Information
	WMILIB_CONTEXT          WmiLibInfo;  //new
} FDO_DEVICE_DATA, *PFDO_DEVICE_DATA;

#define FDO_FROM_PDO(pdoData) \
	((PFDO_DEVICE_DATA) (pdoData)->ParentFdo->DeviceExtension)

#define INITIALIZE_PNP_STATE(_Data_)    \
	(_Data_)->DevicePnPState =  NotStarted;\
	(_Data_)->PreviousPnPState = NotStarted;

#define SET_NEW_PNP_STATE(_Data_, _state_) \
	(_Data_)->PreviousPnPState =  (_Data_)->DevicePnPState;\
	(_Data_)->DevicePnPState = (_state_);

#define RESTORE_PREVIOUS_PNP_STATE(_Data_)   \
	(_Data_)->DevicePnPState =   (_Data_)->PreviousPnPState;\

//
// Prototypes of functions
//
//
// Defined in DriverEntry.C
//
DRIVER_INITIALIZE DriverEntry; //New
NTSTATUS DriverEntry(IN PDRIVER_OBJECT, PUNICODE_STRING);

__drv_dispatchType(IRP_MJ_CREATE) //new
	__drv_dispatchType(IRP_MJ_CLOSE)
	DRIVER_DISPATCH Bus_CreateClose;
NTSTATUS Bus_CreateClose(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);

__drv_dispatchType(IRP_MJ_DEVICE_CONTROL) //new
	DRIVER_DISPATCH Bus_IoCtl;
NTSTATUS Bus_IoCtl(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);

__drv_dispatchType(IRP_MJ_SYSTEM_CONTROL) //new
	DRIVER_DISPATCH Bus_SystemControl;
NTSTATUS Bus_SystemControl (IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);

DRIVER_UNLOAD Bus_DriverUnload; //new
VOID Bus_DriverUnload(IN PDRIVER_OBJECT DriverObject);

VOID Bus_IncIoCount(PFDO_DEVICE_DATA   Data);

VOID Bus_DecIoCount(PFDO_DEVICE_DATA   Data);

PCHAR WMIMinorFunctionString(__in UCHAR MinorFunction); //new

//
// Defined in PNP.C
//

PCHAR PnPMinorFunctionString(UCHAR MinorFunction);

IO_COMPLETION_ROUTINE Bus_CompletionRoutine; //new
NTSTATUS Bus_CompletionRoutine(IN PDEVICE_OBJECT   DeviceObject,
	IN PIRP             Pirp,
	IN PVOID            Context);

NTSTATUS Bus_SendIrpSynchronously(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);

__drv_dispatchType(IRP_MJ_PNP) //new
	DRIVER_DISPATCH Bus_PnP;
NTSTATUS Bus_PnP(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);

DRIVER_ADD_DEVICE Bus_AddDevice;//new
NTSTATUS Bus_AddDevice(IN PDRIVER_OBJECT DriverObject,
	IN PDEVICE_OBJECT BusDeviceObject);

VOID Bus_InitializePdo(__drv_in(__drv_aliasesMem) //new
	PDEVICE_OBJECT Pdo, 
	PFDO_DEVICE_DATA FdoData);

__drv_allocatesMem(Mem)
	NTSTATUS Bus_PlugInDevice(PVUSB_PLUGIN_HARDWARE PlugIn, ULONG PlugInLength, PFDO_DEVICE_DATA DeviceData);

NTSTATUS Bus_UnPlugDevice(PVUSB_UNPLUG_HARDWARE UnPlug, PFDO_DEVICE_DATA DeviceData);

NTSTATUS Bus_EjectDevice(PVUSB_EJECT_HARDWARE Eject, PFDO_DEVICE_DATA FdoData);

void Bus_RemoveFdo(PFDO_DEVICE_DATA FdoData);

NTSTATUS Bus_DestroyPdo(__in __drv_freesMem(Memory) //new
	PDEVICE_OBJECT      Device,
	PPDO_DEVICE_DATA    PdoData);

NTSTATUS Bus_FDO_PnP(IN PDEVICE_OBJECT       DeviceObject,
	IN PIRP                 Irp,
	IN PIO_STACK_LOCATION   IrpStack,
	IN PFDO_DEVICE_DATA     DeviceData);

NTSTATUS Bus_StartFdo(IN  PFDO_DEVICE_DATA   FdoData, IN  PIRP   Irp);

PCHAR DbgDeviceIDString(BUS_QUERY_ID_TYPE Type);

PCHAR DbgDeviceRelationString(IN DEVICE_RELATION_TYPE Type);

//
// Defined in Power.c
//

NTSTATUS Bus_FDO_Power(PFDO_DEVICE_DATA    FdoData, PIRP                Irp);

NTSTATUS Bus_PDO_Power(PPDO_DEVICE_DATA    PdoData, PIRP                Irp);

__drv_dispatchType(IRP_MJ_POWER) //new
	DRIVER_DISPATCH Bus_Power;
NTSTATUS Bus_Power(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);

PCHAR PowerMinorFunctionString(UCHAR MinorFunction);
PCHAR DbgDeviceIDString(BUS_QUERY_ID_TYPE Type);
PCHAR DbgSystemPowerString(IN SYSTEM_POWER_STATE Type);
PCHAR DbgDevicePowerString(IN DEVICE_POWER_STATE Type);

//
// Defined in BusPDO.c
//

NTSTATUS Bus_PDO_PnP(IN PDEVICE_OBJECT       DeviceObject,
	IN PIRP                 Irp,
	IN PIO_STACK_LOCATION   IrpStack,
	IN PPDO_DEVICE_DATA     DeviceData);

NTSTATUS Bus_PDO_QueryDeviceCaps(IN PPDO_DEVICE_DATA     DeviceData,
	IN  PIRP   Irp);

NTSTATUS Bus_PDO_QueryDeviceId(IN PPDO_DEVICE_DATA     DeviceData,
	IN  PIRP   Irp);

NTSTATUS Bus_PDO_QueryDeviceText(IN PPDO_DEVICE_DATA     DeviceData,
	IN  PIRP   Irp);

NTSTATUS Bus_PDO_QueryResources(IN PPDO_DEVICE_DATA     DeviceData,
	IN  PIRP   Irp);

NTSTATUS Bus_PDO_QueryResourceRequirements(IN PPDO_DEVICE_DATA     DeviceData,
	IN  PIRP   Irp);

NTSTATUS Bus_PDO_QueryDeviceRelations(IN PPDO_DEVICE_DATA     DeviceData,
	IN  PIRP   Irp);

NTSTATUS Bus_PDO_QueryBusInformation(IN PPDO_DEVICE_DATA     DeviceData,
	IN  PIRP   Irp);

NTSTATUS Bus_GetDeviceCapabilities(IN  PDEVICE_OBJECT          DeviceObject,
	IN  PDEVICE_CAPABILITIES    DeviceCapabilities);

NTSTATUS Bus_PDO_QueryInterface(IN PPDO_DEVICE_DATA     DeviceData,
	IN  PIRP   Irp);

VOID Bus_InterfaceReference(IN PVOID Context);
VOID Bus_InterfaceDereference(IN PVOID Context);

#endif
