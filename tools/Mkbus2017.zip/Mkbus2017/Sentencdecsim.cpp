//---------------------------------------------------------------------------
extern "C" {
#include <ntddk.h>
}

#include "SentEncDecSim.h"
//---------------------------------------------------------------
#ifdef ALLOC_PRAGMA
#pragma alloc_text (PAGE, QueryInit)
#pragma alloc_text (PAGE, Query)
#pragma alloc_text (PAGE, DoQuery)
#endif

extern "C" void DoQuery(ULONG* QueryData, ULONG QueryLen, ULONG Descriptor, ULONG WP, ULONG C6)
{
	QUERY QueryStruct;
	DWORD Input,Output;
	if (!QueryInit(&QueryStruct,Descriptor,WP,C6)) {
		for (ULONG i=0; i<QueryLen; i++) {
			Input=QueryData[i];
			Output=Query(&QueryStruct,Input);
			QueryData[i]=Query(&QueryStruct,Input+Output);
		}
	}
}

extern "C" ULONG QueryInit(void* QueryStruct, ULONG Descriptor, ULONG WP, ULONG C6)
{
	QUERY* pQuery = (QUERY*)QueryStruct;
	if(Descriptor & 0x80000000)
	{
		if(!(Descriptor & 0x40000000))
		{
			pQuery->LFSR1 = (WP << 0x10) | WP | 0xC000;
			pQuery->Descriptor1 = (Descriptor & 0x3fff3fff) | 0xC000;
			if(pQuery->Descriptor1 & 1) pQuery->Descriptor1 |= 0x40000000;
			pQuery->Type = 0;
		}
		else
		{
			pQuery->Descriptor1 = (Descriptor >> 16) & 0x3FFF;
			pQuery->Descriptor2 = Descriptor & 0xFFFF;

			pQuery->LFSR2 = pQuery->Descriptor1 | 0xC000;
			pQuery->LFSR2 = ((pQuery->LFSR2 >> 1) | (pQuery->LFSR2 << 15)) & 0xFFFF;
			pQuery->LFSR2 = (pQuery->LFSR2 & 0xFFFE) | (((pQuery->LFSR2 >> 15) ^ pQuery->LFSR2) & 1);

			if(!(pQuery->Descriptor1 & 0x000F)) pQuery->Descriptor1 |= 0x0010;
			if(!(pQuery->Descriptor1 & 0x01E0)) pQuery->Descriptor1 |= 0x0200;
			if(!(pQuery->Descriptor1 & 0x3C00)) pQuery->Descriptor1 |= 0x4000;
			if((pQuery->Descriptor2 & 0x8000)) pQuery->Descriptor1 |= 0x4000;
			pQuery->Descriptor1 = (pQuery->Descriptor1 << 2) | 3;

			if(!(pQuery->Descriptor2 & 0x000F)) pQuery->Descriptor2 |= 0x0010;
			if(!(pQuery->Descriptor2 & 0x01E0)) pQuery->Descriptor2 |= 0x0200;
			if(!(pQuery->Descriptor2 & 0x3C00)) pQuery->Descriptor2 |= 0x4000;
			pQuery->Descriptor2 = (pQuery->Descriptor2 & 0x7FFF) ^ 1;

			pQuery->LFSR1 = (C6 << 2) | 3;
			pQuery->Type = 1;
		}
		return 0;
	}
	return 1;
}
extern "C" ULONG Query(void* QueryStruct, ULONG Input)
{
	QUERY* pQuery = (QUERY*)QueryStruct;
	ULONG Output = 0;
	if(pQuery->Type)
	{
		for(LONG I = 31; I >= 0; -- I)
		{
			pQuery->LFSR1 = pQuery->LFSR1 ^ ((Input >> I) & 1);
			pQuery->LFSR1 = ((pQuery->LFSR1 >> 1) | (pQuery->LFSR1 << 17)) & 0x3FFFF;
			if(pQuery->LFSR1 & 0x20000) pQuery->LFSR1 ^= pQuery->Descriptor1;

			pQuery->LFSR2 ^= 1;
			pQuery->LFSR2 = ((pQuery->LFSR2 >> 1) | (pQuery->LFSR2 << 15)) & 0xffff;
			if(pQuery->LFSR2 & 0x8000) pQuery->LFSR2 ^= pQuery->Descriptor2;
		}
		Input = (Input >> 16) | (Input << 16);
		for(LONG I = 31; I >= 0; -- I)
		{
			ULONG Selector = (((pQuery->LFSR1 >> 0x11) & 1) | ((pQuery->LFSR1 >> 0x0C) & 2) |
				((pQuery->LFSR1 >> 0x03) & 4) | ((pQuery->LFSR1 >> 0x04) & 8));

			switch(Selector){
			case 0x6: Output = Output | ((((pQuery->LFSR2 >> 0xF) ^ pQuery->LFSR2) & 0x1) << I); break;
			case 0x3: Output = Output | (((pQuery->LFSR2 >> 0x1) & 1) << I); break;
			case 0x4: Output = Output | (((pQuery->LFSR2 >> 0x2) & 1) << I); break;
			case 0xA: Output = Output | (((pQuery->LFSR2 >> 0x3) & 1) << I); break;
			case 0x7: Output = Output | (((pQuery->LFSR2 >> 0x4) & 1) << I); break;
			case 0xF: Output = Output | (((pQuery->LFSR2 >> 0x5) & 1) << I); break;
			case 0x2: Output = Output | (((pQuery->LFSR2 >> 0x6) & 1) << I); break;
			case 0x0: Output = Output | (((pQuery->LFSR2 >> 0x7) & 1) << I); break;
			case 0xD: Output = Output | (((pQuery->LFSR2 >> 0x8) & 1) << I); break;
			case 0x5: Output = Output | (((pQuery->LFSR2 >> 0x9) & 1) << I); break;
			case 0x9: Output = Output | (((pQuery->LFSR2 >> 0xA) & 1) << I); break;
			case 0x1: Output = Output | (((pQuery->LFSR2 >> 0xB) & 1) << I); break;
			case 0xC: Output = Output | (((pQuery->LFSR2 >> 0xC) & 1) << I); break;
			case 0xE: Output = Output | (((pQuery->LFSR2 >> 0xD) & 1) << I); break;
			case 0x8: Output = Output | (((pQuery->LFSR2 >> 0xE) & 1) << I); break;
			case 0xB: Output = Output | (((pQuery->LFSR2 >> 0xF) & 1) << I); break; }

			pQuery->LFSR1 = pQuery->LFSR1 ^ ((Input >> I) & 1);
			pQuery->LFSR1 = ((pQuery->LFSR1 >> 1) | (pQuery->LFSR1 << 17)) & 0x3FFFF;
			if(pQuery->LFSR1 & 0x20000) pQuery->LFSR1 ^= pQuery->Descriptor1;

			pQuery->LFSR2 ^= 1;
			pQuery->LFSR2 = ((pQuery->LFSR2 >> 1) | (pQuery->LFSR2 << 15)) & 0xffff;
			if(pQuery->LFSR2 & 0x8000) pQuery->LFSR2 ^= pQuery->Descriptor2;
		}
	}
	else
	{
		for(LONG I = 31; I >= 0; -- I)
		{
			pQuery->LFSR1 = pQuery->LFSR1 ^ ((Input >> I) & 1);
			pQuery->LFSR1 = (pQuery->LFSR1 >> 1) | (pQuery->LFSR1 << 31);
			if(pQuery->LFSR1 & 0x80000000) pQuery->LFSR1 ^= pQuery->Descriptor1;
		}
		Input = (Input >> 16) | (Input << 16);
		for(LONG I = 31; I >= 0; -- I)
		{
			Output = Output | ((pQuery->LFSR1 & 1) << I);
			pQuery->LFSR1 = pQuery->LFSR1 ^ ((Input >> I) & 1);
			pQuery->LFSR1 = (pQuery->LFSR1 >> 1) | (pQuery->LFSR1 << 31);
			if(pQuery->LFSR1 & 0x80000000) pQuery->LFSR1 ^= pQuery->Descriptor1;
		}
	}
	return Output;
}