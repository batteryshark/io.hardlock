CryptoProgramming under Win9X and WinNT/2000/XP
--------------------------------------------------

- Please make sure of proper driver-installation (HLDRV32.EXE)!

- For CP-Card PCI-Version install the additional drivers using the .inf-file

- Commandline-switches of CP32.EXE:

	Usage: CP32 <parameter>

	-B                  Burn the key.
	-Ssubcode           Specify subcode.
	-Musermodadr        Specify user module address.
	-Eeepromimage       Path to file.
	-PSigPort           Search signature on port.
	-OProgPort          CP Card port address.
	-L                  Show Port/CPC-list and exit.
	-U                  Burn USB key. Ignore switch -O
	-H                  Show this help.

	(add a leading $ for hexadecimal port addresses)

	Example: CP32 -o$3bc -p$278 -etest.eep -s100

- If the CP-Card (ISA-Version only) is not found, please
    	1) verify the port-adress jumper (278h or 3BCh) with your system (LPT). 
	   For Windows2000/XP please use the setting 3BCh.
	2) for CP-initialisation set the environment:
    	   SET HL_Search=278x,3BCx

- Return codes of CP32.EXE:

    0     Burning successful!
    1     No EEPROM image defined
    2     Hardlock not responding
    4     Unable to load signature
    8     Illegal signature
    16    No memory found
    32    Verify memory failed
    64    No CP-Card found
    128   Wrong Hardlock driver version
    256   No EEPROM image defined
    512   (internal use only)
    1024  Invalid serialnumber

- For sample applications how to use our programming DLL please refer to the SAMPLES
  subdirectory.

Aladdin Knowledge Systems
Technical Support
tech@aladdin.de
