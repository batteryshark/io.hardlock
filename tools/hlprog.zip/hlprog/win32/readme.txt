List of Aladdin HLPROG DLL Versions since February 2005
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The following list includes improvements, bug fixes, and other relevant
information. It is arranged in descending chronological order.

The hlprog.dll is used by the the Hardlock crypto-programming tools to communicate
with the crypto programming devices.

Version 2.10 (February 2005)
=========================

This release supports crypto-programming of Hardlock keys on Windows 9X/ME
platforms where the HASP HL device drivers are installed.

Installation Notes
------------------

Install the new version of the hlprog.dll by copying it over older versions on 
your system.

Aladdin Knowledge Systems Ltd. (c) 1985 - 2005. All rights reserved