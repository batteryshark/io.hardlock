=============================================================================
Note: 	CP for DOS does not run in an Windows NT/2000/XP DOS emulation. 
	CP for DOS does also not support the new PCI Crypto Programmer Card
	Please use the Win32 tools instead.
=============================================================================

                            new since version V4.0

The selection menu for the signature port has changed a little bit. Until
now you had the choice between installed printer ports and they have
been marked with LPT1, LPT2 and LPT3. As a reaction to customer wishes who
use HL-ON-CARD as a master hardlock you can choose now between $278, $378
and $3BC - the real IO addresses of the ports.

--------------------------------------------------------------------------

The burn program got a new name. It is called CP.EXE instead of CP-EYE.EXE
It can be renamed without problems if you want to.

All additional files like CP-EYE.DEF, CP-EYE.LAN, CP-EYE.REP and CP-EYE.MCH
keept their names because of compatibility reasons.

--------------------------------------------------------------------------

The mode of writing the 16 bit registers of the optional memory IC is fixed
to LOHI now and the menu item is removed. It caused to many confusion among
customers and is now compatible with the HARDLOCK API calls.

If you still need to use HILO you can set it with the CP-EYE.DEF settings:

        EEP_MODE=HILO

--------------------------------------------------------------------------

