]http://www.reteam.org/board/archive/index.php?t-662.html




Hi All,
I decided to write this little how-to after spending a lot of time trying to emulate my sentinel dongle. All the programs I used were not written by me and I am very grateful to all great guys here.
I emulated "Sentinel SuperPro"
1.	Dump dongle with PVA 3.3 util with out "Brute WP" selected.
2.	Solve the DMP file using "f1_nodongle" (10x to cEnginEEr) util, you should get XXXX.SSP file (~100kb).
3.	Use "UniDumpToReg" util to convert the SSP to REG. Inside "UniDumpToReg" select your SSP file and then select "SafeKey ssp -> vUSB Sentinel" option and push "GO".
4.	Open the REG file in Notepad or any other text editor and make the following changes:

[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet
\Services\Emulator\Sentinel\Dump\XXXX0000]

To

[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet
\Services\ru-board\mulators\Dump\XXXX0000]

"sntMemory"=hex:0A3E,1255,C5E3,0000,0009�..
To
"sntMemory"=hex:3E,0A,55,12,E3,C5,00,00,09,00�.. make this comma add and switch up to the end of this cell
5.	Run "install.bat" from "vusbus" folder
6.	Your comp should found new hardware and install it by it self
7.	Import your changed REG in to the REGISTRY
8.	Reboot
Here is link to all utils that I mentioned above:
http://rapidshare.com/files/86877710/Sentinel_vUSB_Emulator.zip.html

New converter from ssp to reg ver 1.11:
http://rapidshare.de/files/39593244/ssp2reg1.11.rar.html
pass:reteam.org

OMG!!! Very very helpfull!! I just tried it once and it really works Very greatfull to the master... 

I don't know why or maybe it is ordinary but sometimes when i reboot my pc I have to reinstall and remove the emulator so i can use it again... but hehe does't matter I'm very happy i can use it.