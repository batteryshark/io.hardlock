/****************************************************************************/
/**                                                                        **/
/**                           Hardlock API-Calls                           **/
/**                                                                        **/
/**   This program is just an example for some functions to access the     **/
/**   application programing interface (API) for Hardlock. Feel free to    **/
/**   define your own functions.                                           **/
/**                                                                        **/
/**                  Aladdin Knowledge Systems, Germany                    **/
/**                                                                        **/
/**  Revision history                                                      **/
/**  ----------------                                                      **/
/**
***  $Log: hlapi_c.c,v $
***  Revision 1.68  2003/04/30 11:14:45  chris
***  fix CENTRY and __cdecl for Watcom C
***
***  Revision 1.67  2003/02/11 10:54:04  axel
***  removed 3rd and 4th parameter from HL_SERVERADDR
***  fixed error: NO_LOCAL_FUNCTION in HL_SERVERADDR
***
***  Revision 1.66  2003/01/30 09:34:18  axel
***  added HL_SERVERADDR
***  added "Bcnt = 0" in some places to avoid illegal pointer access
***
***  Revision 1.65  2002/10/10 09:54:24  chris
***  fixed USB key test in HL_SERVERLICENSES
***
***  Revision 1.64  2002/08/23 10:48:35  axel
***  added function HL_SERVERLICENSES()
***
***  Revision 1.63  2002/03/18 13:30:22  chris
***  changes for Win64
***
***  Revision 1.62  2001/02/20 12:44:29  chris
***  return code fixes in HLM_FREESLOT, HLM_CHECKSLOT and HLM_CHECKEXPDATE
***
***  Revision 1.61  2001/02/07 10:59:06  chris
***  fixed HLM_CHECKEXPDATE with slot #0
***
***  Revision 1.60  2001/01/23 15:37:12  chris
***  HLM_CHECKEXPDATE now returns NO_LICENSE if called for a disabled
***  slot (MaxUser == 0)
***
***  Revision 1.59  2000/09/21 13:16:44  chris
***  fix in HLM_CHECKALLSLOTS: clear Bcnt after low-level call
***
***  Revision 1.58  2000/09/21 12:24:37  chris
***  fix in HL_MAXUSER and HL_USERINF: always use API_INFO on
***  locally connected keys
***
***  Revision 1.57  2000/09/20 14:41:21  chris
***  fixed HL_READID, return better error code if structure isn't initialized
***
***  Revision 1.56  2000/09/14 11:54:42  chris
***  removed old history log entries; it was rather big.
***
**/
/****************************************************************************/

#ifdef  _MSC_VER
  #pragma warning (disable:4103)                /* no #pragma pack warnings */
#endif

#define GETSTRUC if (!api_struc) api_struc = &hl_struc

#include "hlapi_c.h"

static HL_API hl_struc = {{0}};                 /* Hardlock API structure   */
static HL_API DATAFAR_ *api_struc=0;            /* Pointer to API structure */

static Word CALL_API (HL_API DATAFAR_ *api_struc);

#ifdef __cplusplus
  extern "C" {
#endif

#ifdef UNIX32
  #define CENTRY
#endif

#if defined(WINNT) || defined(WIN32) || defined(WIN64)
  #ifdef __WATCOMC__
    #pragma aux cdecl "_*" parm caller [] value struct routine [eax] modify [eax ebx ecx edx]
    #pragma aux (cdecl) API_HL_CSTACK;
    #ifndef CENTRY  /* not defined in older versions */
      #define CENTRY
    #endif
  #else
    #define CENTRY
  #endif
#endif

#ifdef SALFORD
  #include <dbos\lib.h>
  #define CENTRY
#endif

#ifdef CENTRY
  #ifdef DLL_USE
    #if defined(WINNT) || defined(WIN32) || defined(WIN64)
      extern Word __stdcall _API_DLL(HL_API DATAFAR_ *api_struc);
      #define API_Function _API_DLL
    #endif
  #else
    #if (defined(WINNT) || defined(WIN32) || defined(WIN64)) && !defined(__WATCOMC__)
      extern Word FAR_ __cdecl API_HL_CSTACK(HL_API DATAFAR_ *api_struc);
    #else
      extern Word FAR_ API_HL_CSTACK(HL_API DATAFAR_ *api_struc);
    #endif
    #define API_Function API_HL_CSTACK
  #endif
#else
  #ifdef DLL_USE
    extern Word FAR_ pascal _API_DLL(HL_API DATAFAR_ *api_struc);
    #define API_Function _API_DLL
  #else
    #ifdef __HIGHC__
      extern Word _API_HL_CSTACK(HL_API DATAFAR_ *api_struc);
      #define API_Function _API_HL_CSTACK
    #else
      extern Word FAR_ pascal _API_HL_STACK(HL_API DATAFAR_ *api_struc);
      #define API_Function _API_HL_STACK
    #endif
  #endif
#endif

#ifdef __cplusplus
  }
#endif

#ifdef WITH_HLM

/* Date helper functions: */
/* ---------------------- */
static int isleap (unsigned yr)
{return yr % 400 == 0 || (yr % 4 == 0 && yr % 100 != 0);}

static unsigned months_to_days (unsigned month)
{return (month * 3057 - 3007) / 100;}

static unsigned long years_to_days (unsigned yr)
{return yr * 365L + yr / 4 - yr / 100 + yr / 400;}

#endif

/****************************************************************************/
static Word CALL_API(HL_API DATAFAR_ *api_struc)
/****************************************************************************/
{
Word result;

/* ----------------- */
/* We call the API : */
/* ----------------- */

#ifdef SALFORD
  set_io_permission(1);
#endif

result = API_Function(api_struc);

#ifdef SALFORD
  set_io_permission(0);
#endif

return (result);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_SELECT(HL_API DATAFAR_ *hl_ptr)
/****************************************************************************/
{
if (!hl_ptr)
  api_struc = &hl_struc;
 else
  api_struc = hl_ptr;

return (STATUS_OK);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_LOGOUT(void)
/****************************************************************************/
{
Word i, result;

GETSTRUC;
if (api_struc->Remote == NET_DEVICE)
  {
  api_struc->Function = API_LOGOUT;
  CALL_API(api_struc);
  }

api_struc->Function = API_DOWN;
CALL_API(api_struc);
if (api_struc->Status)
  {
  api_struc->Function = API_FORCE_DOWN;
  CALL_API(api_struc);
  }

result = api_struc->Status;

/* Set the API structure back to zero: */
/* ----------------------------------- */
for (i = 0; i < sizeof(HL_API); i++)
  ((char *) api_struc)[i] = 0;

return (result);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_PORTINF(void)
/****************************************************************************/
{
GETSTRUC;

if (api_struc->PortFlags & USB_DEVICE)
  return (0);

api_struc->Function = API_AVAIL;
CALL_API(api_struc);

if (api_struc->Status) return (0xffff);
return (api_struc->Port);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_USERINF(void)
/****************************************************************************/
{
GETSTRUC;

if (api_struc->Slot_ID == 0 || (api_struc->Remote & LOCAL_DEVICE))
  api_struc->Function = API_INFO;
 else
  api_struc->Function = API_AVAIL;

api_struc->Application = 0;
CALL_API(api_struc);

if (api_struc->Status) return (0xffff);
return (api_struc->NetUsers);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_MAXUSER(void)
/****************************************************************************/
{
GETSTRUC;

if (api_struc->Slot_ID == 0 || (api_struc->Remote & LOCAL_DEVICE))
  api_struc->Function = API_INFO;
 else
  api_struc->Function = API_AVAIL;

CALL_API(api_struc);

if (api_struc->Status) return (0xffff);
return (api_struc->MaxUsers);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_ACCINF(void)
/****************************************************************************/
{
GETSTRUC;
api_struc->Function = API_AVAIL;
CALL_API(api_struc);

if (api_struc->Status) return (0xffff);
return (api_struc->Remote);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_VERSION(void)
/****************************************************************************/
{
GETSTRUC;
api_struc->Function = API_AVAIL;
CALL_API(api_struc);

if (api_struc->Status) return (0xffff);
return ((api_struc->API_Version_ID[0] * 100) + api_struc->API_Version_ID[1]);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_HLSVERS(void)
/****************************************************************************/
{
Word result;

GETSTRUC;
if (api_struc->Remote == NET_DEVICE)
  {
  api_struc->Function  = API_AVAIL;
  result               = CALL_API(api_struc);
  if (result == STATUS_OK)
    return (api_struc->ShortLife);
  }
return 0;
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_AVAIL(void)
/****************************************************************************/
{
GETSTRUC;

api_struc->Bcnt = 0; /* assure that data isn't accessed */
api_struc->Function = API_AVAIL;
CALL_API(api_struc);

if ((api_struc->Status == NO_DONGLE) && (api_struc->ShortLife == 1) && (api_struc->Remote == LOCAL_DEVICE))
  return(SELECT_DOWN);

return (api_struc->Status);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_CODE(void DATAFAR_ *Data, Word Cnt)
/****************************************************************************/
{
GETSTRUC;
set_data_ptr(api_struc,Data);
api_struc->Bcnt     = Cnt;
api_struc->Function = API_KEYE;
CALL_API(api_struc);
api_struc->Bcnt     = 0;

return (api_struc->Status);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_READ(Word Reg, Word DATAFAR_ *Value)
/****************************************************************************/
{
GETSTRUC;

if(Reg <= 63)
  {
  api_struc->Module.Eye.Reg = Reg;
  api_struc->Function       = API_READ;

  CALL_API(api_struc);
  if(api_struc->Status)
    return (api_struc->Status);

  *Value = api_struc->Module.Eye.Value;
  return (STATUS_OK);
  }

return (INVALID_PARAM);
}

#ifdef WITH_HLM

/****************************************************************************/
RET_ FAR_ CALL_ HLM_CHECKALLSLOTS (Long *BufLen, HL_LIS *Buffer)
/****************************************************************************/
{
GETSTRUC;

if (*BufLen > 0x7ffff) return (INVALID_PARAM); /* max. size possible */
if (Buffer == 0 && *BufLen != 0) return(INVALID_PARAM);

api_struc->Function = API_FFS_CHECK_LIC;
api_struc->FuncOptions = 0;  /* initialize */
set_data_ptr(api_struc,Buffer);
api_struc->Bcnt = *BufLen >> 3;
CALL_API(api_struc);
api_struc->FuncOptions  = 0;
api_struc->Bcnt = 0;
set_data_ptr(api_struc,0);

if (api_struc->Status == STATUS_OK)
  {
  if (*BufLen == 0)
    {
    *BufLen = api_struc->ShortLife << 3;    /* return needed buffer length */
    return(BUFFER_TOO_SMALL);
    }
  else
    {
    api_struc->Slot_ID      = 0;
    api_struc->Slot_ID_HIGH = 0;
    api_struc->RUS_ExpDate  = 0;
    api_struc->Function     = API_FFS_QUERY_SLOT;
    CALL_API(api_struc);
    api_struc->FuncOptions  = 0;

    Buffer->current_date = api_struc->ShortLife;
    Buffer->res = 0;
    }
  }

return (api_struc->Status);
}

/****************************************************************************/
RET_ FAR_ CALL_ HLM_WRITELICENSE (Long BufLen, Byte DATAFAR_ * RTBBuffer, Word Access, Byte DATAFAR_ * SearchStr, Word Options)
/****************************************************************************/
{
Long   xlen;
HL_API local_struc;
Word   i, j, result;
Byte   SString[80];
Word   sslen = 0;
Word   blocks = 0;

if (BufLen > 0x7ffff)
  return (INVALID_PARAM); /* max. size possible */

/* Set the API structure back to zero: */
/* ----------------------------------- */
for (i = 0; i < sizeof(HL_API); i++)
  ((char *)&local_struc)[i] = 0;

/* Parse RTB block: */
/* ---------------- */
xlen = BufLen >> 3;
if (BufLen & 7) xlen++;
local_struc.Remote     = LOCAL_DEVICE;
local_struc.ShortLife  = (xlen << 3) - BufLen;
local_struc.Data       = RTBBuffer;
local_struc.Bcnt       = (Word)xlen;
local_struc.Function   = API_FFS_PARSERTB;
CALL_API(&local_struc);
if (local_struc.Status != STATUS_OK)
  return (local_struc.Status);

local_struc.Data       = 0;
local_struc.Bcnt       = 0;

/* --------------------------------- */
/* Check and prepare search string : */
/* --------------------------------- */
if (SearchStr != 0)
 if(SearchStr[0] != '\0')
  {
  /* Get length of search string : */
  for (sslen = 0; SearchStr[sslen] != '\0'; sslen++);

  /* Add one for zero : */
  sslen++;

  /* count number of 8 bytes blocks we get : */
  blocks = sslen / 8;
  if ((sslen % 8) != 0)
    blocks++;
  if (blocks > 10)
    return (INVALID_ENV);

  /* Copy search string to stack : */
  for (i = 0; i < sslen; i++)
     SString[i] = SearchStr[i];

  /* Add spaces to fill up last block : */
  for (j = 0; j < (blocks * 8 - sslen); j++)
     SString[i + j] = 0x20;

  /* Now put it into api structure : */
  local_struc.Bcnt = blocks;
  local_struc.Data = SString;
  }

/* --------------------------------------------- */
/* Call the INIT (search for Hardlock) function :*/
/* --------------------------------------------- */
local_struc.VendorKey = 0;
local_struc.Remote    = Access;
local_struc.Function  = API_FFS_INIT;
result = CALL_API(&local_struc);
local_struc.Data      = 0;
local_struc.Bcnt      = 0;
/* Old Low-API returns NOT_INIT error, if function not */
/* known and API structure hasn't been initialized yet */
if (result == NOT_INIT)
  return (VERSION_MISMATCH);
if (local_struc.Status != STATUS_OK)
  return (local_struc.Status);

/* ----------------------------- */
/* No further checks necessary : */
/* ----------------------------- */
if ((result == INVALID_ENV) || (result == CANNOT_OPEN_DRIVER))
  return (result);

/* ----------------------------- */
/* Check, if HL-Server is full : */
/* ----------------------------- */
if (result != STATUS_OK)
  {
  if ((Access & NET_DEVICE) == NET_DEVICE)
    {
    local_struc.Function = API_LOGIN_INFO;
    if (CALL_API(&local_struc) == HLS_FULL)
      result = TOO_MANY_USERS;
    }
  return (result);
  }

/* ------------------------------------------ */
/* Login to HL-Server if Hardlock is remote : */
/* ------------------------------------------ */
if (local_struc.Remote == NET_DEVICE)
  {
  local_struc.Function = API_LOGIN; /* don't do API_FFS_LOGIN, we don't have a VK! */
  result = CALL_API(&local_struc);
  if(result)
    {
    local_struc.Function = API_DOWN;
    CALL_API(&local_struc);
    }
  }

/* Now write it: */
/* ------------- */
xlen = BufLen >> 3;
if (BufLen & 7) xlen++;
local_struc.ShortLife   = (xlen << 3) - BufLen;
local_struc.Data        = RTBBuffer;
local_struc.Bcnt        = (Word)xlen;
local_struc.FuncOptions = 0; /* write mode */
if (Options & 1) local_struc.FuncOptions = 2; /* write mode with create flag */
local_struc.Function    = API_FFS_WRITE_LIC;
result = CALL_API(&local_struc);
local_struc.Bcnt        = 0;
local_struc.Data        = 0;
if (local_struc.Status != STATUS_OK) return (local_struc.Status);

xlen = BufLen >> 3;
if (BufLen & 7) xlen++;
local_struc.ShortLife   = (xlen << 3) - BufLen;
local_struc.Data        = RTBBuffer;
local_struc.Bcnt        = (Word)xlen;
local_struc.FuncOptions = 1; /* finish mode */
local_struc.Function    = API_FFS_WRITE_LIC;
result = CALL_API(&local_struc);
local_struc.Bcnt        = 0;
local_struc.ShortLife   = 0;
local_struc.FuncOptions = 0;
local_struc.Data        = 0;

/* Down and Logout: */
/* ---------------- */
if (local_struc.Remote == NET_DEVICE)
  {
  local_struc.Function = API_LOGOUT;
  CALL_API(&local_struc);
  }

local_struc.Function = API_DOWN;
CALL_API(&local_struc);
if (local_struc.Status)
  {
  local_struc.Function = API_FORCE_DOWN;
  CALL_API(&local_struc);
  }

return (result);
}

/****************************************************************************/
RET_ FAR_ CALL_ HLM_GETRUSINFO (Long * BufLen, Byte DATAFAR_ * RTBBuffer, Word Base64)
/****************************************************************************/
{
GETSTRUC;

if (*BufLen > 0x7ffff) return(INVALID_PARAM);
if (RTBBuffer == 0 && *BufLen != 0) return(INVALID_PARAM);

api_struc->ShortLife   = 0;
set_data_ptr(api_struc,RTBBuffer);
api_struc->Bcnt        = *BufLen >> 3;
api_struc->Function    = API_FFS_GETRUSINFO;
api_struc->FuncOptions = Base64 ? 1 : 0;
CALL_API(api_struc);

if (api_struc->Status != STATUS_OK)
  {
  if (api_struc->Status == BUFFER_TOO_SMALL)
    {
    *BufLen = ((Long)api_struc->ShortLife) << 3;          /* return needed buffer length */
    }
  api_struc->Bcnt        = 0;
  api_struc->FuncOptions = 0;
  api_struc->ShortLife   = 0;
  return (api_struc->Status);
  }
*BufLen = (api_struc->Bcnt << 3) - api_struc->ShortLife; /* return correct length in bytes */
api_struc->Bcnt        = 0;
api_struc->FuncOptions = 0;
api_struc->ShortLife   = 0;
return (STATUS_OK);
}

#endif /* #ifdef WITH_HLM */

/****************************************************************************/
RET_ FAR_ CALL_ HL_READID(Word DATAFAR_ *IDLow, Word DATAFAR_ *IDHigh)
/****************************************************************************/
{
GETSTRUC;

api_struc->Module.Eye.Reg = 14;
api_struc->Function       = API_READ_ID;

CALL_API(api_struc);
if(api_struc->Status)
  return (api_struc->Status);

if (!(api_struc->PortFlags & USB_DEVICE))
  return (NO_SERIALID);

*IDLow  = api_struc->Module.Eye.Value;
*IDHigh = api_struc->Module.Eye.Reg;

if ((*IDLow == 0x0000) && (*IDHigh == 0x0000))
  return (NO_SERIALID);

return (STATUS_OK);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_READBL(Byte DATAFAR_ * Eeprom)
/****************************************************************************/
{
GETSTRUC;
api_struc->Bcnt     = 16;
set_data_ptr(api_struc,Eeprom);
api_struc->Function = API_READ_BLOCK;
CALL_API(api_struc);
api_struc->Bcnt     = 0;

return (api_struc->Status);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_WRITEBL(Byte DATAFAR_ * Eeprom)
/****************************************************************************/
{
GETSTRUC;
api_struc->Bcnt     = 4;
set_data_ptr(api_struc,Eeprom);
api_struc->Function = API_WRITE_BLOCK;
CALL_API(api_struc);
api_struc->Bcnt     = 0;

return (api_struc->Status);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_ABORT(void)
/****************************************************************************/
{
GETSTRUC;
api_struc->Function = API_LOGOUT;
CALL_API(api_struc);
api_struc->Function = API_ABORT;
CALL_API(api_struc);

return (api_struc->Status);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_WRITE(Word Reg, Word Value)
/****************************************************************************/
{
GETSTRUC;
if(Reg >= 48 && Reg <= 63)
  {
  api_struc->Module.Eye.Reg   = Reg;
  api_struc->Module.Eye.Value = Value;
  api_struc->Function         = API_WRITE;
  CALL_API(api_struc);
  return (api_struc->Status);
  }

return (INVALID_PARAM);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_MEMINF(void)
/****************************************************************************/
{
Word newvalue, oldvalue;
Word TestMem = 0;
Byte Memory[128];
int i;

GETSTRUC;

/* -------------------------------------- */
/* HL-Server Hardlocks always have memory */
/* -------------------------------------- */
if (api_struc->Remote == NET_DEVICE)
  return (STATUS_OK);

/* -------------------------- */
/* Read memory in one block : */
/* -------------------------- */
api_struc->Bcnt     = 16;
set_data_ptr(api_struc,Memory);
api_struc->Function = API_READ_BLOCK;
CALL_API(api_struc);
api_struc->Bcnt     = 0;
if (api_struc->Status != STATUS_OK)
  return (NO_ACCESS);

/* -------------------------------------- */
/* Check, if every value is zero or one : */
/* -------------------------------------- */
for (i = 0; i < 128; i++)
  TestMem |= Memory[i];
if (TestMem != 0)
  {
  for (i = 0; i < 128; i++)
    {
    if (Memory[i] != 0xff)
      return (STATUS_OK);
    }
  }

/* ---------------------- */
/* Save memory contents : */
/* ---------------------- */
api_struc->Module.Eye.Reg = 48;
api_struc->Function       = API_READ;
CALL_API(api_struc);
if(api_struc->Status) return (NO_ACCESS);
oldvalue                 = api_struc->Module.Eye.Value;

/* ---------------------------------------------------------------- */
/* XOR of the read value to exclude random returns from interface : */
/* ---------------------------------------------------------------- */
newvalue = oldvalue ^ 0x0d0e;

/* ------------------------ */
/* Write new memory value : */
/* ------------------------ */
api_struc->Module.Eye.Value = newvalue;
api_struc->Function         = API_WRITE;
CALL_API(api_struc);
if(api_struc->Status)
 {
 api_struc->Module.Eye.Value = oldvalue;
 api_struc->Function         = API_WRITE;
 CALL_API(api_struc);
 return(NO_ACCESS);
 }

/* ------------------------- */
/* Read and compare memory : */
/* ------------------------- */
api_struc->Function = API_READ;
CALL_API(api_struc);
if(api_struc->Status)
 {
 api_struc->Module.Eye.Value = oldvalue;
 api_struc->Function         = API_WRITE;
 CALL_API(api_struc);
 return(NO_ACCESS);
 }
if (api_struc->Module.Eye.Value != newvalue)
 {
 api_struc->Module.Eye.Value = oldvalue;
 api_struc->Function         = API_WRITE;
 CALL_API(api_struc);
 return(NO_ACCESS);
 }

/* ------------------ */
/* Write old memory : */
/* ------------------ */
api_struc->Module.Eye.Value = oldvalue;
api_struc->Function         = API_WRITE;
CALL_API(api_struc);
if(api_struc->Status)
 {
 api_struc->Module.Eye.Value = oldvalue;
 api_struc->Function         = API_WRITE;
 CALL_API(api_struc);
 return(NO_ACCESS);
 }

return (STATUS_OK);
}

#ifdef WITH_HLM

/****************************************************************************/
RET_ FAR_ CALL_ HLM_OCCUPYSLOT (Long Slot)
/****************************************************************************/
{
GETSTRUC;

api_struc->Bcnt         = 0;
api_struc->Slot_ID      = (Word) (0xffff & Slot);
api_struc->Slot_ID_HIGH = (Word) (Slot >> 16);
api_struc->Function     = API_FFS_OCCUPY_SLOT;
CALL_API(api_struc);

return (api_struc->Status);
}

/****************************************************************************/
RET_ FAR_ CALL_ HLM_FREESLOT (Long Slot)
/****************************************************************************/
{
Word result;

GETSTRUC;

api_struc->Slot_ID      = (Word) (0xffff & Slot);
api_struc->Slot_ID_HIGH = (Word) (Slot >> 16);
api_struc->Function     = API_FFS_FREE_SLOT;
result = CALL_API(api_struc);

if (result == RUS_DATE_EXPIRED) result = STATUS_OK;
return (result);
}

/****************************************************************************/
RET_ FAR_ CALL_ HLM_CHECKSLOT (Long Slot, Long * MaxUser, Long * CurrentUser)
/****************************************************************************/
{
Word result;

GETSTRUC;

api_struc->Slot_ID      = (Word) (0xffff & Slot);
api_struc->Slot_ID_HIGH = (Word) (Slot >> 16);
api_struc->Function     = API_FFS_QUERY_SLOT;
result = CALL_API(api_struc);
if (result != STATUS_OK && result != RUS_INVALID_SLOT)
  return (result);

if (result == STATUS_OK)
  {
    *MaxUser     = api_struc->RUS_MaxInfo;
    *CurrentUser = api_struc->RUS_CurInfo;
  }
 else
  {
    *MaxUser     = 0;
    *CurrentUser = 0;
  }

return (STATUS_OK);
}

/****************************************************************************/
RET_ FAR_ CALL_ HLM_CHECKEXPDATE (Long Slot, Word * Year, Word * Month, Word * Day)
/****************************************************************************/
{
Word result;
Long scalar;
Word n;

GETSTRUC;

/* preinitialize result */
*Month = *Day = *Year = 0;

api_struc->Slot_ID      = (Word) (0xffff & Slot);
api_struc->Slot_ID_HIGH = (Word) (Slot >> 16);
api_struc->RUS_ExpDate  = 0;
api_struc->Function     = API_FFS_QUERY_SLOT;
api_struc->FuncOptions  = 1;
result = CALL_API(api_struc);
api_struc->FuncOptions  = 0;
if (result != STATUS_OK && result != RUS_INVALID_SLOT)
 return (api_struc->Status);

 if (!api_struc->RUS_MaxInfo && Slot)  /* slot 0 is special */
 {
 return(STATUS_OK);  /* slot not enabled */
 }

if (result == RUS_INVALID_SLOT || !api_struc->RUS_ExpDate)
 {
 return (STATUS_OK);
 }

scalar = api_struc->RUS_ExpDate + 730120 - 365;

for (n = (unsigned)((scalar * 400L) / 146097L); years_to_days(n) < scalar; n++);

*Year = n;
n = (unsigned)(scalar - years_to_days(n-1));
if (n > 59)
  {
  n += 2;
  if (isleap(*Year))
    n -= n > 62 ? 1 : 2;
  }
*Month = (n * 100 + 3007) / 3057;
*Day = n - months_to_days(*Month);

if (api_struc->RUS_ExpDate < api_struc->ShortLife)
 result = RUS_DATE_EXPIRED;
api_struc->ShortLife=0;
api_struc->RUS_ExpDate=0;

return (result);
}

/****************************************************************************/
RET_ FAR_ CALL_ HLM_ISRUSHL (Long * ID)
/****************************************************************************/
{
Word result;
Byte MemBuff[128];
RUS_FIB  *myFIB = (RUS_FIB *) MemBuff;

GETSTRUC;

result = HL_READBL(MemBuff);
if (result != STATUS_OK)
  return (api_struc->Status);

api_struc->Bcnt     = 16;
set_data_ptr(api_struc,MemBuff);
api_struc->Function = API_FFS_ISRUSHL;
result = CALL_API(api_struc);
api_struc->Bcnt     = 0;
if (result != STATUS_OK)
  return (api_struc->Status);

*ID = myFIB->SERIAL_ID;

return (STATUS_OK);
}

/****************************************************************************/
RET_ FAR_ CALL_ HLM_CHECKCOUNTER (Word IncVal, Long * MaxCounter, Long * CurrentCounter)
/****************************************************************************/
{
Word result;

GETSTRUC;

api_struc->ShortLife   = IncVal;
api_struc->Function    = API_FFS_INC_CNTR;
result = CALL_API(api_struc);
if (result != STATUS_OK)
  return (api_struc->Status);

*CurrentCounter = api_struc->RUS_CurInfo;
*MaxCounter     = api_struc->RUS_MaxInfo;

return (STATUS_OK);
}

#endif /* #ifdef WITH_HLM */

/****************************************************************************/
RET_ FAR_ CALL_ HLM_LOGIN (Word ModAd, Word Access, Byte DATAFAR_ * RefKey, Byte DATAFAR_ * VerKey, Byte DATAFAR_ * VKey, Long RUSOptions, Byte DATAFAR_ * SearchStr)
/****************************************************************************/
{
Word  result;
Long  OldTimerID;
Word  OldBcnt, OldRemote, OldPort;
Word  i, j;
Byte  SString[80];
Word  sslen = 0;
Word  blocks = 0;

GETSTRUC;
OldRemote  = api_struc->Remote;
OldTimerID = api_struc->Task_ID;
OldPort    = api_struc->Port;
OldBcnt    = api_struc->Bcnt;

api_struc->ModID            = EYE_DONGLE;
api_struc->Remote           = Access;
api_struc->Module.Eye.ModAd = ModAd;
api_struc->Bcnt             = 0;

/* --------------------- */
/* Get TaskID from API : */
/* --------------------- */
#ifndef DOS386
if (api_struc->Task_ID == 0)
  {
  api_struc->Function = API_GET_TASKID;
  CALL_API(api_struc);
  }
#endif

api_struc->Protocol = 0;
api_struc->Timeout  = 0;
api_struc->PM_Host  = API_XTD_DETECT;

/* -------------------------------------------- */
/* We generated a verify key with TESTAPI.EXE : */
/* -------------------------------------------- */
for (i = 0; i < 8; i++)
  {
  api_struc->ID_Ref[i]    = RefKey[i];
  api_struc->ID_Verify[i] = VerKey[i];
  }

/* ------------------------- */
/* Don't check for HL_SEARCH */
/* ------------------------- */
#ifdef NO_ENVCHK
api_struc->EnvMask |= IGNORE_ENVIRONMENT;
#endif

/* --------------------------------- */
/* Check and prepare search string : */
/* --------------------------------- */
if (SearchStr != 0)
 if(SearchStr[0] != '\0')
  {
  /* Get length of search string : */
  for (sslen = 0; SearchStr[sslen] != '\0'; sslen++);

  /* Add one for zero : */
  sslen++;

  /* count number of 8 bytes blocks we get : */
  blocks = sslen / 8;
  if ((sslen % 8) != 0)
    blocks++;
  if (blocks > 10)
        {
    api_struc->Remote  = OldRemote;
    api_struc->Task_ID = OldTimerID;
    api_struc->Port    = OldPort;
    api_struc->Bcnt    = OldBcnt;
    return (INVALID_ENV);
        }

  /* Copy search string to stack : */
  for (i = 0; i < sslen; i++)
     SString[i] = SearchStr[i];

  /* Add spaces to fill up last block : */
  for (j = 0; j < (blocks * 8 - sslen); j++)
     SString[i + j] = 0x20;

  /* Now put it into api structure : */
  api_struc->Bcnt = blocks;
  set_data_ptr(api_struc,SString);
  }

/* --------------------------------------------- */
/* Call the INIT (search for Hardlock) function :*/
/* --------------------------------------------- */
api_struc->FuncOptions = (RUSOptions >> 1) & 1;
if ((VKey == 0) && (!(RUSOptions & FORCE_RUS)))
  {
  api_struc->Function = API_INIT;
  result = CALL_API(api_struc);
  api_struc->FuncOptions = 0;
  api_struc->Bcnt = 0;
  set_data_ptr(api_struc,0);
  }
 else
  {
  api_struc->VendorKey = VKey;
  api_struc->Function = API_FFS_INIT;
  result = CALL_API(api_struc);
  /* Old Low-API returns NOT_INIT error, if function not */
  /* known and API structure hasn't been initialized yet */
  api_struc->FuncOptions = 0;
  api_struc->Bcnt = 0;
  set_data_ptr(api_struc,0);
  if (result == NOT_INIT)
    {
    api_struc->Remote  = OldRemote;
    api_struc->Task_ID = OldTimerID;
    api_struc->Port    = OldPort;
    api_struc->Bcnt    = OldBcnt;
    return (VERSION_MISMATCH);
    }
  }

if (result == ALREADY_INIT)
  {
  api_struc->Remote  = OldRemote;
  api_struc->Task_ID = OldTimerID;
  api_struc->Port    = OldPort;
  api_struc->Bcnt    = OldBcnt;
  return (result);
  }

/* ----------------------------- */
/* No further checks necessary : */
/* ----------------------------- */
if ((result == INVALID_ENV) || (result == CANNOT_OPEN_DRIVER))
  {
  api_struc->Remote  = OldRemote;
  api_struc->Task_ID = OldTimerID;
  api_struc->Port    = OldPort;
  api_struc->Bcnt    = OldBcnt;
  return (result);
  }

/* ----------------------------- */
/* Check, if HL-Server is full : */
/* ----------------------------- */
if (result != STATUS_OK)
  {
  if ((Access & NET_DEVICE) == NET_DEVICE)
    {
    api_struc->Function = API_LOGIN_INFO;
    if (CALL_API(api_struc) == HLS_FULL)
      result = TOO_MANY_USERS;
    }

  api_struc->Remote  = OldRemote;
  api_struc->Task_ID = OldTimerID;
  api_struc->Port    = OldPort;
  api_struc->Bcnt    = OldBcnt;
  return (result);
  }

/* ------------------------------------------ */
/* Login to HL-Server if Hardlock is remote : */
/* ------------------------------------------ */
if (api_struc->Remote == NET_DEVICE)
  {
   if ((VKey == 0) && (!(RUSOptions & FORCE_RUS)))
    api_struc->Function = API_LOGIN;
   else
    api_struc->Function = API_FFS_LOGIN;

  result = CALL_API(api_struc);
  if(result)
    {
    api_struc->Function = API_DOWN;
    CALL_API(api_struc);
    }
  }

if (result != STATUS_OK)
  {
  api_struc->Remote  = OldRemote;
  api_struc->Task_ID = OldTimerID;
  api_struc->Port    = OldPort;
  api_struc->Bcnt    = OldBcnt;
  }

return (result);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_LOGIN(Word ModAd, Word Access, Byte DATAFAR_ * RefKey, Byte DATAFAR_ * VerKey)
/****************************************************************************/
{
/* Just call the new function...: */
return HLM_LOGIN(ModAd, Access, RefKey, VerKey, 0, 0, 0);
}

/****************************************************************************/
RET_ FAR_ CALL_ HLM_LOGOUT(void)
/****************************************************************************/
{
/* Just call the old function...: */
return HL_LOGOUT();
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_LMLOGIN(Word ModAd, Word Access, Byte DATAFAR_ * RefKey, Byte DATAFAR_ * VerKey, Word Slot_ID, Byte DATAFAR_ * SearchStr)
/****************************************************************************/
{
Word  result;
Long  OldTimerID;
Word  OldSlot_ID, OldBcnt, OldRemote, OldPort, OldResult;
Word  i, j;
Byte  SString[80];
Word  sslen = 0;
Word  blocks = 0;

GETSTRUC;
OldRemote  = api_struc->Remote;
OldTimerID = api_struc->Task_ID;
OldPort    = api_struc->Port;
OldSlot_ID = api_struc->Slot_ID;
OldBcnt    = api_struc->Bcnt;

api_struc->ModID            = EYE_DONGLE;
api_struc->Remote           = Access;
api_struc->Slot_ID          = Slot_ID;
api_struc->Module.Eye.ModAd = ModAd;

/* --------------------- */
/* Get TaskID from API : */
/* --------------------- */
#ifndef DOS386
if (api_struc->Task_ID == 0)
  {
  api_struc->Function = API_GET_TASKID;
  CALL_API(api_struc);
  }
#endif

api_struc->Protocol = 0;
api_struc->Timeout  = 0;
api_struc->PM_Host  = API_XTD_DETECT;

/* -------------------------------------------- */
/* We generated a verify key with TESTAPI.EXE : */
/* -------------------------------------------- */
for (i = 0; i < 8; i++)
  {
  api_struc->ID_Ref[i]    = RefKey[i];
  api_struc->ID_Verify[i] = VerKey[i];
  }

/* ------------------------- */
/* Don't check for HL_SEARCH */
/* ------------------------- */
#ifdef NO_ENVCHK
api_struc->EnvMask |= IGNORE_ENVIRONMENT;
#endif

/* --------------------------------- */
/* Check and prepare search string : */
/* --------------------------------- */
if (SearchStr != 0)
  {
  /* Get length of search string : */
  for (sslen = 0; SearchStr[sslen] != '\0'; sslen++);

  /* Add one for zero : */
  sslen++;

  /* count number of 8 bytes blocks we get : */
  blocks = sslen / 8;
  if ((sslen % 8) != 0)
    blocks++;
  if (blocks > 10)
    return (INVALID_ENV);

  /* Copy search string to stack : */
  for (i = 0; i < sslen; i++)
     SString[i] = SearchStr[i];

  /* Add spaces to fill up last block : */
  for (j = 0; j < (blocks * 8 - sslen); j++)
     SString[i + j] = 0x20;

  /* Now put it into api structure : */
  api_struc->Bcnt = blocks;
  set_data_ptr(api_struc,SString);
  }

/* --------------------------------------------- */
/* Call the INIT (search for Hardlock) function :*/
/* --------------------------------------------- */
if (Slot_ID == 0)
  {
  api_struc->Function = API_INIT;
  result = CALL_API(api_struc);
  api_struc->Bcnt = 0;
  set_data_ptr(api_struc,0);
  }
 else
  {
  api_struc->Function = API_LMINIT;
  result = CALL_API(api_struc);
  api_struc->Bcnt = 0;
  set_data_ptr(api_struc,0);
  /* Old Low-API returns NOT_INIT error, if function not */
  /* known and API structure hasn't been initialized yet */
  if (result == NOT_INIT)
    return(VERSION_MISMATCH);
  }

if (result == ALREADY_INIT)
  {
  api_struc->Remote  = OldRemote;
  api_struc->Task_ID = OldTimerID;
  api_struc->Port    = OldPort;
  api_struc->Bcnt    = OldBcnt;
  api_struc->Slot_ID = OldSlot_ID;
  return (result);
  }

/* ----------------------------- */
/* No further checks necessary : */
/* ----------------------------- */
if ((result == INVALID_ENV) || (result == CANNOT_OPEN_DRIVER))
  return (result);

/* ----------------------------- */
/* Check, if HL-Server is full : */
/* ----------------------------- */
if (result != STATUS_OK)
  {
  if ((Access & NET_DEVICE) == NET_DEVICE)
    {
    if (Slot_ID == 0)
      {
      /* Check the old way... : */
      /* ---------------------- */
      api_struc->Function = API_LOGIN_INFO;
      if (CALL_API(api_struc) == HLS_FULL)
        return(TOO_MANY_USERS);
      }
     else
      {
      /* Check using LM functions... : */
      /* ----------------------------- */
      OldResult = result;
      api_struc->Function = API_LMPING;
      result = CALL_API(api_struc);

      if (result == HLS_FULL)
        return(TOO_MANY_USERS);

      if ((result == NO_LICENSE) || (OldResult == NO_LICENSE))
        return(NO_LICENSE);

      if (OldResult == INVALID_LIC)
        return(OldResult);

      if (result == NO_DONGLE)
        return(OldResult);

      return (result);
      }
    }
  return (result);
  }

/* ------------------------------------------ */
/* Login to HL-Server if Hardlock is remote : */
/* ------------------------------------------ */
if (api_struc->Remote == NET_DEVICE)
  {
  api_struc->Function = API_LOGIN;
  result              = CALL_API(api_struc);
  if(result)
    {
    api_struc->Function = API_DOWN;
    CALL_API(api_struc);
    }
  }

return (result);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_SERVERLICENSES(Word DATAFAR_ *Value)
/****************************************************************************/
{
Word result;

GETSTRUC;
*Value = 0; /* preset: 0 licenses (in case of any error) */

if (api_struc->Remote == NET_DEVICE) return (NO_REMOTE_FUNCTION);
if (api_struc->Remote != LOCAL_DEVICE) return (NO_ACCESS);

if (api_struc->PortFlags & USB_DEVICE)  /* USB key */
  {
  api_struc->Function = API_READ_HLS;
  result = CALL_API(api_struc);
  if (result == STATUS_OK) *Value = api_struc->Module.Eye.Value;
  return (result);
  }
else /* parallel key */
  {
  HL_API srv_api = {{0}};
  char   licbuf[10];

  /* switch on HL-Server */
  api_struc->Module.Eye.Reg = 0;
  api_struc->Function = API_READ;
  result = CALL_API(api_struc);
  if (result) return result;

  /* initialize HL-Server */
  srv_api.Module.Eye.ModAd = 18329;
  srv_api.Remote = LOCAL_DEVICE;
  result = CALL_API(&srv_api);
  if (result) return (STATUS_OK); /* no server HL --> 0 Licenses */

  /* get licenses */
  strcpy(licbuf, "HARDLOCK");
  set_data_ptr(&srv_api, &licbuf);
  srv_api.Function = API_KEYE;
  srv_api.Bcnt     = 1;
  result = CALL_API(&srv_api);
  srv_api.Bcnt     = 0;

  /* switch off HL-server */
  srv_api.Function = API_READ;
  CALL_API(&srv_api);

  if (result) return (STATUS_OK); /* problem with server HL --> 0 Licenses */
                                  /* this is the result of API_KEYE */

  set_data_ptr(&srv_api, &licbuf);
  srv_api.Function = API_CALC_HLS;
  srv_api.Bcnt     = 1;
  result = CALL_API(&srv_api);
  srv_api.Bcnt     = 0;
  if (result) return result;

  *Value = srv_api.MaxUsers;
  return (STATUS_OK);
  } /* if parallel key */
} /* HL_SERVERLICENSES */

/****************************************************************************/
RET_ FAR_ CALL_ HL_SERVERADDR (char *text, Long *textsize)
/****************************************************************************/
{
  Word result;

  GETSTRUC;

  if (api_struc->Remote == LOCAL_DEVICE) return (NO_LOCAL_FUNCTION);
  if (api_struc->Remote != NET_DEVICE) return (NO_ACCESS);

  if ( (*textsize < 1) || (*textsize > 0xFFFF) || (text == 0) ) {
    return (INVALID_PARAM);
  }

  /* ak: i'm doing an avail here because all the other get info
     functions also do an avail
  */
  api_struc->Function  = API_AVAIL;
  api_struc->Bcnt      = 0; /* assure that *data isn't accessed */
  api_struc->ShortLife = 0;
  result = CALL_API(api_struc);
  if (result) return(result);

  api_struc->Function  = API_GETHLSTEXT; /* get text addr of currently used HLS */
  api_struc->Bcnt      = *textsize >> 3;
  api_struc->ShortLife = *textsize;
  set_data_ptr(api_struc, text);
  result = CALL_API(api_struc);
  *textsize = api_struc->ShortLife;
  api_struc->Bcnt      = 0;
  api_struc->ShortLife = 0;

  return result;
}


/****************************************************************************/
/****************************************************************************/
/* The following functions map the old Hardlock Calls on the new API. These */
/* functions are defined only for compatibility reasons.                    */
/* !!! Don't mix old and new functions. Don't use if it is not necessary.!!!*/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
void FAR_ CALL_ INT_ON (void)
/****************************************************************************/
{return;}

/****************************************************************************/
void FAR_ CALL_ INT_OFF (void)
/****************************************************************************/
{return;}

/****************************************************************************/
void FAR_ CALL_ HL_ON (Word Port, Word ModAd)
/****************************************************************************/
{
GETSTRUC;
api_struc->ModID            = EYE_DONGLE;
api_struc->Remote           = LOCAL_DEVICE;
api_struc->Module.Eye.ModAd = ModAd;
api_struc->Port             = Port;
api_struc->Function         = API_INIT;
CALL_API(api_struc);
if(api_struc->Status) return;

api_struc->Function = API_LOGIN;
CALL_API(api_struc);
if(api_struc->Status)
 {
 api_struc->Function = API_DOWN;
 CALL_API(api_struc);
 }

return;
}

/****************************************************************************/
void FAR_ CALL_ HL_OFF (Word Port)
/****************************************************************************/
{
GETSTRUC;
api_struc->Port     = Port;
api_struc->Function = API_LOGOUT;
CALL_API(api_struc);

api_struc->Function = API_DOWN;
CALL_API(api_struc);
if (api_struc->Status)
  {
  api_struc->Function = API_FORCE_DOWN;
  CALL_API(api_struc);
  }
return;
}

/****************************************************************************/
Word FAR_ CALL_ K_EYE (Word Port, char  DATAFAR_ *Inp, Word BlkCnt)
/****************************************************************************/
{
GETSTRUC;
api_struc->Port     = Port;
set_data_ptr(api_struc,Inp);
api_struc->Bcnt     = BlkCnt;
api_struc->Function = API_KEYE;
CALL_API(api_struc);
api_struc->Bcnt     = 0;

if (api_struc->Status)
  return (0);
return (1);
}

/****************************************************************************/
void FAR_ CALL_ HL_WR (Word Port, Word Reg, Word Val)
/****************************************************************************/
{
GETSTRUC;
if(Reg >= 48 && Reg <= 63)
  {
  api_struc->Port             = Port;
  api_struc->Module.Eye.Reg   = Reg;
  api_struc->Module.Eye.Value = Val;
  api_struc->Function         = API_WRITE;
  CALL_API(api_struc);
  }
return;
}

/****************************************************************************/
Word FAR_ CALL_ HL_RD (Word Port, Word Reg)
/****************************************************************************/
{
GETSTRUC;
if(Reg <= 63)
  {
  api_struc->Port           = Port;
  api_struc->Module.Eye.Reg = Reg;
  api_struc->Function       = API_READ;
  CALL_API(api_struc);
  if (api_struc->Status == STATUS_OK)
    return (api_struc->Module.Eye.Value);
  }

return (0);
}

/****************************************************************************/
RET_ FAR_ CALL_ HL_CALC (Word i1, Word i2, Word i3, Word i4)
/****************************************************************************/
{
unsigned short Shift1, Shift2;

GETSTRUC;
api_struc->Function = 16;   /* Function: query Hardlock in compatible mode */

Shift1 = i1 | (i2 << 8);
Shift2 = i3 | (i4 << 8);
api_struc->Timeout = (Long) Shift1 | (Long) (Shift2 * 0x10000L);

CALL_API(api_struc);
if(api_struc->Status)
  return 0;
 else
  return api_struc->ShortLife;
}

