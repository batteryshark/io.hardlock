/****************************************************************************/
/**                                                                        **/
/**                          Hardlock API-Calls                            **/
/**                                                                        **/
/**   This program is just an example for some functions to access the     **/
/**   application programing interface (API) for Hardlock. Feel free to    **/
/**   define your own functions.                                           **/
/**                                                                        **/
/**                  Aladdin Knowledge Systems, Germany                    **/
/**                                                                        **/
/**                                                                        **/
/**              Computer : IBM PC or compatible                           **/
/**              OS       : MS-PC/DOS 2.0 or higher                        **/
/**              Language : C                                              **/
/**              Interface: CLIPPER (S'87, 5.xx)                           **/
/**                                                                        **/
/**  Revision history                                                      **/
/**  ----------------                                                      **/
/**                                                                        **/
/**  (related to VCS version)
***  $Log: hlapi_cl.c $
***  Revision 1.13  1999/09/19 16:18:44  Henri
***  Bugfix in HL_PORTINF (last release was okay).
***  
***  Revision 1.12  1998/07/02 18:13:50  Henri
***  Return 0 in HL_PORTINF if key is USB.
***  
***  Revision 1.11  1998/06/16 15:44:20  HENRI
***  Fixed an error in ID generation.
***  
***  Revision 1.10  1998/05/22 11:36:19  Henri
***  Fixed offest of HL_READID.
***  
***  Revision 1.9  1998/05/11 18:44:01  Henri
***  Bugfix in HL_READID.
***  
***  Revision 1.8  1998/05/08 14:12:11  Henri
***  Added defines for HL_READID.
***  
***  Revision 1.7  1997/02/12 17:13:53  henri
***  Missed one _retni().
***
***  Revision 1.6  1997/02/12 13:45:03  henri
***  Changed return code handling for LM.
***
***  Revision 1.5  1997/02/06 14:17:54  henri
***  Added on character to sslen.
***
***  Revision 1.4  1997/02/06 11:11:56  henri
***  Added LM functions.
***
***  Revision 1.3  1996/09/18 11:52:47  henri
***  Support for multi API strutures.
***
***  Revision 1.2  1996/08/08 14:47:13  henri
***  Added VCS log.
***
**/
/****************************************************************************/
#include <dos.h>
#include "fastapi.h"

#define CLIPPER void pascal
extern char *_parc(int, ...);
extern int   _parni(int, ...);
extern void  _retni(int);
extern void  _retl(int);
extern void  _retnl(long);
extern void  _ret(void);

/* --------------------- */
/* Function prototypes : */
/* --------------------- */
static int CALL_API      (HL_API far *api_struc);
CLIPPER    HL_LOGIN      (void);
CLIPPER    HL_LOGOUT     (void);
CLIPPER    HL_AVAIL      (void);
CLIPPER    HL_PORTINF    (void);
CLIPPER    HL_ACCINF     (void);
CLIPPER    HL_USERINF    (void);
CLIPPER    HL_MAXUSER    (void);
CLIPPER    HL_MEMINF     (void);
CLIPPER    HL_CODE       (void);
CLIPPER    HL_WRITE      (void);
CLIPPER    HL_READ       (void);
CLIPPER    HL_READBL     (void);
CLIPPER    HL_WRITEBL    (void);
CLIPPER    HL_ABORT      (void);
CLIPPER    HL_VERSION    (void);
CLIPPER    HL_HLSVERS    (void);
CLIPPER    HL_SELECT     (void);
CLIPPER    HL_LMLOGIN    (void);
CLIPPER    HL_READID     (void);

/****************************************************************************/
/****************************************************************************/
/* The following functions map the old Hardlock Calls on the new API. These */
/* functions are defined only for compatibility reasons.                    */
/* !!! Don't mix old and new functions. Don't use if it is not necessary.!!!*/
/****************************************************************************/
/****************************************************************************/
CLIPPER    CINT_ON       (void);
CLIPPER    CINT_OFF      (void);
CLIPPER    CHL_ON        (void);
CLIPPER    CHL_OFF       (void);
CLIPPER    CK_EYE        (void);
CLIPPER    CHL_WR        (void);
CLIPPER    CHL_RD        (void);

CLIPPER    HL_CALC       (void);
/****************************************************************************/

static HL_API hl_struc = {{0}};                 /* Hardlock API structure   */
static HL_API DATAFAR_ *api_struc = &hl_struc;  /* Pointer to API structure */

extern int far pascal _API_HL_STACK(HL_API far *api_struc);

/****************************************************************************/
static int CALL_API(HL_API far *api_struc)
/****************************************************************************/
{
int result;

/* ----------------- */
/* We call the API : */
/* ----------------- */
result = _API_HL_STACK(api_struc);
return result;
}

/****************************************************************************/
CLIPPER HL_SELECT(void)
/****************************************************************************/
{
api_struc = _parc(1);

if (!_parc(1))
  api_struc = &hl_struc;
 else
  api_struc = _parc(1);

{_retni(STATUS_OK);return;}
}

/****************************************************************************/
CLIPPER HL_LOGIN(void)
/****************************************************************************/
{
int   result;
long  OldTimerID;
int   OldRemote, OldPort;
short i;

OldRemote  = api_struc->Remote;
OldTimerID = api_struc->Task_ID;
OldPort    = api_struc->Port;

api_struc->ModID            = EYE_DONGLE;
api_struc->Module.Eye.ModAd = _parni(1);
api_struc->Remote           = _parni(2);

/* --------------------- */
/* Get TaskID from API : */
/* --------------------- */
if (api_struc->Task_ID == 0)
  {
  api_struc->Function = API_GET_TASKID;
  CALL_API(api_struc);
  }

api_struc->Port     = 0;
api_struc->Timeout  = 0;
api_struc->PM_Host  = API_XTD_DETECT;

/* -------------------------------------------- */
/* We generated a verify key with TESTAPI.EXE : */
/* -------------------------------------------- */
for (i = 0; i < 8; i++)
  {
  api_struc->ID_Ref[i]    = _parc(3)[i];
  api_struc->ID_Verify[i] = _parc(4)[i];
  }

api_struc->Function = API_INIT;
result = CALL_API(api_struc);
if (result == ALREADY_INIT)
  {
  api_struc->Remote  = OldRemote;
  api_struc->Task_ID = OldTimerID;
  api_struc->Port    = OldPort;
  _retni(result);
  return;
  }

/* ----------------------------- */
/* No further checks necessary : */
/* ----------------------------- */
if ((result == INVALID_ENV) || (result == CANNOT_OPEN_DRIVER))
  {
  _retni(result);
  return;
  }

/* ----------------------------- */
/* Check, if HL-Server is full : */
/* ----------------------------- */
if (result)
  {
  if ((_parni(2) & NET_DEVICE) == NET_DEVICE)
    {
    api_struc->Function = API_LOGIN_INFO;
    if (CALL_API(api_struc) == HLS_FULL)
      result = TOO_MANY_USERS;
    }
  {_retni(result);return;}
  }

if (api_struc->Remote == NET_DEVICE)
  {
  api_struc->Function = API_LOGIN;
  result = CALL_API(api_struc);
  if(result)
    {
    api_struc->Function = API_DOWN;
    CALL_API(api_struc);
    }
  }

{_retni(result);return;}
}

/****************************************************************************/
CLIPPER HL_LMLOGIN(void)
/****************************************************************************/
{
Word  result;
Long  OldTimerID;
Word  OldSlot_ID, OldBcnt, OldRemote, OldPort, OldResult;
short i, j;
Byte  SString[80];
Word  sslen = 0;
Word  blocks = 0;

OldRemote  = api_struc->Remote;
OldTimerID = api_struc->Task_ID;
OldPort    = api_struc->Port;
OldSlot_ID = api_struc->Slot_ID;
OldBcnt    = api_struc->Bcnt;

api_struc->ModID            = EYE_DONGLE;
api_struc->Remote           = _parni(2);
api_struc->Slot_ID          = _parni(5);
api_struc->Module.Eye.ModAd = _parni(1);

/* --------------------- */
/* Get TaskID from API : */
/* --------------------- */
if (api_struc->Task_ID == 0)
  {
  api_struc->Function = API_GET_TASKID;
  CALL_API(api_struc);
  }

api_struc->Protocol = 0;
api_struc->Port     = 0;
api_struc->Timeout  = 0;
api_struc->PM_Host  = API_XTD_DETECT;

/* -------------------------------------------- */
/* We generated a verify key with TESTAPI.EXE : */
/* -------------------------------------------- */
for (i = 0; i < 8; i++)
  {
  api_struc->ID_Ref[i]    = _parc(3)[i];
  api_struc->ID_Verify[i] = _parc(4)[i];
  }

/* ------------------------- */
/* Don't check for HL_SEARCH */
/* ------------------------- */
#ifdef NO_ENVCHK
api_struc->EnvMask |= IGNORE_ENVIRONMENT;
#endif

/* --------------------------------- */
/* Check and prepare search string : */
/* --------------------------------- */
if (_parc(6) != 0)
  {
  /* Get length of search string : */
  for (sslen = 0; _parc(6)[sslen] != '\0'; sslen++);

  /* Add one for zero : */
  sslen++;

  /* count number of 8 bytes blocks we get : */
  blocks = sslen / 8;
  if ((sslen % 8) != 0)
    blocks++;
  if (blocks > 10)
    {_retni(INVALID_ENV); return;}

  /* Copy search string to stack : */
  for (i = 0; i < sslen; i++)
     SString[i] = _parc(6)[i];

  /* Add spaces to fill up last block : */
  for (j = 0; j < (blocks * 8 - sslen); j++)
     SString[i + j] = 0x20;

  /* Now put it into api structure : */
  api_struc->Bcnt = blocks;
  api_struc->Data = SString;
  }

/* --------------------------------------------- */
/* Call the INIT (search for Hardlock) function :*/
/* --------------------------------------------- */
if (_parni(5) == 0)
  {
  api_struc->Function = API_INIT;
  result = CALL_API(api_struc);
  }
 else
  {
  api_struc->Function = API_LMINIT;
  result = CALL_API(api_struc);
  if (result == NOT_INIT)
    {_retni(VERSION_MISMATCH);return;}
  }

if (result == ALREADY_INIT)
  {
  api_struc->Remote  = OldRemote;
  api_struc->Task_ID = OldTimerID;
  api_struc->Port    = OldPort;
  api_struc->Bcnt    = OldBcnt;
  api_struc->Slot_ID = OldSlot_ID;
  {_retni(result);return;}
  }

/* ----------------------------- */
/* No further checks necessary : */
/* ----------------------------- */
if ((result == INVALID_ENV) || (result == CANNOT_OPEN_DRIVER))
  {_retni(result);return;}

/* ----------------------------- */
/* Check, if HL-Server is full : */
/* ----------------------------- */
if (result != STATUS_OK)
  {
  if ((_parni(2) & NET_DEVICE) == NET_DEVICE)
    {
    if (_parni(5) == 0)
      {
      /* Check the old way... : */
      /* ---------------------- */
      api_struc->Function = API_LOGIN_INFO;
      if (CALL_API(api_struc) == HLS_FULL)
        result = TOO_MANY_USERS;
      }
     else
      {
      /* Check using LM functions... : */
      /* ----------------------------- */
      OldResult = result;
      api_struc->Function = API_LMPING;
      result = CALL_API(api_struc);

      if (result == HLS_FULL)
        {_retni(TOO_MANY_USERS);return;}

      if ((result == NO_LICENSE) || (OldResult == NO_LICENSE))
        {_retni(NO_LICENSE);return;}

      if (OldResult == INVALID_LIC)
        {_retni(OldResult);return;}

      if (result == NO_DONGLE)
        {_retni(OldResult);return;}

      {_retni(result);return;}
      }
    }
  {_retni(result);return;}
  }

/* ------------------------------------------ */
/* Login to HL-Server if Hardlock is remote : */
/* ------------------------------------------ */
if (api_struc->Remote == NET_DEVICE)
  {
  api_struc->Function = API_LOGIN;
  result              = CALL_API(api_struc);
  if(result)
    {
    api_struc->Function = API_DOWN;
    CALL_API(api_struc);
    }
  }

{_retni(result);return;}
}


/****************************************************************************/
CLIPPER HL_LOGOUT(void)
/****************************************************************************/
{
int result;

if (api_struc->Remote == NET_DEVICE)
  {
  api_struc->Function = API_LOGOUT;
  CALL_API(api_struc);
  }

api_struc->Function = API_DOWN;
result = CALL_API(api_struc);
if (result)
  {
  api_struc->Function = API_FORCE_DOWN;
  result = CALL_API(api_struc);
  }

api_struc->Task_ID = 0;
{_retni(result);return;}
}

/****************************************************************************/
CLIPPER HL_PORTINF(void)
/****************************************************************************/
{
int result;

if (api_struc->PortFlags & USB_DEVICE)
  {_retni(0);return;}

api_struc->Function = API_AVAIL;
result = CALL_API(api_struc);

if (result) {_retni(-1);return;}
{_retni(api_struc->Port);return;}
}

/****************************************************************************/
CLIPPER HL_USERINF(void)
/****************************************************************************/
{
int result;

if (api_struc->Slot_ID == 0)
  api_struc->Function = API_INFO;
 else
  api_struc->Function = API_AVAIL;

result = CALL_API(api_struc);

if (result) {_retni(-1);return;}
{_retni(api_struc->NetUsers);return;}
}

/****************************************************************************/
CLIPPER HL_MAXUSER(void)
/****************************************************************************/
{
int result;

if (api_struc->Slot_ID == 0)
  api_struc->Function = API_INFO;
 else
  api_struc->Function = API_AVAIL;

result = CALL_API(api_struc);

if (result) {_retni(-1);return;}
{_retni(api_struc->MaxUsers);return;}
}

/****************************************************************************/
CLIPPER HL_VERSION(void)
/****************************************************************************/
{
int result;

api_struc->Function = API_AVAIL;
result = CALL_API(api_struc);

if (result) {_retni(-1);return;}

result = (api_struc->API_Version_ID[0] * 100) + api_struc->API_Version_ID[1];
{_retni(result);return;}
}

/****************************************************************************/
CLIPPER HL_HLSVERS(void)
/****************************************************************************/
{
int result;

if (api_struc->Remote == NET_DEVICE)
  {
  api_struc->Function  = API_AVAIL;
  result              = CALL_API(api_struc);
  if (result == STATUS_OK)
    {_retni(api_struc->ShortLife);return;}
  }
{_retni(0);return;}
}

/****************************************************************************/
CLIPPER HL_ACCINF(void)
/****************************************************************************/
{
int result;

api_struc->Function = API_AVAIL;
result = CALL_API(api_struc);

if (result) {_retni(-1);return;}
{_retni(api_struc->Remote);return;}
}

/****************************************************************************/
CLIPPER HL_AVAIL(void)
/****************************************************************************/
{
int result;

api_struc->Function  = API_AVAIL;
result = CALL_API(api_struc);

if ((result == NO_DONGLE) && (api_struc->ShortLife == 1) && (api_struc->Remote == LOCAL_DEVICE))
  result = SELECT_DOWN;

{_retni(result);return;}
}

/****************************************************************************/
CLIPPER HL_CODE(void)
/****************************************************************************/
{
int result;

api_struc->Data     = _parc(1);
api_struc->Bcnt     = _parni(2);
api_struc->Function = API_KEYE;
result              = CALL_API(api_struc);
api_struc->Bcnt     = 0;

{_retni(result);return;}
}

/****************************************************************************/
CLIPPER HL_READ(void)
/****************************************************************************/
{
int result, reg;

reg = _parni(1);
if(reg <= 63)
  {
  api_struc->Module.Eye.Reg = reg;
  api_struc->Function       = API_READ;
  result = CALL_API(api_struc);
  if(result) {_retni(-1);return;}
  {_retni(api_struc->Module.Eye.Value);return;}
  }

{_retni(-1);return;}
}

/****************************************************************************/
CLIPPER HL_READID(void)
/****************************************************************************/
{
if (!(api_struc->PortFlags & USB_DEVICE))
  {_retni(-1);return;}

api_struc->Module.Eye.Reg = 14;
api_struc->Function       = API_READ_ID;

CALL_API(api_struc);
if(api_struc->Status)
  {_retni(-1);return;}

if ((api_struc->Module.Eye.Value == 0) && (api_struc->Module.Eye.Reg == 0))
  {_retni(-1);return;}

{_retnl((api_struc->Module.Eye.Reg * 65536L) | api_struc->Module.Eye.Value);return;}
}

/****************************************************************************/
CLIPPER HL_READBL(void)
/****************************************************************************/
{
int result;

api_struc->Bcnt     = 16;
api_struc->Data     = _parc(1);
api_struc->Function = API_READ_BLOCK;
result              = CALL_API(api_struc);
api_struc->Bcnt     = 0;

{_retni(result);return;}
}

/****************************************************************************/
CLIPPER HL_WRITEBL(void)
/****************************************************************************/
{
int result;

api_struc->Bcnt     = 4;
api_struc->Data     = _parc(1);
api_struc->Function = API_WRITE_BLOCK;
result              = CALL_API(api_struc);
api_struc->Bcnt     = 0;

{_retni(result);return;}
}

/****************************************************************************/
CLIPPER HL_ABORT(void)
/****************************************************************************/
{
int result;

api_struc->Function = API_ABORT;
result = CALL_API(api_struc);

{_retni(result);return;}
}

/****************************************************************************/
CLIPPER HL_WRITE(void)
/****************************************************************************/
{
int result, reg, value;

reg   = _parni(1);
value = _parni(2);
if(reg >= 48 && reg <= 63)
  {
  api_struc->Module.Eye.Reg   = reg;
  api_struc->Module.Eye.Value = value;
  api_struc->Function         = API_WRITE;
  result = CALL_API(api_struc);
  if(result) {_retni(result);return;}
  {_retni(STATUS_OK);return;}
  }

{_retni(INVALID_PARAM);return;}
}

/****************************************************************************/
CLIPPER HL_MEMINF(void)
/****************************************************************************/
{
int result, newvalue, oldvalue;
int TestMem = 0;
unsigned char Memory[128];
int i;

/* -------------------------- */
/* Read memory in one block : */
/* -------------------------- */
api_struc->Bcnt     = 16;
api_struc->Data     = Memory;
api_struc->Function = API_READ_BLOCK;
CALL_API(api_struc);
api_struc->Bcnt     = 0;
if (api_struc->Status != STATUS_OK)
  {_retni(NO_ACCESS);return;}

/* -------------------------------------- */
/* Check, if every value is zero or one : */
/* -------------------------------------- */
for (i = 0; i < 128; i++)
  TestMem |= Memory[i];
if (TestMem != 0)
  {
  for (i = 0; i < 128; i++)
    {
    if (Memory[i] != 0xff)
      {_retni(STATUS_OK);return;}
    }
  }

/* ---------------------- */
/* Save memory contents : */
/* ---------------------- */
api_struc->Module.Eye.Reg = 48;
api_struc->Function       = API_READ;
result = CALL_API(api_struc);
if(result) {_retni(NO_ACCESS);return;}
oldvalue                 = api_struc->Module.Eye.Value;

/* ---------------------------------------------------------------- */
/* XOR of the read value to exclude random returns from interface : */
/* ---------------------------------------------------------------- */
newvalue = oldvalue ^ 0x0d0e;

/* ------------------------ */
/* Write new memory value : */
/* ------------------------ */
api_struc->Module.Eye.Value = newvalue;
api_struc->Function         = API_WRITE;
result = CALL_API(api_struc);
if(result)
 {
 api_struc->Module.Eye.Value = oldvalue;
 api_struc->Function         = API_WRITE;
 result = CALL_API(api_struc);
 _retni(NO_ACCESS);
 return;
 }

/* ------------------------- */
/* Read and compare memory : */
/* ------------------------- */
api_struc->Function  = API_READ;
result = CALL_API(api_struc);
if(result)
  {
  api_struc->Module.Eye.Value = oldvalue;
  api_struc->Function         = API_WRITE;
  result = CALL_API(api_struc);
  _retni(NO_ACCESS);
  return;
  }
if (api_struc->Module.Eye.Value != newvalue)
  {
  api_struc->Module.Eye.Value = oldvalue;
  api_struc->Function         = API_WRITE;
  result = CALL_API(api_struc);
  _retni(NO_ACCESS);
  return;
  }

/* ------------------ */
/* Write old memory : */
/* ------------------ */
api_struc->Module.Eye.Value = oldvalue;
api_struc->Function         = API_WRITE;
result = CALL_API(api_struc);
if(result)
  {
  _retni(NO_ACCESS);
  return;
  }

{_retni(STATUS_OK);return;}
}

/****************************************************************************/
/****************************************************************************/
/* The following functions map the old Hardlock Calls on the new API. These */
/* functions are defined only for compatibility reasons.                    */
/* !!! Don't mix old and new functions. Don't use if it is not necessary.!!!*/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
CLIPPER CINT_ON (void)
/****************************************************************************/
{_ret();return;}

/****************************************************************************/
CLIPPER CINT_OFF (void)
/****************************************************************************/
{_ret();return;}

/****************************************************************************/
CLIPPER CHL_ON (void)
/****************************************************************************/
{
int result;

api_struc->ModID            = EYE_DONGLE;
api_struc->Remote           = LOCAL_DEVICE;
api_struc->Module.Eye.ModAd = _parni(2);
api_struc->Port             = _parni(1);
api_struc->Function         = API_INIT;
result                      = CALL_API(api_struc);
if(result) {_ret();return;}
api_struc->Function         = API_LOGIN;
result                      = CALL_API(api_struc);
if(result)
 {
 api_struc->Function = API_DOWN;
 CALL_API(api_struc);
 }

{_ret();return;}
}

/****************************************************************************/
CLIPPER CHL_OFF (void)
/****************************************************************************/
{
HL_LOGOUT();
{_ret();return;}
}

/****************************************************************************/
CLIPPER CK_EYE (void)
/****************************************************************************/
{
int result;

api_struc->Data     = _parc(2);
api_struc->Bcnt     = _parni(3);
api_struc->Function = API_KEYE;
result              = CALL_API(api_struc);
api_struc->Bcnt     = 0;
if (result) {_retl(0);return;}
{_retl(1);return;}
}

/****************************************************************************/
CLIPPER CHL_WR (void)
/****************************************************************************/
{
int n = 5, result, reg, value;

reg   = _parni(2);
value = _parni(3);
if(reg >= 48 && reg <= 63)
  {
  do
    {
    api_struc->Module.Eye.Reg   = reg;
    api_struc->Module.Eye.Value = value;
    api_struc->Function         = API_WRITE;
    result = CALL_API(api_struc);
    if(result) {_ret();return;}

    api_struc->Module.Eye.Reg = reg;
    api_struc->Function       = API_READ;
    result = CALL_API(api_struc);
    if(result) {_ret();return;}
    } while(--n && api_struc->Module.Eye.Value != value);
  }

{_ret();return;}
}

/****************************************************************************/
CLIPPER CHL_RD (void)
/****************************************************************************/
{
int result, reg;

reg = _parni(2);
if(reg <= 63)
  {
  api_struc->Module.Eye.Reg = reg;
  api_struc->Function       = API_READ;
  result                    = CALL_API(api_struc);
  if(result) {_retni(0);return;}
    {_retni(api_struc->Module.Eye.Value);return;}
  }

{_retni(0);return;}
}

/****************************************************************************/
CLIPPER HL_CALC (void)
/****************************************************************************/
{
Word result;
unsigned short Shift1, Shift2;

api_struc->Function = 16;   /* Function: query Hardlock in compatible mode */

Shift1 = _parni(1) | (_parni(2) << 8);
Shift2 = _parni(3) | (_parni(4) << 8);
api_struc->Timeout = (Long) Shift1 | (Long) (Shift2 * 0x10000L);

result = CALL_API(api_struc);
if(result)
  {_retni(0);return;}
 else
  {_retni(api_struc->ShortLife);return;}
}
