/****************************************************************************/
/**                                                                        **/
/**                         Hardlock API-Calls                             **/
/**                                                                        **/
/**   This program is just an example for some functions to access the     **/
/**   application programing interface (API) for Hardlock. Feel free to    **/
/**   define your own functions.                                           **/
/**                                                                        **/
/**                  Aladdin Knowledge Systems, Germany                    **/
/**                                                                        **/
/**              Computer  : IBM PC or compatible                          **/
/**              OS        : MS-PC/DOS 2.0 or higher, Windows 3.x, Win32   **/
/**              Language  : MSC                                           **/
/**              Interface : FOXPRO 2.5, VFP                               **/
/**                                                                        **/
/**  Revision history                                                      **/
/**  ----------------                                                      **/
/**  (related to API version)                                              **/
/**  3.18  -- Initial implementation                                       **/
/**        -- Get the TaskID from API function.                            **/
/**        -- HL_MEMINF strategy changed                                   **/
/**        -- New function: HL_HLSVERS: return HL-Server version           **/
/**  3.22  -- Search order added to HL_LOGIN, call to function (33).       **/
/**  3.23  -- Search order removed, handeled internal by LowAPI.           **/
/**        -- HL_LOGOUT, HL_LOGIN optimized (call API_LOGIN and API_LOGOUT **/
/**           only for remote access.                                      **/
/**  3.24  -- Bugfix for HL-Server licenced to one user.                   **/
/**        -- No further checks on HL_LOGIN on specific errors.            **/
/**  3.26  -- Adapted for Win32. VFP support added.                        **/
/**                                                                        **/
/**  (related to VCS version)
***  $Log: hlapi_fp.c $
***  Revision 1.14  1999/09/19 16:23:10  Henri
***  Changed calling to CStack entry.
***  
***  Revision 1.13  1999/09/19 16:18:43  Henri
***  Bugfix in HL_PORTINF (last release was okay).
***  
***  Revision 1.12  1998/07/02 18:13:52  Henri
***  Return 0 in HL_PORTINF if key is USB.
***  
***  Revision 1.11  1998/06/19 14:02:06  HENRI
***  Fixed a bug (return) in HL_READID function.
***  
***  Revision 1.10  1998/05/22 11:36:22  Henri
***  Fixed offest of HL_READID.
***  
***  Revision 1.9  1998/05/08 14:12:14  Henri
***  Added defines for HL_READID.
***  
***  Revision 1.8  1997/09/22 17:47:06  HENRI
***  ifndef _FreeHand, because this will crash on DOS Foxpro.
***  
***  Revision 1.7  1997/02/12 13:45:05  henri
***  Changed return code handling for LM.
***  
***  Revision 1.6  1997/02/06 14:18:52  henri
***  Added one character to sslen.
***
***  Revision 1.5  1997/02/06 12:59:28  henri
***  Added LM functions.
***
***  Revision 1.4  1996/12/11 10:30:13  henri
***  Fixed a bug with unreleased handles.
***
***  Revision 1.3  1996/09/18 11:52:49  henri
***  Support for multi API strutures.
***
***  Revision 1.2  1996/08/08 14:47:34  henri
***  Added VCS log.
***
**/
/****************************************************************************/
#include <pro_ext.h>
#include "fastapi.h"

/* --------------------- */
/* Function prototypes : */
/* --------------------- */
void far HL_Login   (ParamBlk far *param);
void far HL_Logout  (void);
void far HL_Avail   (void);
void far HL_Abort   (void);
void far HL_Version (void);
void far HL_PortInf (void);
void far HL_AccInf  (void);
void far HL_UserInf (void);
void far HL_Maxuser (void);
void far HL_Code    (ParamBlk far *param);
void far HL_MemInf  (void);
void far HL_Read    (ParamBlk far *param);
void far HL_Write   (ParamBlk far *param);
void far HL_ReadBl  (ParamBlk far *param);
void far HL_WriteBl (ParamBlk far *param);
void far HL_HLSVers (void);
void far HL_Select  (ParamBlk far *param);
void far HL_LMLogin (ParamBlk far *param);
void far HL_ReadID  (ParamBlk far *param);

static HL_API hl_struc = {{0}};                 /* Hardlock API structure   */
static HL_API DATAFAR_ *api_struc = &hl_struc;  /* Pointer to API structure */

#ifdef WINNT
  extern Word far __cdecl API_HL_CSTACK(HL_API far *api_struc);
  #define API_Function API_HL_CSTACK
#else
  extern Word far pascal _API_HL_STACK(HL_API far *api_struc);
  #define API_Function _API_HL_STACK
#endif

/****************************************************************************/
static Word far CALL_API (HL_API far *api_struc)
/****************************************************************************/
  { Word result;
    result=API_Function(api_struc);
    return result;
  }

/****************************************************************************/
void far HL_Select(ParamBlk far *param)
/****************************************************************************/
  { //Parameter: HL_API *hl_ptr
    Value val;
    Locator loc;

    loc=param->p[0].loc;
    _Load(&loc,&val);

    if (!(_HandToPtr(val.ev_handle)))
      api_struc = &hl_struc;
    else
      api_struc=_HandToPtr(val.ev_handle);

#ifdef DOSFP
    _FreeHand(val.ev_handle);
#endif
    _RetInt(STATUS_OK,10);
  }

/****************************************************************************/
void far HL_Login(ParamBlk far *param)
/****************************************************************************/
  { // Paramter: Word ModAd,Word Access,char far * RefKey,char far * VerKey
    long  result;
    long  ModAd, Access;
    long  OldTimerID;
    int   OldRemote, OldPort;
    char  far *RefKey, far *VerKey;
    short i;

    OldRemote  = api_struc->Remote;
    OldTimerID = api_struc->Task_ID;
    OldPort    = api_struc->Port;

    ModAd=param->p[0].val.ev_long;
    Access=param->p[1].val.ev_long;
    api_struc->ModID            = EYE_DONGLE;
    api_struc->Module.Eye.ModAd = (unsigned short)ModAd;
    api_struc->Remote           = (unsigned short)Access;

    api_struc->Function = API_GET_TASKID;
    CALL_API(api_struc);

    api_struc->Port             = 0;
    api_struc->Timeout          = 0;

    RefKey=(char far *) _HandToPtr(param->p[2].val.ev_handle);
    VerKey=(char far *) _HandToPtr(param->p[3].val.ev_handle);
    for (i=0; i<8; i++)
      {
      api_struc->ID_Ref[i]    = RefKey[i];
      api_struc->ID_Verify[i] = VerKey[i];
      }

    api_struc->Function = API_INIT;
    result = CALL_API(api_struc);

    if (result == ALREADY_INIT)
      {
      api_struc->Remote  = OldRemote;
      api_struc->Task_ID = OldTimerID;
      api_struc->Port    = OldPort;
      }
     else
      {
      if ((result == INVALID_ENV) || (result == CANNOT_OPEN_DRIVER))
        {
        #ifndef DOSFP
        _FreeHand(param->p[2].val.ev_handle);
        _FreeHand(param->p[3].val.ev_handle);
        #endif
        _RetInt(result,10);
        }
      if (result)
        {
        if ((Access & NET_DEVICE) == NET_DEVICE)
          {
          api_struc->Function = API_LOGIN_INFO;
          if (CALL_API(api_struc) == HLS_FULL)
            result = TOO_MANY_USERS;
          }
        }
       else
        {
        if (api_struc->Remote == NET_DEVICE)
          {
          api_struc->Function = API_LOGIN;
          result             = CALL_API(api_struc);
          if (result)
            {
            api_struc->Function = API_DOWN;
            CALL_API(api_struc);
            }
          }
        }
      }
    #ifndef DOSFP
    _FreeHand(param->p[2].val.ev_handle);
    _FreeHand(param->p[3].val.ev_handle);
    #endif
    _RetInt(result,10);
  }

/****************************************************************************/
void far HL_LMLogin(ParamBlk far *param)
/****************************************************************************/
  { // Paramter: Word ModAd,Word Access,char far * RefKey,char far * VerKey, Word Slot_ID, char far * SearchStr
   long  ModAd, Access, Slot_ID;
   Word  result;
   Long  OldTimerID;
   Word  OldSlot_ID, OldBcnt, OldRemote, OldPort, OldResult;
   short i, j;
   char  far *RefKey, far *VerKey, far *SearchStr;
   Byte  SString[80];
   Word  sslen = 0;
   Word  blocks = 0;

   OldRemote  = api_struc->Remote;
   OldTimerID = api_struc->Task_ID;
   OldPort    = api_struc->Port;
   OldSlot_ID = api_struc->Slot_ID;
   OldBcnt    = api_struc->Bcnt;

   ModAd   = param->p[0].val.ev_long;
   Access  = param->p[1].val.ev_long;
   Slot_ID = param->p[4].val.ev_long;

   api_struc->ModID            = EYE_DONGLE;
   api_struc->Remote           = (unsigned short)Access;
   api_struc->Slot_ID          = (unsigned short)Slot_ID;
   api_struc->Module.Eye.ModAd = (unsigned short)ModAd;

   api_struc->Function = API_GET_TASKID;
   CALL_API(api_struc);

   api_struc->Protocol = 0;
   api_struc->Port     = 0;
   api_struc->Timeout  = 0;
   api_struc->PM_Host  = API_XTD_DETECT;

   /* -------------------------------------------- */
   /* We generated a verify key with TESTAPI.EXE : */
   /* -------------------------------------------- */
   RefKey=(char far *) _HandToPtr(param->p[2].val.ev_handle);
   VerKey=(char far *) _HandToPtr(param->p[3].val.ev_handle);
   for (i = 0; i < 8; i++)
     {
     api_struc->ID_Ref[i]    = RefKey[i];
     api_struc->ID_Verify[i] = VerKey[i];
     }

   /* --------------------------------- */
   /* Check and prepare search string : */
   /* --------------------------------- */
   SearchStr=(char far *) _HandToPtr(param->p[5].val.ev_handle);
   if (SearchStr != 0)
     {
     /* Get length of search string : */
     for (sslen = 0; SearchStr[sslen] != '\0'; sslen++);

     /* Add one for zero : */
     sslen++;

     /* count number of 8 bytes blocks we get : */
     blocks = sslen / 8;
     if ((sslen % 8) != 0)
       blocks++;
     if (blocks > 10)
       {
        #ifndef DOSFP
        _FreeHand(param->p[2].val.ev_handle);
        _FreeHand(param->p[3].val.ev_handle);
        _FreeHand(param->p[5].val.ev_handle);
        #endif
        _RetInt(INVALID_ENV,10);
       }

     /* Copy search string to stack : */
     for (i = 0; i < sslen; i++)
        SString[i] = SearchStr[i];

     /* Add spaces to fill up last block : */
     for (j = 0; j < (blocks * 8 - sslen); j++)
        SString[i + j] = 0x20;

     /* Now put it into api structure : */
     api_struc->Bcnt = blocks;
     api_struc->Data = SString;
     }

   /* --------------------------------------------- */
   /* Call the INIT (search for Hardlock) function :*/
   /* --------------------------------------------- */
   if (Slot_ID == 0)
     {
     api_struc->Function = API_INIT;
     result = CALL_API(api_struc);
     }
    else
     {
     api_struc->Function = API_LMINIT;
     result = CALL_API(api_struc);
     if (result == NOT_INIT)
       {
       #ifndef DOSFP
       _FreeHand(param->p[2].val.ev_handle);
       _FreeHand(param->p[3].val.ev_handle);
       _FreeHand(param->p[5].val.ev_handle);
       #endif
       _RetInt(VERSION_MISMATCH,10);
       }

     }

   if (result == ALREADY_INIT)
     {
     api_struc->Remote  = OldRemote;
     api_struc->Task_ID = OldTimerID;
     api_struc->Port    = OldPort;
     api_struc->Bcnt    = OldBcnt;
     api_struc->Slot_ID = OldSlot_ID;
     #ifndef DOSFP
     _FreeHand(param->p[2].val.ev_handle);
     _FreeHand(param->p[3].val.ev_handle);
     _FreeHand(param->p[5].val.ev_handle);
     #endif
     _RetInt(result,10);
     }

   /* ----------------------------- */
   /* No further checks necessary : */
   /* ----------------------------- */
   if ((result == INVALID_ENV) || (result == CANNOT_OPEN_DRIVER))
     {
     #ifndef DOSFP
     _FreeHand(param->p[2].val.ev_handle);
     _FreeHand(param->p[3].val.ev_handle);
     _FreeHand(param->p[5].val.ev_handle);
     #endif
     _RetInt(result,10);
     }

   /* ----------------------------- */
   /* Check, if HL-Server is full : */
   /* ----------------------------- */
   if (result != STATUS_OK)
     {
     if ((Access & NET_DEVICE) == NET_DEVICE)
       {
       if (Slot_ID == 0)
         {
         /* Check the old way... : */
         /* ---------------------- */
         api_struc->Function = API_LOGIN_INFO;
         if (CALL_API(api_struc) == HLS_FULL)
           result = TOO_MANY_USERS;
         }
        else
         {
         /* Check using LM functions... : */
         /* ----------------------------- */
         OldResult = result;
         api_struc->Function = API_LMPING;
         result = CALL_API(api_struc);

         if (result == HLS_FULL)
           {
           #ifndef DOSFP
           _FreeHand(param->p[2].val.ev_handle);
           _FreeHand(param->p[3].val.ev_handle);
           _FreeHand(param->p[5].val.ev_handle);
           #endif
           _RetInt(TOO_MANY_USERS,10);
           }

         if ((result == NO_LICENSE) || (OldResult == NO_LICENSE))
           {
           #ifndef DOSFP
           _FreeHand(param->p[2].val.ev_handle);
           _FreeHand(param->p[3].val.ev_handle);
           _FreeHand(param->p[5].val.ev_handle);
           #endif
           _RetInt(NO_LICENSE,10);
           }

         if (OldResult == INVALID_LIC)
           {
           #ifndef DOSFP
           _FreeHand(param->p[2].val.ev_handle);
           _FreeHand(param->p[3].val.ev_handle);
           _FreeHand(param->p[5].val.ev_handle);
           #endif
           _RetInt(OldResult,10);
           }

         if (result == NO_DONGLE)
           {
           #ifndef DOSFP
           _FreeHand(param->p[2].val.ev_handle);
           _FreeHand(param->p[3].val.ev_handle);
           _FreeHand(param->p[5].val.ev_handle);
           #endif
           _RetInt(OldResult,10);
           }

         #ifndef DOSFP
         _FreeHand(param->p[2].val.ev_handle);
         _FreeHand(param->p[3].val.ev_handle);
         _FreeHand(param->p[5].val.ev_handle);
         #endif
         _RetInt(result,10);
         }
       }
     #ifndef DOSFP
     _FreeHand(param->p[2].val.ev_handle);
     _FreeHand(param->p[3].val.ev_handle);
     _FreeHand(param->p[5].val.ev_handle);
     #endif
     _RetInt(result,10);
     }

   /* ------------------------------------------ */
   /* Login to HL-Server if Hardlock is remote : */
   /* ------------------------------------------ */
   if (api_struc->Remote == NET_DEVICE)
     {
     api_struc->Function = API_LOGIN;
     result = CALL_API(api_struc);
     if(result)
       {
       api_struc->Function = API_DOWN;
       CALL_API(api_struc);
       }
     }

   #ifndef DOSFP
   _FreeHand(param->p[2].val.ev_handle);
   _FreeHand(param->p[3].val.ev_handle);
   _FreeHand(param->p[5].val.ev_handle);
   #endif
   _RetInt(result,10);
   }


/****************************************************************************/
void far HL_Logout(void)
/****************************************************************************/
  { long result;

    if (api_struc->Remote == NET_DEVICE)
      {
      api_struc->Function = API_LOGOUT;
      CALL_API(api_struc);
      }

    api_struc->Function = API_DOWN;
    result             = CALL_API(api_struc);
    if (result)
      {
      api_struc->Function = API_FORCE_DOWN;
      result             = CALL_API(api_struc);
      }

    api_struc->Task_ID = 0;
    _RetInt(result,10);
  }

/****************************************************************************/
void far HL_Avail(void)
/****************************************************************************/
  { long result;

    api_struc->Function  = API_AVAIL;
    result              = CALL_API(api_struc);

    if ((result == NO_DONGLE) && (api_struc->ShortLife == 1))
       result = SELECT_DOWN;

    _RetInt(result,10);
  }

/****************************************************************************/
void far HL_Abort(void)
/****************************************************************************/
  { long result;

    api_struc->Function = API_LOGOUT;
    CALL_API(api_struc);
    api_struc->Function = API_ABORT;
    result             = CALL_API(api_struc);
    _RetInt(result,10);
  }

/****************************************************************************/
void far HL_Version(void)
/****************************************************************************/
  { long result;

    api_struc->Function = API_AVAIL;
    result             = CALL_API(api_struc);

    if (result) result=(-1);
    else result=(api_struc->API_Version_ID[1] * 100) + api_struc->API_Version_ID[0];
    _RetInt(result,10);
  }

/****************************************************************************/
void far HL_PortInf(void)
/****************************************************************************/
  { long result;

    if (api_struc->PortFlags & USB_DEVICE)
      {
      _RetInt(0,10);
      return;
      }

    api_struc->Function = API_AVAIL;
    result             = CALL_API(api_struc);

    if (result) result=(-1);
    else result=api_struc->Port;
    _RetInt(result,10);
  }

/****************************************************************************/
void far HL_AccInf(void)
/****************************************************************************/
  { long result;

    api_struc->Function = API_AVAIL;
    result             = CALL_API(api_struc);

    if (result) result=(-1);
    else result=api_struc->Remote;
    _RetInt(result,10);
  }

/****************************************************************************/
void far HL_UserInf(void)
/****************************************************************************/
  { long result;

    if (api_struc->Slot_ID == 0)
      api_struc->Function = API_INFO;
     else
      api_struc->Function = API_AVAIL;

    result = CALL_API(api_struc);

    if (result) result=(-1);
    else result=api_struc->NetUsers;
    _RetInt(result,10);
  }

/****************************************************************************/
void far HL_HLSVers(void)
/****************************************************************************/
  { long result;

    result = 0;

    if (api_struc->Remote == NET_DEVICE)
      {
      api_struc->Function  = API_AVAIL;
      result              = CALL_API(api_struc);
      if (result == STATUS_OK)
        result = api_struc->ShortLife;
       else
        result = 0;
      }
    _RetInt(result,10);
  }

/****************************************************************************/
void far HL_MaxUser(void)
/****************************************************************************/
  { long result;

    if (api_struc->Slot_ID == 0)
      api_struc->Function = API_INFO;
     else
      api_struc->Function = API_AVAIL;

    result = CALL_API(api_struc);

    if (result) result=(-1);
    else result=api_struc->MaxUsers;
    _RetInt(result,10);
  }

/****************************************************************************/
void far HL_Code(ParamBlk far *param)
/****************************************************************************/
  { // Paramter: far *Data, Word Cnt
    long result;
    char far *data;
    long Cnt;
    Value val;
    Locator loc;

    loc=param->p[0].loc;
    _Load(&loc,&val);
    data=_HandToPtr(val.ev_handle);
    Cnt=param->p[1].val.ev_long;

    api_struc->Data     = data;
    api_struc->Bcnt     = (unsigned short)Cnt;
    api_struc->Function = API_KEYE;
    result              = CALL_API(api_struc);
    api_struc->Bcnt     = 0;

    _Store(&loc,&val);
    _FreeHand(val.ev_handle);
    _RetInt(result,10);
  }

/****************************************************************************/
void far HL_MemInf(void)
/****************************************************************************/
  { long result;
    Word newvalue, oldvalue;
    Word TestMem = 0;
    Byte Memory[128];
    int i;

    // Read memory in one block :
    api_struc->Bcnt     = 16;
    api_struc->Data     = Memory;
    api_struc->Function = API_READ_BLOCK;
    CALL_API(api_struc);
    api_struc->Bcnt     = 0;
    if (api_struc->Status != STATUS_OK)
      {
      _RetInt(NO_ACCESS,10);
      return;
      }

    // Check, if every value is zero or one :
    for (i = 0; i < 128; i++)
      TestMem |= Memory[i];
    if (TestMem != 0)
      {
      for (i = 0; i < 128; i++)
        {
        if (Memory[i] != 0xff)
          {
          _RetInt(STATUS_OK,10);
          return;
          }
        }
      }

    // Save memory contents :
    api_struc->Module.Eye.Reg = 48;
    api_struc->Function       = API_READ;
    result                   = CALL_API(api_struc);
    if (result)
      { _RetInt(NO_ACCESS,10);
        return;
      }
    oldvalue                 = api_struc->Module.Eye.Value;

    // XOR of the read value to exclude random returns from interface :
    newvalue = oldvalue ^ 0x0d0e;

    // Write new memory value :
    api_struc->Module.Eye.Value = newvalue;
    api_struc->Function         = API_WRITE;
    result                     = CALL_API(api_struc);
    if (result)
      { api_struc->Module.Eye.Value = oldvalue;
        api_struc->Function         = API_WRITE;
        result                     = CALL_API(api_struc);
        _RetInt(NO_ACCESS,10);
        return;
      }

    // Read and compare memory :
    api_struc->Function = API_READ;
    result             = CALL_API(api_struc);
    if (result)
      { api_struc->Module.Eye.Value = oldvalue;
        api_struc->Function         = API_WRITE;
        result                     = CALL_API(api_struc);
        _RetInt(NO_ACCESS,10);
        return;
      }
    if (api_struc->Module.Eye.Value != newvalue)
      { api_struc->Module.Eye.Value = oldvalue;
        api_struc->Function         = API_WRITE;
        result                     = CALL_API(api_struc);
        _RetInt(NO_ACCESS,10);
        return;
      }

    // Write old memory :
    api_struc->Module.Eye.Value = oldvalue;
    api_struc->Function         = API_WRITE;
    result                     = CALL_API(api_struc);
    if (result)
      { api_struc->Module.Eye.Value = oldvalue;
        api_struc->Function         = API_WRITE;
        result                     = CALL_API(api_struc);
        _RetInt(NO_ACCESS,10);
        return;
      }

    _RetInt(STATUS_OK,10);
  }

/****************************************************************************/
void far HL_Read(ParamBlk far *param)
/****************************************************************************/
  { // Parameter: Word Reg, Word far *Value
    Word result;
    long Reg;
    Locator loc;
    Value val;

    Reg=param->p[0].val.ev_long;
    loc=param->p[1].loc;
    if (Reg>63)
        result=INVALID_PARAM;
    else
      { api_struc->Module.Eye.Reg = (unsigned short)Reg;
        api_struc->Function       = API_READ;
        result                   = CALL_API(api_struc);
        if (!result)
          { val.ev_type='I';
            val.ev_width=10;
            val.ev_long=api_struc->Module.Eye.Value;
            _Store(&loc,&val);
            result=STATUS_OK;
          }
      }

    _RetInt(result,10);
  }

/****************************************************************************/
void far HL_ReadID(ParamBlk far *param)
/****************************************************************************/
  { // Parameter: Word far *IDLow, Word far *IDHigh

    long result;
    Locator loclow, lochigh;
    Value val;

    loclow =param->p[0].loc;
    lochigh=param->p[1].loc;

    if (!(api_struc->PortFlags & USB_DEVICE))
      {
      _RetInt(NO_SERIALID,10);
      return;
      }

    api_struc->Module.Eye.Reg = 14;
    api_struc->Function       = API_READ_ID;

    result = CALL_API(api_struc);
    if (result)
      {
      _RetInt(result,10);
      return;
      }

    val.ev_type='I';
    val.ev_width=10;
    val.ev_long=api_struc->Module.Eye.Value;
    _Store(&loclow,&val);

    val.ev_type='I';
    val.ev_width=10;
    val.ev_long=api_struc->Module.Eye.Reg;
    _Store(&lochigh,&val);

    if ((api_struc->Module.Eye.Value == 0) && (api_struc->Module.Eye.Reg == 0))
      {
      _RetInt(NO_SERIALID,10);
      return;
      }

    result = STATUS_OK;
    _RetInt(result,10);
    return;
  }

/****************************************************************************/
void far HL_Write(ParamBlk far *param)
/****************************************************************************/
  { // Parameter: Word Reg, Word Value
    Word result;
    long Reg,RegVal;

    Reg=param->p[0].val.ev_long;
    RegVal=param->p[1].val.ev_long;
    if (Reg>=48 && Reg<=63)
      { api_struc->Module.Eye.Reg   = (unsigned short)Reg;
        api_struc->Module.Eye.Value = (unsigned short)RegVal;
        api_struc->Function         = API_WRITE;
        result                     = CALL_API(api_struc);
      }
    else result=INVALID_PARAM;
    _RetInt(result,10);
  }

/****************************************************************************/
void far HL_ReadBl(ParamBlk far *param)
/****************************************************************************/
  { // Parameter: char far * Eeprom
    Word result;
    char far *Eeprom;
    MHANDLE mh;
    Locator loc;
    Value val;

    loc=param->p[0].loc;
    if ((mh=_AllocHand(128))==0) _Error(182); // "Insufficient memory."
    Eeprom=(char far *) _HandToPtr(mh);
    api_struc->Bcnt     = 16;
    api_struc->Data     = Eeprom;
    api_struc->Function = API_READ_BLOCK;
    result             = CALL_API(api_struc);
    api_struc->Bcnt     = 0;
    if (!result)
      { val.ev_type='C';
        val.ev_length=128;
        val.ev_handle=mh;
        _Store(&loc,&val);
      }

    #ifndef DOSFP
    _FreeHand(mh);
    #endif
    _RetInt(result,10);
  }

/****************************************************************************/
void far HL_WriteBl(ParamBlk far *param)
/****************************************************************************/
  { // Parameter: char far * Eeprom
    Word result;
    char far *Eeprom;
    MHANDLE mh;

    mh=param->p[0].val.ev_handle;
    Eeprom=(char far *) _HandToPtr(mh);
    api_struc->Bcnt     = 4;
    api_struc->Data     = Eeprom;
    api_struc->Function = API_WRITE_BLOCK;
    result             = CALL_API(api_struc);
    api_struc->Bcnt     = 0;

    #ifndef DOSFP
    _FreeHand(mh);
    #endif
    _RetInt(result,10);
  }

/* ----------------------------------------------------------------- */
/* Module table                                                      */
/* ----------------------------------------------------------------- */

FoxInfo hlFoxInfo[] = {
  { "HL_LOGIN",   (FPFI) HL_Login,   4, "I,I,C,C" },
  { "HL_LOGOUT",  (FPFI) HL_Logout,  0, "" },
  { "HL_AVAIL",   (FPFI) HL_Avail,   0, "" },
  { "HL_ABORT",   (FPFI) HL_Abort,   0, "" },
  { "HL_VERSION", (FPFI) HL_Version, 0, "" },
  { "HL_PORTINF", (FPFI) HL_PortInf, 0, "" },
  { "HL_ACCINF",  (FPFI) HL_AccInf,  0, "" },
  { "HL_USERINF", (FPFI) HL_UserInf, 0, "" },
  { "HL_MAXUSER", (FPFI) HL_MaxUser, 0, "" },
  { "HL_CODE",    (FPFI) HL_Code,    2, "R,I" },
  { "HL_MEMINF",  (FPFI) HL_MemInf,  0, "" },
  { "HL_READ",    (FPFI) HL_Read,    2, "I,R" },
  { "HL_WRITE",   (FPFI) HL_Write,   2, "I,I" },
  { "HL_READBL",  (FPFI) HL_ReadBl,  1, "R" },
  { "HL_WRITEBL", (FPFI) HL_WriteBl, 1, "C" },
  { "HL_HLSVERS", (FPFI) HL_HLSVers, 0, "" },
  { "HL_SELECT",  (FPFI) HL_Select,  1, "R" },
  { "HL_LMLOGIN", (FPFI) HL_LMLogin, 6, "I,I,C,C,I,C" },
  { "HL_READID",  (FPFI) HL_ReadID,  2, "R,R" },
};

FoxTable _FoxTable = {
  (FoxTable FAR *)0, sizeof(hlFoxInfo)/sizeof(FoxInfo), hlFoxInfo
};
