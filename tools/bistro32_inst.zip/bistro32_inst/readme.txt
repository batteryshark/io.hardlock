Hardlock Bistro Version 2.5.2 (September 3, 2003)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

New Features
===========

Latteccino (2.5.1):
Supports new API functions (HL_SERVERADDR, HL_SERVERLICENSES)
For more information see the HL-API manual.
Revised language plugins for Latteccino: C#, Delphi, C/C++ 
New language plugin for VB


Cappuccino (2.5.2):
CaML scripting language introduced and supported in GUI.

HL Patcher (2.31):
Patcher utilizes new HL API. Therefore new latest driver is required.
Enhanced Debugger detection. 
Passive anti-debugging methods extended. 

Known Issues
===========
Win2003 Server is not supported as development platform 

Support for HL_ABORT is discontinued. This applies to both HL API and Latteccino.


Hardlock Bistro Version History
-------------------------------------------
Hardlock Bistro Version 2.50 
Improved error reporting for HLDB.INI.
Compiled with new version number.
Click on Aladdin logo always lead to German web site.
Some regions have �,� instead of �.� as floating number divider. This caused a crash in HLDB version check.
Uses HLPROG.DLL 2.03.

Hardlock Bistro Version 2.40
New graphics
Compiled with new version number.

Hardlock Bistro Version 2.30 
Compiled with new version number.

Hardlock Bistro Version 2.20 
Redesigned the Bistro entry screen (the old one was overloaded)
Bug fix: by default Bistro was installed in German. Now the
installation takes the language settings into consideration.
Bug fix: added RunTimeDir to the settings dialog.
Bug fix: the query for needed DB version was not handled
correctly (if installed version was higher than the needed
version).
Bug fix: wrong messages in the message boxes, if required DLL
version was not found.
Bug fix: DB fields of type "Date" had "01.01.1899" instead of NULL value.

Hardlock Bistro Version 2.10 
Common settings dialog which can be accessed from each Bistro2 application.
Implemented ADOX database access.
New customizable fields in Database
HLTOOLS.DLL no longer needed.
Extendable using language DLL�s.
Full English version.

Hardlock Bistro Version 2.00 
Added Hardlock RUS support. Added Gazzetta to Hardlock Bistro.

Hardlock Bistro Version 1.30  
Many bug fixes and enhancements. Please refer to the PDF file in your Bistro directory for details.

Hardlock Bistro Version 1.20 
Added support for Hardlock USB

Hardlock Bistro Version 1.10 
Added support for new encryption level (-sec:6).
Hardlock Bistro now needs the new version of Microsoft Common
Control DLL (comctrl32.dll). The DLL will be updated
automatically during installation of Hardlock Bistro. Since
this version you cannot run Bistro on Windows NT 3.51 anymore.

Hardlock Bistro Version 1.01 
Name change into Hardlock Bistro!
Corrected program windows size and default positions if used
with large fonts.
Complete support for English language (including help files!).
Software supports Spanish and Italian language (not including help files!).

Hardlock Bistro Version 1.00 

Initial public release.

Espresso:
========
Version 2.50
Deleting an item in the tree refreshes program/data list dialog now. And the data is shown correctly when displaying the view the first time.

Version 2.40 
Espresso can access red HL-Crypt module remotely when protecting W32 applications.
Bug fix: Encryption key can be shorter than 8 characters in GUI.
Bug fix: Background check interval 1..86400 instead of 1..60 sec.

Version 2.30 
Some GUI enhancements.
qslren option removed from the GUI.
Bug fix: handling for unknown file types enhanced.
Bug fix: switch �y was not transferred correctly to patcher engine.
Bug fix: some error numbers from Win32 engine are unknown to
Espresso GUI.
Bug fix: range checking for RUS options corrected.
Bug fix: more than 8 file masks for data protection not allowed.

Version 2.20 
Small GUI enhancements & bug fixes
 Win16 �self loading� applications could not be protected with
Espresso.
Bug fix: temporary HL$ file was not deleted after protection.
Bug fix: now the used HL-Crypt versions can be displayed in from
the about box. (F2 = HL-Crypt for Win32, F3 = HL-Crypt for Win16,
F4 = HL-Crypt for DOS)

Version 2.10 
Complete rewrite of Espresso, adapted the Bistro2 look & feel.
Added file type associations (es2)

Version 2.00 
Added Hardlock RUS support. Old projects are not compatible!

Version 1.30 
Many bug fixes and enhancements. Please refer to the PDF file in
your Bistro directory for details.

Version 1.20 
Bug fix: Espresso was crashing when opening a old project that
uses date settings.
Bug fix: Problem with protecting executable in root dir.
Bug fix: corrected some spelling errors.

Version 1.10 
Bug fix: There was a program crash when changing the expiration
date in Espresso manually.
Bug fix: The last parameter in the extended option menu was ignored.
Bug fix: Display of sublicensing slots corrected.
The default timeout for HL-Server is now set to 12 minutes.

Version 1.01 
Checks if the HL-crypt Hardlock (red) is not connected to
the CP-Card, if the program tries to encode a new Hardlock.
Users can no longer destroy their HL-Crypt Hardlocks.
When the wizard has finished a new dialog box is displayed
and you can directly test (launch) your protected application.
If source- and destination file name (with path) are the same,
the destination file name automatically gets an 'c' at the
beginning e.g.: test01.txt -> ctext01.txt
'Date Picker Control' for better expiration date input in
'Hardlock Options'.
Double click and ALT-key shows advanced command line edit
control on item properties.
The setting with the scroll bar for the background checks
was vice versa. Now the value will be generated correctly.
Bug fix: Protecting a 32bit EXE under Win NT does not generate
a 'File protected....' entry in the LOG file/window (Problem
does not exist under Win95!).
Bug fix: GPF when closing print preview window with close
button (only if preview windows is maximized).
Bug fix: Drive selection and displayed icons are not correct if you
have 'no support for shell interface' and German version installed.

Version 1.00 
Initial public release

Latteccino
=========
Version 2.50 
Divider position cannot be corrupted anymore.
Missing help topic for settings dialog is found now.

Version 2.40
Minor bug fixes.

Version 2.30  
Minor bug fixes.

Version 2.20 
Added new API functions to the GUI (HLM_LOGIN, HL_ERRMSG,
HLM_CHECKALLSLOTS).
Bug fix: wrong description in the online help file for HL_CODE()
Bug fix: some typing errors in the source generation fixed.
Bug fix: fixed a problem in the source code generation of RUS
functions.

Version 2.10 
Added source code generation.

Version 2.00  
Added Hardlock RUS support. Complete rewrite of application.

Version 1.30 
Many bug fixes and enhancements. Please refer to the PDF file in
your Bistro directory for details.

Version 1.20 
Implemented HL_READID function.

Version 1.10 
Internal changes.

Version 1.01  
HL_LOGIN() OK then HL_LOGOUT() now returns correct value
STATUS_OK.

Version 1.00 -
Initial public release

Cappuccino:
==========

Version 2.5.2
Bug fix: Enhanced fault tolerance of database.

Version 2.50
Doesn�t crash anymore when entering settings/CPC dialog and PCI CPC specified in Bistro.ini does not exist (Win9.x only).
Error message �CPC cannot be found� is not displayed multiple times now.
Startup error message �CPC cannot be found� is not displayed when �Encode on USB� is selected.
No error occurred when trying to burn a Hardlock Server USB.
Doesn�t crash when no driver is installed.
Crash in Vendor Key Manager fixed.

Version 2.40 
Support for Crypto-Programmer Card PCI.
Option for writing date to Hardlock during encoding added.
Bug fix: correct new slot number when first slot is not equal 1
Bug fix: Updating stock item via email doesn't use %c1 - %c3 contents anymore

Version 2.30  
Bug fix: some controls have not been resized correctly.
Bug fix: loading info from Hardlock or CTV does not use mechanism
for converted Vendor Key.
Bug fix: database update failed on MDAC 2.6.
Bug fix: EPP DLL could not find include files.
Bug fix: Problem with context menu �Update all customers�.
Bug fix: sending update using email failed with a crash.

Version 2.20 
New features include memory content generation through DLL interface, a
box for notes, new grids for slot editing and other GUI
enhancements.
Bug fix: when changing the number of licenses for a slot in the
order list and saving the resulting order list (before burning or
changing dialog-focus) the changes are lost when loading the
order-list again
Bug fix: when entering A:\ as ALF file directory, the application
was crashing.
Bug fix: relation in CA2 file and DB got lost.
Bug fix: the combo box for vendor keys was not update correctly
after creation of new key.
Bug fix: After coding Hardlock with more than 5 slots the scroll-
bar in the license information does not work

Version 2.10 
Added SMTP support
Added file type associations (ctv, ca2)
Variable parser for default strings
Improved handling of warnings and errors

Version 2.00 
Added Hardlock RUS support. Old projects are not compatible!
Complete rewrite of application.

Version 1.30  
Many bug fixes and enhancements. Please refer to the PDF file in
your Bistro directory for details.

Version 1.20 
Added crypto programming support for Hardlock USB.

Version 1.10 
Internal changes.

Version 1.01  
Auto detection of port address used by CP-Card.
Startup warning if CP-Card is NOT connected to the actual
system.
The EEP file name is added into LOG file if EEP file was used
for encoding a new Hardlock.

Version 1.00 
Initial public release

Gazzetta:
=======

Version 2.50 
No changes

Version 2.40 
Bug fix: Closing filter manager after adding an unnamed filter
doesn�t cause a crash.
Bug fix: Slots are always shown in correct order when HLDB.MDB is in Access97 format

Version 2.30 
Bug fix: database update failed on MDAC 2.6.
 Bug fix: sometimes a wrong filter was applied from menu.

Version 2.20
Small GUI enhancements & bug fixes.
Now up to twenty user defined filters are supported (10 before).
Bug fix: Setting filters with Slot expiry dates in the past also
showed up local Hardlocks (they don�t have a slot expiration date)
Bug fix: Right mouse-Paste in Compare Value of Filter grid did not
enable save button.
Bug fix: In Hardlock properties, the �Show memory� button was
always enabled (even on keys without memory). Pressing the button
leaded to a crash.
Bug fix: choosing Excel export format will now disable �overwrite
existing tables� checkbox. It is not support by OLE DB provider.
Bug fix: fixed a crash when changing customer data which is
currently the sorting criteria.

Version 2.10 
Release of full English version - Added customizable reserved fields - Enhanced filter capabilities.

Version 2.00 
Initial Release. Gazzetta is the interface for the Hardlock
customer & license database.
